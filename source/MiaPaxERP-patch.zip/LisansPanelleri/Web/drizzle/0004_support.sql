CREATE TABLE support_devices(license_id TEXT NOT NULL REFERENCES licenses(id),device_id TEXT NOT NULL,role TEXT NOT NULL,device_name TEXT NOT NULL,os TEXT NOT NULL DEFAULT '',cpu TEXT NOT NULL DEFAULT '',ram_gb REAL,disk_total_gb REAL,disk_free_gb REAL,app_version TEXT NOT NULL DEFAULT '',last_seen TEXT NOT NULL,PRIMARY KEY(license_id,device_id));
--> statement-breakpoint
CREATE TABLE support_issues(id TEXT PRIMARY KEY,license_id TEXT NOT NULL REFERENCES licenses(id),device_id TEXT NOT NULL,module TEXT NOT NULL,code TEXT NOT NULL,summary TEXT NOT NULL,occurrences INTEGER NOT NULL DEFAULT 1,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open');
--> statement-breakpoint
CREATE INDEX support_issue_license ON support_issues(license_id,status,last_seen);
--> statement-breakpoint
CREATE TABLE support_events(license_id TEXT NOT NULL REFERENCES licenses(id),event_id TEXT NOT NULL,received_at TEXT NOT NULL,PRIMARY KEY(license_id,event_id));
