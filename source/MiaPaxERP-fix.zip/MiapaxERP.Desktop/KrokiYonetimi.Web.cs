using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Web.WebView2.Wpf;
using Microsoft.Web.WebView2.Core;

namespace MiapaxERP.Desktop;
public partial class KrokiYonetimi
{
    private WebView2? web;
    private WebView2? aiWeb;
    private CoreWebView2Environment? krokiOrtami;
    private bool webBasladi;
    private void GelismisKrokiyiBagla()
    {
        var eski=Content;Content=null;
        var sekmeler=new System.Windows.Controls.TabControl();var gelismis=new TabItem{Header="Otomatik plan • Harita • 3D"};
        var aiProje=new TabItem{Header="🤖 Yapay zekâ proje sihirbazı"};sekmeler.Items.Add(gelismis);sekmeler.Items.Add(new TabItem{Header="Basit elle çizim",Content=eski});sekmeler.Items.Add(aiProje);Content=sekmeler;
        sekmeler.SelectionChanged+=async (_,e)=>{if(e.Source==sekmeler&&sekmeler.SelectedItem==aiProje)await AiProjeAc(aiProje);};
        web=new WebView2();gelismis.Content=web;
        Loaded+=async (_,_)=>{
            if(webBasladi)return;webBasladi=true;
            try{
                var profile=krokiProfil??Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","KrokiTarayici");
                var env=krokiOrtami=await CoreWebView2Environment.CreateAsync(null,profile);
                await web.EnsureCoreWebView2Async(env);
                web.CoreWebView2.SetVirtualHostNameToFolderMapping("kroki.boruerp.local",Path.Combine(AppContext.BaseDirectory,"Assets","KrokiWeb"),CoreWebView2HostResourceAccessKind.DenyCors);
                web.CoreWebView2.Settings.AreDevToolsEnabled=false;
                web.CoreWebView2.NavigationStarting+=(_,e)=>{if(!Yerel(e.Uri))e.Cancel=true;};
                web.CoreWebView2.NewWindowRequested+=(_,e)=>{e.Handled=true;};
                web.CoreWebView2.WebMessageReceived+=async (_,e)=>await MesajIsle(web!,e);
                web.Source=new Uri("https://kroki.boruerp.local/index.html?v="+typeof(KrokiYonetimi).Assembly.GetName().Version+"&kroki=next1");
                if(Window.GetWindow(this) is Window owner)owner.Closed+=(_,_)=>web.Dispose();
            }catch(Exception ex){gelismis.Content=new TextBlock{Text="Gelişmiş kroki açılamadı. Microsoft Edge WebView2 Runtime kurulu olmalı. Basit elle çizim sekmesini kullanabilirsiniz.\n"+ex.Message,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(24)};}
        };
    }
    private async Task MesajIsle(WebView2 w,CoreWebView2WebMessageReceivedEventArgs e)
    {
                if(!Yerel(e.Source))return;
                try{
                    using var msg=JsonDocument.Parse(e.WebMessageAsJson);var root=msg.RootElement;
                    switch(root.GetProperty("action").GetString()){
                        case "stockSearch":
                            try{KrokiYetkiKontrol();var rows=await Task.Run(()=>new KrokiTeklifServisi(ServisBaglantisi!,ServisKullanici).StokAra(root.GetProperty("search").GetString()??""));w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="stockResult",rows}));}
                            catch(Exception ex){w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="stockResult",error=ex.Message}));}break;
                        case "designSettings":KrokiAsistanAyarlari();break;
                        case "designAsk":await KrokiAsistanSor(w,root);break;
                        case "projectAsk":await KrokiProjeSor(w,root);break;
                        case "map":MessageBox.Show("Harici tarayıcı yerine program içindeki haritayı kullanın.","Kroki");break;
                        case "googleSettings":KrokiHaritaAyarlari.Ayarlar(Window.GetWindow(this));goto case "googleRead";
                        case "googleRead":w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="googleSettings",key=KrokiHaritaAyarlari.Oku()}));break;
                        case "parcelSettings":ParselServisi.Ayarlar(Window.GetWindow(this));break;
                        case "parcelQuery":
                            try{var geometry=await ParselServisi.Sorgula(root.GetProperty("fields"));w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="parcelResult",geometry}));}
                            catch(Exception ex){w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="parcelResult",error=ex.Message}));}break;
                        case "ready":
                            string logo=Tema170.Mevcut.Logo;
                            if(File.Exists(logo) && !GorunumDeposu.EskiUygulamaLogosu(logo)){var image=GorunumDeposu.Resim(logo);var png=new System.Windows.Media.Imaging.PngBitmapEncoder();png.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(image));using var stream=new MemoryStream();png.Save(stream);w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="logo",url="data:image/png;base64,"+Convert.ToBase64String(stream.ToArray())}));}
                            break;
                        case "pdf":
                            var save=new SaveFileDialog{Filter="PDF belgesi|*.pdf",FileName=root.TryGetProperty("file",out var fn)&&fn.ValueKind==JsonValueKind.String&&fn.GetString() is { Length:>0 and <=80 } ad&&ad.IndexOfAny(Path.GetInvalidFileNameChars())<0?ad:"MiapaxERP-Sulama-Plani.pdf"};
                            if(save.ShowDialog(Window.GetWindow(this))==true){var settings=w.CoreWebView2.Environment.CreatePrintSettings();settings.PageWidth=8.2677;settings.PageHeight=11.6929;settings.MarginTop=.47;settings.MarginBottom=.47;settings.MarginLeft=.47;settings.MarginRight=.47;settings.ShouldPrintBackgrounds=true;settings.ShouldPrintHeaderAndFooter=false;if(!await w.CoreWebView2.PrintToPdfAsync(save.FileName,settings))throw new IOException("PDF oluşturulamadı.");}
                            await w.ExecuteScriptAsync("document.body.classList.remove('fp-printing')");break;
                    }
                }catch(Exception ex){DestekIzleme.Bildir(ex,"KrokiYonetimi.Web");MessageBox.Show(Window.GetWindow(this),ex.Message,"Kroki işlemi tamamlanamadı");await w.ExecuteScriptAsync("document.body.classList.remove('fp-printing')");}
    }
    /// <summary>Yapay zekâ proje sihirbazı: ölçü, boru, sulama türü, aksesuar ve su kaynağından otomatik hesap, 3D görünüm ve PDF.</summary>
    private async Task AiProjeAc(TabItem tab)
    {
        if(aiWeb is not null)return;
        try{
            KrokiYetkiKontrol();
            if(krokiOrtami is null)throw new InvalidOperationException("Kroki tarayıcısı henüz hazır değil; birkaç saniye sonra tekrar deneyin.");
            aiWeb=new WebView2();tab.Content=aiWeb;
            await aiWeb.EnsureCoreWebView2Async(krokiOrtami);
            aiWeb.CoreWebView2.SetVirtualHostNameToFolderMapping("kroki.boruerp.local",Path.Combine(AppContext.BaseDirectory,"Assets","KrokiWeb"),CoreWebView2HostResourceAccessKind.DenyCors);
            aiWeb.CoreWebView2.Settings.AreDevToolsEnabled=false;
            aiWeb.CoreWebView2.NavigationStarting+=(_,e)=>{if(!Yerel(e.Uri))e.Cancel=true;};
            aiWeb.CoreWebView2.NewWindowRequested+=(_,e)=>{e.Handled=true;};
            var hedef=aiWeb;hedef.CoreWebView2.WebMessageReceived+=async (_,e)=>await MesajIsle(hedef,e);
            aiWeb.Source=new Uri("https://kroki.boruerp.local/ai-proje.html?v="+typeof(KrokiYonetimi).Assembly.GetName().Version);
            if(Window.GetWindow(this) is Window owner)owner.Closed+=(_,_)=>hedef.Dispose();
        }catch(Exception ex){aiWeb?.Dispose();aiWeb=null;DestekIzleme.Bildir(ex,"KrokiYonetimi.AiProje");tab.Content=new TextBlock{Text="Yapay zekâ proje sihirbazı açılamadı: "+ex.Message+"\nSekmeyi yeniden seçerek tekrar deneyebilirsiniz.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(24)};}
    }
    private static bool Yerel(string value)=>Uri.TryCreate(value,UriKind.Absolute,out var uri)&&uri.Scheme=="https"&&uri.Host=="kroki.boruerp.local";
    private static void HaritaAc(string value)
    {
        if(!Uri.TryCreate(value,UriKind.Absolute,out var uri)||uri.Scheme!="https"||!new[]{"parselsorgu.tkgm.gov.tr","www.google.com","earth.google.com","www.openstreetmap.org","openstreetmap.org"}.Contains(uri.Host))return;
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(uri.AbsoluteUri){UseShellExecute=true});
    }
}


