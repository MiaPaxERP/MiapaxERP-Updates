using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed record MaliyetKalemi(string Tur,string Kaynak,decimal Miktar,string Birim,decimal? BirimFiyat,string Aciklama,bool Dahil=true){public decimal? Tutar=>Dahil&&BirimFiyat.HasValue?decimal.Round(Miktar*BirimFiyat.Value,4):null;}
public sealed record MaliyetCalismasi(long? Id,int Emir,string No,string Urun,string Birim,decimal Saglam,decimal Fire,MaliyetKalemi[] Kalemler,string Not,byte[]? Surum){public string[] Eksikler=>Kalemler.Where(x=>x.Dahil&&!x.BirimFiyat.HasValue).Select(x=>x.Tur+": "+x.Kaynak).ToArray();public decimal BilinenToplam=>Kalemler.Where(x=>x.Dahil).Sum(x=>x.Tutar??0);public decimal? BirimMaliyet=>Saglam>0&&Eksikler.Length==0?decimal.Round(BilinenToplam/Saglam,6):null;}
public sealed class DetayliMaliyetServisi(string connection,int user)
{
 readonly ErpModulServisi access=new(connection,user);
 readonly Action<SqlConnection,SqlTransaction?,string>? fixtureCheck;
 internal DetayliMaliyetServisi(string connection,int user,Action<SqlConnection,SqlTransaction?,string> check):this(connection,user){fixtureCheck=check;}
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps)=>ErpModulServisi.Komut(c,t,sql,ps);
 void Check(SqlConnection c,string code){if(fixtureCheck is not null)fixtureCheck(c,null,code);else access.Yetki(c,null,code);}
 static DataTable Table(SqlCommand q){using(q)using(var r=q.ExecuteReader()){var dt=new DataTable();dt.Load(r);return dt;}}
 public DataTable Emirler(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<DataTable>(connection,"DetayliMaliyetServisi.Emirler","",[]);
  using var c=access.Ac();Check(c,"COST.VIEW");return Table(Q(c,null,"SELECT u.Id,u.UretimEmriNo+N' · '+s.StokAdi+N' · '+u.Durum Ad FROM dbo.UretimEmirleri u JOIN dbo.StokKartlari s ON s.Id=u.MamulStokId ORDER BY u.Id DESC"));
 }
 public MaliyetCalismasi Analiz(int order,bool saved=true){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<MaliyetCalismasi>(connection,"DetayliMaliyetServisi.Analiz","",[order,saved]);
  using var c=access.Ac();Check(c,"COST.VIEW");return Build(c,order,saved);
 }
 static MaliyetCalismasi Build(SqlConnection c,int order,bool saved){
  if(saved){using var q=Q(c,null,"SELECT TOP(1) Id,Veri,Surum FROM dbo.MPXNext_Maliyet WHERE Emir=@o ORDER BY Id DESC",("@o",order));using var r=q.ExecuteReader();if(r.Read()){var value=JsonSerializer.Deserialize<MaliyetCalismasi>(r.GetString(1),HttpsJson.Ayarlar)??throw new InvalidOperationException("Maliyet kaydı okunamadı.");return value with{Id=r.GetInt64(0),Surum=(byte[])r[2]};}}
  var orders=Table(Q(c,null,"SELECT u.UretimEmriNo,s.StokAdi,u.MiktarBirimi,u.UretilenMiktar,u.FireMiktari,u.Durum FROM dbo.UretimEmirleri u JOIN dbo.StokKartlari s ON s.Id=u.MamulStokId WHERE u.Id=@o",("@o",order)));if(orders.Rows.Count!=1)throw new ArgumentException("Üretim emri bulunamadı.");var o=orders.Rows[0];var rows=new List<MaliyetKalemi>();
  var raw=Table(Q(c,null,"SELECT s.StokKodu,s.StokAdi,s.Birim,l.Kod,b.Miktar,l.BirimMaliyet,s.Id AS StokId FROM dbo.MPX310_Lot urun JOIN dbo.MPX310_LotBag b ON b.UrunLot=urun.Id JOIN dbo.MPX310_Lot l ON l.Id=b.KaynakLot JOIN dbo.StokKartlari s ON s.Id=l.StokId WHERE urun.Kaynak='Uretim' AND urun.KaynakId=@o",("@o",order)));
  foreach(DataRow r in raw.Rows){
   decimal? fiyat=r.IsNull("BirimMaliyet")?null:Convert.ToDecimal(r["BirimMaliyet"]);string not="Fiilî parti tüketimi ve alış maliyeti. Fire tüketimi zaten bu tutardadır; tekrar eklenmez.";
   if(fiyat is null){var (f,k)=MaliyetFiyatlari.BirimFiyat(c,null,Convert.ToInt32(r["StokId"]));fiyat=f;not=f is null?"Partinin alış maliyeti yok; stok kartına alış fiyatı girin.":"Parti maliyeti olmadığı için "+k.ToLowerInvariant()+" kullanıldı.";}
   rows.Add(new("Hammadde",r["StokKodu"]+" · "+r["StokAdi"]+" · Parti "+r["Kod"],Convert.ToDecimal(r["Miktar"]),Convert.ToString(r["Birim"])!,fiyat,not));
  }
  if(raw.Rows.Count==0){
   // Fiilî parti tüketimi yoksa (emir henüz tamamlanmadı veya parti takibi kullanılmıyor) reçeteye göre tahmini tüketim fiyatlanır.
   var est=Table(Q(c,null,"SELECT s.Id,s.StokKodu,s.StokAdi,s.Birim,k.Oran,e.HedefAgirlikKg,e.PlanlananMiktar,e.UretilenMiktar,e.FireMiktari FROM dbo.UretimEmirleri e CROSS APPLY(SELECT a.HammaddeStokId,a.YuzdeOrani Oran FROM dbo.UretimEmriReceteAnlikKalemleri a WHERE a.UretimEmriId=e.Id UNION ALL SELECT rk.HammaddeStokId,rk.YuzdeOrani FROM dbo.UretimReceteKalemleri rk WHERE rk.ReceteId=e.ReceteId AND NOT EXISTS(SELECT 1 FROM dbo.UretimEmriReceteAnlikKalemleri a2 WHERE a2.UretimEmriId=e.Id)) k JOIN dbo.StokKartlari s ON s.Id=k.HammaddeStokId WHERE e.Id=@o",("@o",order)));
   foreach(DataRow r in est.Rows){
    decimal hedef=r.IsNull("HedefAgirlikKg")?0:Convert.ToDecimal(r["HedefAgirlikKg"]),plan=r.IsNull("PlanlananMiktar")?0:Convert.ToDecimal(r["PlanlananMiktar"]),gercek=Convert.ToDecimal(r["UretilenMiktar"])+Convert.ToDecimal(r["FireMiktari"]);
    decimal kg=plan>0&&gercek>0?hedef*gercek/plan:hedef;decimal miktar=decimal.Round(kg*Convert.ToDecimal(r["Oran"])/100,3);
    var (f,k)=MaliyetFiyatlari.BirimFiyat(c,null,Convert.ToInt32(r["Id"]));
    rows.Add(new("Hammadde (reçete tahmini)",r["StokKodu"]+" · "+r["StokAdi"],miktar,Convert.ToString(r["Birim"])!,f,(gercek>0?"Gerçekleşen üretim":"Planlanan miktar")+" × reçete oranı. Fiyat: "+(f is null?"stok kartında alış fiyatı yok":k)+". Emir tamamlanınca fiilî tüketimle değişir."));
   }
   if(est.Rows.Count==0)rows.Add(new("Hammadde","Fiilî tüketim ve reçete yok",1,"toplam",null,"Emre reçete bağlayın veya üretimi stok işleyin."));
  }
  var logs=Table(Q(c,null,"SELECT TOP(1) Veri FROM dbo.MPX310_Kayit WHERE Tur='UretimMaliyet' AND TRY_CONVERT(int,JSON_VALUE(Veri,'$.girdi.uretimEmri'))=@o ORDER BY Id DESC",("@o",order)));
  if(logs.Rows.Count>0){using var doc=JsonDocument.Parse((string)logs.Rows[0][0]);var root=doc.RootElement;var m=root.GetProperty("makine");decimal hours=root.GetProperty("girdi").GetProperty("calismaDakika").GetDecimal()/60;string name=m.GetProperty("ad").GetString()??"Makine";foreach(var (kind,property) in new[]{("Makine / amortisman","saatMaliyeti"),("İşçilik","iscilikSaatMaliyeti"),("Elektrik","enerjiSaatMaliyeti")})rows.Add(new(kind,name,hours,"saat",m.GetProperty(property).GetDecimal(),"Kesinleşmiş fiilî maliyet kaydındaki çalışma süresi ve saat ücreti."));decimal other=root.GetProperty("girdi").GetProperty("digerGider").GetDecimal();if(other>0)rows.Add(new("Diğer gider",name,1,"toplam",other,"Kesinleşmiş maliyetin diğer gideri. Sevkiyat/genel gider ayrıca eklenirken aynı tutarı tekrar saymayın."));}
  else{foreach(string kind in new[]{"Makine / amortisman","İşçilik","Elektrik"})rows.Add(new(kind,"Süre / sayaç / ücret girilmedi",1,"saat",null,"Fiilî süreyi ve saat ücretini girin. Elektrik için birimi kWh, miktarı sayaç tüketimi ve fiyatı kWh tarifesi olarak değiştirebilirsiniz."));}
  var shipments=Table(Q(c,null,"SELECT DISTINCT k.Id,JSON_VALUE(k.Veri,'$.no') No FROM dbo.MPX310_Kayit k WHERE k.Tur='Sevkiyat' AND k.Durum<>N'İptal' AND TRY_CONVERT(bigint,JSON_VALUE(k.Veri,'$.satis')) IN(SELECT sl.BelgeId FROM dbo.MPX310_SatisLot sl JOIN dbo.MPX310_Lot l ON l.Id=sl.LotId WHERE l.Kaynak='Uretim' AND l.KaynakId=@o)",("@o",order)));
  rows.Add(new("Sevkiyat",shipments.Rows.Count>0?string.Join(", ",shipments.AsEnumerable().Select(x=>x["No"]+" (#"+x["Id"]+")")):"Bu partiye bağlı sevkiyat kaydı yok",1,"pay",null,"Yalnız bu ürüne düşen navlun / taşıma payını girin. Sevkiyat yoksa Dahil seçimini kaldırın; şirketin tüm giderleri otomatik yüklenmez."));
  rows.Add(new("Genel gider / muhasebe payı","Muhasebe gider dayanağı",1,"pay",null,"Kira, bakım, sigorta ve diğer giderlerden bu üretime ayrılan pay. Belge / fiş numarasını açıklamaya yazın; kapsam dışıysa Dahil seçimini kaldırın."));
  return new(null,order,(string)o[0],(string)o[1],(string)o[2],Convert.ToDecimal(o[3]),Convert.ToDecimal(o[4]),rows.ToArray(),"Durum: "+o[5]+". Bu çalışma analizdir; muhasebe veya stok maliyetini kendiliğinden değiştirmez. Fire hammadde tüketimine dahildir.",null);
 }
 public static void Dogrula(MaliyetCalismasi g){if(g is null||g.Kalemler is null||g.Kalemler.Length is <1 or >500||g.Saglam<0||g.Fire<0||g.Saglam>1000000000||g.Not?.Length>2000||g.Kalemler.Any(x=>x is null||string.IsNullOrWhiteSpace(x.Tur)||x.Tur.Length>100||x.Kaynak?.Length>300||x.Birim?.Length>20||x.Aciklama?.Length>1000||x.Miktar<0||x.Miktar>1000000000||x.BirimFiyat<0||x.BirimFiyat>1000000000))throw new ArgumentException("Maliyet çalışma tablosundaki miktar ve tutarları kontrol edin.");}
 public long Kaydet(MaliyetCalismasi g){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<long>(connection,"DetayliMaliyetServisi.Kaydet","",[g]);
  Dogrula(g);using var c=access.Ac();Check(c,"COST.EDIT");using var t=c.BeginTransaction(IsolationLevel.Serializable);using(var exists=Q(c,t,"SELECT COUNT(*) FROM dbo.UretimEmirleri WITH(HOLDLOCK) WHERE Id=@o",("@o",g.Emir)))if(Convert.ToInt32(exists.ExecuteScalar())!=1)throw new ArgumentException("Üretim emri bulunamadı.");
  using(var factual=Q(c,t,"SELECT UretilenMiktar,FireMiktari FROM dbo.UretimEmirleri WHERE Id=@o",("@o",g.Emir))){using var facts=factual.ExecuteReader();facts.Read();if(g.Saglam!=Convert.ToDecimal(facts[0])||g.Fire!=Convert.ToDecimal(facts[1]))throw new InvalidOperationException("Üretim miktarı değişmiş. Tabloyu yeniden okuyun.");}
  var json=JsonSerializer.Serialize(g with{Id=null,Surum=null},HttpsJson.Ayarlar);long id;if(g.Id.HasValue){using var q=Q(c,t,"UPDATE dbo.MPXNext_Maliyet SET Veri=@v,Olusturan=@u,Tarih=SYSUTCDATETIME() OUTPUT INSERTED.Id WHERE Id=@i AND Emir=@o AND Surum=@s",("@v",json),("@u",user),("@i",g.Id),("@o",g.Emir),("@s",g.Surum));var result=q.ExecuteScalar();if(result is null)throw new InvalidOperationException("Tablo başka kullanıcı tarafından değiştirildi. Yeniden okuyun.");id=Convert.ToInt64(result);}else{using var q=Q(c,t,"INSERT dbo.MPXNext_Maliyet(Emir,Veri,Olusturan) OUTPUT INSERTED.Id VALUES(@o,@v,@u)",("@o",g.Emir),("@v",json),("@u",user));id=Convert.ToInt64(q.ExecuteScalar());}using(var audit=Q(c,t,"INSERT dbo.MPXNext_MaliyetRevizyon(Kayit,Veri,Kullanici) VALUES(@i,@v,@u)",("@i",id),("@v",json),("@u",user)))audit.ExecuteNonQuery();t.Commit();return id;
 }
 public DataTable GiderDayanaklari(DateTime start,DateTime end){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<DataTable>(connection,"DetayliMaliyetServisi.GiderDayanaklari","",[start,end]);
  if(end<start||end-start>TimeSpan.FromDays(366))throw new ArgumentException("En fazla bir yıllık dönem seçin.");using var c=access.Ac();Check(c,"COST.VIEW");Check(c,"FINANCE.VIEW");return Table(Q(c,null,"SELECT f.Id,f.Tarih,f.HareketTipi,f.Tutar,h.ParaBirimi,f.Aciklama FROM dbo.FinansHareketleri f JOIN dbo.FinansHesaplari h ON h.Id=f.HesapId WHERE f.Tarih>=@a AND f.Tarih<@b AND f.HareketTipi=N'Çıkış' ORDER BY f.Tarih DESC,f.Id DESC",("@a",start.Date),("@b",end.Date.AddDays(1))));
 }
 public int Gunluk(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<int>(connection,"DetayliMaliyetServisi.Gunluk","",[]);
  using var c=access.Ac();Check(c,"COST.PUBLISH");Check(c,"COST.VIEW");var date=DateTime.Today;using(var check=Q(c,null,"SELECT COUNT(*) FROM dbo.MPXNext_Gunluk WHERE Tarih=@d",("@d",date)))if(Convert.ToInt32(check.ExecuteScalar())>0)return 0;
  var orders=Table(Q(c,null,"SELECT Id FROM (SELECT Id,ROW_NUMBER() OVER(PARTITION BY MamulStokId ORDER BY Id DESC) n FROM dbo.UretimEmirleri WHERE Durum=N'Tamamlandı') x WHERE n=1 ORDER BY Id"));var reports=new List<MaliyetCalismasi>();foreach(DataRow r in orders.Rows)reports.Add(Build(c,(int)r[0],true));
  using var t=c.BeginTransaction(IsolationLevel.Serializable);using(var gate=Q(c,t,"SELECT COUNT(*) FROM dbo.MPXNext_Gunluk WITH(UPDLOCK,HOLDLOCK) WHERE Tarih=@d",("@d",date)))if(Convert.ToInt32(gate.ExecuteScalar())>0)return 0;
  var recipients=Table(Q(c,t,"SELECT k.Id FROM dbo.Kullanicilar k WHERE k.Aktif=1 AND (EXISTS(SELECT 1 FROM dbo.KullaniciRolAtamalari a JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId WHERE a.KullaniciId=k.Id AND r.Aktif=1 AND r.RolAdi=N'Yönetici') OR (EXISTS(SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri v WHERE v.KullaniciId=k.Id AND v.Yetkili=1 AND v.YetkiKodu='COST.VIEW') AND EXISTS(SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri v WHERE v.KullaniciId=k.Id AND v.Yetkili=1 AND v.YetkiKodu='ACCOUNTING.VIEW')))"));
  foreach(var report in reports){string text=report.Urun+" · "+report.No+"\n"+(report.BirimMaliyet.HasValue?"Birim maliyet: "+report.BirimMaliyet.Value.ToString("N4")+" TRY / "+report.Birim:"Eksik veriler nedeniyle kesin birim maliyet hesaplanamadı. Bilinen maliyet: "+report.BilinenToplam.ToString("N2")+" TRY.")+"\nSağlam: "+report.Saglam+" · Fire: "+report.Fire+" "+report.Birim+"\n"+string.Join("; ",report.Kalemler.Select(x=>x.Tur+": "+(x.Tutar?.ToString("N2")??"Eksik / hariç")))+"\nMRP ve Ayrıntılı Maliyet ekranından inceleyin.";if(text.Length>3900)text=text[..3900];foreach(DataRow recipient in recipients.Rows){int id=(int)recipient[0];IsbirligiServisi.Insert(c,t,Guid.NewGuid(),"GUNLUKMALIYET:"+date.ToString("yyyyMMdd")+":"+report.Emir+":"+id,user,"Günlük üretim maliyeti · "+date.ToString("dd.MM.yyyy"),text,null,id);}}
  using(var q=Q(c,t,"INSERT dbo.MPXNext_Gunluk(Tarih) VALUES(@d)",("@d",date)))q.ExecuteNonQuery();t.Commit();return reports.Count;
 }
}
