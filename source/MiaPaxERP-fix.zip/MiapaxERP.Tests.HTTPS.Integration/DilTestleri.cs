using System.IO;
using System.Text;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class DilTestleri
{
    private static string Sozluk()
    {
        using var s=typeof(Dil).Assembly.GetManifestResourceStream("MiapaxERP.Desktop.Diller.ceviri.tsv");
        Assert.NotNull(s);
        return new StreamReader(s!,Encoding.UTF8).ReadToEnd();
    }
    [Fact]public void YerlesikSozlukTumDillerdeEksiksizdir()
    {
        var satirlar=Sozluk().Replace("\r\n","\n").Split('\n',StringSplitOptions.RemoveEmptyEntries);
        Assert.Equal("tr\ten\tde\tfr\tru\tar\tzh",satirlar[0]);
        Assert.True(satirlar.Length>300);
        foreach(var s in satirlar)Assert.True(s.Split('\t').Length==7&&s.Split('\t').All(x=>x.Trim().Length>0),s);
        Assert.Equal(Dil.Diller.Select(d=>d.Kod),satirlar[0].Split('\t'));
    }
    [Fact]public void SimgeVeIkiNoktaKorunarakCevrilir()
    {
        try
        {
            Dil.TestIcinAyarla(Sozluk(),"en");
            Assert.Equal("Save",Dil.Cevir("Kaydet"));
            Assert.Equal("▤   Stock management",Dil.Cevir("▤   Stok Yönetimi"));
            Assert.Equal("Date:",Dil.Cevir("Tarih:"));
            Assert.Equal("Loading...",Dil.Cevir("Yükleniyor..."));
            Assert.Equal("ABC-123",Dil.Cevir("ABC-123"));
            Dil.TestIcinAyarla(Sozluk(),"ar");
            Assert.True(Dil.SagdanSola);
            Assert.Equal("حفظ",Dil.Cevir("kaydet"));
        }
        finally{Dil.TestIcinAyarla(Sozluk(),"tr");}
    }
    [Fact]public void YapayZekaYanitindanJsonAyiklanir()
    {
        var d=Dil.JsonAyikla("Tabii:\n```json\n{\"Kaydet\":\"Save\",\"Sil\":\"Delete\"}\n```");
        Assert.Equal("Save",d["Kaydet"]);Assert.Equal("Delete",d["Sil"]);
        Assert.Empty(Dil.JsonAyikla("yanıt yok"));
    }
}
