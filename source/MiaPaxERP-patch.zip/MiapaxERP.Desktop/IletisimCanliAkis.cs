using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System.Net.Http.Json;
using System.Text.Json;
namespace MiapaxERP.Desktop;
public static class IletisimCanliAkis
{
 public static void Kur(WebApplication app,string connection,Func<HttpContext,int> user){
  var connections=new SemaphoreSlim(20,20);
  app.MapGet(HttpsApi.Kok+"/events",async(HttpContext c)=>{if(!await connections.WaitAsync(0,c.RequestAborted)){c.Response.StatusCode=429;return;}try{
   int actor=user(c);string cursor=c.Request.Query["cursor"].ToString();if(cursor.Length>100)throw new ArgumentException();var service=new IsbirligiServisi(connection,actor);string current=service.Sinyal();for(int n=0;n<18&&current==cursor;n++){await Task.Delay(1000,c.RequestAborted);if(user(c)!=actor)throw new UnauthorizedAccessException();current=service.Sinyal();}await c.Response.WriteAsJsonAsync(new{cursor=current},c.RequestAborted);
  }finally{connections.Release();}});
 }
}
public sealed partial class HttpsIstemci
{
 public event Action? IsbirligiDegisti;
 public async Task OlaylariIzle(CancellationToken stop){string cursor="";while(!stop.IsCancellationRequested&&Oturum is not null)try{using var r=await http.GetAsync(HttpsApi.Kok+"/events?cursor="+Uri.EscapeDataString(cursor),stop).ConfigureAwait(false);await Kontrol(r,stop).ConfigureAwait(false);using var json=JsonDocument.Parse(await r.Content.ReadAsStringAsync(stop).ConfigureAwait(false));string next=json.RootElement.GetProperty("cursor").GetString()??"";if(next!=cursor){cursor=next;IsbirligiDegisti?.Invoke();}}catch(OperationCanceledException)when(stop.IsCancellationRequested){break;}catch{try{await Task.Delay(5000,stop).ConfigureAwait(false);}catch(OperationCanceledException){break;}}}
}
