// Bağımsız barındırma (AUTH_MODE=password) kimlik doğrulama testleri.
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import app from '../worker/index.js';
import {hashPassword,verifyPassword} from '../worker/auth.js';

class DB{
 constructor(){this.db=new DatabaseSync(':memory:');this.db.exec('PRAGMA foreign_keys=ON;');for(const f of readdirSync('drizzle').filter(x=>/^\d{4}_.*\.sql$/.test(x)).sort())this.db.exec(readFileSync('drizzle/'+f,'utf8').replaceAll('--> statement-breakpoint',''));}
 prepare(sql){const db=this.db;let args=[];return {bind(...v){args=v;return this;},async first(){return db.prepare(sql).get(...args)||null;},async run(){const r=db.prepare(sql).run(...args);return {success:true,meta:{changes:Number(r.changes)}};},async all(){const results=db.prepare(sql).all(...args);return {results,success:true,meta:{changes:Number(db.prepare('SELECT changes() AS n').get().n)}};}};}
 async batch(queries){this.db.exec('BEGIN IMMEDIATE');try{const out=[];for(const q of queries)out.push(await q.all());this.db.exec('COMMIT');return out;}catch(e){this.db.exec('ROLLBACK');throw e;}}
}
const origin='https://lisans.example.com';let checks=0;
const check=(v,label)=>{assert.ok(v,label);console.log('PASS '+label);checks++;};
const pair=await crypto.subtle.generateKey({name:'RSA-PSS',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
const env={LICENSE_PRIVATE_PKCS8:Buffer.from(await crypto.subtle.exportKey('pkcs8',pair.privateKey)).toString('base64'),DB:new DB(),AUTH_MODE:'password',ADMIN_SETUP_TOKEN:'kurulum-anahtari-0123456789abcdef',ADMIN_USER_ID:'test-owner'};
let cookie='';
async function call(path,b,{withOrigin=true,headers={},ip='1.1.1.1'}={}){
 const h={'cf-connecting-ip':ip,...headers};if(withOrigin)h.origin=origin;if(b)h['content-type']='application/json';if(cookie)h.cookie=cookie;
 const r=await app.fetch(new Request(origin+path,{method:b?'POST':'GET',headers:h,body:b?JSON.stringify(b):undefined}),env);
 const set=r.headers.get('set-cookie');if(set)cookie=set.split(';')[0].endsWith('=')?'':set.split(';')[0];
 let j=null;if((r.headers.get('content-type')||'').includes('json'))j=await r.json();else j=await r.text();return {r,j};
}

check(await verifyPassword('Dogru-parola-123',await hashPassword('Dogru-parola-123')),'PBKDF2 parola doğrulanır');
check(!await verifyPassword('yanlis',await hashPassword('Dogru-parola-123')),'Yanlış parola reddedilir');
check((await call('/')).j.includes('İlk yönetici hesabı'),'Yönetici yokken kurulum sayfası gösterilir');
check((await call('/api/admin/state',null,{headers:{'oai-authenticated-user-id':'test-owner'}})).r.status===401,'Parola modunda oai başlığına güvenilmez');
check((await call('/api/auth/setup',{setupToken:'yanlis',username:'yonetici',password:'Guclu-parola-2026'})).r.status===403,'Yanlış kurulum anahtarı reddedilir');
check((await call('/api/auth/setup',{setupToken:env.ADMIN_SETUP_TOKEN,username:'yonetici',password:'kisa1'})).r.status===400,'Zayıf parola reddedilir');
check((await call('/api/auth/setup',{setupToken:env.ADMIN_SETUP_TOKEN,username:'yonetici',password:'Guclu-parola-2026'},{withOrigin:false})).r.status===403,'Kurulumda kaynak denetimi');
const setup=await call('/api/auth/setup',{setupToken:env.ADMIN_SETUP_TOKEN,username:'yonetici',password:'Guclu-parola-2026'});
check(setup.r.ok&&cookie.startsWith('__Host-lisans_oturum='),'İlk yönetici oluşturulur ve oturum açılır');
check(/HttpOnly/.test(setup.r.headers.get('set-cookie'))&&/Secure/.test(setup.r.headers.get('set-cookie')),'Oturum çerezi HttpOnly ve Secure');
check((await call('/api/admin/state')).r.ok,'Oturumla yönetim API erişimi');
const saved=cookie;cookie='';
check((await call('/api/auth/setup',{setupToken:env.ADMIN_SETUP_TOKEN,username:'ikinci',password:'Guclu-parola-2026'})).r.status===409,'İkinci kurulum yapılamaz');
check((await call('/')).j.includes('Yönetici hesabınızla giriş yapın'),'Oturumsuz ziyaretçiye giriş sayfası');
check((await call('/api/admin/state')).r.status===401,'Oturumsuz yönetim isteği reddedilir');
check((await call('/api/auth/login',{username:'yonetici',password:'Yanlis-parola-0000'})).r.status===401,'Hatalı parola ile giriş reddedilir');
check((await call('/api/auth/login',{username:'yok',password:'Guclu-parola-2026'})).r.status===401,'Olmayan kullanıcı aynı yanıtı alır');
check((await call('/api/auth/login',{username:'Yonetici',password:'Guclu-parola-2026'})).r.ok&&cookie,'Doğru bilgilerle giriş');
check((await call('/')).j.includes('LİSANS YÖNETİM MERKEZİ'),'Giriş sonrası panel açılır');
const cr=await call('/api/admin/customer',{name:'Firma A',sector:'KAFE',email:'a@example.com',tax:{number:'1234567890',office:'Test',title:'Firma A'},initialLicense:{modules:['STOK'],maxDevices:1,startsAt:'2026-01-01',expiresAt:null}});check(cr.r.ok,'Oturumla müşteri oluşturulur');
check(env.DB.db.prepare("SELECT COUNT(*) n FROM audit WHERE actor='admin:yonetici'").get().n>=2,'İşlemler yönetici adıyla denetime yazılır');
// Geçici parola akışı (scripts/yonetici-parola.mjs ile aynı alanlar)
env.DB.db.prepare('UPDATE admin_users SET password_hash=?,must_change=1 WHERE username=?').run(await hashPassword('Gecici-parola-1111'),'yonetici');
cookie='';await call('/api/auth/login',{username:'yonetici',password:'Gecici-parola-1111'});
check((await call('/')).j.includes('Parolanızı değiştirin'),'Geçici parola sonrası değiştirme ekranı');
check((await call('/api/admin/state')).r.status===403,'Parola değişmeden yönetim kapalı');
check((await call('/api/auth/password',{current:'Gecici-parola-1111',password:'Yeni-guclu-parola-42'})).r.ok,'Parola değiştirilir');
check((await call('/api/admin/state')).r.ok,'Yeni oturumla yönetim açık');
const before=cookie;const out=await call('/api/auth/logout',{});
check(out.r.status===303&&!cookie,'Çıkış oturumu kapatır');
cookie=before;check((await call('/api/admin/state')).r.status===401,'Kapatılan oturum tekrar kullanılamaz');
cookie=saved;check((await call('/api/admin/state')).r.status===401,'Parola değişince eski oturumlar düşer');
cookie='';let limited=false;for(let i=0;i<12;i++){const r=await call('/api/auth/login',{username:'yonetici',password:'Yanlis-'+i+'-parola'},{ip:'9.9.9.9'});if(r.r.status===429)limited=true;}
check(limited,'Kaba kuvvet denemesi sınırlanır');
// Sites modu geriye uyumluluk
const sitesEnv={...env,AUTH_MODE:undefined};const s=await app.fetch(new Request(origin+'/api/admin/state',{headers:{'oai-authenticated-user-id':'test-owner'}}),sitesEnv);
check(s.ok,'AUTH_MODE yok + ADMIN_USER_ID varsa Sites modu sürer');
console.log('PASSED '+checks);
