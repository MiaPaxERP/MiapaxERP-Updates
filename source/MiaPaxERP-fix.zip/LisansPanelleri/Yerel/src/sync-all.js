// Tüm lisansları internet lisans paneline gönderir (ör. kendi Cloudflare hesabınıza taşıdıktan sonra).
// Hedef: LICENSE_CLOUD_ORIGIN (yoksa mevcut panel). Lisans anahtarının kendisi gönderilmez; yalnız özet ve imzalı kayıt.
import {loadConfig} from './config.js';
import {openDatabase} from './database.js';
import {syncLicense} from './license-cloud.js';
import {cloudOrigin} from './cloud-origin.js';
import {fileURLToPath} from 'node:url';

export async function syncAll(db,env,send=fetch){
 const ids=db.prepare('SELECT id FROM licenses ORDER BY created_at').all().map(x=>x.id);
 const out={target:cloudOrigin(env),total:ids.length,ok:0,failed:[]};
 for(const id of ids){const r=await syncLicense(db,{...env,SUPPORT_CLOUD_ENABLED:'true'},id,send);if(r.ok)out.ok++;else out.failed.push({id,message:r.message});}
 return out;
}

if(process.argv[1]&&fileURLToPath(import.meta.url)===process.argv[1]){
 try{const env=loadConfig();if(!env.LICENSE_PRIVATE_PKCS8)throw Error('İmza anahtarı (LICENSE_PRIVATE_PKCS8) gizli ayarlarda yok.');
  const db=openDatabase(env.DB_PATH);try{console.log(JSON.stringify({ok:true,...await syncAll(db,env)}));}finally{db.close();}}
 catch(e){console.log(JSON.stringify({ok:false,error:String(e.message||e)}));process.exitCode=1;}
}
