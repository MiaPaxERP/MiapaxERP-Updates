using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record MobilAgAdresi(string Ip,string Ad,int Oncelik){public override string ToString()=>Ip+" — "+Ad;}
public sealed record MobilYerelTanim(string Adres,string ParmakIzi,DateTime Bitis,string? DisAdres=null);
public sealed class MobilYerelSunucu:IAsyncDisposable{
 WebApplication? app;X509Certificate2? cert;
 public MobilYerelTanim? Tanim{get;private set;}
 public static bool OzelIp(string address){
  if(!IPAddress.TryParse(address,out var ip)||ip.AddressFamily!=AddressFamily.InterNetwork||ip.ToString()!=address)return false;
  var b=ip.GetAddressBytes();return b[0]==10||b[0]==172&&b[1]>=16&&b[1]<=31||b[0]==192&&b[1]==168;
 }
 /// <summary>İnternetten erişilebilen IPv4 (özel, döngü, bağlantı-yerel, CGNAT, çok noktaya yayın değil).</summary>
 public static bool DisIp(string address){
  if(!IPAddress.TryParse(address,out var ip)||ip.AddressFamily!=AddressFamily.InterNetwork||ip.ToString()!=address||OzelIp(address))return false;
  var b=ip.GetAddressBytes();return !(b[0]==0||b[0]==127||b[0]>=224||b[0]==169&&b[1]==254||b[0]==100&&b[1]>=64&&b[1]<=127);
 }
 public static bool DisPortGecerli(int port)=>port is >=1024 and <=65535 and not 1433 and not 1434 and not 3389;
 /// <summary>Modemin internete çıktığı dış IPv4 adresini öğrenir (yalnız adres sorulur, veri gönderilmez).</summary>
 public static async Task<string> DisIpBulAsync(CancellationToken token=default){
  using var http=new HttpClient{Timeout=TimeSpan.FromSeconds(6)};
  foreach(var url in new[]{"https://api.ipify.org","https://ifconfig.me/ip","https://icanhazip.com"}){
   try{var ip=(await http.GetStringAsync(url,token)).Trim();if(DisIp(ip))return ip;}
   catch(Exception e) when(e is HttpRequestException or TaskCanceledException){}
  }
  throw new InvalidOperationException("Dış IP adresi otomatik bulunamadı. İnternet bağlantısını kontrol edin veya modem arayüzündeki WAN IP adresini elle yazın.");
 }
 public static MobilAgAdresi[] Aglar()=>NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up&&n.NetworkInterfaceType!=NetworkInterfaceType.Loopback).SelectMany(n=>n.GetIPProperties().UnicastAddresses.Select(a=>new MobilAgAdresi(a.Address.ToString(),n.Name,(n.GetIPProperties().GatewayAddresses.Count>0?0:10)+(n.NetworkInterfaceType==NetworkInterfaceType.Wireless80211?0:n.NetworkInterfaceType==NetworkInterfaceType.Ethernet?1:2)))).Where(a=>OzelIp(a.Ip)).DistinctBy(a=>a.Ip).OrderBy(a=>a.Oncelik).ThenBy(a=>a.Ip).ToArray();
 public static string[] Adresler()=>Aglar().Select(a=>a.Ip).ToArray();
 public static X509Certificate2 YeniSertifika(params IPAddress[] addresses){
  using var rsa=RSA.Create(3072);var request=new CertificateRequest("CN=MiapaxERP Yerel Mobil",rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
  var san=new SubjectAlternativeNameBuilder();foreach(var address in addresses)san.AddIpAddress(address);request.CertificateExtensions.Add(san.Build());
  request.CertificateExtensions.Add(new X509BasicConstraintsExtension(false,false,0,true));
  request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature|X509KeyUsageFlags.KeyEncipherment,true));
  request.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(new System.Security.Cryptography.OidCollection{new("1.3.6.1.5.5.7.3.1")},true));
  using var created=request.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-5),DateTimeOffset.UtcNow.AddYears(1));
  return X509CertificateLoader.LoadPkcs12(created.Export(X509ContentType.Pfx),null,X509KeyStorageFlags.DefaultKeySet|X509KeyStorageFlags.Exportable);
 }
 public static string Paket(MobilYerelTanim info,string code){
  var uri=new Uri(info.Adres);if(uri.Scheme!="https"||!OzelIp(uri.Host)||uri.Port!=5189||uri.AbsolutePath!="/"||!string.IsNullOrEmpty(uri.UserInfo)||!string.IsNullOrEmpty(uri.Query)||!string.IsNullOrEmpty(uri.Fragment)||info.ParmakIzi.Length!=64||code.Length!=64)throw new ArgumentException("Yerel eşleme bilgileri geçersiz.");
  Convert.FromHexString(info.ParmakIzi);Convert.FromHexString(code);
  if(info.DisAdres is {Length:>0} dis){
   var d=new Uri(dis);if(d.Scheme!="https"||!DisIp(d.Host)||!DisPortGecerli(d.Port)||d.AbsolutePath!="/")throw new ArgumentException("Dış IP adresi veya portu geçersiz.");
   return "BERP-LAN1:"+Convert.ToBase64String(JsonSerializer.SerializeToUtf8Bytes(new{v=2,address=info.Adres,alt=dis,pin=info.ParmakIzi,code})).TrimEnd('=').Replace('+','-').Replace('/','_');
  }
  var json=JsonSerializer.SerializeToUtf8Bytes(new{v=1,address=info.Adres,pin=info.ParmakIzi,code});
  return "BERP-LAN1:"+Convert.ToBase64String(json).TrimEnd('=').Replace('+','-').Replace('/','_');
 }
 public async Task<MobilYerelTanim> Baslat(string connection,string ip,Func<bool> active,string? disIp=null,int disPort=5189){
  LisansOturumu.Gerekli("MOBIL");if(!OzelIp(ip)||!Adresler().Contains(ip))throw new ArgumentException("Bu bilgisayara ait özel ağ IPv4 adresini seçin.");
  disIp=string.IsNullOrWhiteSpace(disIp)?null:disIp.Trim();
  if(disIp is not null&&!DisIp(disIp))throw new ArgumentException("Dış IP adresi geçerli bir internet IPv4 adresi olmalı (ör. 85.105.10.20). 192.168…, 10… gibi adresler yerel adrestir.");
  if(disIp is not null&&!DisPortGecerli(disPort))throw new ArgumentException("Dış port 1024–65535 arasında olmalı (1433, 1434, 3389 hariç).");
  var cs=new SqlConnectionStringBuilder(connection);var db=MobilRaporSunucusu.Ozet(cs.DataSource.ToUpperInvariant()+"|"+cs.InitialCatalog.ToUpperInvariant());
  var folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","MobilYerel",db);Directory.CreateDirectory(folder);
  var file=Path.Combine(folder,ip.Replace('.','-')+(disIp is null?"":"_"+disIp.Replace('.','-'))+".dpapi");
  if(File.Exists(file)){
   var bytes=ProtectedData.Unprotect(File.ReadAllBytes(file),null,DataProtectionScope.CurrentUser);
   cert=X509CertificateLoader.LoadPkcs12(bytes,null,X509KeyStorageFlags.DefaultKeySet|X509KeyStorageFlags.Exportable);
   if(cert.NotAfter.ToUniversalTime()<DateTime.UtcNow.AddDays(2)){cert.Dispose();cert=null;}
  }
  if(cert is null){cert=disIp is null?YeniSertifika(IPAddress.Parse(ip)):YeniSertifika(IPAddress.Parse(ip),IPAddress.Parse(disIp));File.WriteAllBytes(file+".tmp",ProtectedData.Protect(cert.Export(X509ContentType.Pfx),null,DataProtectionScope.CurrentUser));File.Move(file+".tmp",file,true);}
  app=MobilApi220.Olustur(connection,listen:o=>o.Listen(IPAddress.Parse(ip),5189,l=>l.UseHttps(cert)),active:active);
  try{await app.StartAsync();Tanim=new("https://"+ip+":5189",Convert.ToHexString(SHA256.HashData(cert.RawData)),cert.NotAfter,disIp is null?null:"https://"+disIp+":"+disPort.ToString(System.Globalization.CultureInfo.InvariantCulture));return Tanim;}
  catch{await DisposeAsync();throw;}
 }
 public async ValueTask DisposeAsync(){var old=app;app=null;Tanim=null;if(old is not null){using var stop=new CancellationTokenSource(TimeSpan.FromSeconds(5));try{await old.StopAsync(stop.Token);}finally{await old.DisposeAsync();}}cert?.Dispose();cert=null;}
 public static void AgIzni(bool disaridan=false){
  string path=Environment.ProcessPath??throw new InvalidOperationException("Program yolu okunamadı.");
  string script="$ErrorActionPreference='Stop'; $n='MiapaxERP-Mobil-Yerel-5189'; if (!(Get-NetFirewallRule -Name $n -ErrorAction SilentlyContinue)) { New-NetFirewallRule -Name $n -DisplayName 'MiapaxERP Mobil Yerel TLS' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 5189 -RemoteAddress LocalSubnet -Profile Private,Domain -Program '"+path.Replace("'","''")+"' | Out-Null }; "+(disaridan?"$d='MiapaxERP-Mobil-Dis-5189'; if (!(Get-NetFirewallRule -Name $d -ErrorAction SilentlyContinue)) { New-NetFirewallRule -Name $d -DisplayName 'MiapaxERP Mobil Dis IP TLS' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 5189 -RemoteAddress Any -Profile Private,Domain -Program '"+path.Replace("'","''")+"' | Out-Null }; Write-Host 'Dis IP erisim izni hazir. Modemde dis porttan bu bilgisayarin 5189 portuna yonlendirme yapin.'; ":"")+"Write-Host 'MiapaxERP yerel ağ izni hazır. Ağ profili Özel veya Etki Alanı olmalı.'; Read-Host 'Kapatmak için Enter'";
  var start=new System.Diagnostics.ProcessStartInfo("powershell.exe"){UseShellExecute=true,Verb="runas"};
  foreach(var a in new[]{"-NoProfile","-EncodedCommand",Convert.ToBase64String(Encoding.Unicode.GetBytes(script))})start.ArgumentList.Add(a);
  System.Diagnostics.Process.Start(start);
 }
}
