-- MiaPaxERP boş kurulum şeması. Yalnız DDL; müşteri verisi içermez.
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokBakiyeleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokBakiyeleri](
	[StokKartId] [int] NOT NULL,
	[Birim] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[SonGuncelleme] [datetime2](3) NOT NULL,
 CONSTRAINT [PK_StokBakiyeleri] PRIMARY KEY CLUSTERED 
(
	[StokKartId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokKartlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokKartlari](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StokKodu] [nvarchar](50) COLLATE Turkish_CI_AS NOT NULL,
	[StokAdi] [nvarchar](200) COLLATE Turkish_CI_AS NOT NULL,
	[StokTipi] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[Birim] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Aktif] [bit] NOT NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
	[CapMm] [decimal](12, 3) NULL,
	[BasincSinifi] [nvarchar](30) COLLATE Turkish_CI_AS NULL,
	[UzunlukMetre] [decimal](12, 3) NULL,
	[Renk] [nvarchar](50) COLLATE Turkish_CI_AS NULL,
	[EtKalinligiMm] [decimal](12, 3) NULL,
	[HammaddeTuru] [nvarchar](100) COLLATE Turkish_CI_AS NULL,
	[AgirlikKg] [decimal](12, 3) NULL,
	[MinimumStokMiktari] [decimal](18, 3) NULL,
	[PaketIciAdet] [int] NULL,
	[StokAileId] [int] NULL,
	[VaryantAdi] [nvarchar](150) COLLATE Turkish_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[StokKodu] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vw_KritikStoklar]'))
EXEC dbo.sp_executesql @statement = N'CREATE   VIEW dbo.vw_KritikStoklar AS
 SELECT s.Id AS StokKartId,s.StokKodu,s.StokAdi,s.StokTipi,s.Birim,
        CAST(ISNULL(b.Miktar,0) AS decimal(18,3)) AS MevcutMiktar,
        s.MinimumStokMiktari,
        CAST(s.MinimumStokMiktari-ISNULL(b.Miktar,0) AS decimal(18,3)) AS EksikMiktar
 FROM dbo.StokKartlari s LEFT JOIN dbo.StokBakiyeleri b ON b.StokKartId=s.Id
 WHERE s.Aktif=1 AND s.MinimumStokMiktari IS NOT NULL
   AND ISNULL(b.Miktar,0) < s.MinimumStokMiktari;
' 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokFiyatlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokFiyatlari](
	[StokKartId] [int] NOT NULL,
	[AlisMaliyeti] [decimal](18, 4) NULL,
	[BayiSatisFiyati] [decimal](18, 4) NULL,
	[PerakendeSatisFiyati] [decimal](18, 4) NULL,
	[ParaBirimi] [char](3) COLLATE Turkish_CI_AS NOT NULL,
	[GuncellemeUtc] [datetime2](3) NOT NULL,
 CONSTRAINT [PK_StokFiyatlari] PRIMARY KEY CLUSTERED 
(
	[StokKartId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vw_StokKarMarjlari]'))
EXEC dbo.sp_executesql @statement = N'CREATE   VIEW dbo.vw_StokKarMarjlari AS
 SELECT s.Id AS StokKartId,s.StokKodu,s.StokAdi,f.ParaBirimi,
  f.AlisMaliyeti,f.BayiSatisFiyati,f.PerakendeSatisFiyati,
  (f.BayiSatisFiyati-f.AlisMaliyeti) AS BayiBirimBrutKar,
  (f.PerakendeSatisFiyati-f.AlisMaliyeti) AS PerakendeBirimBrutKar
 FROM dbo.StokKartlari s JOIN dbo.StokFiyatlari f ON f.StokKartId=s.Id;
' 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KullaniciRolleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[KullaniciRolleri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RolAdi] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](250) COLLATE Turkish_CI_AS NULL,
	[Aktif] [bit] NOT NULL,
	[KayitTarihiUtc] [datetime2](0) NOT NULL,
 CONSTRAINT [PK_KullaniciRolleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_KullaniciRolleri_RolAdi] UNIQUE NONCLUSTERED 
(
	[RolAdi] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Kullanicilar]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Kullanicilar](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[KullaniciAdi] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[AdSoyad] [nvarchar](120) COLLATE Turkish_CI_AS NOT NULL,
	[Eposta] [nvarchar](254) COLLATE Turkish_CI_AS NULL,
	[SifreOzeti] [nvarchar](512) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
	[SifreDegistirmeli] [bit] NOT NULL,
	[BasarisizGirisSayisi] [int] NOT NULL,
	[KilitBitisUtc] [datetime2](0) NULL,
	[SonGirisUtc] [datetime2](0) NULL,
	[KayitTarihiUtc] [datetime2](0) NOT NULL,
	[GuncellemeTarihiUtc] [datetime2](0) NULL,
 CONSTRAINT [PK_Kullanicilar] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Kullanicilar_KullaniciAdi] UNIQUE NONCLUSTERED 
(
	[KullaniciAdi] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KullaniciRolAtamalari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[KullaniciRolAtamalari](
	[KullaniciId] [int] NOT NULL,
	[RolId] [int] NOT NULL,
	[AtamaTarihiUtc] [datetime2](0) NOT NULL,
 CONSTRAINT [PK_KullaniciRolAtamalari] PRIMARY KEY CLUSTERED 
(
	[KullaniciId] ASC,
	[RolId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Yetkiler]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Yetkiler](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[YetkiKodu] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[Modul] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[Islem] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](250) COLLATE Turkish_CI_AS NULL,
	[Aktif] [bit] NOT NULL,
 CONSTRAINT [PK_Yetkiler] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Yetkiler_YetkiKodu] UNIQUE NONCLUSTERED 
(
	[YetkiKodu] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RolYetkileri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RolYetkileri](
	[RolId] [int] NOT NULL,
	[YetkiId] [int] NOT NULL,
	[AtamaTarihiUtc] [datetime2](0) NOT NULL,
 CONSTRAINT [PK_RolYetkileri] PRIMARY KEY CLUSTERED 
(
	[RolId] ASC,
	[YetkiId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KullaniciYetkileri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[KullaniciYetkileri](
	[KullaniciId] [int] NOT NULL,
	[YetkiId] [int] NOT NULL,
	[IzinVerildi] [bit] NOT NULL,
	[GuncellemeTarihiUtc] [datetime2](0) NOT NULL,
	[GuncelleyenKullaniciId] [int] NULL,
 CONSTRAINT [PK_KullaniciYetkileri] PRIMARY KEY CLUSTERED 
(
	[KullaniciId] ASC,
	[YetkiId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vw_KullaniciEtkinYetkileri]'))
EXEC dbo.sp_executesql @statement = N'
-- Okuma amacli gorunum. Nihai yetki kontrolu C# servis katmaninda da uygulanmali.
CREATE   VIEW dbo.vw_KullaniciEtkinYetkileri
AS
SELECT
    k.Id AS KullaniciId,
    y.Id AS YetkiId,
    y.YetkiKodu,
    CAST
    (
        CASE
            WHEN k.Aktif = 0 OR y.Aktif = 0 THEN 0
            WHEN y.YetkiKodu IN (N''USERS.MANAGE'', N''PERMISSIONS.MANAGE'') THEN
                CASE WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KullaniciRolAtamalari AS kra
                    INNER JOIN dbo.KullaniciRolleri AS kr ON kr.Id = kra.RolId
                    WHERE kra.KullaniciId = k.Id
                      AND kr.RolAdi = N''Yönetici''
                      AND kr.Aktif = 1
                ) THEN 1 ELSE 0 END
            WHEN ky.KullaniciId IS NOT NULL THEN
                CASE WHEN ky.IzinVerildi = 1 THEN 1 ELSE 0 END
            WHEN EXISTS
            (
                SELECT 1
                FROM dbo.KullaniciRolAtamalari AS kra
                INNER JOIN dbo.KullaniciRolleri AS kr ON kr.Id = kra.RolId
                INNER JOIN dbo.RolYetkileri AS ry ON ry.RolId = kr.Id
                WHERE kra.KullaniciId = k.Id
                  AND kr.Aktif = 1
                  AND ry.YetkiId = y.Id
            ) THEN 1
            ELSE 0
        END AS BIT
    ) AS Yetkili
FROM dbo.Kullanicilar AS k
CROSS JOIN dbo.Yetkiler AS y
LEFT JOIN dbo.KullaniciYetkileri AS ky
    ON ky.KullaniciId = k.Id AND ky.YetkiId = y.Id;
' 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_Denetim]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_Denetim](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Tarih] [datetime2](7) NOT NULL,
	[KullaniciId] [int] NOT NULL,
	[Modul] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[KayitId] [bigint] NOT NULL,
	[Islem] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_IKIslem]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_IKIslem](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[PersonelId] [int] NOT NULL,
	[Tur] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Baslangic] [date] NOT NULL,
	[Bitis] [date] NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[Aciklama] [nvarchar](1000) COLLATE Turkish_CI_AS NOT NULL,
	[Durum] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[KullaniciId] [int] NOT NULL,
	[Onaylayan] [int] NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_Paket]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_Paket](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[PartiId] [bigint] NOT NULL,
	[Barkod] [varchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Sira] [int] NOT NULL,
	[Kg] [decimal](18, 3) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[PartiId] ASC,
	[Sira] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Barkod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_Parti]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_Parti](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[BelgeNo] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[Tedarikci] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[PartiNo] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[StokId] [int] NOT NULL,
	[Tarih] [date] NOT NULL,
	[Icerik] [nvarchar](500) COLLATE Turkish_CI_AS NOT NULL,
	[Kg] [decimal](18, 3) NOT NULL,
	[PaketAdet] [int] NOT NULL,
	[HareketId] [bigint] NOT NULL,
	[KullaniciId] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[PartiNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Tedarikci] ASC,
	[BelgeNo] ASC,
	[StokId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[HareketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_Personel]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_Personel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Sicil] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[AdSoyad] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[Departman] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[Gorev] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[IseGiris] [date] NOT NULL,
	[IstenCikis] [date] NULL,
	[Telefon] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Eposta] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](1000) COLLATE Turkish_CI_AS NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Sicil] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_SatinAlma]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_SatinAlma](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[BelgeNo] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[Tarih] [date] NOT NULL,
	[Tedarikci] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[Malzeme] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[Birim] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[BirimFiyat] [decimal](18, 4) NOT NULL,
	[ParaBirimi] [nvarchar](3) COLLATE Turkish_CI_AS NOT NULL,
	[Vade] [date] NOT NULL,
	[Aciklama] [nvarchar](1000) COLLATE Turkish_CI_AS NOT NULL,
	[Durum] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[KullaniciId] [int] NOT NULL,
	[Onaylayan] [int] NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[BelgeNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_Sema]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_Sema](
	[Surum] [int] NOT NULL,
	[Tarih] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Surum] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_TicaretDosya]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_TicaretDosya](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Modul] [varchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Referans] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[Tur] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Firma] [nvarchar](160) COLLATE Turkish_CI_AS NOT NULL,
	[Baslik] [nvarchar](180) COLLATE Turkish_CI_AS NOT NULL,
	[Sorumlu] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[Tarih] [date] NOT NULL,
	[Vade] [date] NOT NULL,
	[Tutar] [decimal](18, 2) NOT NULL,
	[Doviz] [char](3) COLLATE Turkish_CI_AS NOT NULL,
	[Durum] [nvarchar](50) COLLATE Turkish_CI_AS NOT NULL,
	[Detay] [nvarchar](max) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](2000) COLLATE Turkish_CI_AS NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Modul] ASC,
	[Referans] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_TicaretOdeme]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_TicaretOdeme](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[DosyaId] [bigint] NOT NULL,
	[Tarih] [date] NOT NULL,
	[Tutar] [decimal](18, 2) NOT NULL,
	[Tur] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[Yontem] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Belge] [nvarchar](120) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](320) COLLATE Turkish_CI_AS NOT NULL,
	[KullaniciId] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP_TicaretOlay]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP_TicaretOlay](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[DosyaId] [bigint] NOT NULL,
	[Zaman] [datetime2](7) NOT NULL,
	[KullaniciId] [int] NOT NULL,
	[Olay] [nvarchar](350) COLLATE Turkish_CI_AS NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP200_Recete]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP200_Recete](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Kod] [nvarchar](50) COLLATE Turkish_CI_AS NOT NULL,
	[Ad] [nvarchar](160) COLLATE Turkish_CI_AS NOT NULL,
	[Sektor] [varchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[MamulId] [int] NOT NULL,
	[CiktiBirimi] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[FireYuzde] [decimal](9, 3) NOT NULL,
	[Aktif] [bit] NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Kod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP200_ReceteKalem]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP200_ReceteKalem](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ReceteId] [bigint] NOT NULL,
	[StokId] [int] NOT NULL,
	[Birim] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[BirimCiktiIcinMiktar] [decimal](18, 6) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[ReceteId] ASC,
	[StokId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP200_Uretim]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP200_Uretim](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[IstekOzeti] [char](64) COLLATE Turkish_CI_AS NOT NULL,
	[ReceteId] [bigint] NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[Belge] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[Tarih] [datetime2](7) NOT NULL,
	[KullaniciId] [int] NOT NULL,
	[Detay] [nvarchar](max) COLLATE Turkish_CI_AS NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP210_Gorusme]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP210_Gorusme](
	[Id] [uniqueidentifier] NOT NULL,
	[MusteriId] [uniqueidentifier] NOT NULL,
	[Tarih] [datetime2](7) NOT NULL,
	[Sonuc] [nvarchar](2000) COLLATE Turkish_CI_AS NOT NULL,
	[KullaniciId] [int] NOT NULL,
	[KayitZamani] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP210_SahaMusteri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP210_SahaMusteri](
	[Id] [uniqueidentifier] NOT NULL,
	[IlId] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[IlceId] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Koy] [nvarchar](160) COLLATE Turkish_CI_AS NOT NULL,
	[Ad] [nvarchar](160) COLLATE Turkish_CI_AS NOT NULL,
	[Telefon] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[Veri] [nvarchar](max) COLLATE Turkish_CI_AS NOT NULL,
	[Olusturan] [int] NOT NULL,
	[Olusturma] [datetime2](7) NOT NULL,
	[Guncelleme] [datetime2](7) NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP220_Cihaz]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP220_Cihaz](
	[Ozet] [char](64) COLLATE Turkish_CI_AS NOT NULL,
	[HesapId] [uniqueidentifier] NOT NULL,
	[Ad] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[Olusturma] [datetime2](7) NOT NULL,
	[SonGorulme] [datetime2](7) NOT NULL,
	[Iptal] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Ozet] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP220_Esleme]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP220_Esleme](
	[Ozet] [char](64) COLLATE Turkish_CI_AS NOT NULL,
	[HesapId] [uniqueidentifier] NOT NULL,
	[Bitis] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Ozet] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP220_Hesap]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP220_Hesap](
	[Id] [uniqueidentifier] NOT NULL,
	[KullaniciId] [int] NOT NULL,
	[Ad] [nvarchar](160) COLLATE Turkish_CI_AS NOT NULL,
	[Rol] [varchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[KullaniciId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP220_Islem]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP220_Islem](
	[HesapId] [uniqueidentifier] NOT NULL,
	[Id] [uniqueidentifier] NOT NULL,
	[Ozet] [char](64) COLLATE Turkish_CI_AS NOT NULL,
	[Surum] [varchar](20) COLLATE Turkish_CI_AS NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[HesapId] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP270_EBelge]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP270_EBelge](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Ortam] [varchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Vkn] [varchar](11) COLLATE Turkish_CI_AS NOT NULL,
	[Ettn] [uniqueidentifier] NOT NULL,
	[BelgeNo] [varchar](16) COLLATE Turkish_CI_AS NOT NULL,
	[BelgeTarihi] [date] NOT NULL,
	[AppType] [int] NOT NULL,
	[Alici] [varchar](11) COLLATE Turkish_CI_AS NOT NULL,
	[KaynakEtiket] [nvarchar](250) COLLATE Turkish_CI_AS NOT NULL,
	[HedefEtiket] [nvarchar](250) COLLATE Turkish_CI_AS NOT NULL,
	[YerelId] [varchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[Xml] [nvarchar](max) COLLATE Turkish_CI_AS NOT NULL,
	[Ozet] [char](64) COLLATE Turkish_CI_AS NOT NULL,
	[Durum] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Sonuc] [nvarchar](1000) COLLATE Turkish_CI_AS NOT NULL,
	[Olusturan] [int] NOT NULL,
	[Olusma] [datetimeoffset](7) NOT NULL,
	[Guncelleme] [datetimeoffset](7) NOT NULL,
	[Surum] [timestamp] NOT NULL,
	[Taslak] [bit] NOT NULL,
	[SatisId] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UX_EBelge_Ettn] UNIQUE NONCLUSTERED 
(
	[Ortam] ASC,
	[Vkn] ASC,
	[Ettn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UX_EBelge_Local] UNIQUE NONCLUSTERED 
(
	[Ortam] ASC,
	[Vkn] ASC,
	[YerelId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UX_EBelge_No] UNIQUE NONCLUSTERED 
(
	[Ortam] ASC,
	[Vkn] ASC,
	[BelgeNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeBirim]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP270_EBelgeBirim](
	[Yerel] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[Ubl] [varchar](3) COLLATE Turkish_CI_AS NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Yerel] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeDosya]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP270_EBelgeDosya](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Ortam] [varchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Vkn] [varchar](11) COLLATE Turkish_CI_AS NOT NULL,
	[Ettn] [uniqueidentifier] NOT NULL,
	[Kutu] [int] NOT NULL,
	[Xml] [nvarchar](max) COLLATE Turkish_CI_AS NOT NULL,
	[Ozet] [char](64) COLLATE Turkish_CI_AS NOT NULL,
	[Taslak] [bit] NOT NULL,
	[Durum] [int] NOT NULL,
	[ZarfDurum] [int] NOT NULL,
	[Iptal] [bit] NOT NULL,
	[Alindi] [datetimeoffset](7) NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Ortam] ASC,
	[Vkn] ASC,
	[Ettn] ASC,
	[Kutu] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeIslem]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP270_EBelgeIslem](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Ortam] [varchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Vkn] [varchar](11) COLLATE Turkish_CI_AS NOT NULL,
	[Ettn] [uniqueidentifier] NOT NULL,
	[Islem] [varchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[CariId] [int] NULL,
	[CariHareketId] [bigint] NULL,
	[OncekiHareketId] [bigint] NULL,
	[Gerekce] [nvarchar](400) COLLATE Turkish_CI_AS NOT NULL,
	[Kullanici] [int] NOT NULL,
	[Zaman] [datetimeoffset](7) NOT NULL,
	[TersId] [bigint] NULL,
	[BelgeNo] [varchar](16) COLLATE Turkish_CI_AS NULL,
	[BelgeTipi] [nvarchar](40) COLLATE Turkish_CI_AS NULL,
	[BelgeTarihi] [date] NULL,
	[Matrah] [decimal](18, 4) NULL,
	[Kdv] [decimal](18, 4) NULL,
	[GenelToplam] [decimal](18, 4) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Ortam] ASC,
	[Vkn] ASC,
	[Ettn] ASC,
	[Islem] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeOlay]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP270_EBelgeOlay](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[BelgeId] [bigint] NOT NULL,
	[Kullanici] [int] NOT NULL,
	[Islem] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](1000) COLLATE Turkish_CI_AS NOT NULL,
	[Zaman] [datetimeoffset](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeSatisBag]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP270_EBelgeSatisBag](
	[Ortam] [varchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Vkn] [varchar](11) COLLATE Turkish_CI_AS NOT NULL,
	[SatisId] [bigint] NOT NULL,
	[Tur] [varchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[EbelgeId] [bigint] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Ortam] ASC,
	[Vkn] ASC,
	[SatisId] ASC,
	[Tur] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[EbelgeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeStokBag]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP270_EBelgeStokBag](
	[IslemId] [bigint] NOT NULL,
	[Satir] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[StokId] [int] NOT NULL,
	[HareketId] [bigint] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[IslemId] ASC,
	[Satir] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[HareketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeTaraf]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BERP270_EBelgeTaraf](
	[Ortam] [varchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Vkn] [varchar](11) COLLATE Turkish_CI_AS NOT NULL,
	[Veri] [nvarchar](max) COLLATE Turkish_CI_AS NOT NULL,
	[Kullanici] [int] NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Ortam] ASC,
	[Vkn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Bildirimler]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Bildirimler](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[AliciKullaniciId] [int] NOT NULL,
	[Tur] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[Baslik] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[Mesaj] [nvarchar](500) COLLATE Turkish_CI_AS NOT NULL,
	[IlgiliKullaniciId] [int] NULL,
	[KayitTarihiUtc] [datetime2](0) NOT NULL,
	[OkunduUtc] [datetime2](0) NULL,
 CONSTRAINT [PK_Bildirimler] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_GelenEFaturalar]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_GelenEFaturalar](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[FaturaNo] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[CariId] [int] NOT NULL,
	[FaturaTarihi] [date] NOT NULL,
	[VadeTarihi] [date] NULL,
	[Matrah] [decimal](18, 2) NOT NULL,
	[Kdv] [decimal](18, 2) NOT NULL,
	[GenelToplam] [decimal](18, 2) NOT NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NULL,
	[Durum] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[KayitTarihi] [datetime2](0) NOT NULL,
 CONSTRAINT [PK_BoruERP_GelenEFaturalar] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_BoruERP_GelenEFaturalar_No] UNIQUE NONCLUSTERED 
(
	[CariId] ASC,
	[FaturaNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_GelirGider]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_GelirGider](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[IslemAnahtari] [uniqueidentifier] NOT NULL,
	[Tarih] [date] NOT NULL,
	[Tur] [nvarchar](5) COLLATE Turkish_CI_AS NOT NULL,
	[HesapKodu] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[MaliyetMerkeziId] [int] NOT NULL,
	[Tutar] [decimal](18, 2) NOT NULL,
	[BelgeNo] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NOT NULL,
	[EskiMasrafId] [bigint] NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[KayitZamani] [datetime2](7) NOT NULL,
	[Iptal] [bit] NOT NULL,
	[IptalKullaniciId] [int] NULL,
	[IptalZamani] [datetime2](7) NULL,
	[IptalNedeni] [nvarchar](400) COLLATE Turkish_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[IslemAnahtari] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_GGHesaplar]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_GGHesaplar](
	[Kod] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[Ad] [nvarchar](200) COLLATE Turkish_CI_AS NOT NULL,
	[GrupKodu] [nvarchar](3) COLLATE Turkish_CI_AS NOT NULL,
	[Tur] [nvarchar](5) COLLATE Turkish_CI_AS NOT NULL,
	[Detay] [bit] NOT NULL,
	[Aktif] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Kod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_GGOdemeler]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_GGOdemeler](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[KayitId] [bigint] NOT NULL,
	[FinansHareketId] [bigint] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[FinansHareketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_IlkKurulum]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_IlkKurulum](
	[Id] [tinyint] NOT NULL,
	[OlusturulduUtc] [datetime2](0) NOT NULL,
 CONSTRAINT [PK_BoruERP_IlkKurulum] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_MaliyetMerkezleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_MaliyetMerkezleri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Kod] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[Ad] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Kod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_SemaSurumleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_SemaSurumleri](
	[Surum] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[UygulamaUtc] [datetime2](3) NOT NULL,
 CONSTRAINT [PK_BoruERP_SemaSurumleri] PRIMARY KEY CLUSTERED 
(
	[Surum] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_YeniBelgeKalemleri](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[BelgeId] [bigint] NOT NULL,
	[StokKartId] [int] NOT NULL,
	[UrunAciklama] [nvarchar](350) COLLATE Turkish_CI_AS NOT NULL,
	[Birim] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[BirimFiyat] [decimal](18, 2) NOT NULL,
	[KdvOrani] [decimal](5, 2) NOT NULL,
	[SatirAraToplam] [decimal](18, 2) NOT NULL,
	[KdvTutari] [decimal](18, 2) NOT NULL,
	[SatirGenelToplam] [decimal](18, 2) NOT NULL,
 CONSTRAINT [PK_BoruERP_YeniBelgeKalemleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_YeniBelgeler](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[BelgeTuru] [nchar](1) COLLATE Turkish_CI_AS NOT NULL,
	[BelgeNo] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[CariId] [int] NOT NULL,
	[Tarih] [date] NOT NULL,
	[GecerlilikTarihi] [date] NULL,
	[OdemeDurumu] [nvarchar](20) COLLATE Turkish_CI_AS NULL,
	[AraToplam] [decimal](18, 2) NOT NULL,
	[KdvToplam] [decimal](18, 2) NOT NULL,
	[Indirim] [decimal](18, 2) NOT NULL,
	[GenelToplam] [decimal](18, 2) NOT NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NULL,
	[Durum] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[KaynakTeklifId] [bigint] NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[KayitTarihi] [datetime2](0) NOT NULL,
 CONSTRAINT [PK_BoruERP_YeniBelgeler] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_BoruERP_YeniBelgeler_No] UNIQUE NONCLUSTERED 
(
	[BelgeTuru] ASC,
	[BelgeNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniMasraflar]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BoruERP_YeniMasraflar](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Tarih] [date] NOT NULL,
	[Kategori] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[Tutar] [decimal](18, 2) NOT NULL,
	[CariId] [int] NULL,
	[FinansHareketId] [bigint] NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[KayitTarihi] [datetime2](0) NOT NULL,
 CONSTRAINT [PK_BoruERP_YeniMasraflar] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CariHareketleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CariHareketleri](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CariId] [int] NOT NULL,
	[Tarih] [date] NOT NULL,
	[HareketTipi] [nvarchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Tutar] [decimal](18, 2) NOT NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NOT NULL,
	[Kaynak] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[TersKayitId] [bigint] NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CariHareketleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CariKartlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CariKartlari](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CariKodu] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Unvan] [nvarchar](200) COLLATE Turkish_CI_AS NOT NULL,
	[CariTipi] [nvarchar](25) COLLATE Turkish_CI_AS NOT NULL,
	[VergiNo] [nvarchar](20) COLLATE Turkish_CI_AS NULL,
	[Telefon] [nvarchar](40) COLLATE Turkish_CI_AS NULL,
	[Eposta] [nvarchar](150) COLLATE Turkish_CI_AS NULL,
	[Adres] [nvarchar](400) COLLATE Turkish_CI_AS NULL,
	[Aktif] [bit] NOT NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
	[VergiDairesi] [nvarchar](100) COLLATE Turkish_CI_AS NULL,
 CONSTRAINT [PK_CariKartlari] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_CariKartlari_Kod] UNIQUE NONCLUSTERED 
(
	[CariKodu] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CekSenetDurumGecmisi]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CekSenetDurumGecmisi](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[EvrakId] [bigint] NOT NULL,
	[EskiDurum] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[YeniDurum] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[IslemTarihi] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CekSenetDurumGecmisi] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CekSenetler]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CekSenetler](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[EvrakNo] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[EvrakTipi] [nvarchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Yon] [nvarchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[CariId] [int] NULL,
	[VadeTarihi] [date] NOT NULL,
	[Tutar] [decimal](18, 2) NOT NULL,
	[ParaBirimi] [nvarchar](3) COLLATE Turkish_CI_AS NOT NULL,
	[Durum] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NULL,
	[IslemTarihi] [datetime2](7) NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CekSenetler] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_CekSenetler_Evrak] UNIQUE NONCLUSTERED 
(
	[EvrakTipi] ASC,
	[Yon] ASC,
	[EvrakNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FinansHareketleri](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[HesapId] [int] NOT NULL,
	[CariId] [int] NULL,
	[CariHareketId] [bigint] NULL,
	[TersKayitId] [bigint] NULL,
	[Tarih] [date] NOT NULL,
	[HareketTipi] [nvarchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Tutar] [decimal](18, 2) NOT NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NOT NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_FinansHareketleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FinansHesaplari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FinansHesaplari](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[HesapKodu] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[HesapAdi] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[HesapTipi] [nvarchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[ParaBirimi] [nvarchar](3) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_FinansHesaplari] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_FinansHesaplari_Kod] UNIQUE NONCLUSTERED 
(
	[HesapKodu] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FirmaBelgeleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FirmaBelgeleri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[BelgeTuru] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[DosyaAdi] [nvarchar](255) COLLATE Turkish_CI_AS NOT NULL,
	[PdfIcerik] [varbinary](max) NOT NULL,
	[EklenmeTarihi] [datetime2](7) NOT NULL,
	[EkleyenKullaniciId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FirmaBilgileri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[FirmaBilgileri](
	[Id] [int] NOT NULL,
	[FirmaAdi] [nvarchar](200) COLLATE Turkish_CI_AS NOT NULL,
	[VergiDairesi] [nvarchar](100) COLLATE Turkish_CI_AS NULL,
	[VergiNo] [nvarchar](20) COLLATE Turkish_CI_AS NULL,
	[Telefon] [nvarchar](40) COLLATE Turkish_CI_AS NULL,
	[Adres] [nvarchar](400) COLLATE Turkish_CI_AS NULL,
	[GuncellemeTarihi] [datetime2](7) NOT NULL,
	[KisaAd] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[FirmaTuru] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[MersisNo] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[TicaretSicilNo] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[TicaretSicilMudurlugu] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[NaceKodu] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[KurulusTarihi] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Telefon2] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Eposta] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[WebSitesi] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[KepAdresi] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Etebligat] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Il] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Ilce] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[PostaKodu] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Ulke] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[YetkiliAdSoyad] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[YetkiliUnvan] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[YetkiliTelefon] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Iban] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[BankaAdi] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[SubeAdi] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[HesapNo] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[OdaKayitNo] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[FaaliyetKonusu] [nvarchar](1000) COLLATE Turkish_CI_AS NULL,
	[Aciklama] [nvarchar](1000) COLLATE Turkish_CI_AS NULL,
 CONSTRAINT [PK_FirmaBilgileri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HammaddePaketleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[HammaddePaketleri](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[PartiId] [bigint] NOT NULL,
	[Barkod] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[PaketTipi] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[IlkKg] [decimal](18, 3) NOT NULL,
	[KalanKg] [decimal](18, 3) NOT NULL,
	[OlusturmaZamani] [datetime2](0) NOT NULL,
 CONSTRAINT [PK_HammaddePaketleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_HammaddePaketleri_Barkod] UNIQUE NONCLUSTERED 
(
	[Barkod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HammaddePartileri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[HammaddePartileri](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StokKartId] [int] NOT NULL,
	[LotNo] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[TedarikciAdi] [nvarchar](250) COLLATE Turkish_CI_AS NOT NULL,
	[GirisTarihi] [date] NOT NULL,
	[IrsaliyeNo] [nvarchar](100) COLLATE Turkish_CI_AS NULL,
	[DepoKonumu] [nvarchar](150) COLLATE Turkish_CI_AS NULL,
	[Aciklama] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[OlusturmaZamani] [datetime2](0) NOT NULL,
 CONSTRAINT [PK_HammaddePartileri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_HammaddePartileri_LotNo] UNIQUE NONCLUSTERED 
(
	[LotNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HatirlananOturumlar]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[HatirlananOturumlar](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[KullaniciId] [int] NOT NULL,
	[BelirtecOzeti] [varbinary](32) NOT NULL,
	[SifreDurumuOzeti] [varbinary](32) NOT NULL,
	[BitisUtc] [datetime2](7) NOT NULL,
	[OlusturmaUtc] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[BelirtecOzeti] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IsTakvimi]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[IsTakvimi](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Baslik] [nvarchar](180) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](1000) COLLATE Turkish_CI_AS NOT NULL,
	[Tur] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[PlanTarihi] [datetime2](0) NOT NULL,
	[OlusturanKullaniciId] [int] NOT NULL,
	[AtananKullaniciId] [int] NULL,
	[Durum] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[OlusturmaTarihi] [datetime2](0) NOT NULL,
	[DegistirenKullaniciId] [int] NULL,
	[DegistirmeTarihi] [datetime2](0) NULL,
 CONSTRAINT [PK_IsTakvimi] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KullaniciGorunumAyarlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[KullaniciGorunumAyarlari](
	[KullaniciId] [int] NOT NULL,
	[Tema] [nvarchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[VurguRengi] [nvarchar](7) COLLATE Turkish_CI_AS NOT NULL,
	[Kompakt] [bit] NOT NULL,
	[GuncellemeTarihi] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_KullaniciGorunumAyarlari] PRIMARY KEY CLUSTERED 
(
	[KullaniciId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KullaniciKurtarmaKodlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[KullaniciKurtarmaKodlari](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[KullaniciId] [int] NOT NULL,
	[GrupId] [uniqueidentifier] NOT NULL,
	[KodOzeti] [binary](32) NOT NULL,
	[OlusturulmaUtc] [datetime2](0) NOT NULL,
	[KullanildiUtc] [datetime2](0) NULL,
	[GecersizUtc] [datetime2](0) NULL,
 CONSTRAINT [PK_KullaniciKurtarmaKodlari] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_KurtarmaKodlari_Hash] UNIQUE NONCLUSTERED 
(
	[KullaniciId] ASC,
	[KodOzeti] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KurtarmaKoduTeslimDurumu]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[KurtarmaKoduTeslimDurumu](
	[KullaniciId] [int] NOT NULL,
	[GrupId] [uniqueidentifier] NOT NULL,
	[OlusturulmaUtc] [datetime2](0) NOT NULL,
	[OnayUtc] [datetime2](0) NULL,
 CONSTRAINT [PK_KurtarmaKoduTeslimDurumu] PRIMARY KEY CLUSTERED 
(
	[KullaniciId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Depo]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Depo](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Kod] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[Ad] [nvarchar](120) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Kod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Donem]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Donem](
	[Yil] [int] NOT NULL,
	[Ay] [int] NOT NULL,
	[Kapali] [bit] NOT NULL,
	[Kapatan] [int] NULL,
	[Kapanis] [datetimeoffset](7) NULL,
	[Gerekce] [nvarchar](400) COLLATE Turkish_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[Yil] ASC,
	[Ay] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Ek]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Ek](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[KayitId] [bigint] NOT NULL,
	[Ad] [nvarchar](180) COLLATE Turkish_CI_AS NOT NULL,
	[Tur] [varchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[Veri] [varbinary](max) NOT NULL,
	[Sha256] [char](64) COLLATE Turkish_CI_AS NOT NULL,
	[Ekleyen] [int] NOT NULL,
	[Zaman] [datetimeoffset](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Fis]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Fis](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[Yil] [int] NOT NULL,
	[Sira] [int] NOT NULL,
	[Tarih] [date] NOT NULL,
	[Kaynak] [varchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[KaynakId] [bigint] NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NOT NULL,
	[Durum] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[TersFisId] [bigint] NULL,
	[Kullanici] [int] NOT NULL,
	[Zaman] [datetimeoffset](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Yil] ASC,
	[Sira] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_FisKalem]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_FisKalem](
	[FisId] [bigint] NOT NULL,
	[Sira] [int] NOT NULL,
	[Hesap] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[Borc] [decimal](28, 8) NOT NULL,
	[Alacak] [decimal](28, 8) NOT NULL,
	[CariId] [int] NULL,
	[Doviz] [varchar](3) COLLATE Turkish_CI_AS NOT NULL,
	[DovizTutar] [decimal](28, 8) NOT NULL,
	[Kur] [decimal](28, 8) NOT NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[FisId] ASC,
	[Sira] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Gizli]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Gizli](
	[Kullanici] [int] NOT NULL,
	[Saglayici] [varchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[Ortam] [varchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Vkn] [varchar](11) COLLATE Turkish_CI_AS NOT NULL,
	[Sifreli] [varbinary](max) NOT NULL,
	[Guncelleme] [datetimeoffset](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Kullanici] ASC,
	[Saglayici] ASC,
	[Ortam] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Hesap]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Hesap](
	[Kod] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[Ad] [nvarchar](160) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Kod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Kayit]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Kayit](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[Tur] [varchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[ParentId] [bigint] NULL,
	[Veri] [nvarchar](max) COLLATE Turkish_CI_AS NOT NULL,
	[Ozet] [char](64) COLLATE Turkish_CI_AS NOT NULL,
	[Durum] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Olusturan] [int] NOT NULL,
	[Olusturma] [datetimeoffset](7) NOT NULL,
	[Guncelleyen] [int] NOT NULL,
	[Guncelleme] [datetimeoffset](7) NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Lot]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Lot](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StokId] [int] NOT NULL,
	[Kod] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[Kaynak] [varchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[KaynakId] [bigint] NULL,
	[Kalite] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[BirimMaliyet] [decimal](28, 8) NULL,
	[Olusturma] [datetimeoffset](7) NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[StokId] ASC,
	[Kod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_LotBag]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_LotBag](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[KaynakLot] [bigint] NOT NULL,
	[UrunLot] [bigint] NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[UretimEmriId] [int] NULL,
	[KayitId] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[KaynakLot] ASC,
	[UrunLot] ASC,
	[UretimEmriId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_LotBakiye]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_LotBakiye](
	[LotId] [bigint] NOT NULL,
	[RafId] [int] NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[LotId] ASC,
	[RafId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_LotHareket]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_LotHareket](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[LotId] [bigint] NOT NULL,
	[RafId] [int] NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[Tur] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Kaynak] [varchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[KaynakId] [bigint] NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NOT NULL,
	[Kullanici] [int] NOT NULL,
	[Zaman] [datetimeoffset](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Olay]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Olay](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[KayitId] [bigint] NULL,
	[Tur] [nvarchar](60) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](2000) COLLATE Turkish_CI_AS NOT NULL,
	[Kullanici] [int] NOT NULL,
	[Zaman] [datetimeoffset](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Raf]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Raf](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DepoId] [int] NOT NULL,
	[Kod] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Ad] [nvarchar](120) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[DepoId] ASC,
	[Kod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Rezervasyon]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Rezervasyon](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[KayitId] [bigint] NULL,
	[LotId] [bigint] NOT NULL,
	[RafId] [int] NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[Durum] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[Kullanici] [int] NOT NULL,
	[Zaman] [datetimeoffset](7) NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Satis]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Satis](
	[BelgeId] [bigint] NOT NULL,
	[CariHareketId] [bigint] NOT NULL,
	[FisId] [bigint] NOT NULL,
	[Doviz] [varchar](3) COLLATE Turkish_CI_AS NOT NULL,
	[Kur] [decimal](28, 8) NOT NULL,
	[Toplam] [decimal](18, 2) NOT NULL,
	[Kapanan] [decimal](18, 2) NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[BelgeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[FisId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[CariHareketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_SatisLot]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_SatisLot](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[BelgeId] [bigint] NOT NULL,
	[KalemId] [bigint] NOT NULL,
	[LotId] [bigint] NOT NULL,
	[RafId] [int] NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[SevkEdilen] [decimal](18, 3) NOT NULL,
	[Maliyet] [decimal](28, 8) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Sira]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Sira](
	[Yil] [int] NOT NULL,
	[Son] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Yil] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Tahsilat]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPX310_Tahsilat](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[BelgeId] [bigint] NOT NULL,
	[Tarih] [date] NOT NULL,
	[Tutar] [decimal](18, 2) NOT NULL,
	[Kur] [decimal](28, 8) NOT NULL,
	[DefterTutar] [decimal](18, 2) NOT NULL,
	[KurFarki] [decimal](18, 2) NOT NULL,
	[FinansHareketId] [bigint] NOT NULL,
	[CariHareketId] [bigint] NOT NULL,
	[FisId] [bigint] NOT NULL,
	[Kullanici] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[FisId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[CariHareketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[FinansHareketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_Barkod]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_Barkod](
	[Barkod] [varchar](100) COLLATE Latin1_General_100_BIN2 NOT NULL,
	[Stok] [int] NOT NULL,
	[Carpan] [decimal](18, 3) NOT NULL,
	[Olusturan] [int] NOT NULL,
	[Tarih] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Barkod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_Departman]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_Departman](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Ad] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Ad] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_DepartmanUye]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_DepartmanUye](
	[Departman] [int] NOT NULL,
	[Kullanici] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Departman] ASC,
	[Kullanici] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_Duyuru]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_Duyuru](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[Kaynak] [nvarchar](180) COLLATE Turkish_CI_AS NULL,
	[Gonderen] [int] NOT NULL,
	[Baslik] [nvarchar](160) COLLATE Turkish_CI_AS NOT NULL,
	[Metin] [nvarchar](4000) COLLATE Turkish_CI_AS NOT NULL,
	[Tarih] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_DuyuruAlici]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_DuyuruAlici](
	[Duyuru] [bigint] NOT NULL,
	[Kullanici] [int] NOT NULL,
	[Okundu] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Duyuru] ASC,
	[Kullanici] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_Gunluk]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_Gunluk](
	[Tarih] [date] NOT NULL,
	[Kayit] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Tarih] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_Maliyet]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_Maliyet](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Emir] [int] NOT NULL,
	[Veri] [nvarchar](max) COLLATE Turkish_CI_AS NOT NULL,
	[Olusturan] [int] NOT NULL,
	[Tarih] [datetime2](7) NOT NULL,
	[Surum] [timestamp] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_MaliyetRevizyon]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_MaliyetRevizyon](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Kayit] [bigint] NOT NULL,
	[Veri] [nvarchar](max) COLLATE Turkish_CI_AS NOT NULL,
	[Kullanici] [int] NOT NULL,
	[Tarih] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_Mesaj]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_Mesaj](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Anahtar] [uniqueidentifier] NOT NULL,
	[Gonderen] [int] NOT NULL,
	[Alici] [int] NULL,
	[Departman] [int] NULL,
	[Metin] [nvarchar](4000) COLLATE Turkish_CI_AS NOT NULL,
	[Tarih] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Anahtar] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_MesajOkuma]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MPXNext_MesajOkuma](
	[Kullanici] [int] NOT NULL,
	[Mesaj] [bigint] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Kullanici] ASC,
	[Mesaj] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PiyasaFirmalari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PiyasaFirmalari](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FirmaAdi] [nvarchar](200) COLLATE Turkish_CI_AS NOT NULL,
	[Sehir] [nvarchar](100) COLLATE Turkish_CI_AS NULL,
	[WebAdresi] [nvarchar](1000) COLLATE Turkish_CI_AS NULL,
	[Notlar] [nvarchar](1000) COLLATE Turkish_CI_AS NULL,
	[Aktif] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PiyasaFiyatlari](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[FirmaId] [int] NOT NULL,
	[UrunGrubu] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[UrunAciklamasi] [nvarchar](300) COLLATE Turkish_CI_AS NOT NULL,
	[CapMm] [decimal](10, 2) NULL,
	[BasincPN] [decimal](10, 2) NULL,
	[SDR] [decimal](10, 2) NULL,
	[UzunlukMetre] [decimal](12, 3) NULL,
	[Birim] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[ParaBirimi] [char](3) COLLATE Turkish_CI_AS NOT NULL,
	[BirimFiyat] [decimal](18, 4) NOT NULL,
	[KdvDahil] [bit] NULL,
	[FiyatTarihi] [date] NULL,
	[SonKontrolUtc] [datetime2](0) NOT NULL,
	[KaynakTuru] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[KaynakUrl] [nvarchar](1500) COLLATE Turkish_CI_AS NULL,
	[Notlar] [nvarchar](1000) COLLATE Turkish_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PlanliOdemeler](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Baslik] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[CariId] [int] NULL,
	[VadeTarihi] [date] NOT NULL,
	[Tutar] [decimal](18, 2) NOT NULL,
	[ParaBirimi] [nvarchar](3) COLLATE Turkish_CI_AS NOT NULL,
	[Durum] [nvarchar](15) COLLATE Turkish_CI_AS NOT NULL,
	[IslemTarihi] [datetime2](7) NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_PlanliOdemeler] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokAileleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokAileleri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[AileKodu] [nvarchar](50) COLLATE Turkish_CI_AS NOT NULL,
	[AileAdi] [nvarchar](200) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
	[KayitTarihiUtc] [datetime2](3) NOT NULL,
 CONSTRAINT [PK_StokAileleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_StokAileleri_AileKodu] UNIQUE NONCLUSTERED 
(
	[AileKodu] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokAlimKayitlari](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StokKartId] [int] NOT NULL,
	[CariKartId] [int] NULL,
	[AlimTarihi] [date] NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[BirimFiyat] [decimal](18, 4) NOT NULL,
	[ParaBirimi] [char](3) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[KayitUtc] [datetime2](3) NOT NULL,
	[StokHareketId] [bigint] NULL,
 CONSTRAINT [PK_StokAlimKayitlari] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokHareketleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokHareketleri](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StokKartId] [int] NOT NULL,
	[UretimStokIslemId] [bigint] NULL,
	[HareketTipi] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[Yon] [nchar](1) COLLATE Turkish_CI_AS NOT NULL,
	[Miktar] [decimal](18, 3) NOT NULL,
	[Birim] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[ReceteOrani] [decimal](9, 4) NULL,
	[Aciklama] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[KayitTarihi] [datetime2](3) NOT NULL,
 CONSTRAINT [PK_StokHareketleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokKategorileri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokKategorileri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StokTipId] [int] NOT NULL,
	[UstKategoriId] [int] NULL,
	[Ad] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[BoruOzellikleri] [bit] NOT NULL,
	[Aktif] [bit] NOT NULL,
 CONSTRAINT [PK_StokKategorileri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokKategoriSecimleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokKategoriSecimleri](
	[StokKartId] [int] NOT NULL,
	[KategoriId] [int] NOT NULL,
 CONSTRAINT [PK_StokKategoriSecimleri] PRIMARY KEY CLUSTERED 
(
	[StokKartId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokOzellikDegerleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokOzellikDegerleri](
	[StokKartId] [int] NOT NULL,
	[OzellikId] [int] NOT NULL,
	[Deger] [nvarchar](450) COLLATE Turkish_CI_AS NOT NULL,
 CONSTRAINT [PK_StokOzellikDegerleri] PRIMARY KEY CLUSTERED 
(
	[StokKartId] ASC,
	[OzellikId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokOzellikTanimlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokOzellikTanimlari](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StokTipId] [int] NOT NULL,
	[KategoriId] [int] NULL,
	[AlanAdi] [nvarchar](100) COLLATE Turkish_CI_AS NOT NULL,
	[AlanTuru] [nvarchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[Secenekler] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Zorunlu] [bit] NOT NULL,
	[Aktif] [bit] NOT NULL,
 CONSTRAINT [PK_StokOzellikTanimlari] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StokTipleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[StokTipleri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Ad] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[Aktif] [bit] NOT NULL,
 CONSTRAINT [PK_StokTipleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_StokTipleri_Ad] UNIQUE NONCLUSTERED 
(
	[Ad] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[TicariBelgeler](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[BelgeNo] [nvarchar](80) COLLATE Turkish_CI_AS NOT NULL,
	[BelgeTipi] [nvarchar](10) COLLATE Turkish_CI_AS NOT NULL,
	[CariId] [int] NOT NULL,
	[CariHareketId] [bigint] NOT NULL,
	[BelgeTarihi] [date] NOT NULL,
	[AraToplam] [decimal](18, 2) NOT NULL,
	[KdvOrani] [decimal](5, 2) NOT NULL,
	[KdvTutari] [decimal](18, 2) NOT NULL,
	[GenelToplam] [decimal](18, 2) NOT NULL,
	[Aciklama] [nvarchar](400) COLLATE Turkish_CI_AS NOT NULL,
	[Durum] [nvarchar](15) COLLATE Turkish_CI_AS NOT NULL,
	[YapanKullaniciId] [int] NOT NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_TicariBelgeler] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_TicariBelgeler_Belge] UNIQUE NONCLUSTERED 
(
	[BelgeTipi] ASC,
	[BelgeNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_TicariBelgeler_CariHareket] UNIQUE NONCLUSTERED 
(
	[CariHareketId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UretimEmirleri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UretimEmriNo] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[MamulStokId] [int] NOT NULL,
	[PlanlananMiktar] [decimal](18, 3) NOT NULL,
	[UretilenMiktar] [decimal](18, 3) NOT NULL,
	[FireMiktari] [decimal](18, 3) NOT NULL,
	[PlanlananBaslangic] [datetime2](7) NULL,
	[PlanlananBitis] [datetime2](7) NULL,
	[Durum] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[Aciklama] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
	[MiktarBirimi] [nvarchar](10) COLLATE Turkish_CI_AS NULL,
	[HedefAgirlikKg] [decimal](18, 3) NULL,
	[ReceteId] [int] NULL,
 CONSTRAINT [PK_UretimEmirleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_UretimEmirleri_EmirNo] UNIQUE NONCLUSTERED 
(
	[UretimEmriNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UretimEmriReceteAnlikKalemleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UretimEmriReceteAnlikKalemleri](
	[UretimEmriId] [int] NOT NULL,
	[HammaddeStokId] [int] NOT NULL,
	[YuzdeOrani] [decimal](9, 4) NOT NULL,
	[KayitTarihi] [datetime2](3) NOT NULL,
 CONSTRAINT [PK_UretimEmriReceteAnlikKalemleri] PRIMARY KEY CLUSTERED 
(
	[UretimEmriId] ASC,
	[HammaddeStokId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UretimGunlukKayitlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UretimGunlukKayitlari](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[UretimEmriId] [int] NOT NULL,
	[UretilenFark] [decimal](18, 3) NOT NULL,
	[FireFark] [decimal](18, 3) NOT NULL,
	[KayitTarihi] [datetime2](0) NOT NULL,
	[KaydedenKullaniciId] [int] NULL,
 CONSTRAINT [PK_UretimGunlukKayitlari] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UretimPaketlemeKayitlari]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UretimPaketlemeKayitlari](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[UretimEmriId] [int] NOT NULL,
	[PaketIciAdet] [int] NOT NULL,
	[PaketSayisi] [int] NOT NULL,
	[ToplamAdet] [bigint] NOT NULL,
	[KayitTarihi] [datetime2](0) NOT NULL,
	[KaydedenKullaniciId] [int] NULL,
 CONSTRAINT [PK_UretimPaketlemeKayitlari] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UretimReceteKalemleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UretimReceteKalemleri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ReceteId] [int] NOT NULL,
	[HammaddeStokId] [int] NOT NULL,
	[YuzdeOrani] [decimal](9, 4) NOT NULL,
	[Aciklama] [nvarchar](250) COLLATE Turkish_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_ReceteKalemleri_TekHammadde] UNIQUE NONCLUSTERED 
(
	[ReceteId] ASC,
	[HammaddeStokId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UretimReceteleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UretimReceteleri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ReceteKodu] [nvarchar](30) COLLATE Turkish_CI_AS NOT NULL,
	[ReceteAdi] [nvarchar](150) COLLATE Turkish_CI_AS NOT NULL,
	[MamulStokId] [int] NOT NULL,
	[Aciklama] [nvarchar](500) COLLATE Turkish_CI_AS NULL,
	[Aktif] [bit] NOT NULL,
	[KayitTarihi] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[ReceteKodu] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UretimStokIslemleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UretimStokIslemleri](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[UretimEmriId] [int] NOT NULL,
	[ReceteId] [int] NULL,
	[MamulMiktari] [decimal](18, 3) NOT NULL,
	[FireMiktari] [decimal](18, 3) NOT NULL,
	[MamulBirimi] [nvarchar](20) COLLATE Turkish_CI_AS NOT NULL,
	[GerceklesenTuketimKg] [decimal](18, 3) NOT NULL,
	[IslemZamani] [datetime2](3) NOT NULL,
 CONSTRAINT [PK_UretimStokIslemleri] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_UretimStokIslemleri_UretimEmri] UNIQUE NONCLUSTERED 
(
	[UretimEmriId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UrunGorselleri]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UrunGorselleri](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StokKartId] [int] NOT NULL,
	[DosyaAdi] [nvarchar](255) COLLATE Turkish_CI_AS NOT NULL,
	[IcerikTuru] [nvarchar](40) COLLATE Turkish_CI_AS NOT NULL,
	[GorselVerisi] [varbinary](max) NOT NULL,
	[KapakMi] [bit] NOT NULL,
	[SiraNo] [int] NOT NULL,
	[EklenmeUtc] [datetime2](0) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BERP_TicaretOdeme]') AND name = N'IX_BERP_OdemeDosya')
CREATE NONCLUSTERED INDEX [IX_BERP_OdemeDosya] ON [dbo].[BERP_TicaretOdeme]
(
	[DosyaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BERP210_SahaMusteri]') AND name = N'IX_BERP210_Konum')
CREATE NONCLUSTERED INDEX [IX_BERP210_Konum] ON [dbo].[BERP210_SahaMusteri]
(
	[IlId] ASC,
	[IlceId] ASC,
	[Koy] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BERP270_EBelge]') AND name = N'UX_Ebelge_Satis')
CREATE UNIQUE NONCLUSTERED INDEX [UX_Ebelge_Satis] ON [dbo].[BERP270_EBelge]
(
	[Ortam] ASC,
	[Vkn] ASC,
	[SatisId] ASC,
	[AppType] ASC
)
WHERE ([SatisId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Bildirimler]') AND name = N'IX_Bildirimler_Alici_Okunma')
CREATE NONCLUSTERED INDEX [IX_Bildirimler_Alici_Okunma] ON [dbo].[Bildirimler]
(
	[AliciKullaniciId] ASC,
	[OkunduUtc] ASC,
	[Id] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_GelirGider]') AND name = N'IX_GG_TarihMerkez')
CREATE NONCLUSTERED INDEX [IX_GG_TarihMerkez] ON [dbo].[BoruERP_GelirGider]
(
	[Tarih] ASC,
	[MaliyetMerkeziId] ASC,
	[HesapKodu] ASC
)
INCLUDE([Tur],[Tutar],[Iptal]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_GelirGider]') AND name = N'UX_GG_EskiMasraf')
CREATE UNIQUE NONCLUSTERED INDEX [UX_GG_EskiMasraf] ON [dbo].[BoruERP_GelirGider]
(
	[EskiMasrafId] ASC
)
WHERE ([EskiMasrafId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_GGOdemeler]') AND name = N'IX_GGOdeme_Kayit')
CREATE NONCLUSTERED INDEX [IX_GGOdeme_Kayit] ON [dbo].[BoruERP_GGOdemeler]
(
	[KayitId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]') AND name = N'UX_BoruERP_YeniBelgeler_KaynakTeklif')
CREATE UNIQUE NONCLUSTERED INDEX [UX_BoruERP_YeniBelgeler_KaynakTeklif] ON [dbo].[BoruERP_YeniBelgeler]
(
	[KaynakTeklifId] ASC
)
WHERE ([KaynakTeklifId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CariHareketleri]') AND name = N'UX_CariHareketleri_TersKayit')
CREATE UNIQUE NONCLUSTERED INDEX [UX_CariHareketleri_TersKayit] ON [dbo].[CariHareketleri]
(
	[TersKayitId] ASC
)
WHERE ([TersKayitId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]') AND name = N'UX_FinansHareketleri_TersKayit')
CREATE UNIQUE NONCLUSTERED INDEX [UX_FinansHareketleri_TersKayit] ON [dbo].[FinansHareketleri]
(
	[TersKayitId] ASC
)
WHERE ([TersKayitId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[HatirlananOturumlar]') AND name = N'IX_HatirlananOturumlar_Kullanici')
CREATE NONCLUSTERED INDEX [IX_HatirlananOturumlar_Kullanici] ON [dbo].[HatirlananOturumlar]
(
	[KullaniciId] ASC,
	[BitisUtc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[IsTakvimi]') AND name = N'IX_IsTakvimi_Tarih')
CREATE NONCLUSTERED INDEX [IX_IsTakvimi_Tarih] ON [dbo].[IsTakvimi]
(
	[PlanTarihi] ASC,
	[Durum] ASC
)
INCLUDE([OlusturanKullaniciId],[AtananKullaniciId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[KullaniciKurtarmaKodlari]') AND name = N'IX_KurtarmaKodlari_Aktif')
CREATE NONCLUSTERED INDEX [IX_KurtarmaKodlari_Aktif] ON [dbo].[KullaniciKurtarmaKodlari]
(
	[KullaniciId] ASC,
	[GrupId] ASC,
	[KullanildiUtc] ASC,
	[GecersizUtc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Fis]') AND name = N'IX_MPX310_Fis_Tarih')
CREATE NONCLUSTERED INDEX [IX_MPX310_Fis_Tarih] ON [dbo].[MPX310_Fis]
(
	[Tarih] ASC,
	[Durum] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Fis]') AND name = N'UX_MPX310_Fis_Ters')
CREATE UNIQUE NONCLUSTERED INDEX [UX_MPX310_Fis_Ters] ON [dbo].[MPX310_Fis]
(
	[TersFisId] ASC
)
WHERE ([TersFisId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Kayit]') AND name = N'IX_MPX310_Kayit_Tur')
CREATE NONCLUSTERED INDEX [IX_MPX310_Kayit_Tur] ON [dbo].[MPX310_Kayit]
(
	[Tur] ASC,
	[ParentId] ASC,
	[Durum] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Rezervasyon]') AND name = N'IX_MPX310_Rez_Lot')
CREATE NONCLUSTERED INDEX [IX_MPX310_Rez_Lot] ON [dbo].[MPX310_Rezervasyon]
(
	[LotId] ASC,
	[RafId] ASC,
	[Durum] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_Duyuru]') AND name = N'UX_Duyuru_Kaynak')
CREATE UNIQUE NONCLUSTERED INDEX [UX_Duyuru_Kaynak] ON [dbo].[MPXNext_Duyuru]
(
	[Kaynak] ASC
)
WHERE ([Kaynak] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_DuyuruAlici]') AND name = N'IX_MPXNext_DuyuruUser')
CREATE NONCLUSTERED INDEX [IX_MPXNext_DuyuruUser] ON [dbo].[MPXNext_DuyuruAlici]
(
	[Kullanici] ASC,
	[Duyuru] ASC
)
INCLUDE([Okundu]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[MPXNext_Mesaj]') AND name = N'IX_MPXNext_MesajAlici')
CREATE NONCLUSTERED INDEX [IX_MPXNext_MesajAlici] ON [dbo].[MPXNext_Mesaj]
(
	[Alici] ASC,
	[Departman] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]') AND name = N'IX_PiyasaFiyatlari_Firma')
CREATE NONCLUSTERED INDEX [IX_PiyasaFiyatlari_Firma] ON [dbo].[PiyasaFiyatlari]
(
	[FirmaId] ASC,
	[SonKontrolUtc] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]') AND name = N'IX_PiyasaFiyatlari_Karsilastirma')
CREATE NONCLUSTERED INDEX [IX_PiyasaFiyatlari_Karsilastirma] ON [dbo].[PiyasaFiyatlari]
(
	[UrunGrubu] ASC,
	[CapMm] ASC,
	[BasincPN] ASC,
	[FiyatTarihi] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]') AND name = N'UX_StokAlimKayitlari_Hareket')
CREATE UNIQUE NONCLUSTERED INDEX [UX_StokAlimKayitlari_Hareket] ON [dbo].[StokAlimKayitlari]
(
	[StokHareketId] ASC
)
WHERE ([StokHareketId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[StokHareketleri]') AND name = N'IX_StokHareketleri_StokKartId_Tarih')
CREATE NONCLUSTERED INDEX [IX_StokHareketleri_StokKartId_Tarih] ON [dbo].[StokHareketleri]
(
	[StokKartId] ASC,
	[KayitTarihi] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[StokHareketleri]') AND name = N'IX_StokHareketleri_UretimStokIslemId')
CREATE NONCLUSTERED INDEX [IX_StokHareketleri_UretimStokIslemId] ON [dbo].[StokHareketleri]
(
	[UretimStokIslemId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[StokHareketleri]') AND name = N'UX_StokHareketleri_Uretim_Tip_Stok')
CREATE UNIQUE NONCLUSTERED INDEX [UX_StokHareketleri_Uretim_Tip_Stok] ON [dbo].[StokHareketleri]
(
	[UretimStokIslemId] ASC,
	[HareketTipi] ASC,
	[StokKartId] ASC
)
WHERE ([UretimStokIslemId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[StokKartlari]') AND name = N'IX_StokKartlari_Aile')
CREATE NONCLUSTERED INDEX [IX_StokKartlari_Aile] ON [dbo].[StokKartlari]
(
	[StokAileId] ASC,
	[Aktif] ASC
)
INCLUDE([StokKodu],[StokAdi]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[StokKategorileri]') AND name = N'UX_StokKat_Alt')
CREATE UNIQUE NONCLUSTERED INDEX [UX_StokKat_Alt] ON [dbo].[StokKategorileri]
(
	[StokTipId] ASC,
	[UstKategoriId] ASC,
	[Ad] ASC
)
WHERE ([UstKategoriId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[StokKategorileri]') AND name = N'UX_StokKat_Kok')
CREATE UNIQUE NONCLUSTERED INDEX [UX_StokKat_Kok] ON [dbo].[StokKategorileri]
(
	[StokTipId] ASC,
	[Ad] ASC
)
WHERE ([UstKategoriId] IS NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[StokOzellikTanimlari]') AND name = N'UX_StokOzellik_Kat')
CREATE UNIQUE NONCLUSTERED INDEX [UX_StokOzellik_Kat] ON [dbo].[StokOzellikTanimlari]
(
	[StokTipId] ASC,
	[KategoriId] ASC,
	[AlanAdi] ASC
)
WHERE ([KategoriId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[StokOzellikTanimlari]') AND name = N'UX_StokOzellik_Tip')
CREATE UNIQUE NONCLUSTERED INDEX [UX_StokOzellik_Tip] ON [dbo].[StokOzellikTanimlari]
(
	[StokTipId] ASC,
	[AlanAdi] ASC
)
WHERE ([KategoriId] IS NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UretimGunlukKayitlari]') AND name = N'IX_UGK_Emir_Tarih')
CREATE NONCLUSTERED INDEX [IX_UGK_Emir_Tarih] ON [dbo].[UretimGunlukKayitlari]
(
	[UretimEmriId] ASC,
	[KayitTarihi] ASC
)
INCLUDE([UretilenFark],[FireFark]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UretimPaketlemeKayitlari]') AND name = N'IX_UPK_Emir_Tarih')
CREATE NONCLUSTERED INDEX [IX_UPK_Emir_Tarih] ON [dbo].[UretimPaketlemeKayitlari]
(
	[UretimEmriId] ASC,
	[KayitTarihi] ASC
)
INCLUDE([ToplamAdet],[PaketSayisi]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UrunGorselleri]') AND name = N'IX_UrunGorselleri_Stok')
CREATE NONCLUSTERED INDEX [IX_UrunGorselleri_Stok] ON [dbo].[UrunGorselleri]
(
	[StokKartId] ASC,
	[SiraNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UrunGorselleri]') AND name = N'UX_UrunGorselleri_TekKapak')
CREATE UNIQUE NONCLUSTERED INDEX [UX_UrunGorselleri_TekKapak] ON [dbo].[UrunGorselleri]
(
	[StokKartId] ASC
)
WHERE ([KapakMi]=(1))
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP_Dene__Tarih__3C54ED00]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP_Denetim] ADD  DEFAULT (sysutcdatetime()) FOR [Tarih]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP_IKIs__Mikta__20ACD28B]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP_IKIslem] ADD  DEFAULT ((0)) FOR [Miktar]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP_IKIs__Durum__21A0F6C4]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP_IKIslem] ADD  DEFAULT (N'Taslak') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP_Pers__Telef__19FFD4FC]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP_Personel] ADD  DEFAULT ('') FOR [Telefon]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP_Pers__Epost__1AF3F935]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP_Personel] ADD  DEFAULT ('') FOR [Eposta]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP_Pers__Acikl__1BE81D6E]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP_Personel] ADD  DEFAULT ('') FOR [Aciklama]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP_Sati__Durum__284DF453]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP_SatinAlma] ADD  DEFAULT (N'Talep') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP_Sema__Tarih__52442E1F]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP_Sema] ADD  DEFAULT (sysutcdatetime()) FOR [Tarih]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP_Tica__Zaman__44EA3301]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP_TicaretOlay] ADD  DEFAULT (sysdatetime()) FOR [Zaman]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP200_R__Aktif__0B7CAB7B]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP200_Recete] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP200_U__Tarih__16EE5E27]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP200_Uretim] ADD  DEFAULT (sysutcdatetime()) FOR [Tarih]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP210_G__Kayit__6C040022]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP210_Gorusme] ADD  DEFAULT (sysutcdatetime()) FOR [KayitZamani]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP210_S__Olust__673F4B05]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP210_SahaMusteri] ADD  DEFAULT (sysutcdatetime()) FOR [Olusturma]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP210_S__Gunce__68336F3E]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP210_SahaMusteri] ADD  DEFAULT (sysutcdatetime()) FOR [Guncelleme]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP220_C__Olust__01F34141]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP220_Cihaz] ADD  DEFAULT (sysutcdatetime()) FOR [Olusturma]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP220_C__SonGo__02E7657A]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP220_Cihaz] ADD  DEFAULT (sysutcdatetime()) FOR [SonGorulme]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP220_C__Iptal__03DB89B3]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP220_Cihaz] ADD  DEFAULT ((0)) FOR [Iptal]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP220_H__Aktif__7B4643B2]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP220_Hesap] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP270_E__Durum__1E8F7FEF]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP270_EBelge] ADD  DEFAULT (N'Hazır') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP270_E__Sonuc__1F83A428]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP270_EBelge] ADD  DEFAULT (N'') FOR [Sonuc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP270_E__Olusm__2077C861]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP270_EBelge] ADD  DEFAULT (sysdatetimeoffset()) FOR [Olusma]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP270_E__Gunce__216BEC9A]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP270_EBelge] ADD  DEFAULT (sysdatetimeoffset()) FOR [Guncelleme]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_EBelge_Taslak]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP270_EBelge] ADD  CONSTRAINT [DF_EBelge_Taslak]  DEFAULT ((1)) FOR [Taslak]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP270_E__Alind__2DD1C37F]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP270_EBelgeDosya] ADD  DEFAULT (sysdatetimeoffset()) FOR [Alindi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP270_E__Zaman__31A25463]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP270_EBelgeIslem] ADD  DEFAULT (sysdatetimeoffset()) FOR [Zaman]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BERP270_E__Zaman__2630A1B7]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BERP270_EBelgeOlay] ADD  DEFAULT (sysdatetimeoffset()) FOR [Zaman]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_Bildirimler_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Bildirimler] ADD  CONSTRAINT [DF_Bildirimler_Kayit]  DEFAULT (sysutcdatetime()) FOR [KayitTarihiUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_BoruERP_GelenEFaturalar_Durum]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar] ADD  CONSTRAINT [DF_BoruERP_GelenEFaturalar_Durum]  DEFAULT (N'Manuel Kayıt') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_BoruERP_GelenEFaturalar_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar] ADD  CONSTRAINT [DF_BoruERP_GelenEFaturalar_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BoruERP_G__Belge__6C390A4C]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_GelirGider] ADD  DEFAULT (N'') FOR [BelgeNo]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BoruERP_G__Kayit__6E2152BE]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_GelirGider] ADD  DEFAULT (sysdatetime()) FOR [KayitZamani]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BoruERP_G__Iptal__6F1576F7]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_GelirGider] ADD  DEFAULT ((0)) FOR [Iptal]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BoruERP_G__Aktif__60C757A0]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_GGHesaplar] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_BoruERP_IlkKurulum_Tarih]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_IlkKurulum] ADD  CONSTRAINT [DF_BoruERP_IlkKurulum_Tarih]  DEFAULT (sysutcdatetime()) FOR [OlusturulduUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__BoruERP_M__Aktif__6497E884]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_MaliyetMerkezleri] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_BoruERP_SemaSurumleri_Tarih]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_SemaSurumleri] ADD  CONSTRAINT [DF_BoruERP_SemaSurumleri_Tarih]  DEFAULT (sysutcdatetime()) FOR [UygulamaUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_BoruERP_YeniBelgeler_Indirim]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_YeniBelgeler] ADD  CONSTRAINT [DF_BoruERP_YeniBelgeler_Indirim]  DEFAULT ((0)) FOR [Indirim]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_BoruERP_YeniBelgeler_Durum]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_YeniBelgeler] ADD  CONSTRAINT [DF_BoruERP_YeniBelgeler_Durum]  DEFAULT (N'Kaydedildi') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_BoruERP_YeniBelgeler_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_YeniBelgeler] ADD  CONSTRAINT [DF_BoruERP_YeniBelgeler_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_BoruERP_YeniMasraflar_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[BoruERP_YeniMasraflar] ADD  CONSTRAINT [DF_BoruERP_YeniMasraflar_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_CariHareketleri_Kaynak]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CariHareketleri] ADD  CONSTRAINT [DF_CariHareketleri_Kaynak]  DEFAULT (N'Manuel') FOR [Kaynak]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_CariHareketleri_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CariHareketleri] ADD  CONSTRAINT [DF_CariHareketleri_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_CariKartlari_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CariKartlari] ADD  CONSTRAINT [DF_CariKartlari_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_CariKartlari_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CariKartlari] ADD  CONSTRAINT [DF_CariKartlari_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_CekSenetDurumGecmisi_Islem]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CekSenetDurumGecmisi] ADD  CONSTRAINT [DF_CekSenetDurumGecmisi_Islem]  DEFAULT (sysdatetime()) FOR [IslemTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_CekSenetler_Durum]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CekSenetler] ADD  CONSTRAINT [DF_CekSenetler_Durum]  DEFAULT (N'Bekliyor') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_CekSenetler_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[CekSenetler] ADD  CONSTRAINT [DF_CekSenetler_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_FinansHareketleri_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[FinansHareketleri] ADD  CONSTRAINT [DF_FinansHareketleri_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_FinansHesaplari_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[FinansHesaplari] ADD  CONSTRAINT [DF_FinansHesaplari_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_FinansHesaplari_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[FinansHesaplari] ADD  CONSTRAINT [DF_FinansHesaplari_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_FirmaBelgeleri_Eklenme]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[FirmaBelgeleri] ADD  CONSTRAINT [DF_FirmaBelgeleri_Eklenme]  DEFAULT (sysdatetime()) FOR [EklenmeTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_FirmaBilgileri_Guncelleme]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[FirmaBilgileri] ADD  CONSTRAINT [DF_FirmaBilgileri_Guncelleme]  DEFAULT (sysdatetime()) FOR [GuncellemeTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_HammaddePaketleri_Olusturma]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[HammaddePaketleri] ADD  CONSTRAINT [DF_HammaddePaketleri_Olusturma]  DEFAULT (sysutcdatetime()) FOR [OlusturmaZamani]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_HammaddePartileri_Olusturma]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[HammaddePartileri] ADD  CONSTRAINT [DF_HammaddePartileri_Olusturma]  DEFAULT (sysutcdatetime()) FOR [OlusturmaZamani]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__Hatirlana__Olust__2116E6DF]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[HatirlananOturumlar] ADD  DEFAULT (sysutcdatetime()) FOR [OlusturmaUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_IsTakvimi_Aciklama]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[IsTakvimi] ADD  CONSTRAINT [DF_IsTakvimi_Aciklama]  DEFAULT (N'') FOR [Aciklama]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_IsTakvimi_Durum]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[IsTakvimi] ADD  CONSTRAINT [DF_IsTakvimi_Durum]  DEFAULT (N'Bekliyor') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_IsTakvimi_Olusturma]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[IsTakvimi] ADD  CONSTRAINT [DF_IsTakvimi_Olusturma]  DEFAULT (sysutcdatetime()) FOR [OlusturmaTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KullaniciGorunumAyarlari_Tema]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KullaniciGorunumAyarlari] ADD  CONSTRAINT [DF_KullaniciGorunumAyarlari_Tema]  DEFAULT (N'Açık') FOR [Tema]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KullaniciGorunumAyarlari_Renk]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KullaniciGorunumAyarlari] ADD  CONSTRAINT [DF_KullaniciGorunumAyarlari_Renk]  DEFAULT (N'#2563EB') FOR [VurguRengi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KullaniciGorunumAyarlari_Kompakt]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KullaniciGorunumAyarlari] ADD  CONSTRAINT [DF_KullaniciGorunumAyarlari_Kompakt]  DEFAULT ((0)) FOR [Kompakt]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KullaniciGorunumAyarlari_Guncelleme]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KullaniciGorunumAyarlari] ADD  CONSTRAINT [DF_KullaniciGorunumAyarlari_Guncelleme]  DEFAULT (sysdatetime()) FOR [GuncellemeTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KurtarmaKodlari_Olusturma]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KullaniciKurtarmaKodlari] ADD  CONSTRAINT [DF_KurtarmaKodlari_Olusturma]  DEFAULT (sysutcdatetime()) FOR [OlusturulmaUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_Kullanicilar_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Kullanicilar] ADD  CONSTRAINT [DF_Kullanicilar_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_Kullanicilar_SifreDegistirmeli]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Kullanicilar] ADD  CONSTRAINT [DF_Kullanicilar_SifreDegistirmeli]  DEFAULT ((0)) FOR [SifreDegistirmeli]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_Kullanicilar_Basarisiz]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Kullanicilar] ADD  CONSTRAINT [DF_Kullanicilar_Basarisiz]  DEFAULT ((0)) FOR [BasarisizGirisSayisi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_Kullanicilar_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Kullanicilar] ADD  CONSTRAINT [DF_Kullanicilar_Kayit]  DEFAULT (sysutcdatetime()) FOR [KayitTarihiUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KullaniciRolAtamalari_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KullaniciRolAtamalari] ADD  CONSTRAINT [DF_KullaniciRolAtamalari_Kayit]  DEFAULT (sysutcdatetime()) FOR [AtamaTarihiUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KullaniciRolleri_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KullaniciRolleri] ADD  CONSTRAINT [DF_KullaniciRolleri_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KullaniciRolleri_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KullaniciRolleri] ADD  CONSTRAINT [DF_KullaniciRolleri_Kayit]  DEFAULT (sysutcdatetime()) FOR [KayitTarihiUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KullaniciYetkileri_Guncelleme]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KullaniciYetkileri] ADD  CONSTRAINT [DF_KullaniciYetkileri_Guncelleme]  DEFAULT (sysutcdatetime()) FOR [GuncellemeTarihiUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_KurtarmaTeslim_Olusturma]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[KurtarmaKoduTeslimDurumu] ADD  CONSTRAINT [DF_KurtarmaTeslim_Olusturma]  DEFAULT (sysutcdatetime()) FOR [OlusturulmaUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_De__Aktif__55DFB4D9]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Depo] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Do__Kapal__058EC7FB]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Donem] ADD  DEFAULT ((0)) FOR [Kapali]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Ek__Zaman__511AFFBC]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Ek] ADD  DEFAULT (sysdatetimeoffset()) FOR [Zaman]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Fi__Durum__0C3BC58A]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Fis] ADD  DEFAULT (N'Taslak') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Fi__Zaman__0E240DFC]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Fis] ADD  DEFAULT (sysdatetimeoffset()) FOR [Zaman]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Fi__Doviz__15C52FC4]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_FisKalem] ADD  DEFAULT ('TRY') FOR [Doviz]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Fi__Doviz__16B953FD]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_FisKalem] ADD  DEFAULT ((0)) FOR [DovizTutar]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_FisK__Kur__17AD7836]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_FisKalem] ADD  DEFAULT ((1)) FOR [Kur]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Gi__Gunce__7EE1CA6C]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Gizli] ADD  DEFAULT (sysdatetimeoffset()) FOR [Guncelleme]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_He__Aktif__01BE3717]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Hesap] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Ka__Olust__47919582]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Kayit] ADD  DEFAULT (sysdatetimeoffset()) FOR [Olusturma]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Ka__Gunce__4885B9BB]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Kayit] ADD  DEFAULT (sysdatetimeoffset()) FOR [Guncelleme]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Lo__Kalit__5F691F13]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Lot] ADD  DEFAULT (N'Serbest') FOR [Kalite]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Lo__Olust__61516785]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Lot] ADD  DEFAULT (sysdatetimeoffset()) FOR [Olusturma]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Lo__Zaman__6BCEF5F8]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_LotHareket] ADD  DEFAULT (sysdatetimeoffset()) FOR [Zaman]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Ol__Zaman__4C564A9F]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Olay] ADD  DEFAULT (sysdatetimeoffset()) FOR [Zaman]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Ra__Aktif__5AA469F6]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Raf] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Re__Durum__737017C0]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Rezervasyon] ADD  DEFAULT (N'Bekliyor') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Re__Zaman__74643BF9]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Rezervasyon] ADD  DEFAULT (sysdatetimeoffset()) FOR [Zaman]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Sa__Kapan__231F2AE2]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_Satis] ADD  DEFAULT ((0)) FOR [Kapanan]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPX310_Sa__SevkE__3726238F]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPX310_SatisLot] ADD  DEFAULT ((0)) FOR [SevkEdilen]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPXNext_B__Carpa__7152C524]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPXNext_Barkod] ADD  DEFAULT ((1)) FOR [Carpan]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPXNext_B__Tarih__733B0D96]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPXNext_Barkod] ADD  DEFAULT (sysutcdatetime()) FOR [Tarih]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPXNext_D__Aktif__569ECEE8]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPXNext_Departman] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPXNext_D__Tarih__5E3FF0B0]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPXNext_Duyuru] ADD  DEFAULT (sysutcdatetime()) FOR [Tarih]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPXNext_G__Kayit__79E80B25]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPXNext_Gunluk] ADD  DEFAULT (sysutcdatetime()) FOR [Kayit]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPXNext_M__Tarih__770B9E7A]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPXNext_Maliyet] ADD  DEFAULT (sysutcdatetime()) FOR [Tarih]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPXNext_M__Tarih__7EACC042]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPXNext_MaliyetRevizyon] ADD  DEFAULT (sysutcdatetime()) FOR [Tarih]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__MPXNext_M__Tarih__68BD7F23]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[MPXNext_Mesaj] ADD  DEFAULT (sysutcdatetime()) FOR [Tarih]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_PiyasaFirmalari_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[PiyasaFirmalari] ADD  CONSTRAINT [DF_PiyasaFirmalari_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_PiyasaFiyatlari_Para]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[PiyasaFiyatlari] ADD  CONSTRAINT [DF_PiyasaFiyatlari_Para]  DEFAULT ('TRY') FOR [ParaBirimi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_PiyasaFiyatlari_Kontrol]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[PiyasaFiyatlari] ADD  CONSTRAINT [DF_PiyasaFiyatlari_Kontrol]  DEFAULT (sysutcdatetime()) FOR [SonKontrolUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_PlanliOdemeler_Durum]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[PlanliOdemeler] ADD  CONSTRAINT [DF_PlanliOdemeler_Durum]  DEFAULT (N'Bekliyor') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_PlanliOdemeler_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[PlanliOdemeler] ADD  CONSTRAINT [DF_PlanliOdemeler_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_RolYetkileri_Atama]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[RolYetkileri] ADD  CONSTRAINT [DF_RolYetkileri_Atama]  DEFAULT (sysutcdatetime()) FOR [AtamaTarihiUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokAileleri_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokAileleri] ADD  CONSTRAINT [DF_StokAileleri_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokAileleri_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokAileleri] ADD  CONSTRAINT [DF_StokAileleri_Kayit]  DEFAULT (sysutcdatetime()) FOR [KayitTarihiUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokAlimKayitlari_PB]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokAlimKayitlari] ADD  CONSTRAINT [DF_StokAlimKayitlari_PB]  DEFAULT ('TRY') FOR [ParaBirimi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokAlimKayitlari_Tarih]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokAlimKayitlari] ADD  CONSTRAINT [DF_StokAlimKayitlari_Tarih]  DEFAULT (sysutcdatetime()) FOR [KayitUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokBakiyeleri_Miktar]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokBakiyeleri] ADD  CONSTRAINT [DF_StokBakiyeleri_Miktar]  DEFAULT ((0)) FOR [Miktar]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokBakiyeleri_SonGuncelleme]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokBakiyeleri] ADD  CONSTRAINT [DF_StokBakiyeleri_SonGuncelleme]  DEFAULT (sysdatetime()) FOR [SonGuncelleme]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokFiyatlari_PB]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokFiyatlari] ADD  CONSTRAINT [DF_StokFiyatlari_PB]  DEFAULT ('TRY') FOR [ParaBirimi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokFiyatlari_Tarih]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokFiyatlari] ADD  CONSTRAINT [DF_StokFiyatlari_Tarih]  DEFAULT (sysutcdatetime()) FOR [GuncellemeUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokHareketleri_KayitTarihi]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokHareketleri] ADD  CONSTRAINT [DF_StokHareketleri_KayitTarihi]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__StokKartl__Aktif__4BAC3F29]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokKartlari] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__StokKartl__Kayit__4CA06362]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokKartlari] ADD  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokKat_Boru]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokKategorileri] ADD  CONSTRAINT [DF_StokKat_Boru]  DEFAULT ((0)) FOR [BoruOzellikleri]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokKat_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokKategorileri] ADD  CONSTRAINT [DF_StokKat_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokOzellik_Zorunlu]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokOzellikTanimlari] ADD  CONSTRAINT [DF_StokOzellik_Zorunlu]  DEFAULT ((0)) FOR [Zorunlu]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokOzellik_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokOzellikTanimlari] ADD  CONSTRAINT [DF_StokOzellik_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_StokTipleri_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StokTipleri] ADD  CONSTRAINT [DF_StokTipleri_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_TicariBelgeler_Durum]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[TicariBelgeler] ADD  CONSTRAINT [DF_TicariBelgeler_Durum]  DEFAULT (N'Kaydedildi') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_TicariBelgeler_Kayit]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[TicariBelgeler] ADD  CONSTRAINT [DF_TicariBelgeler_Kayit]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UretimEmirleri_Uretilen]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimEmirleri] ADD  CONSTRAINT [DF_UretimEmirleri_Uretilen]  DEFAULT ((0)) FOR [UretilenMiktar]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UretimEmirleri_Fire]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimEmirleri] ADD  CONSTRAINT [DF_UretimEmirleri_Fire]  DEFAULT ((0)) FOR [FireMiktari]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UretimEmirleri_Durum]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimEmirleri] ADD  CONSTRAINT [DF_UretimEmirleri_Durum]  DEFAULT (N'Planlandı') FOR [Durum]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UretimEmirleri_KayitTarihi]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimEmirleri] ADD  CONSTRAINT [DF_UretimEmirleri_KayitTarihi]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UretimEmriReceteAnlikKalemleri_Tarih]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimEmriReceteAnlikKalemleri] ADD  CONSTRAINT [DF_UretimEmriReceteAnlikKalemleri_Tarih]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UGK_Tarih]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimGunlukKayitlari] ADD  CONSTRAINT [DF_UGK_Tarih]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UPK_Tarih]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimPaketlemeKayitlari] ADD  CONSTRAINT [DF_UPK_Tarih]  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__UretimRec__Aktif__693CA210]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimReceteleri] ADD  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__UretimRec__Kayit__6A30C649]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimReceteleri] ADD  DEFAULT (sysdatetime()) FOR [KayitTarihi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UretimStokIslemleri_IslemZamani]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UretimStokIslemleri] ADD  CONSTRAINT [DF_UretimStokIslemleri_IslemZamani]  DEFAULT (sysdatetime()) FOR [IslemZamani]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UrunGorselleri_Kapak]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UrunGorselleri] ADD  CONSTRAINT [DF_UrunGorselleri_Kapak]  DEFAULT ((0)) FOR [KapakMi]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UrunGorselleri_Sira]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UrunGorselleri] ADD  CONSTRAINT [DF_UrunGorselleri_Sira]  DEFAULT ((0)) FOR [SiraNo]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_UrunGorselleri_Tarih]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[UrunGorselleri] ADD  CONSTRAINT [DF_UrunGorselleri_Tarih]  DEFAULT (sysutcdatetime()) FOR [EklenmeUtc]
END

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF_Yetkiler_Aktif]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Yetkiler] ADD  CONSTRAINT [DF_Yetkiler_Aktif]  DEFAULT ((1)) FOR [Aktif]
END

GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP_IKIs__Perso__1FB8AE52]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_IKIslem]'))
ALTER TABLE [dbo].[BERP_IKIslem]  WITH CHECK ADD FOREIGN KEY([PersonelId])
REFERENCES [dbo].[BERP_Personel] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP_Pake__Parti__38845C1C]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_Paket]'))
ALTER TABLE [dbo].[BERP_Paket]  WITH CHECK ADD FOREIGN KEY([PartiId])
REFERENCES [dbo].[BERP_Parti] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP_Part__Harek__31D75E8D]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_Parti]'))
ALTER TABLE [dbo].[BERP_Parti]  WITH CHECK ADD FOREIGN KEY([HareketId])
REFERENCES [dbo].[StokHareketleri] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP_Part__StokI__30E33A54]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_Parti]'))
ALTER TABLE [dbo].[BERP_Parti]  WITH CHECK ADD FOREIGN KEY([StokId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP_Tica__Dosya__5708E33C]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_TicaretOdeme]'))
ALTER TABLE [dbo].[BERP_TicaretOdeme]  WITH CHECK ADD FOREIGN KEY([DosyaId])
REFERENCES [dbo].[BERP_TicaretDosya] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP_Tica__Dosya__43F60EC8]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_TicaretOlay]'))
ALTER TABLE [dbo].[BERP_TicaretOlay]  WITH CHECK ADD FOREIGN KEY([DosyaId])
REFERENCES [dbo].[BERP_TicaretDosya] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP200_R__Mamul__09946309]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP200_Recete]'))
ALTER TABLE [dbo].[BERP200_Recete]  WITH CHECK ADD FOREIGN KEY([MamulId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP200_R__Recet__0F4D3C5F]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP200_ReceteKalem]'))
ALTER TABLE [dbo].[BERP200_ReceteKalem]  WITH CHECK ADD FOREIGN KEY([ReceteId])
REFERENCES [dbo].[BERP200_Recete] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP200_R__StokI__10416098]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP200_ReceteKalem]'))
ALTER TABLE [dbo].[BERP200_ReceteKalem]  WITH CHECK ADD FOREIGN KEY([StokId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP200_U__Recet__150615B5]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP200_Uretim]'))
ALTER TABLE [dbo].[BERP200_Uretim]  WITH CHECK ADD FOREIGN KEY([ReceteId])
REFERENCES [dbo].[BERP200_Recete] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP210_G__Muste__6B0FDBE9]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP210_Gorusme]'))
ALTER TABLE [dbo].[BERP210_Gorusme]  WITH CHECK ADD FOREIGN KEY([MusteriId])
REFERENCES [dbo].[BERP210_SahaMusteri] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP220_C__Hesap__00FF1D08]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP220_Cihaz]'))
ALTER TABLE [dbo].[BERP220_Cihaz]  WITH CHECK ADD FOREIGN KEY([HesapId])
REFERENCES [dbo].[BERP220_Hesap] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP220_E__Hesap__7E22B05D]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP220_Esleme]'))
ALTER TABLE [dbo].[BERP220_Esleme]  WITH CHECK ADD FOREIGN KEY([HesapId])
REFERENCES [dbo].[BERP220_Hesap] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP220_H__Kulla__795DFB40]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP220_Hesap]'))
ALTER TABLE [dbo].[BERP220_Hesap]  WITH CHECK ADD FOREIGN KEY([KullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP270_E__TersI__3296789C]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeIslem]'))
ALTER TABLE [dbo].[BERP270_EBelgeIslem]  WITH CHECK ADD FOREIGN KEY([TersId])
REFERENCES [dbo].[BERP270_EBelgeIslem] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP270_E__Belge__253C7D7E]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeOlay]'))
ALTER TABLE [dbo].[BERP270_EBelgeOlay]  WITH CHECK ADD FOREIGN KEY([BelgeId])
REFERENCES [dbo].[BERP270_EBelge] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP270_E__Ebelg__3E082B48]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeSatisBag]'))
ALTER TABLE [dbo].[BERP270_EBelgeSatisBag]  WITH CHECK ADD FOREIGN KEY([EbelgeId])
REFERENCES [dbo].[BERP270_EBelge] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BERP270_E__Islem__36670980]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeStokBag]'))
ALTER TABLE [dbo].[BERP270_EBelgeStokBag]  WITH CHECK ADD FOREIGN KEY([IslemId])
REFERENCES [dbo].[BERP270_EBelgeIslem] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Bildirimler_Alici]') AND parent_object_id = OBJECT_ID(N'[dbo].[Bildirimler]'))
ALTER TABLE [dbo].[Bildirimler]  WITH CHECK ADD  CONSTRAINT [FK_Bildirimler_Alici] FOREIGN KEY([AliciKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Bildirimler_Alici]') AND parent_object_id = OBJECT_ID(N'[dbo].[Bildirimler]'))
ALTER TABLE [dbo].[Bildirimler] CHECK CONSTRAINT [FK_Bildirimler_Alici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Bildirimler_Ilgili]') AND parent_object_id = OBJECT_ID(N'[dbo].[Bildirimler]'))
ALTER TABLE [dbo].[Bildirimler]  WITH CHECK ADD  CONSTRAINT [FK_Bildirimler_Ilgili] FOREIGN KEY([IlgiliKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Bildirimler_Ilgili]') AND parent_object_id = OBJECT_ID(N'[dbo].[Bildirimler]'))
ALTER TABLE [dbo].[Bildirimler] CHECK CONSTRAINT [FK_Bildirimler_Ilgili]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_GelenEFaturalar_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelenEFaturalar]'))
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar]  WITH CHECK ADD  CONSTRAINT [FK_BoruERP_GelenEFaturalar_Cari] FOREIGN KEY([CariId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_GelenEFaturalar_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelenEFaturalar]'))
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar] CHECK CONSTRAINT [FK_BoruERP_GelenEFaturalar_Cari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_GelenEFaturalar_Kul]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelenEFaturalar]'))
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar]  WITH CHECK ADD  CONSTRAINT [FK_BoruERP_GelenEFaturalar_Kul] FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_GelenEFaturalar_Kul]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelenEFaturalar]'))
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar] CHECK CONSTRAINT [FK_BoruERP_GelenEFaturalar_Kul]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BoruERP_G__Hesap__695C9DA1]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelirGider]'))
ALTER TABLE [dbo].[BoruERP_GelirGider]  WITH CHECK ADD FOREIGN KEY([HesapKodu])
REFERENCES [dbo].[BoruERP_GGHesaplar] ([Kod])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BoruERP_G__Iptal__70099B30]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelirGider]'))
ALTER TABLE [dbo].[BoruERP_GelirGider]  WITH CHECK ADD FOREIGN KEY([IptalKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BoruERP_G__Maliy__6A50C1DA]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelirGider]'))
ALTER TABLE [dbo].[BoruERP_GelirGider]  WITH CHECK ADD FOREIGN KEY([MaliyetMerkeziId])
REFERENCES [dbo].[BoruERP_MaliyetMerkezleri] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BoruERP_G__Yapan__6D2D2E85]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelirGider]'))
ALTER TABLE [dbo].[BoruERP_GelirGider]  WITH CHECK ADD FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BoruERP_G__Finan__74CE504D]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GGOdemeler]'))
ALTER TABLE [dbo].[BoruERP_GGOdemeler]  WITH CHECK ADD FOREIGN KEY([FinansHareketId])
REFERENCES [dbo].[FinansHareketleri] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__BoruERP_G__Kayit__73DA2C14]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GGOdemeler]'))
ALTER TABLE [dbo].[BoruERP_GGOdemeler]  WITH CHECK ADD FOREIGN KEY([KayitId])
REFERENCES [dbo].[BoruERP_GelirGider] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniBelgeKalemleri_Belge]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri]  WITH CHECK ADD  CONSTRAINT [FK_BoruERP_YeniBelgeKalemleri_Belge] FOREIGN KEY([BelgeId])
REFERENCES [dbo].[BoruERP_YeniBelgeler] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniBelgeKalemleri_Belge]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri] CHECK CONSTRAINT [FK_BoruERP_YeniBelgeKalemleri_Belge]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniBelgeKalemleri_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri]  WITH CHECK ADD  CONSTRAINT [FK_BoruERP_YeniBelgeKalemleri_Stok] FOREIGN KEY([StokKartId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniBelgeKalemleri_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri] CHECK CONSTRAINT [FK_BoruERP_YeniBelgeKalemleri_Stok]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniBelgeler_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeler]  WITH CHECK ADD  CONSTRAINT [FK_BoruERP_YeniBelgeler_Cari] FOREIGN KEY([CariId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniBelgeler_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeler] CHECK CONSTRAINT [FK_BoruERP_YeniBelgeler_Cari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniBelgeler_Kul]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeler]  WITH CHECK ADD  CONSTRAINT [FK_BoruERP_YeniBelgeler_Kul] FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniBelgeler_Kul]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeler] CHECK CONSTRAINT [FK_BoruERP_YeniBelgeler_Kul]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniMasraflar_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniMasraflar]'))
ALTER TABLE [dbo].[BoruERP_YeniMasraflar]  WITH CHECK ADD  CONSTRAINT [FK_BoruERP_YeniMasraflar_Cari] FOREIGN KEY([CariId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniMasraflar_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniMasraflar]'))
ALTER TABLE [dbo].[BoruERP_YeniMasraflar] CHECK CONSTRAINT [FK_BoruERP_YeniMasraflar_Cari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniMasraflar_Finans]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniMasraflar]'))
ALTER TABLE [dbo].[BoruERP_YeniMasraflar]  WITH CHECK ADD  CONSTRAINT [FK_BoruERP_YeniMasraflar_Finans] FOREIGN KEY([FinansHareketId])
REFERENCES [dbo].[FinansHareketleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniMasraflar_Finans]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniMasraflar]'))
ALTER TABLE [dbo].[BoruERP_YeniMasraflar] CHECK CONSTRAINT [FK_BoruERP_YeniMasraflar_Finans]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniMasraflar_Kul]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniMasraflar]'))
ALTER TABLE [dbo].[BoruERP_YeniMasraflar]  WITH CHECK ADD  CONSTRAINT [FK_BoruERP_YeniMasraflar_Kul] FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_BoruERP_YeniMasraflar_Kul]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniMasraflar]'))
ALTER TABLE [dbo].[BoruERP_YeniMasraflar] CHECK CONSTRAINT [FK_BoruERP_YeniMasraflar_Kul]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CariHareketleri_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariHareketleri]'))
ALTER TABLE [dbo].[CariHareketleri]  WITH CHECK ADD  CONSTRAINT [FK_CariHareketleri_Cari] FOREIGN KEY([CariId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CariHareketleri_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariHareketleri]'))
ALTER TABLE [dbo].[CariHareketleri] CHECK CONSTRAINT [FK_CariHareketleri_Cari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CariHareketleri_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariHareketleri]'))
ALTER TABLE [dbo].[CariHareketleri]  WITH CHECK ADD  CONSTRAINT [FK_CariHareketleri_Kullanici] FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CariHareketleri_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariHareketleri]'))
ALTER TABLE [dbo].[CariHareketleri] CHECK CONSTRAINT [FK_CariHareketleri_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CekSenetDurumGecmisi_Evrak]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetDurumGecmisi]'))
ALTER TABLE [dbo].[CekSenetDurumGecmisi]  WITH CHECK ADD  CONSTRAINT [FK_CekSenetDurumGecmisi_Evrak] FOREIGN KEY([EvrakId])
REFERENCES [dbo].[CekSenetler] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CekSenetDurumGecmisi_Evrak]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetDurumGecmisi]'))
ALTER TABLE [dbo].[CekSenetDurumGecmisi] CHECK CONSTRAINT [FK_CekSenetDurumGecmisi_Evrak]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CekSenetDurumGecmisi_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetDurumGecmisi]'))
ALTER TABLE [dbo].[CekSenetDurumGecmisi]  WITH CHECK ADD  CONSTRAINT [FK_CekSenetDurumGecmisi_Kullanici] FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CekSenetDurumGecmisi_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetDurumGecmisi]'))
ALTER TABLE [dbo].[CekSenetDurumGecmisi] CHECK CONSTRAINT [FK_CekSenetDurumGecmisi_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CekSenetler_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler]  WITH CHECK ADD  CONSTRAINT [FK_CekSenetler_Cari] FOREIGN KEY([CariId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CekSenetler_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler] CHECK CONSTRAINT [FK_CekSenetler_Cari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CekSenetler_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler]  WITH CHECK ADD  CONSTRAINT [FK_CekSenetler_Kullanici] FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_CekSenetler_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler] CHECK CONSTRAINT [FK_CekSenetler_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FinansHareketleri_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri]  WITH CHECK ADD  CONSTRAINT [FK_FinansHareketleri_Cari] FOREIGN KEY([CariId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FinansHareketleri_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri] CHECK CONSTRAINT [FK_FinansHareketleri_Cari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FinansHareketleri_CariHareket]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri]  WITH CHECK ADD  CONSTRAINT [FK_FinansHareketleri_CariHareket] FOREIGN KEY([CariHareketId])
REFERENCES [dbo].[CariHareketleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FinansHareketleri_CariHareket]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri] CHECK CONSTRAINT [FK_FinansHareketleri_CariHareket]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FinansHareketleri_Hesap]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri]  WITH CHECK ADD  CONSTRAINT [FK_FinansHareketleri_Hesap] FOREIGN KEY([HesapId])
REFERENCES [dbo].[FinansHesaplari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FinansHareketleri_Hesap]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri] CHECK CONSTRAINT [FK_FinansHareketleri_Hesap]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FinansHareketleri_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri]  WITH CHECK ADD  CONSTRAINT [FK_FinansHareketleri_Kullanici] FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_FinansHareketleri_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri] CHECK CONSTRAINT [FK_FinansHareketleri_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_HammaddePaketleri_Parti]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePaketleri]'))
ALTER TABLE [dbo].[HammaddePaketleri]  WITH CHECK ADD  CONSTRAINT [FK_HammaddePaketleri_Parti] FOREIGN KEY([PartiId])
REFERENCES [dbo].[HammaddePartileri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_HammaddePaketleri_Parti]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePaketleri]'))
ALTER TABLE [dbo].[HammaddePaketleri] CHECK CONSTRAINT [FK_HammaddePaketleri_Parti]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_HammaddePartileri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePartileri]'))
ALTER TABLE [dbo].[HammaddePartileri]  WITH CHECK ADD  CONSTRAINT [FK_HammaddePartileri_StokKartlari] FOREIGN KEY([StokKartId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_HammaddePartileri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePartileri]'))
ALTER TABLE [dbo].[HammaddePartileri] CHECK CONSTRAINT [FK_HammaddePartileri_StokKartlari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__Hatirlana__Kulla__07220AB2]') AND parent_object_id = OBJECT_ID(N'[dbo].[HatirlananOturumlar]'))
ALTER TABLE [dbo].[HatirlananOturumlar]  WITH CHECK ADD FOREIGN KEY([KullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__Hatirlana__Kulla__2022C2A6]') AND parent_object_id = OBJECT_ID(N'[dbo].[HatirlananOturumlar]'))
ALTER TABLE [dbo].[HatirlananOturumlar]  WITH CHECK ADD FOREIGN KEY([KullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__Hatirlana__Kulla__5C37ACAD]') AND parent_object_id = OBJECT_ID(N'[dbo].[HatirlananOturumlar]'))
ALTER TABLE [dbo].[HatirlananOturumlar]  WITH CHECK ADD FOREIGN KEY([KullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciGorunumAyarlari_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciGorunumAyarlari]'))
ALTER TABLE [dbo].[KullaniciGorunumAyarlari]  WITH CHECK ADD  CONSTRAINT [FK_KullaniciGorunumAyarlari_Kullanici] FOREIGN KEY([KullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciGorunumAyarlari_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciGorunumAyarlari]'))
ALTER TABLE [dbo].[KullaniciGorunumAyarlari] CHECK CONSTRAINT [FK_KullaniciGorunumAyarlari_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KurtarmaKodlari_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciKurtarmaKodlari]'))
ALTER TABLE [dbo].[KullaniciKurtarmaKodlari]  WITH CHECK ADD  CONSTRAINT [FK_KurtarmaKodlari_Kullanici] FOREIGN KEY([KullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KurtarmaKodlari_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciKurtarmaKodlari]'))
ALTER TABLE [dbo].[KullaniciKurtarmaKodlari] CHECK CONSTRAINT [FK_KurtarmaKodlari_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciRolAtamalari_Kullanicilar]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciRolAtamalari]'))
ALTER TABLE [dbo].[KullaniciRolAtamalari]  WITH CHECK ADD  CONSTRAINT [FK_KullaniciRolAtamalari_Kullanicilar] FOREIGN KEY([KullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciRolAtamalari_Kullanicilar]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciRolAtamalari]'))
ALTER TABLE [dbo].[KullaniciRolAtamalari] CHECK CONSTRAINT [FK_KullaniciRolAtamalari_Kullanicilar]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciRolAtamalari_Roller]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciRolAtamalari]'))
ALTER TABLE [dbo].[KullaniciRolAtamalari]  WITH CHECK ADD  CONSTRAINT [FK_KullaniciRolAtamalari_Roller] FOREIGN KEY([RolId])
REFERENCES [dbo].[KullaniciRolleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciRolAtamalari_Roller]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciRolAtamalari]'))
ALTER TABLE [dbo].[KullaniciRolAtamalari] CHECK CONSTRAINT [FK_KullaniciRolAtamalari_Roller]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciYetkileri_Guncelleyen]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciYetkileri]'))
ALTER TABLE [dbo].[KullaniciYetkileri]  WITH CHECK ADD  CONSTRAINT [FK_KullaniciYetkileri_Guncelleyen] FOREIGN KEY([GuncelleyenKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciYetkileri_Guncelleyen]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciYetkileri]'))
ALTER TABLE [dbo].[KullaniciYetkileri] CHECK CONSTRAINT [FK_KullaniciYetkileri_Guncelleyen]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciYetkileri_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciYetkileri]'))
ALTER TABLE [dbo].[KullaniciYetkileri]  WITH CHECK ADD  CONSTRAINT [FK_KullaniciYetkileri_Kullanici] FOREIGN KEY([KullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciYetkileri_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciYetkileri]'))
ALTER TABLE [dbo].[KullaniciYetkileri] CHECK CONSTRAINT [FK_KullaniciYetkileri_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciYetkileri_Yetki]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciYetkileri]'))
ALTER TABLE [dbo].[KullaniciYetkileri]  WITH CHECK ADD  CONSTRAINT [FK_KullaniciYetkileri_Yetki] FOREIGN KEY([YetkiId])
REFERENCES [dbo].[Yetkiler] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KullaniciYetkileri_Yetki]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciYetkileri]'))
ALTER TABLE [dbo].[KullaniciYetkileri] CHECK CONSTRAINT [FK_KullaniciYetkileri_Yetki]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KurtarmaTeslim_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[KurtarmaKoduTeslimDurumu]'))
ALTER TABLE [dbo].[KurtarmaKoduTeslimDurumu]  WITH CHECK ADD  CONSTRAINT [FK_KurtarmaTeslim_Kullanici] FOREIGN KEY([KullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_KurtarmaTeslim_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[KurtarmaKoduTeslimDurumu]'))
ALTER TABLE [dbo].[KurtarmaKoduTeslimDurumu] CHECK CONSTRAINT [FK_KurtarmaTeslim_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Ek__Kayit__5026DB83]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Ek]'))
ALTER TABLE [dbo].[MPX310_Ek]  WITH CHECK ADD FOREIGN KEY([KayitId])
REFERENCES [dbo].[MPX310_Kayit] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Fi__TersF__0D2FE9C3]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Fis]'))
ALTER TABLE [dbo].[MPX310_Fis]  WITH CHECK ADD FOREIGN KEY([TersFisId])
REFERENCES [dbo].[MPX310_Fis] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Fi__CariI__14D10B8B]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_FisKalem]'))
ALTER TABLE [dbo].[MPX310_FisKalem]  WITH CHECK ADD FOREIGN KEY([CariId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Fi__FisId__11007AA7]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_FisKalem]'))
ALTER TABLE [dbo].[MPX310_FisKalem]  WITH CHECK ADD FOREIGN KEY([FisId])
REFERENCES [dbo].[MPX310_Fis] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Fi__Hesap__11F49EE0]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_FisKalem]'))
ALTER TABLE [dbo].[MPX310_FisKalem]  WITH CHECK ADD FOREIGN KEY([Hesap])
REFERENCES [dbo].[MPX310_Hesap] ([Kod])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Ka__Paren__45A94D10]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Kayit]'))
ALTER TABLE [dbo].[MPX310_Kayit]  WITH CHECK ADD FOREIGN KEY([ParentId])
REFERENCES [dbo].[MPX310_Kayit] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Lo__StokI__5E74FADA]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Lot]'))
ALTER TABLE [dbo].[MPX310_Lot]  WITH CHECK ADD FOREIGN KEY([StokId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Lo__Kayit__7B113988]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotBag]'))
ALTER TABLE [dbo].[MPX310_LotBag]  WITH CHECK ADD FOREIGN KEY([KayitId])
REFERENCES [dbo].[MPX310_Kayit] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Lo__Kayna__7834CCDD]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotBag]'))
ALTER TABLE [dbo].[MPX310_LotBag]  WITH CHECK ADD FOREIGN KEY([KaynakLot])
REFERENCES [dbo].[MPX310_Lot] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Lo__UrunL__7928F116]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotBag]'))
ALTER TABLE [dbo].[MPX310_LotBag]  WITH CHECK ADD FOREIGN KEY([UrunLot])
REFERENCES [dbo].[MPX310_Lot] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Lo__LotId__642DD430]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotBakiye]'))
ALTER TABLE [dbo].[MPX310_LotBakiye]  WITH CHECK ADD FOREIGN KEY([LotId])
REFERENCES [dbo].[MPX310_Lot] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Lo__RafId__6521F869]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotBakiye]'))
ALTER TABLE [dbo].[MPX310_LotBakiye]  WITH CHECK ADD FOREIGN KEY([RafId])
REFERENCES [dbo].[MPX310_Raf] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Lo__LotId__68F2894D]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotHareket]'))
ALTER TABLE [dbo].[MPX310_LotHareket]  WITH CHECK ADD FOREIGN KEY([LotId])
REFERENCES [dbo].[MPX310_Lot] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Lo__RafId__69E6AD86]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotHareket]'))
ALTER TABLE [dbo].[MPX310_LotHareket]  WITH CHECK ADD FOREIGN KEY([RafId])
REFERENCES [dbo].[MPX310_Raf] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Ol__Kayit__4B622666]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Olay]'))
ALTER TABLE [dbo].[MPX310_Olay]  WITH CHECK ADD FOREIGN KEY([KayitId])
REFERENCES [dbo].[MPX310_Kayit] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Ra__DepoI__59B045BD]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Raf]'))
ALTER TABLE [dbo].[MPX310_Raf]  WITH CHECK ADD FOREIGN KEY([DepoId])
REFERENCES [dbo].[MPX310_Depo] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Re__Kayit__6F9F86DC]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Rezervasyon]'))
ALTER TABLE [dbo].[MPX310_Rezervasyon]  WITH CHECK ADD FOREIGN KEY([KayitId])
REFERENCES [dbo].[MPX310_Kayit] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Re__LotId__7093AB15]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Rezervasyon]'))
ALTER TABLE [dbo].[MPX310_Rezervasyon]  WITH CHECK ADD FOREIGN KEY([LotId])
REFERENCES [dbo].[MPX310_Lot] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Re__RafId__7187CF4E]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Rezervasyon]'))
ALTER TABLE [dbo].[MPX310_Rezervasyon]  WITH CHECK ADD FOREIGN KEY([RafId])
REFERENCES [dbo].[MPX310_Raf] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Sa__Belge__1E5A75C5]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Satis]'))
ALTER TABLE [dbo].[MPX310_Satis]  WITH CHECK ADD FOREIGN KEY([BelgeId])
REFERENCES [dbo].[BoruERP_YeniBelgeler] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Sa__CariH__1F4E99FE]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Satis]'))
ALTER TABLE [dbo].[MPX310_Satis]  WITH CHECK ADD FOREIGN KEY([CariHareketId])
REFERENCES [dbo].[CariHareketleri] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Sa__FisId__2042BE37]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Satis]'))
ALTER TABLE [dbo].[MPX310_Satis]  WITH CHECK ADD FOREIGN KEY([FisId])
REFERENCES [dbo].[MPX310_Fis] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Sa__Belge__32616E72]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_SatisLot]'))
ALTER TABLE [dbo].[MPX310_SatisLot]  WITH CHECK ADD FOREIGN KEY([BelgeId])
REFERENCES [dbo].[MPX310_Satis] ([BelgeId])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Sa__Kalem__335592AB]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_SatisLot]'))
ALTER TABLE [dbo].[MPX310_SatisLot]  WITH CHECK ADD FOREIGN KEY([KalemId])
REFERENCES [dbo].[BoruERP_YeniBelgeKalemleri] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Sa__LotId__3449B6E4]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_SatisLot]'))
ALTER TABLE [dbo].[MPX310_SatisLot]  WITH CHECK ADD FOREIGN KEY([LotId])
REFERENCES [dbo].[MPX310_Lot] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Sa__RafId__353DDB1D]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_SatisLot]'))
ALTER TABLE [dbo].[MPX310_SatisLot]  WITH CHECK ADD FOREIGN KEY([RafId])
REFERENCES [dbo].[MPX310_Raf] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Ta__Belge__2AC04CAA]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Tahsilat]'))
ALTER TABLE [dbo].[MPX310_Tahsilat]  WITH CHECK ADD FOREIGN KEY([BelgeId])
REFERENCES [dbo].[MPX310_Satis] ([BelgeId])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Ta__CariH__2E90DD8E]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Tahsilat]'))
ALTER TABLE [dbo].[MPX310_Tahsilat]  WITH CHECK ADD FOREIGN KEY([CariHareketId])
REFERENCES [dbo].[CariHareketleri] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Ta__Finan__2D9CB955]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Tahsilat]'))
ALTER TABLE [dbo].[MPX310_Tahsilat]  WITH CHECK ADD FOREIGN KEY([FinansHareketId])
REFERENCES [dbo].[FinansHareketleri] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPX310_Ta__FisId__2F8501C7]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Tahsilat]'))
ALTER TABLE [dbo].[MPX310_Tahsilat]  WITH CHECK ADD FOREIGN KEY([FisId])
REFERENCES [dbo].[MPX310_Fis] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_Ba__Stok__705EA0EB]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_Barkod]'))
ALTER TABLE [dbo].[MPXNext_Barkod]  WITH CHECK ADD FOREIGN KEY([Stok])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_D__Depar__597B3B93]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_DepartmanUye]'))
ALTER TABLE [dbo].[MPXNext_DepartmanUye]  WITH CHECK ADD FOREIGN KEY([Departman])
REFERENCES [dbo].[MPXNext_Departman] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_D__Kulla__5A6F5FCC]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_DepartmanUye]'))
ALTER TABLE [dbo].[MPXNext_DepartmanUye]  WITH CHECK ADD FOREIGN KEY([Kullanici])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_D__Duyur__611C5D5B]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_DuyuruAlici]'))
ALTER TABLE [dbo].[MPXNext_DuyuruAlici]  WITH CHECK ADD FOREIGN KEY([Duyuru])
REFERENCES [dbo].[MPXNext_Duyuru] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_D__Kulla__62108194]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_DuyuruAlici]'))
ALTER TABLE [dbo].[MPXNext_DuyuruAlici]  WITH CHECK ADD FOREIGN KEY([Kullanici])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_M__Kayit__7CC477D0]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_MaliyetRevizyon]'))
ALTER TABLE [dbo].[MPXNext_MaliyetRevizyon]  WITH CHECK ADD FOREIGN KEY([Kayit])
REFERENCES [dbo].[MPXNext_Maliyet] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_M__Alici__66D536B1]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_Mesaj]'))
ALTER TABLE [dbo].[MPXNext_Mesaj]  WITH CHECK ADD FOREIGN KEY([Alici])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_M__Depar__67C95AEA]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_Mesaj]'))
ALTER TABLE [dbo].[MPXNext_Mesaj]  WITH CHECK ADD FOREIGN KEY([Departman])
REFERENCES [dbo].[MPXNext_Departman] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_M__Gonde__65E11278]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_Mesaj]'))
ALTER TABLE [dbo].[MPXNext_Mesaj]  WITH CHECK ADD FOREIGN KEY([Gonderen])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_M__Kulla__6C8E1007]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_MesajOkuma]'))
ALTER TABLE [dbo].[MPXNext_MesajOkuma]  WITH CHECK ADD FOREIGN KEY([Kullanici])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK__MPXNext_M__Mesaj__6D823440]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_MesajOkuma]'))
ALTER TABLE [dbo].[MPXNext_MesajOkuma]  WITH CHECK ADD FOREIGN KEY([Mesaj])
REFERENCES [dbo].[MPXNext_Mesaj] ([Id])
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PiyasaFiyatlari_Firma]') AND parent_object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]'))
ALTER TABLE [dbo].[PiyasaFiyatlari]  WITH CHECK ADD  CONSTRAINT [FK_PiyasaFiyatlari_Firma] FOREIGN KEY([FirmaId])
REFERENCES [dbo].[PiyasaFirmalari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PiyasaFiyatlari_Firma]') AND parent_object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]'))
ALTER TABLE [dbo].[PiyasaFiyatlari] CHECK CONSTRAINT [FK_PiyasaFiyatlari_Firma]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PlanliOdemeler_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler]  WITH CHECK ADD  CONSTRAINT [FK_PlanliOdemeler_Cari] FOREIGN KEY([CariId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PlanliOdemeler_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler] CHECK CONSTRAINT [FK_PlanliOdemeler_Cari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PlanliOdemeler_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler]  WITH CHECK ADD  CONSTRAINT [FK_PlanliOdemeler_Kullanici] FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PlanliOdemeler_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler] CHECK CONSTRAINT [FK_PlanliOdemeler_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolYetkileri_Rol]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolYetkileri]'))
ALTER TABLE [dbo].[RolYetkileri]  WITH CHECK ADD  CONSTRAINT [FK_RolYetkileri_Rol] FOREIGN KEY([RolId])
REFERENCES [dbo].[KullaniciRolleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolYetkileri_Rol]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolYetkileri]'))
ALTER TABLE [dbo].[RolYetkileri] CHECK CONSTRAINT [FK_RolYetkileri_Rol]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolYetkileri_Yetki]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolYetkileri]'))
ALTER TABLE [dbo].[RolYetkileri]  WITH CHECK ADD  CONSTRAINT [FK_RolYetkileri_Yetki] FOREIGN KEY([YetkiId])
REFERENCES [dbo].[Yetkiler] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_RolYetkileri_Yetki]') AND parent_object_id = OBJECT_ID(N'[dbo].[RolYetkileri]'))
ALTER TABLE [dbo].[RolYetkileri] CHECK CONSTRAINT [FK_RolYetkileri_Yetki]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokAlimKayitlari_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]'))
ALTER TABLE [dbo].[StokAlimKayitlari]  WITH CHECK ADD  CONSTRAINT [FK_StokAlimKayitlari_Cari] FOREIGN KEY([CariKartId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokAlimKayitlari_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]'))
ALTER TABLE [dbo].[StokAlimKayitlari] CHECK CONSTRAINT [FK_StokAlimKayitlari_Cari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokAlimKayitlari_Hareket]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]'))
ALTER TABLE [dbo].[StokAlimKayitlari]  WITH CHECK ADD  CONSTRAINT [FK_StokAlimKayitlari_Hareket] FOREIGN KEY([StokHareketId])
REFERENCES [dbo].[StokHareketleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokAlimKayitlari_Hareket]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]'))
ALTER TABLE [dbo].[StokAlimKayitlari] CHECK CONSTRAINT [FK_StokAlimKayitlari_Hareket]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokAlimKayitlari_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]'))
ALTER TABLE [dbo].[StokAlimKayitlari]  WITH CHECK ADD  CONSTRAINT [FK_StokAlimKayitlari_Stok] FOREIGN KEY([StokKartId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokAlimKayitlari_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]'))
ALTER TABLE [dbo].[StokAlimKayitlari] CHECK CONSTRAINT [FK_StokAlimKayitlari_Stok]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokBakiyeleri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokBakiyeleri]'))
ALTER TABLE [dbo].[StokBakiyeleri]  WITH CHECK ADD  CONSTRAINT [FK_StokBakiyeleri_StokKartlari] FOREIGN KEY([StokKartId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokBakiyeleri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokBakiyeleri]'))
ALTER TABLE [dbo].[StokBakiyeleri] CHECK CONSTRAINT [FK_StokBakiyeleri_StokKartlari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokFiyatlari_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokFiyatlari]'))
ALTER TABLE [dbo].[StokFiyatlari]  WITH CHECK ADD  CONSTRAINT [FK_StokFiyatlari_Stok] FOREIGN KEY([StokKartId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokFiyatlari_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokFiyatlari]'))
ALTER TABLE [dbo].[StokFiyatlari] CHECK CONSTRAINT [FK_StokFiyatlari_Stok]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokHareketleri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri]  WITH CHECK ADD  CONSTRAINT [FK_StokHareketleri_StokKartlari] FOREIGN KEY([StokKartId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokHareketleri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri] CHECK CONSTRAINT [FK_StokHareketleri_StokKartlari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokHareketleri_UretimStokIslemleri]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri]  WITH CHECK ADD  CONSTRAINT [FK_StokHareketleri_UretimStokIslemleri] FOREIGN KEY([UretimStokIslemId])
REFERENCES [dbo].[UretimStokIslemleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokHareketleri_UretimStokIslemleri]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri] CHECK CONSTRAINT [FK_StokHareketleri_UretimStokIslemleri]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKartlari_StokAileleri]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKartlari]'))
ALTER TABLE [dbo].[StokKartlari]  WITH CHECK ADD  CONSTRAINT [FK_StokKartlari_StokAileleri] FOREIGN KEY([StokAileId])
REFERENCES [dbo].[StokAileleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKartlari_StokAileleri]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKartlari]'))
ALTER TABLE [dbo].[StokKartlari] CHECK CONSTRAINT [FK_StokKartlari_StokAileleri]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKat_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKategorileri]'))
ALTER TABLE [dbo].[StokKategorileri]  WITH CHECK ADD  CONSTRAINT [FK_StokKat_Tip] FOREIGN KEY([StokTipId])
REFERENCES [dbo].[StokTipleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKat_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKategorileri]'))
ALTER TABLE [dbo].[StokKategorileri] CHECK CONSTRAINT [FK_StokKat_Tip]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKat_Ust]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKategorileri]'))
ALTER TABLE [dbo].[StokKategorileri]  WITH CHECK ADD  CONSTRAINT [FK_StokKat_Ust] FOREIGN KEY([UstKategoriId])
REFERENCES [dbo].[StokKategorileri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKat_Ust]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKategorileri]'))
ALTER TABLE [dbo].[StokKategorileri] CHECK CONSTRAINT [FK_StokKat_Ust]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKategoriSec_Kategori]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKategoriSecimleri]'))
ALTER TABLE [dbo].[StokKategoriSecimleri]  WITH CHECK ADD  CONSTRAINT [FK_StokKategoriSec_Kategori] FOREIGN KEY([KategoriId])
REFERENCES [dbo].[StokKategorileri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKategoriSec_Kategori]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKategoriSecimleri]'))
ALTER TABLE [dbo].[StokKategoriSecimleri] CHECK CONSTRAINT [FK_StokKategoriSec_Kategori]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKategoriSec_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKategoriSecimleri]'))
ALTER TABLE [dbo].[StokKategoriSecimleri]  WITH CHECK ADD  CONSTRAINT [FK_StokKategoriSec_Stok] FOREIGN KEY([StokKartId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokKategoriSec_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokKategoriSecimleri]'))
ALTER TABLE [dbo].[StokKategoriSecimleri] CHECK CONSTRAINT [FK_StokKategoriSec_Stok]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokDeger_Ozellik]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikDegerleri]'))
ALTER TABLE [dbo].[StokOzellikDegerleri]  WITH CHECK ADD  CONSTRAINT [FK_StokDeger_Ozellik] FOREIGN KEY([OzellikId])
REFERENCES [dbo].[StokOzellikTanimlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokDeger_Ozellik]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikDegerleri]'))
ALTER TABLE [dbo].[StokOzellikDegerleri] CHECK CONSTRAINT [FK_StokDeger_Ozellik]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokDeger_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikDegerleri]'))
ALTER TABLE [dbo].[StokOzellikDegerleri]  WITH CHECK ADD  CONSTRAINT [FK_StokDeger_Stok] FOREIGN KEY([StokKartId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokDeger_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikDegerleri]'))
ALTER TABLE [dbo].[StokOzellikDegerleri] CHECK CONSTRAINT [FK_StokDeger_Stok]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokOzellik_Kategori]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikTanimlari]'))
ALTER TABLE [dbo].[StokOzellikTanimlari]  WITH CHECK ADD  CONSTRAINT [FK_StokOzellik_Kategori] FOREIGN KEY([KategoriId])
REFERENCES [dbo].[StokKategorileri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokOzellik_Kategori]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikTanimlari]'))
ALTER TABLE [dbo].[StokOzellikTanimlari] CHECK CONSTRAINT [FK_StokOzellik_Kategori]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokOzellik_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikTanimlari]'))
ALTER TABLE [dbo].[StokOzellikTanimlari]  WITH CHECK ADD  CONSTRAINT [FK_StokOzellik_Tip] FOREIGN KEY([StokTipId])
REFERENCES [dbo].[StokTipleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_StokOzellik_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikTanimlari]'))
ALTER TABLE [dbo].[StokOzellikTanimlari] CHECK CONSTRAINT [FK_StokOzellik_Tip]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TicariBelgeler_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler]  WITH CHECK ADD  CONSTRAINT [FK_TicariBelgeler_Cari] FOREIGN KEY([CariId])
REFERENCES [dbo].[CariKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TicariBelgeler_Cari]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler] CHECK CONSTRAINT [FK_TicariBelgeler_Cari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TicariBelgeler_CariHareket]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler]  WITH CHECK ADD  CONSTRAINT [FK_TicariBelgeler_CariHareket] FOREIGN KEY([CariHareketId])
REFERENCES [dbo].[CariHareketleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TicariBelgeler_CariHareket]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler] CHECK CONSTRAINT [FK_TicariBelgeler_CariHareket]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TicariBelgeler_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler]  WITH CHECK ADD  CONSTRAINT [FK_TicariBelgeler_Kullanici] FOREIGN KEY([YapanKullaniciId])
REFERENCES [dbo].[Kullanicilar] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TicariBelgeler_Kullanici]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler] CHECK CONSTRAINT [FK_TicariBelgeler_Kullanici]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimEmirleri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri]  WITH CHECK ADD  CONSTRAINT [FK_UretimEmirleri_StokKartlari] FOREIGN KEY([MamulStokId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimEmirleri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri] CHECK CONSTRAINT [FK_UretimEmirleri_StokKartlari]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimEmirleri_UretimReceteleri]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri]  WITH CHECK ADD  CONSTRAINT [FK_UretimEmirleri_UretimReceteleri] FOREIGN KEY([ReceteId])
REFERENCES [dbo].[UretimReceteleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimEmirleri_UretimReceteleri]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri] CHECK CONSTRAINT [FK_UretimEmirleri_UretimReceteleri]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimEmriReceteAnlikKalemleri_Emir]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmriReceteAnlikKalemleri]'))
ALTER TABLE [dbo].[UretimEmriReceteAnlikKalemleri]  WITH CHECK ADD  CONSTRAINT [FK_UretimEmriReceteAnlikKalemleri_Emir] FOREIGN KEY([UretimEmriId])
REFERENCES [dbo].[UretimEmirleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimEmriReceteAnlikKalemleri_Emir]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmriReceteAnlikKalemleri]'))
ALTER TABLE [dbo].[UretimEmriReceteAnlikKalemleri] CHECK CONSTRAINT [FK_UretimEmriReceteAnlikKalemleri_Emir]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimEmriReceteAnlikKalemleri_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmriReceteAnlikKalemleri]'))
ALTER TABLE [dbo].[UretimEmriReceteAnlikKalemleri]  WITH CHECK ADD  CONSTRAINT [FK_UretimEmriReceteAnlikKalemleri_Stok] FOREIGN KEY([HammaddeStokId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimEmriReceteAnlikKalemleri_Stok]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmriReceteAnlikKalemleri]'))
ALTER TABLE [dbo].[UretimEmriReceteAnlikKalemleri] CHECK CONSTRAINT [FK_UretimEmriReceteAnlikKalemleri_Stok]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UGK_UretimEmri]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimGunlukKayitlari]'))
ALTER TABLE [dbo].[UretimGunlukKayitlari]  WITH CHECK ADD  CONSTRAINT [FK_UGK_UretimEmri] FOREIGN KEY([UretimEmriId])
REFERENCES [dbo].[UretimEmirleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UGK_UretimEmri]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimGunlukKayitlari]'))
ALTER TABLE [dbo].[UretimGunlukKayitlari] CHECK CONSTRAINT [FK_UGK_UretimEmri]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UPK_UretimEmri]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimPaketlemeKayitlari]'))
ALTER TABLE [dbo].[UretimPaketlemeKayitlari]  WITH CHECK ADD  CONSTRAINT [FK_UPK_UretimEmri] FOREIGN KEY([UretimEmriId])
REFERENCES [dbo].[UretimEmirleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UPK_UretimEmri]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimPaketlemeKayitlari]'))
ALTER TABLE [dbo].[UretimPaketlemeKayitlari] CHECK CONSTRAINT [FK_UPK_UretimEmri]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReceteKalemleri_Hammadde]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimReceteKalemleri]'))
ALTER TABLE [dbo].[UretimReceteKalemleri]  WITH CHECK ADD  CONSTRAINT [FK_ReceteKalemleri_Hammadde] FOREIGN KEY([HammaddeStokId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReceteKalemleri_Hammadde]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimReceteKalemleri]'))
ALTER TABLE [dbo].[UretimReceteKalemleri] CHECK CONSTRAINT [FK_ReceteKalemleri_Hammadde]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReceteKalemleri_Recete]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimReceteKalemleri]'))
ALTER TABLE [dbo].[UretimReceteKalemleri]  WITH CHECK ADD  CONSTRAINT [FK_ReceteKalemleri_Recete] FOREIGN KEY([ReceteId])
REFERENCES [dbo].[UretimReceteleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ReceteKalemleri_Recete]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimReceteKalemleri]'))
ALTER TABLE [dbo].[UretimReceteKalemleri] CHECK CONSTRAINT [FK_ReceteKalemleri_Recete]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimReceteleri_Mamul]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimReceteleri]'))
ALTER TABLE [dbo].[UretimReceteleri]  WITH CHECK ADD  CONSTRAINT [FK_UretimReceteleri_Mamul] FOREIGN KEY([MamulStokId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimReceteleri_Mamul]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimReceteleri]'))
ALTER TABLE [dbo].[UretimReceteleri] CHECK CONSTRAINT [FK_UretimReceteleri_Mamul]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimStokIslemleri_Receteler]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimStokIslemleri]'))
ALTER TABLE [dbo].[UretimStokIslemleri]  WITH CHECK ADD  CONSTRAINT [FK_UretimStokIslemleri_Receteler] FOREIGN KEY([ReceteId])
REFERENCES [dbo].[UretimReceteleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimStokIslemleri_Receteler]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimStokIslemleri]'))
ALTER TABLE [dbo].[UretimStokIslemleri] CHECK CONSTRAINT [FK_UretimStokIslemleri_Receteler]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimStokIslemleri_UretimEmirleri]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimStokIslemleri]'))
ALTER TABLE [dbo].[UretimStokIslemleri]  WITH CHECK ADD  CONSTRAINT [FK_UretimStokIslemleri_UretimEmirleri] FOREIGN KEY([UretimEmriId])
REFERENCES [dbo].[UretimEmirleri] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UretimStokIslemleri_UretimEmirleri]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimStokIslemleri]'))
ALTER TABLE [dbo].[UretimStokIslemleri] CHECK CONSTRAINT [FK_UretimStokIslemleri_UretimEmirleri]
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UrunGorselleri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[UrunGorselleri]'))
ALTER TABLE [dbo].[UrunGorselleri]  WITH CHECK ADD  CONSTRAINT [FK_UrunGorselleri_StokKartlari] FOREIGN KEY([StokKartId])
REFERENCES [dbo].[StokKartlari] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UrunGorselleri_StokKartlari]') AND parent_object_id = OBJECT_ID(N'[dbo].[UrunGorselleri]'))
ALTER TABLE [dbo].[UrunGorselleri] CHECK CONSTRAINT [FK_UrunGorselleri_StokKartlari]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_IKIs__Mikta__23893F36]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_IKIslem]'))
ALTER TABLE [dbo].[BERP_IKIslem]  WITH CHECK ADD CHECK  (([Miktar]>=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_IKIslem__22951AFD]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_IKIslem]'))
ALTER TABLE [dbo].[BERP_IKIslem]  WITH CHECK ADD CHECK  (([Bitis]>=[Baslangic]))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_Paket__Kg__39788055]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_Paket]'))
ALTER TABLE [dbo].[BERP_Paket]  WITH CHECK ADD CHECK  (([Kg]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_Part__Paket__33BFA6FF]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_Parti]'))
ALTER TABLE [dbo].[BERP_Parti]  WITH CHECK ADD CHECK  (([PaketAdet]>=(1) AND [PaketAdet]<=(1000)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_Parti__Kg__32CB82C6]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_Parti]'))
ALTER TABLE [dbo].[BERP_Parti]  WITH CHECK ADD CHECK  (([Kg]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_Sati__Birim__2A363CC5]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_SatinAlma]'))
ALTER TABLE [dbo].[BERP_SatinAlma]  WITH CHECK ADD CHECK  (([BirimFiyat]>=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_Sati__Mikta__2942188C]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_SatinAlma]'))
ALTER TABLE [dbo].[BERP_SatinAlma]  WITH CHECK ADD CHECK  (([Miktar]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_Tica__Tutar__40257DE4]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_TicaretDosya]'))
ALTER TABLE [dbo].[BERP_TicaretDosya]  WITH CHECK ADD CHECK  (([Tutar]>=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BERP_Modul181]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_TicaretDosya]'))
ALTER TABLE [dbo].[BERP_TicaretDosya]  WITH CHECK ADD  CONSTRAINT [CK_BERP_Modul181] CHECK  (([Modul]='PURCHASE' OR [Modul]='SALES' OR [Modul]='TRADE' OR [Modul]='ECOM' OR [Modul]='CRM'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BERP_Modul181]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_TicaretDosya]'))
ALTER TABLE [dbo].[BERP_TicaretDosya] CHECK CONSTRAINT [CK_BERP_Modul181]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_Tica__Tutar__57FD0775]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_TicaretOdeme]'))
ALTER TABLE [dbo].[BERP_TicaretOdeme]  WITH CHECK ADD CHECK  (([Tutar]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP_Ticare__Tur__58F12BAE]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP_TicaretOdeme]'))
ALTER TABLE [dbo].[BERP_TicaretOdeme]  WITH CHECK ADD CHECK  (([Tur]=N'İade' OR [Tur]=N'Ödeme'))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP200_R__FireY__0A888742]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP200_Recete]'))
ALTER TABLE [dbo].[BERP200_Recete]  WITH CHECK ADD CHECK  (([FireYuzde]>=(0) AND [FireYuzde]<=(100)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP200_R__Birim__113584D1]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP200_ReceteKalem]'))
ALTER TABLE [dbo].[BERP200_ReceteKalem]  WITH CHECK ADD CHECK  (([BirimCiktiIcinMiktar]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP200_U__Mikta__15FA39EE]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP200_Uretim]'))
ALTER TABLE [dbo].[BERP200_Uretim]  WITH CHECK ADD CHECK  (([Miktar]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP210_Sa__Veri__664B26CC]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP210_SahaMusteri]'))
ALTER TABLE [dbo].[BERP210_SahaMusteri]  WITH CHECK ADD CHECK  ((isjson([Veri])=(1)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP220_Hes__Rol__7A521F79]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP220_Hesap]'))
ALTER TABLE [dbo].[BERP220_Hesap]  WITH CHECK ADD CHECK  (([Rol]='PATRON' OR [Rol]='SAHA'))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP270_E__AppTy__1D9B5BB6]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelge]'))
ALTER TABLE [dbo].[BERP270_EBelge]  WITH CHECK ADD CHECK  (([AppType]=(5) OR [AppType]=(3) OR [AppType]=(1)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP270_E__Ortam__1CA7377D]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelge]'))
ALTER TABLE [dbo].[BERP270_EBelge]  WITH CHECK ADD CHECK  (([Ortam]='Canli' OR [Ortam]='Test'))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_EBelge_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelge]'))
ALTER TABLE [dbo].[BERP270_EBelge]  WITH CHECK ADD  CONSTRAINT [CK_EBelge_Durum] CHECK  (([Durum]=N'Sağlayıcıda bulundu' OR [Durum]=N'Reddedildi' OR [Durum]=N'Belirsiz' OR [Durum]=N'Gönderim kabul edildi' OR [Durum]=N'Taslak kabul edildi' OR [Durum]=N'Gönderim başladı' OR [Durum]=N'Hazır'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_EBelge_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelge]'))
ALTER TABLE [dbo].[BERP270_EBelge] CHECK CONSTRAINT [CK_EBelge_Durum]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP270_E__Ortam__2BE97B0D]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeDosya]'))
ALTER TABLE [dbo].[BERP270_EBelgeDosya]  WITH CHECK ADD CHECK  (([Ortam]='Canli' OR [Ortam]='Test'))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BERP270_EB__Kutu__2CDD9F46]') AND parent_object_id = OBJECT_ID(N'[dbo].[BERP270_EBelgeDosya]'))
ALTER TABLE [dbo].[BERP270_EBelgeDosya]  WITH CHECK ADD CHECK  (([Kutu]>=(1) AND [Kutu]<=(5)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_GelenEFaturalar_Kdv]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelenEFaturalar]'))
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar]  WITH CHECK ADD  CONSTRAINT [CK_BoruERP_GelenEFaturalar_Kdv] CHECK  (([Kdv]>=(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_GelenEFaturalar_Kdv]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelenEFaturalar]'))
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar] CHECK CONSTRAINT [CK_BoruERP_GelenEFaturalar_Kdv]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_GelenEFaturalar_Matrah]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelenEFaturalar]'))
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar]  WITH CHECK ADD  CONSTRAINT [CK_BoruERP_GelenEFaturalar_Matrah] CHECK  (([Matrah]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_GelenEFaturalar_Matrah]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelenEFaturalar]'))
ALTER TABLE [dbo].[BoruERP_GelenEFaturalar] CHECK CONSTRAINT [CK_BoruERP_GelenEFaturalar_Matrah]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BoruERP_G__Tutar__6B44E613]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelirGider]'))
ALTER TABLE [dbo].[BoruERP_GelirGider]  WITH CHECK ADD CHECK  (([Tutar]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BoruERP_Gel__Tur__68687968]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GelirGider]'))
ALTER TABLE [dbo].[BoruERP_GelirGider]  WITH CHECK ADD CHECK  (([Tur]=N'Gider' OR [Tur]=N'Gelir'))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__BoruERP_GGH__Tur__5FD33367]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_GGHesaplar]'))
ALTER TABLE [dbo].[BoruERP_GGHesaplar]  WITH CHECK ADD CHECK  (([Tur]=N'Gider' OR [Tur]=N'Gelir'))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_IlkKurulum_TekKayit]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_IlkKurulum]'))
ALTER TABLE [dbo].[BoruERP_IlkKurulum]  WITH CHECK ADD  CONSTRAINT [CK_BoruERP_IlkKurulum_TekKayit] CHECK  (([Id]=(1)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_IlkKurulum_TekKayit]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_IlkKurulum]'))
ALTER TABLE [dbo].[BoruERP_IlkKurulum] CHECK CONSTRAINT [CK_BoruERP_IlkKurulum_TekKayit]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeKalemleri_Fiyat]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri]  WITH CHECK ADD  CONSTRAINT [CK_BoruERP_YeniBelgeKalemleri_Fiyat] CHECK  (([BirimFiyat]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeKalemleri_Fiyat]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri] CHECK CONSTRAINT [CK_BoruERP_YeniBelgeKalemleri_Fiyat]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeKalemleri_Kdv]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri]  WITH CHECK ADD  CONSTRAINT [CK_BoruERP_YeniBelgeKalemleri_Kdv] CHECK  (([KdvOrani]>=(0) AND [KdvOrani]<=(100)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeKalemleri_Kdv]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri] CHECK CONSTRAINT [CK_BoruERP_YeniBelgeKalemleri_Kdv]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeKalemleri_Miktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri]  WITH CHECK ADD  CONSTRAINT [CK_BoruERP_YeniBelgeKalemleri_Miktar] CHECK  (([Miktar]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeKalemleri_Miktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeKalemleri]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeKalemleri] CHECK CONSTRAINT [CK_BoruERP_YeniBelgeKalemleri_Miktar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeler_Genel]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeler]  WITH CHECK ADD  CONSTRAINT [CK_BoruERP_YeniBelgeler_Genel] CHECK  (([GenelToplam]>=(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeler_Genel]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeler] CHECK CONSTRAINT [CK_BoruERP_YeniBelgeler_Genel]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeler_Turu]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeler]  WITH CHECK ADD  CONSTRAINT [CK_BoruERP_YeniBelgeler_Turu] CHECK  (([BelgeTuru]=N'S' OR [BelgeTuru]=N'T'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniBelgeler_Turu]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniBelgeler]'))
ALTER TABLE [dbo].[BoruERP_YeniBelgeler] CHECK CONSTRAINT [CK_BoruERP_YeniBelgeler_Turu]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniMasraflar_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniMasraflar]'))
ALTER TABLE [dbo].[BoruERP_YeniMasraflar]  WITH CHECK ADD  CONSTRAINT [CK_BoruERP_YeniMasraflar_Tutar] CHECK  (([Tutar]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_BoruERP_YeniMasraflar_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[BoruERP_YeniMasraflar]'))
ALTER TABLE [dbo].[BoruERP_YeniMasraflar] CHECK CONSTRAINT [CK_BoruERP_YeniMasraflar_Tutar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CariHareketleri_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariHareketleri]'))
ALTER TABLE [dbo].[CariHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_CariHareketleri_Tip] CHECK  (([HareketTipi]=N'Alacak' OR [HareketTipi]=N'Borç'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CariHareketleri_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariHareketleri]'))
ALTER TABLE [dbo].[CariHareketleri] CHECK CONSTRAINT [CK_CariHareketleri_Tip]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CariHareketleri_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariHareketleri]'))
ALTER TABLE [dbo].[CariHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_CariHareketleri_Tutar] CHECK  (([Tutar]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CariHareketleri_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariHareketleri]'))
ALTER TABLE [dbo].[CariHareketleri] CHECK CONSTRAINT [CK_CariHareketleri_Tutar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CariKartlari_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariKartlari]'))
ALTER TABLE [dbo].[CariKartlari]  WITH CHECK ADD  CONSTRAINT [CK_CariKartlari_Tip] CHECK  (([CariTipi]=N'Diğer' OR [CariTipi]=N'Tedarikçi' OR [CariTipi]=N'Müşteri'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CariKartlari_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[CariKartlari]'))
ALTER TABLE [dbo].[CariKartlari] CHECK CONSTRAINT [CK_CariKartlari_Tip]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler]  WITH CHECK ADD  CONSTRAINT [CK_CekSenetler_Birim] CHECK  (([ParaBirimi]=N'EUR' OR [ParaBirimi]=N'USD' OR [ParaBirimi]=N'TRY'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler] CHECK CONSTRAINT [CK_CekSenetler_Birim]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler]  WITH CHECK ADD  CONSTRAINT [CK_CekSenetler_Durum] CHECK  (([Durum]=N'İptal' OR [Durum]=N'Tahsil Edildi' OR [Durum]=N'Ödendi' OR [Durum]=N'Bekliyor'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler] CHECK CONSTRAINT [CK_CekSenetler_Durum]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler]  WITH CHECK ADD  CONSTRAINT [CK_CekSenetler_Tip] CHECK  (([EvrakTipi]=N'Senet' OR [EvrakTipi]=N'Çek'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler] CHECK CONSTRAINT [CK_CekSenetler_Tip]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler]  WITH CHECK ADD  CONSTRAINT [CK_CekSenetler_Tutar] CHECK  (([Tutar]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler] CHECK CONSTRAINT [CK_CekSenetler_Tutar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Yon]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler]  WITH CHECK ADD  CONSTRAINT [CK_CekSenetler_Yon] CHECK  (([Yon]=N'Verilen' OR [Yon]=N'Alınan'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_CekSenetler_Yon]') AND parent_object_id = OBJECT_ID(N'[dbo].[CekSenetler]'))
ALTER TABLE [dbo].[CekSenetler] CHECK CONSTRAINT [CK_CekSenetler_Yon]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FinansHareketleri_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_FinansHareketleri_Tip] CHECK  (([HareketTipi]=N'Çıkış' OR [HareketTipi]=N'Giriş'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FinansHareketleri_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri] CHECK CONSTRAINT [CK_FinansHareketleri_Tip]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FinansHareketleri_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_FinansHareketleri_Tutar] CHECK  (([Tutar]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FinansHareketleri_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHareketleri]'))
ALTER TABLE [dbo].[FinansHareketleri] CHECK CONSTRAINT [CK_FinansHareketleri_Tutar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FinansHesaplari_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHesaplari]'))
ALTER TABLE [dbo].[FinansHesaplari]  WITH CHECK ADD  CONSTRAINT [CK_FinansHesaplari_Birim] CHECK  (([ParaBirimi]=N'EUR' OR [ParaBirimi]=N'USD' OR [ParaBirimi]=N'TRY'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FinansHesaplari_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHesaplari]'))
ALTER TABLE [dbo].[FinansHesaplari] CHECK CONSTRAINT [CK_FinansHesaplari_Birim]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FinansHesaplari_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHesaplari]'))
ALTER TABLE [dbo].[FinansHesaplari]  WITH CHECK ADD  CONSTRAINT [CK_FinansHesaplari_Tip] CHECK  (([HesapTipi]=N'Banka' OR [HesapTipi]=N'Kasa'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FinansHesaplari_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[FinansHesaplari]'))
ALTER TABLE [dbo].[FinansHesaplari] CHECK CONSTRAINT [CK_FinansHesaplari_Tip]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FirmaBilgileri_TekSatir]') AND parent_object_id = OBJECT_ID(N'[dbo].[FirmaBilgileri]'))
ALTER TABLE [dbo].[FirmaBilgileri]  WITH CHECK ADD  CONSTRAINT [CK_FirmaBilgileri_TekSatir] CHECK  (([Id]=(1)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_FirmaBilgileri_TekSatir]') AND parent_object_id = OBJECT_ID(N'[dbo].[FirmaBilgileri]'))
ALTER TABLE [dbo].[FirmaBilgileri] CHECK CONSTRAINT [CK_FirmaBilgileri_TekSatir]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_HammaddePaketleri_IlkKg]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePaketleri]'))
ALTER TABLE [dbo].[HammaddePaketleri]  WITH CHECK ADD  CONSTRAINT [CK_HammaddePaketleri_IlkKg] CHECK  (([IlkKg]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_HammaddePaketleri_IlkKg]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePaketleri]'))
ALTER TABLE [dbo].[HammaddePaketleri] CHECK CONSTRAINT [CK_HammaddePaketleri_IlkKg]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_HammaddePaketleri_KalanKg]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePaketleri]'))
ALTER TABLE [dbo].[HammaddePaketleri]  WITH CHECK ADD  CONSTRAINT [CK_HammaddePaketleri_KalanKg] CHECK  (([KalanKg]>=(0) AND [KalanKg]<=[IlkKg]))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_HammaddePaketleri_KalanKg]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePaketleri]'))
ALTER TABLE [dbo].[HammaddePaketleri] CHECK CONSTRAINT [CK_HammaddePaketleri_KalanKg]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_HammaddePaketleri_PaketTipi]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePaketleri]'))
ALTER TABLE [dbo].[HammaddePaketleri]  WITH CHECK ADD  CONSTRAINT [CK_HammaddePaketleri_PaketTipi] CHECK  (([PaketTipi]=N'DIGER' OR [PaketTipi]=N'PALET' OR [PaketTipi]=N'BIGBAG' OR [PaketTipi]=N'CUVAL'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_HammaddePaketleri_PaketTipi]') AND parent_object_id = OBJECT_ID(N'[dbo].[HammaddePaketleri]'))
ALTER TABLE [dbo].[HammaddePaketleri] CHECK CONSTRAINT [CK_HammaddePaketleri_PaketTipi]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_IsTakvimi_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[IsTakvimi]'))
ALTER TABLE [dbo].[IsTakvimi]  WITH CHECK ADD  CONSTRAINT [CK_IsTakvimi_Durum] CHECK  (([Durum]=N'İptal' OR [Durum]=N'Tamamlandı' OR [Durum]=N'Bekliyor'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_IsTakvimi_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[IsTakvimi]'))
ALTER TABLE [dbo].[IsTakvimi] CHECK CONSTRAINT [CK_IsTakvimi_Durum]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_KullaniciGorunumAyarlari_Tema]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciGorunumAyarlari]'))
ALTER TABLE [dbo].[KullaniciGorunumAyarlari]  WITH CHECK ADD  CONSTRAINT [CK_KullaniciGorunumAyarlari_Tema] CHECK  (([Tema]=N'Sistem' OR [Tema]=N'Koyu' OR [Tema]=N'Açık'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_KullaniciGorunumAyarlari_Tema]') AND parent_object_id = OBJECT_ID(N'[dbo].[KullaniciGorunumAyarlari]'))
ALTER TABLE [dbo].[KullaniciGorunumAyarlari] CHECK CONSTRAINT [CK_KullaniciGorunumAyarlari_Tema]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_Kullanicilar_BasarisizGiris]') AND parent_object_id = OBJECT_ID(N'[dbo].[Kullanicilar]'))
ALTER TABLE [dbo].[Kullanicilar]  WITH CHECK ADD  CONSTRAINT [CK_Kullanicilar_BasarisizGiris] CHECK  (([BasarisizGirisSayisi]>=(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_Kullanicilar_BasarisizGiris]') AND parent_object_id = OBJECT_ID(N'[dbo].[Kullanicilar]'))
ALTER TABLE [dbo].[Kullanicilar] CHECK CONSTRAINT [CK_Kullanicilar_BasarisizGiris]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_Kullanicilar_KullaniciAdi]') AND parent_object_id = OBJECT_ID(N'[dbo].[Kullanicilar]'))
ALTER TABLE [dbo].[Kullanicilar]  WITH CHECK ADD  CONSTRAINT [CK_Kullanicilar_KullaniciAdi] CHECK  ((len(ltrim(rtrim([KullaniciAdi])))>=(3)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_Kullanicilar_KullaniciAdi]') AND parent_object_id = OBJECT_ID(N'[dbo].[Kullanicilar]'))
ALTER TABLE [dbo].[Kullanicilar] CHECK CONSTRAINT [CK_Kullanicilar_KullaniciAdi]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_Kullanicilar_SifreOzeti]') AND parent_object_id = OBJECT_ID(N'[dbo].[Kullanicilar]'))
ALTER TABLE [dbo].[Kullanicilar]  WITH CHECK ADD  CONSTRAINT [CK_Kullanicilar_SifreOzeti] CHECK  ((len(ltrim(rtrim([SifreOzeti])))>=(30)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_Kullanicilar_SifreOzeti]') AND parent_object_id = OBJECT_ID(N'[dbo].[Kullanicilar]'))
ALTER TABLE [dbo].[Kullanicilar] CHECK CONSTRAINT [CK_Kullanicilar_SifreOzeti]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Donem__Ay__049AA3C2]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Donem]'))
ALTER TABLE [dbo].[MPX310_Donem]  WITH CHECK ADD CHECK  (([Ay]>=(1) AND [Ay]<=(12)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Ek__Veri__520F23F5]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Ek]'))
ALTER TABLE [dbo].[MPX310_Ek]  WITH CHECK ADD CHECK  ((datalength([Veri])>=(1) AND datalength([Veri])<=(41943040)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Fi__Alaca__13DCE752]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_FisKalem]'))
ALTER TABLE [dbo].[MPX310_FisKalem]  WITH CHECK ADD CHECK  (([Alacak]>=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Fis__Borc__12E8C319]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_FisKalem]'))
ALTER TABLE [dbo].[MPX310_FisKalem]  WITH CHECK ADD CHECK  (([Borc]>=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_FisK__Kur__18A19C6F]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_FisKalem]'))
ALTER TABLE [dbo].[MPX310_FisKalem]  WITH CHECK ADD CHECK  (([Kur]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_FisKalem__1995C0A8]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_FisKalem]'))
ALTER TABLE [dbo].[MPX310_FisKalem]  WITH CHECK ADD CHECK  (([Borc]>(0) AND [Alacak]=(0) OR [Alacak]>(0) AND [Borc]=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Kay__Veri__469D7149]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Kayit]'))
ALTER TABLE [dbo].[MPX310_Kayit]  WITH CHECK ADD CHECK  ((isjson([Veri])=(1)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Lo__Birim__605D434C]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Lot]'))
ALTER TABLE [dbo].[MPX310_Lot]  WITH CHECK ADD CHECK  (([BirimMaliyet]>=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Lo__Mikta__7A1D154F]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotBag]'))
ALTER TABLE [dbo].[MPX310_LotBag]  WITH CHECK ADD CHECK  (([Miktar]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_LotBag__7C055DC1]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotBag]'))
ALTER TABLE [dbo].[MPX310_LotBag]  WITH CHECK ADD CHECK  (([KaynakLot]<[UrunLot]))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Lo__Mikta__66161CA2]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotBakiye]'))
ALTER TABLE [dbo].[MPX310_LotBakiye]  WITH CHECK ADD CHECK  (([Miktar]>=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Lo__Mikta__6ADAD1BF]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_LotHareket]'))
ALTER TABLE [dbo].[MPX310_LotHareket]  WITH CHECK ADD CHECK  (([Miktar]<>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Re__Mikta__727BF387]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Rezervasyon]'))
ALTER TABLE [dbo].[MPX310_Rezervasyon]  WITH CHECK ADD CHECK  (([Miktar]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Sa__Kapan__24134F1B]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Satis]'))
ALTER TABLE [dbo].[MPX310_Satis]  WITH CHECK ADD CHECK  (([Kapanan]>=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Sa__Topla__222B06A9]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Satis]'))
ALTER TABLE [dbo].[MPX310_Satis]  WITH CHECK ADD CHECK  (([Toplam]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Sati__Kur__2136E270]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Satis]'))
ALTER TABLE [dbo].[MPX310_Satis]  WITH CHECK ADD CHECK  (([Kur]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Sa__Mikta__3631FF56]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_SatisLot]'))
ALTER TABLE [dbo].[MPX310_SatisLot]  WITH CHECK ADD CHECK  (([Miktar]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Sa__SevkE__381A47C8]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_SatisLot]'))
ALTER TABLE [dbo].[MPX310_SatisLot]  WITH CHECK ADD CHECK  (([SevkEdilen]>=(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Ta__Tutar__2BB470E3]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Tahsilat]'))
ALTER TABLE [dbo].[MPX310_Tahsilat]  WITH CHECK ADD CHECK  (([Tutar]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPX310_Tahs__Kur__2CA8951C]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPX310_Tahsilat]'))
ALTER TABLE [dbo].[MPX310_Tahsilat]  WITH CHECK ADD CHECK  (([Kur]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPXNext_B__Carpa__7246E95D]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_Barkod]'))
ALTER TABLE [dbo].[MPXNext_Barkod]  WITH CHECK ADD CHECK  (([Carpan]>(0)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPXNext_Ma__Veri__76177A41]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_Maliyet]'))
ALTER TABLE [dbo].[MPXNext_Maliyet]  WITH CHECK ADD CHECK  ((isjson([Veri])=(1)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPXNext_Ma__Veri__7DB89C09]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_MaliyetRevizyon]'))
ALTER TABLE [dbo].[MPXNext_MaliyetRevizyon]  WITH CHECK ADD CHECK  ((isjson([Veri])=(1)))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK__MPXNext_Mesaj__69B1A35C]') AND parent_object_id = OBJECT_ID(N'[dbo].[MPXNext_Mesaj]'))
ALTER TABLE [dbo].[MPXNext_Mesaj]  WITH CHECK ADD CHECK  (([Alici] IS NULL AND [Departman] IS NOT NULL OR [Alici] IS NOT NULL AND [Departman] IS NULL))
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PiyasaFiyatlari_Fiyat]') AND parent_object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]'))
ALTER TABLE [dbo].[PiyasaFiyatlari]  WITH CHECK ADD  CONSTRAINT [CK_PiyasaFiyatlari_Fiyat] CHECK  (([BirimFiyat]>=(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PiyasaFiyatlari_Fiyat]') AND parent_object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]'))
ALTER TABLE [dbo].[PiyasaFiyatlari] CHECK CONSTRAINT [CK_PiyasaFiyatlari_Fiyat]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PiyasaFiyatlari_Grup]') AND parent_object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]'))
ALTER TABLE [dbo].[PiyasaFiyatlari]  WITH CHECK ADD  CONSTRAINT [CK_PiyasaFiyatlari_Grup] CHECK  (([UrunGrubu]=N'Yağmurlama' OR [UrunGrubu]=N'Tarımsal Sulama' OR [UrunGrubu]=N'PE100' OR [UrunGrubu]=N'PE80'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PiyasaFiyatlari_Grup]') AND parent_object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]'))
ALTER TABLE [dbo].[PiyasaFiyatlari] CHECK CONSTRAINT [CK_PiyasaFiyatlari_Grup]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PiyasaFiyatlari_Kaynak]') AND parent_object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]'))
ALTER TABLE [dbo].[PiyasaFiyatlari]  WITH CHECK ADD  CONSTRAINT [CK_PiyasaFiyatlari_Kaynak] CHECK  (([KaynakTuru]=N'API' OR [KaynakTuru]=N'PDF' OR [KaynakTuru]=N'Manuel' OR [KaynakTuru]=N'Web'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PiyasaFiyatlari_Kaynak]') AND parent_object_id = OBJECT_ID(N'[dbo].[PiyasaFiyatlari]'))
ALTER TABLE [dbo].[PiyasaFiyatlari] CHECK CONSTRAINT [CK_PiyasaFiyatlari_Kaynak]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PlanliOdemeler_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler]  WITH CHECK ADD  CONSTRAINT [CK_PlanliOdemeler_Birim] CHECK  (([ParaBirimi]=N'EUR' OR [ParaBirimi]=N'USD' OR [ParaBirimi]=N'TRY'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PlanliOdemeler_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler] CHECK CONSTRAINT [CK_PlanliOdemeler_Birim]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PlanliOdemeler_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler]  WITH CHECK ADD  CONSTRAINT [CK_PlanliOdemeler_Durum] CHECK  (([Durum]=N'İptal' OR [Durum]=N'Ödendi' OR [Durum]=N'Bekliyor'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PlanliOdemeler_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler] CHECK CONSTRAINT [CK_PlanliOdemeler_Durum]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PlanliOdemeler_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler]  WITH CHECK ADD  CONSTRAINT [CK_PlanliOdemeler_Tutar] CHECK  (([Tutar]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_PlanliOdemeler_Tutar]') AND parent_object_id = OBJECT_ID(N'[dbo].[PlanliOdemeler]'))
ALTER TABLE [dbo].[PlanliOdemeler] CHECK CONSTRAINT [CK_PlanliOdemeler_Tutar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokAlimKayitlari_Deger]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]'))
ALTER TABLE [dbo].[StokAlimKayitlari]  WITH CHECK ADD  CONSTRAINT [CK_StokAlimKayitlari_Deger] CHECK  (([Miktar]>(0) AND [BirimFiyat]>=(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokAlimKayitlari_Deger]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokAlimKayitlari]'))
ALTER TABLE [dbo].[StokAlimKayitlari] CHECK CONSTRAINT [CK_StokAlimKayitlari_Deger]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokBakiyeleri_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokBakiyeleri]'))
ALTER TABLE [dbo].[StokBakiyeleri]  WITH CHECK ADD  CONSTRAINT [CK_StokBakiyeleri_Birim] CHECK  ((len(ltrim(rtrim([Birim])))>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokBakiyeleri_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokBakiyeleri]'))
ALTER TABLE [dbo].[StokBakiyeleri] CHECK CONSTRAINT [CK_StokBakiyeleri_Birim]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokBakiyeleri_Miktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokBakiyeleri]'))
ALTER TABLE [dbo].[StokBakiyeleri]  WITH CHECK ADD  CONSTRAINT [CK_StokBakiyeleri_Miktar] CHECK  (([Miktar]>=(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokBakiyeleri_Miktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokBakiyeleri]'))
ALTER TABLE [dbo].[StokBakiyeleri] CHECK CONSTRAINT [CK_StokBakiyeleri_Miktar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokFiyatlari_Negatif]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokFiyatlari]'))
ALTER TABLE [dbo].[StokFiyatlari]  WITH CHECK ADD  CONSTRAINT [CK_StokFiyatlari_Negatif] CHECK  ((([AlisMaliyeti] IS NULL OR [AlisMaliyeti]>=(0)) AND ([BayiSatisFiyati] IS NULL OR [BayiSatisFiyati]>=(0)) AND ([PerakendeSatisFiyati] IS NULL OR [PerakendeSatisFiyati]>=(0))))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokFiyatlari_Negatif]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokFiyatlari]'))
ALTER TABLE [dbo].[StokFiyatlari] CHECK CONSTRAINT [CK_StokFiyatlari_Negatif]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_StokHareketleri_Birim] CHECK  ((len(ltrim(rtrim([Birim])))>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri] CHECK CONSTRAINT [CK_StokHareketleri_Birim]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_Miktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_StokHareketleri_Miktar] CHECK  (([Miktar]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_Miktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri] CHECK CONSTRAINT [CK_StokHareketleri_Miktar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_ReceteOrani]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_StokHareketleri_ReceteOrani] CHECK  (([ReceteOrani] IS NULL OR [ReceteOrani]>(0) AND [ReceteOrani]<=(100)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_ReceteOrani]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri] CHECK CONSTRAINT [CK_StokHareketleri_ReceteOrani]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_StokHareketleri_Tip] CHECK  (([HareketTipi]=N'DUZELTME_CIKIS' OR [HareketTipi]=N'DUZELTME_GIRIS' OR [HareketTipi]=N'URETIM_MAMUL_GIRIS' OR [HareketTipi]=N'URETIM_HAMMADDE_CIKIS' OR [HareketTipi]=N'MANUEL_CIKIS' OR [HareketTipi]=N'MANUEL_GIRIS' OR [HareketTipi]=N'ALIS_GIRIS' OR [HareketTipi]=N'ACILIS_GIRIS'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri] CHECK CONSTRAINT [CK_StokHareketleri_Tip]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_TipYon]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_StokHareketleri_TipYon] CHECK  ((([HareketTipi]=N'DUZELTME_GIRIS' OR [HareketTipi]=N'URETIM_MAMUL_GIRIS' OR [HareketTipi]=N'MANUEL_GIRIS' OR [HareketTipi]=N'ALIS_GIRIS' OR [HareketTipi]=N'ACILIS_GIRIS') AND [Yon]=N'G' OR ([HareketTipi]=N'DUZELTME_CIKIS' OR [HareketTipi]=N'URETIM_HAMMADDE_CIKIS' OR [HareketTipi]=N'MANUEL_CIKIS') AND [Yon]=N'C'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_TipYon]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri] CHECK CONSTRAINT [CK_StokHareketleri_TipYon]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_UretimReferansi]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_StokHareketleri_UretimReferansi] CHECK  ((([HareketTipi]=N'URETIM_MAMUL_GIRIS' OR [HareketTipi]=N'URETIM_HAMMADDE_CIKIS') AND [UretimStokIslemId] IS NOT NULL OR NOT ([HareketTipi]=N'URETIM_MAMUL_GIRIS' OR [HareketTipi]=N'URETIM_HAMMADDE_CIKIS') AND [UretimStokIslemId] IS NULL))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_UretimReferansi]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri] CHECK CONSTRAINT [CK_StokHareketleri_UretimReferansi]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_Yon]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri]  WITH CHECK ADD  CONSTRAINT [CK_StokHareketleri_Yon] CHECK  (([Yon]=N'C' OR [Yon]=N'G'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokHareketleri_Yon]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokHareketleri]'))
ALTER TABLE [dbo].[StokHareketleri] CHECK CONSTRAINT [CK_StokHareketleri_Yon]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokOzellik_Tur]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikTanimlari]'))
ALTER TABLE [dbo].[StokOzellikTanimlari]  WITH CHECK ADD  CONSTRAINT [CK_StokOzellik_Tur] CHECK  (([AlanTuru]=N'Seçim' OR [AlanTuru]=N'Tarih' OR [AlanTuru]=N'Sayı' OR [AlanTuru]=N'Metin'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_StokOzellik_Tur]') AND parent_object_id = OBJECT_ID(N'[dbo].[StokOzellikTanimlari]'))
ALTER TABLE [dbo].[StokOzellikTanimlari] CHECK CONSTRAINT [CK_StokOzellik_Tur]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_AraToplam]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler]  WITH CHECK ADD  CONSTRAINT [CK_TicariBelgeler_AraToplam] CHECK  (([AraToplam]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_AraToplam]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler] CHECK CONSTRAINT [CK_TicariBelgeler_AraToplam]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler]  WITH CHECK ADD  CONSTRAINT [CK_TicariBelgeler_Durum] CHECK  (([Durum]=N'İptal' OR [Durum]=N'Kaydedildi'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler] CHECK CONSTRAINT [CK_TicariBelgeler_Durum]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_Genel]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler]  WITH CHECK ADD  CONSTRAINT [CK_TicariBelgeler_Genel] CHECK  (([GenelToplam]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_Genel]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler] CHECK CONSTRAINT [CK_TicariBelgeler_Genel]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_Kdv]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler]  WITH CHECK ADD  CONSTRAINT [CK_TicariBelgeler_Kdv] CHECK  (([KdvOrani]>=(0) AND [KdvOrani]<=(100)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_Kdv]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler] CHECK CONSTRAINT [CK_TicariBelgeler_Kdv]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler]  WITH CHECK ADD  CONSTRAINT [CK_TicariBelgeler_Tip] CHECK  (([BelgeTipi]=N'Satış' OR [BelgeTipi]=N'Alış'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_TicariBelgeler_Tip]') AND parent_object_id = OBJECT_ID(N'[dbo].[TicariBelgeler]'))
ALTER TABLE [dbo].[TicariBelgeler] CHECK CONSTRAINT [CK_TicariBelgeler_Tip]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri]  WITH CHECK ADD  CONSTRAINT [CK_UretimEmirleri_Durum] CHECK  (([Durum]=N'İptal' OR [Durum]=N'Tamamlandı' OR [Durum]=N'Üretimde' OR [Durum]=N'Planlandı'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_Durum]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri] CHECK CONSTRAINT [CK_UretimEmirleri_Durum]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_FireMiktari]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri]  WITH CHECK ADD  CONSTRAINT [CK_UretimEmirleri_FireMiktari] CHECK  (([FireMiktari]>=(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_FireMiktari]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri] CHECK CONSTRAINT [CK_UretimEmirleri_FireMiktari]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_HedefAgirlikKg]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri]  WITH CHECK ADD  CONSTRAINT [CK_UretimEmirleri_HedefAgirlikKg] CHECK  (([HedefAgirlikKg] IS NULL OR [HedefAgirlikKg]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_HedefAgirlikKg]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri] CHECK CONSTRAINT [CK_UretimEmirleri_HedefAgirlikKg]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_MiktarBirimi]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri]  WITH CHECK ADD  CONSTRAINT [CK_UretimEmirleri_MiktarBirimi] CHECK  (([MiktarBirimi] IS NULL OR ([MiktarBirimi]=N'adet' OR [MiktarBirimi]=N'metre' OR [MiktarBirimi]=N'kg')))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_MiktarBirimi]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri] CHECK CONSTRAINT [CK_UretimEmirleri_MiktarBirimi]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_PlanlananMiktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri]  WITH CHECK ADD  CONSTRAINT [CK_UretimEmirleri_PlanlananMiktar] CHECK  (([PlanlananMiktar]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_PlanlananMiktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri] CHECK CONSTRAINT [CK_UretimEmirleri_PlanlananMiktar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_UretilenMiktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri]  WITH CHECK ADD  CONSTRAINT [CK_UretimEmirleri_UretilenMiktar] CHECK  (([UretilenMiktar]>=(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmirleri_UretilenMiktar]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmirleri]'))
ALTER TABLE [dbo].[UretimEmirleri] CHECK CONSTRAINT [CK_UretimEmirleri_UretilenMiktar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmriReceteAnlikKalemleri_Oran]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmriReceteAnlikKalemleri]'))
ALTER TABLE [dbo].[UretimEmriReceteAnlikKalemleri]  WITH CHECK ADD  CONSTRAINT [CK_UretimEmriReceteAnlikKalemleri_Oran] CHECK  (([YuzdeOrani]>(0) AND [YuzdeOrani]<=(100)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimEmriReceteAnlikKalemleri_Oran]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimEmriReceteAnlikKalemleri]'))
ALTER TABLE [dbo].[UretimEmriReceteAnlikKalemleri] CHECK CONSTRAINT [CK_UretimEmriReceteAnlikKalemleri_Oran]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UGK_BosDegil]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimGunlukKayitlari]'))
ALTER TABLE [dbo].[UretimGunlukKayitlari]  WITH CHECK ADD  CONSTRAINT [CK_UGK_BosDegil] CHECK  (([UretilenFark]<>(0) OR [FireFark]<>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UGK_BosDegil]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimGunlukKayitlari]'))
ALTER TABLE [dbo].[UretimGunlukKayitlari] CHECK CONSTRAINT [CK_UGK_BosDegil]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UPK_Pozitif]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimPaketlemeKayitlari]'))
ALTER TABLE [dbo].[UretimPaketlemeKayitlari]  WITH CHECK ADD  CONSTRAINT [CK_UPK_Pozitif] CHECK  (([PaketIciAdet]>=(1) AND [PaketIciAdet]<=(1000000) AND [PaketSayisi]>=(1)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UPK_Pozitif]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimPaketlemeKayitlari]'))
ALTER TABLE [dbo].[UretimPaketlemeKayitlari] CHECK CONSTRAINT [CK_UPK_Pozitif]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UPK_Toplam]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimPaketlemeKayitlari]'))
ALTER TABLE [dbo].[UretimPaketlemeKayitlari]  WITH CHECK ADD  CONSTRAINT [CK_UPK_Toplam] CHECK  (([ToplamAdet]=CONVERT([bigint],[PaketIciAdet])*[PaketSayisi]))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UPK_Toplam]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimPaketlemeKayitlari]'))
ALTER TABLE [dbo].[UretimPaketlemeKayitlari] CHECK CONSTRAINT [CK_UPK_Toplam]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_ReceteKalemleri_Oran]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimReceteKalemleri]'))
ALTER TABLE [dbo].[UretimReceteKalemleri]  WITH CHECK ADD  CONSTRAINT [CK_ReceteKalemleri_Oran] CHECK  (([YuzdeOrani]>(0) AND [YuzdeOrani]<=(100)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_ReceteKalemleri_Oran]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimReceteKalemleri]'))
ALTER TABLE [dbo].[UretimReceteKalemleri] CHECK CONSTRAINT [CK_ReceteKalemleri_Oran]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimStokIslemleri_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimStokIslemleri]'))
ALTER TABLE [dbo].[UretimStokIslemleri]  WITH CHECK ADD  CONSTRAINT [CK_UretimStokIslemleri_Birim] CHECK  ((len(ltrim(rtrim([MamulBirimi])))>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimStokIslemleri_Birim]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimStokIslemleri]'))
ALTER TABLE [dbo].[UretimStokIslemleri] CHECK CONSTRAINT [CK_UretimStokIslemleri_Birim]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimStokIslemleri_Miktarlar]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimStokIslemleri]'))
ALTER TABLE [dbo].[UretimStokIslemleri]  WITH CHECK ADD  CONSTRAINT [CK_UretimStokIslemleri_Miktarlar] CHECK  (([MamulMiktari]>=(0) AND [FireMiktari]>=(0) AND [GerceklesenTuketimKg]>(0)))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UretimStokIslemleri_Miktarlar]') AND parent_object_id = OBJECT_ID(N'[dbo].[UretimStokIslemleri]'))
ALTER TABLE [dbo].[UretimStokIslemleri] CHECK CONSTRAINT [CK_UretimStokIslemleri_Miktarlar]
GO
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UrunGorselleri_Tur]') AND parent_object_id = OBJECT_ID(N'[dbo].[UrunGorselleri]'))
ALTER TABLE [dbo].[UrunGorselleri]  WITH CHECK ADD  CONSTRAINT [CK_UrunGorselleri_Tur] CHECK  (([IcerikTuru]=N'image/webp' OR [IcerikTuru]=N'image/png' OR [IcerikTuru]=N'image/jpeg'))
GO
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_UrunGorselleri_Tur]') AND parent_object_id = OBJECT_ID(N'[dbo].[UrunGorselleri]'))
ALTER TABLE [dbo].[UrunGorselleri] CHECK CONSTRAINT [CK_UrunGorselleri_Tur]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_Fis_Koru]'))
EXEC dbo.sp_executesql @statement = N'CREATE   TRIGGER [dbo].[MPX310_Fis_Koru] ON [dbo].[MPX310_Fis] AFTER INSERT,UPDATE,DELETE AS
BEGIN SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM deleted WHERE Durum=N''Kesin'') THROW 51310,N''Kesin muhasebe fişi değiştirilemez veya silinemez.'',1;
 IF EXISTS(SELECT 1 FROM inserted f JOIN dbo.MPX310_Donem d ON d.Yil=f.Yil AND d.Ay=MONTH(f.Tarih) WHERE d.Kapali=1) THROW 51310,N''Kapalı döneme fiş kaydedilemez.'',1;
 IF EXISTS(SELECT 1 FROM inserted f WHERE f.Durum=N''Kesin'' AND (NOT EXISTS(SELECT 1 FROM dbo.MPX310_FisKalem k WHERE k.FisId=f.Id) OR (SELECT SUM(Borc-Alacak) FROM dbo.MPX310_FisKalem k WHERE k.FisId=f.Id)<>0)) THROW 51310,N''Kesin fiş dengeli ve kalemli olmalı.'',1;
END' 
GO
ALTER TABLE [dbo].[MPX310_Fis] ENABLE TRIGGER [MPX310_Fis_Koru]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[MPX310_FisKalem_Koru]'))
EXEC dbo.sp_executesql @statement = N'CREATE   TRIGGER [dbo].[MPX310_FisKalem_Koru] ON [dbo].[MPX310_FisKalem] AFTER INSERT,UPDATE,DELETE AS
BEGIN SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM (SELECT FisId FROM inserted UNION SELECT FisId FROM deleted) x JOIN dbo.MPX310_Fis f ON f.Id=x.FisId WHERE f.Durum=N''Kesin'') THROW 51310,N''Kesin fiş kalemleri değiştirilemez; ters fiş kullanın.'',1;
END' 
GO
ALTER TABLE [dbo].[MPX310_FisKalem] ENABLE TRIGGER [MPX310_FisKalem_Koru]
GO