using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class LisansYenilemeTestleri
{
 [Fact]public void KayitliAnahtarYenidenSunucuyaSorulabilir(){var old=new string('a',64);Assert.Equal(old,LisansYenilemeKurallari.Anahtar(null,old));Assert.Equal(old,LisansYenilemeKurallari.Anahtar(" ",old));Assert.Equal(new string('b',64),LisansYenilemeKurallari.Anahtar(" "+new string('B',64)+" ",old));Assert.Equal("",LisansYenilemeKurallari.Anahtar(null,null));}
 [Fact]public void YeniAnahtarAgHatasindaEskiBelgeyleBasariliSayilmaz(){Assert.False(LisansYenilemeKurallari.CevrimdisiDevam(true,true));Assert.False(LisansYenilemeKurallari.CevrimdisiDevam(false,false));Assert.True(LisansYenilemeKurallari.CevrimdisiDevam(false,true));}
}
