using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
public sealed class IlkKurulumPenceresi:Window
{
 readonly StackPanel root=new(){Margin=new Thickness(28)};
 readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,14,0,0)};
 bool busy;
 public IlkKurulumPenceresi(){FontSize=14;Title="MiaPaxERP • İlk kurulum";Width=720;Height=760;MinWidth=560;MinHeight=500;WindowStartupLocation=WindowStartupLocation.CenterScreen;Content=new ScrollViewer{Content=root};Closing+=(_,e)=>{if(busy)e.Cancel=true;};Giris();}
 TextBlock Text(string text,int size=14)=>new(){Text=text,FontSize=size,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,10)};
 void Giris(){
  root.Children.Clear();root.Children.Add(Text("MiaPaxERP ilk kurulum",27));root.Children.Add(Text("Program SQL Server kurmaz. Önceden kurulu SQL Server'a bağlanır, boş şirket veritabanını ve tablolarını hazırlar. Müşteri verisi kopyalamanız gerekmez."));
  root.Children.Add(Text("Kurulum girişi · Admin / 1234",18));var user=new TextBox{Text="Admin",MinHeight=34};var pass=new PasswordBox{MinHeight=34,Margin=new Thickness(0,8,0,12)};root.Children.Add(user);root.Children.Add(pass);
  root.Children.Add(Text("Bu giriş yalnız ilk bağlantı sihirbazını açar. Var olan şirket kullanıcılarının şifrelerini değiştirmez."));var next=new Button{Content="Bağlantı ayarlarına geç",Padding=new Thickness(12)};root.Children.Add(next);root.Children.Add(status);next.Click+=(_,_)=>{if(!user.Text.Trim().Equals("admin",StringComparison.OrdinalIgnoreCase)||pass.Password!="1234"){status.Text="İlk kurulum için Admin / 1234 kullanın.";return;}pass.Clear();Baglanti();};
  var side=new Button{Content="Bu bir yan bilgisayar · HTTPS ile bağlan",Margin=new Thickness(0,18,0,0),Padding=new Thickness(10)};root.Children.Add(side);side.Click+=(_,_)=>{new BaglantiAyarlariPenceresi{Owner=this}.ShowDialog();if(KolayBaglantiProfili.Oku().Rol=="Yan")DialogResult=true;};
 }
 void Baglanti(){
  root.Children.Clear();status.Text="";root.Children.Add(Text("Şirket veritabanını hazırla",26));root.Children.Add(Text("Windows hesabı veya SQL Server kullanıcı adı/parolası seçin. SQL hesabınızın veritabanı oluşturma ve tablo hazırlama yetkisi olmalıdır."));
  var old=MiapaxERPBaglantiAyarlari.Oku();var server=new TextBox{Text=old.Sunucu,MinHeight=34};var database=new TextBox{Text=old.Veritabani,MinHeight=34};var auth=new ComboBox{MinHeight=34,ItemsSource=new[]{"Windows giriş kimliği","SQL Server kullanıcı adı ve parola"},SelectedIndex=old.KimlikDogrulama=="Sql"?1:0};var username=new TextBox{Text=old.SqlKullanici,MinHeight=34};var password=new PasswordBox{MinHeight=34};try{if(auth.SelectedIndex==1)password.Password=old.ParolayiCoz();}catch{}
  void Field(string name,Control control){root.Children.Add(Text(name));root.Children.Add(control);}Field("SQL Server adı veya instance · örnek FABRIKA\\SQLEXPRESS",server);Field("Şirket veritabanı adı",database);Field("Kimlik doğrulama",auth);
  var sqlPanel=new StackPanel();sqlPanel.Children.Add(Text("SQL kullanıcı adı"));sqlPanel.Children.Add(username);sqlPanel.Children.Add(Text("SQL parolası"));sqlPanel.Children.Add(password);root.Children.Add(sqlPanel);void Toggle()=>sqlPanel.Visibility=auth.SelectedIndex==1?Visibility.Visible:Visibility.Collapsed;auth.SelectionChanged+=(_,_)=>Toggle();Toggle();
  var create=new CheckBox{Content="Veritabanı yoksa oluştur",IsChecked=true,Margin=new Thickness(0,16,0,6)};root.Children.Add(create);var verify=new CheckBox{Content="SQL sunucusunun güvenilir TLS sertifikasını doğrula",IsChecked=old.SertifikaDogrula,Margin=new Thickness(0,6,0,10)};root.Children.Add(verify);
  var go=new Button{Content="Bağlan · veritabanı ve tabloları hazırla",Padding=new Thickness(12)};root.Children.Add(go);root.Children.Add(status);
  go.Click+=async(_,_)=>{go.IsEnabled=false;busy=true;try{var setting=new MiapaxERPBaglantiAyarlari{Rol="Ana",Sunucu=server.Text.Trim(),Veritabani=IlkKurulumServisi.Veritabani(database.Text),KimlikDogrulama=auth.SelectedIndex==1?"Sql":"Windows",SqlKullanici=username.Text.Trim(),SertifikaDogrula=verify.IsChecked==true,BaglantiZamanAsimi=15};if(auth.SelectedIndex==1)setting.ParolayiAyarla(password.Password);bool make=create.IsChecked==true;string connection=setting.BaglantiDizesi();status.Text="SQL bağlantısı ve boş kurulum hazırlanıyor…";string result=await Task.Run(()=>IlkKurulumServisi.Hazirla(connection,make));setting.Kaydet();var profile=KolayBaglantiProfili.Oku() with{Rol="Ana"};profile.Kaydet();password.Clear();status.Text=result+" Lisans ekranına geçebilirsiniz.";go.Visibility=Visibility.Collapsed;var done=new Button{Content="Lisans ve giriş ekranına geç",Margin=new Thickness(0,12,0,0),Padding=new Thickness(12)};root.Children.Add(done);done.Click+=(_,_)=>DialogResult=true;}
   catch(Exception e){status.Text="Kurulum tamamlanamadı: "+e.Message+"\nSQL Server'ın kurulu/açık olduğunu, kimlik bilgilerini ve veritabanı oluşturma yetkisini kontrol edin. Var olan müşteri verisi silinmedi.";}finally{go.IsEnabled=true;busy=false;}};
 }
}
