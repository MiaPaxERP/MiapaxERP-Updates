CREATE TABLE admin_users(username TEXT PRIMARY KEY,password_hash TEXT NOT NULL,must_change INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
--> statement-breakpoint
CREATE TABLE admin_sessions(token_hash TEXT PRIMARY KEY,username TEXT NOT NULL REFERENCES admin_users(username),expires_at INTEGER NOT NULL,created_at TEXT NOT NULL);
--> statement-breakpoint
CREATE INDEX admin_sessions_expiry ON admin_sessions(expires_at);
