using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using MiapaxERP.Lisans.Core;
namespace MiapaxERP.Desktop;

public sealed partial class LisansPenceresi:Window
{
    public LisansPenceresi()
    {
        Title="MiapaxERP "+typeof(LisansPenceresi).Assembly.GetName().Version?.ToString(3)+" | Lisans ve etkinleştirme";Width=700;Height=800;WindowStartupLocation=WindowStartupLocation.CenterOwner;
        var p=new StackPanel{Margin=new Thickness(26)};Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        var brand=new StackPanel{Orientation=System.Windows.Controls.Orientation.Horizontal,Margin=new Thickness(0,0,0,12)};
        brand.Children.Add(new System.Windows.Controls.Image{Source=new System.Windows.Media.Imaging.BitmapImage(new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/MiapaxERP_Amblem.png")),Width=42,Height=42,Margin=new Thickness(0,0,12,0)});
        brand.Children.Add(new TextBlock{Text="MiaPaxERP",FontSize=26,FontWeight=FontWeights.SemiBold,VerticalAlignment=VerticalAlignment.Center});p.Children.Add(brand);
        p.Children.Add(new TextBlock{Text="Müşteri lisansı",FontSize=26,Margin=new Thickness(0,0,0,16)});
        p.Children.Add(new TextBlock{Text="Lisans panelinde müşteriye tanımlanan anahtarı girin. Lisans bu bilgisayar ve seçili veritabanına bağlanır. Süresiz lisanslarda da en az 7 günde bir internet doğrulaması gerekir.",TextWrapping=TextWrapping.Wrap});
        var key=new PasswordBox{Margin=new Thickness(0,18,0,8),MinHeight=36};p.Children.Add(key);
        var status=new TextBlock{Text=LisansOturumu.SonMesaj,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,16)};p.Children.Add(status);
        var sectorTitle=new TextBlock{Text="Sektör ve lisans kapsamı",FontSize=17,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,6)};p.Children.Add(sectorTitle);
        var sector=new TextBlock{Text=SektorOzeti(),TextWrapping=TextWrapping.Wrap,LineHeight=20};
        p.Children.Add(new Border{Child=sector,Padding=new Thickness(12),Margin=new Thickness(0,0,0,16),BorderThickness=new Thickness(1),BorderBrush=System.Windows.Media.Brushes.LightSteelBlue,CornerRadius=new CornerRadius(6)});
        var bar=new WrapPanel();p.Children.Add(bar);
        var activate=new Button{Content="Etkinleştir / yenile",Padding=new Thickness(12),Margin=new Thickness(4)};bar.Children.Add(activate);
        activate.Click+=async(_,_)=>{activate.IsEnabled=false;try{bool ok=await LisansOturumu.YenileAsync(string.IsNullOrWhiteSpace(key.Password)?null:key.Password);status.Text=LisansOturumu.SonMesaj;sector.Text=SektorOzeti();if(ok)DialogResult=true;}catch(Exception ex){status.Text=ex.Message;}finally{activate.IsEnabled=true;}};
        var close=new Button{Content="Kapat",Padding=new Thickness(12),Margin=new Thickness(4)};bar.Children.Add(close);close.Click+=(_,_)=>Close();
        var identity=new TextBlock{Text="Cihaz: "+LisansOturumu.CihazKimligi+"\nVeritabanı: "+LisansOturumu.VeritabaniKimligi,TextWrapping=TextWrapping.Wrap,FontSize=11,Margin=new Thickness(0,22,0,0)};
        p.Children.Add(identity);
        var connection=new Button{Content="Sunucu / veritabanı ayarları",Padding=new Thickness(10),Margin=new Thickness(0,16,0,0)};
        p.Children.Add(connection);
        connection.Click+=(_,_)=>{new BaglantiAyarlariPenceresi{Owner=this}.ShowDialog();LisansOturumu.Hazirla(MiapaxERPBaglantiAyarlari.BaglantiAdresi());status.Text="Bağlantı ayarları güncellendi. Seçili veritabanı için lisansı etkinleştirin.";identity.Text="Cihaz: "+LisansOturumu.CihazKimligi+"\nVeritabanı: "+LisansOturumu.VeritabaniKimligi;};
    }
}
public partial class LisansPenceresi
{
    /// <summary>Lisanstaki sektörün ayrıntıları ve sektörün önerdiği modüllerle lisans kapsamı.</summary>
    public static string SektorOzeti()
    {
        var license=LisansOturumu.Gecerli;
        string ModulAdi(string code)=>UrunKatalogu.Moduller.FirstOrDefault(m=>m.Kod==code)?.Ad??code;
        if(license is null)
        {
            if(HttpsOturumu.Istemci?.Oturum is { } remote)
            {
                var r=UrunKatalogu.Sektorler.FirstOrDefault(x=>x.Kod==remote.Sektor);
                return r is null?"Bu cihaz ana sunucunun lisansını kullanır.":"Ana sunucu lisansı • "+r.GrupluAd+"\n"+r.Aciklama+"\nAçık modüller: "+string.Join(", ",remote.Moduller.Select(ModulAdi));
            }
            return "Lisans doğrulandığında firma, sektör ve modül bilgileri burada görünür.";
        }
        var s=UrunKatalogu.SektorBul(license.Sector);
        var now=DateTimeOffset.UtcNow;
        var modules=license.Modules.Select(m=>ModulAdi(m)+(license.ModuleExpiresAt?.TryGetValue(m,out var end)==true?(end<=now?" (süresi doldu)":" ("+end.ToLocalTime().ToString("d")+" bitiş)"):"")).ToArray();
        var missing=s.OnerilenModuller.Where(m=>!license.Modules.Contains(m)).Select(ModulAdi).ToArray();
        return "Firma: "+license.Company
            +"\nSektör: "+s.GrupluAd
            +"\n"+s.Aciklama
            +"\nAlt dallar: "+string.Join(", ",s.AltDallar)
            +"\nÖnerilen birimler: "+string.Join(", ",s.Birimler)
            +"\nLisanstaki modüller: "+string.Join(", ",modules)
            +"\nLisans bitişi: "+(license.ExpiresAt is { } e?e.ToLocalTime().ToString("d"):"Süresiz")
            +(missing.Length>0?"\nBu sektör için önerilen, lisansınızda olmayan modüller: "+string.Join(", ",missing)+". Mağaza bölümünden inceleyebilirsiniz.":"\nSektör için önerilen tüm modüller lisansınızda açık.");
    }
}
public partial class MainWindow
{
    readonly DispatcherTimer lisansSaat=new(){Interval=TimeSpan.FromMinutes(30)};
    readonly DispatcherTimer lisansYerelSaat=new(){Interval=TimeSpan.FromMinutes(1)};
    bool lisansYenileniyor;
    bool EskiUretimYetkisi(string permission)
    {
        try{LisansOturumu.Gerekli("URETIM");if(aktifKullanici is null)throw new UnauthorizedAccessException("Önce oturum açın.");if(permission!="PRODUCTION.VIEW")new SektorUretimServisi(baglantiAdresi,aktifKullanici.KullaniciId).Kur();if(HttpsOturumu.Uzak(baglantiAdresi))return new YardimciEkranServisi(baglantiAdresi,aktifKullanici.KullaniciId).YetkiVar(permission);var access=new ErpModulServisi(baglantiAdresi,aktifKullanici.KullaniciId);using var c=access.Ac();access.Yetki(c,null,permission);return true;}
        catch(Exception ex){DestekIzleme.Bildir(ex,"MainWindow.Lisans200");MessageBox.Show(ex.Message,"Üretim yetkisi");return false;}
    }
    async Task<bool> LisansBaslatAsync()
    {
        if(HttpsOturumu.Istemci is not null){LisansMenuUygula();return true;}if(!LisansOturumu.Zorunlu)return true;
        try
        {
            if (!App.LisansAcilistaDogrulandi)
            {
                LisansOturumu.Hazirla(baglantiAdresi);
                if(!await LisansOturumu.YenileAsync())
                {if(new LisansPenceresi{Owner=this}.ShowDialog()!=true){Close();return false;}}
            }
            App.LisansAcilistaDogrulandi = false;
            LisansMenuUygula();
            lisansSaat.Tick+=async(_,_)=>
            {
                if(lisansYenileniyor)return;lisansYenileniyor=true;
                try{await LisansOturumu.YenileAsync();LisansMenuUygula();if(LisansOturumu.Gecerli is not null)GorunumuUygula(gorunum.Kopya());}
                catch{ }
                finally{lisansYenileniyor=false;}
            };
            lisansYerelSaat.Tick+=(_,_)=>{try{LisansOturumu.SaatIziniGuncelle();if(LisansOturumu.Gecerli is null)LisansMenuUygula();}catch{}};
            lisansSaat.Start();lisansYerelSaat.Start();Closed+=(_,_)=>{lisansSaat.Stop();lisansYerelSaat.Stop();try{LisansOturumu.SaatIziniGuncelle();}catch{}};return true;
        }
        catch(Exception ex){DestekIzleme.Bildir(ex,"MainWindow.Lisans200");MessageBox.Show(ex.Message,"Lisans doğrulanamadı");Close();return false;}
    }
    void LisansMenuUygula()
    {
        foreach(var (id,mod) in new[]{("BtnMenuLaboratuvar","LABORATUVAR"),("BtnMenuWebYonetim","ETICARET"),("BtnMenuSaha","CRM"),("BtnMenuStok","STOK"),("BtnMenuUretim","URETIM"),("BtnMenuRecete","URETIM"),("BtnMenuFinans","FINANS"),("BtnMenuKroki","KROKI"),("BtnMenuSektorUretim","URETIM"),("BtnMenuRestoran","RESTORAN")})
            if(FindName(id)is FrameworkElement c)c.Visibility=LisansOturumu.ModulVar(mod)?Visibility.Visible:Visibility.Collapsed;
        MenuYetkiGorunumunuUygula();
        if(HttpsOturumu.Istemci is null&&LisansOturumu.Zorunlu&&LisansOturumu.Gecerli is null){TumIcerikleriGizle();SayfaBasligi.Text="Lisans doğrulaması gerekiyor";}
    }
    void LisansAyarAc_Click(object s,RoutedEventArgs e){if(HttpsOturumu.Istemci is not null){MessageBox.Show(this,"Lisans ana sunucudan yönetilir. Bu cihaz sunucuda açık modülleri kullanır.","MiaPaxERP");return;}new LisansPenceresi{Owner=this}.ShowDialog();LisansMenuUygula();if(LisansOturumu.Gecerli is not null)GorunumuUygula(gorunum.Kopya());}
}

