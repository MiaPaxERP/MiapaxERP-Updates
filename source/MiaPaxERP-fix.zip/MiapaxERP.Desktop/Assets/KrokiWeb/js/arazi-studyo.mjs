// MiapaxERP Arazi Stüdyosu · tek ekran: konum → tarla → su kaynağı → borular → analiz → PDF.
import * as M from './arazi-model.mjs?v=arazi1';
import {analyse} from './arazi-analiz.mjs?v=arazi1';
import {createStudio3D,imageryCredit,terrainCredit} from './arazi-3d.mjs?v=arazi1';
import {matchPrices,parseText,fromAi,PIPE_OD,MATERIALS,ACCESSORIES} from './ai-project.mjs?v=arazi1';

const $=id=>document.getElementById(id);
const L=window.L;const web=window.chrome?.webview;const post=m=>web?.postMessage(m);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tr=new Intl.NumberFormat('tr-TR',{maximumFractionDigits:2});const n=x=>tr.format(x??0);
const para=x=>x==null?'—':new Intl.NumberFormat('tr-TR',{style:'currency',currency:'TRY',maximumFractionDigits:2}).format(x);
const KEY='miapax-arazi-v1';
const VARS={material:'PE100',mainDiameter:0,lateralDiameter:16,rowGap:1,emitterGap:0.33,emitterFlow:2,headFlow:1.2,headRange:12,sourceKind:'well',wellDepth:40,width:100,length:200,fittingKind:'tee',fittingOd:63,accessories:['filter','manometer','airValve','flushValve','pump']};

let state=yukle(),opts={...VARS,...(state.opts||{})},undo=[],arac='sec',taslak=null,secili=null,sekme='proje',stok=null,fiyatli=null,gorunum='2d',s3=null,logo=null,aiLog=[],aiBekleyen=new Map();

// ---------- Kalıcılık ----------
function yukle(){try{const raw=JSON.parse(localStorage.getItem(KEY)||'null');const s=M.clean(raw);s.opts=raw?.opts;return s;}catch{return M.empty();}}
let kayitZamani=0;function kaydet(){clearTimeout(kayitZamani);kayitZamani=setTimeout(()=>{try{localStorage.setItem(KEY,JSON.stringify({...state,opts}));}catch{}},250);}
function degistir(fn){undo.push(JSON.stringify(state));if(undo.length>60)undo.shift();fn();state.updated=new Date().toISOString();fiyatli=null;kaydet();ciz();panel();adimlar();if(gorunum==='3d')uc3();}
function geriAl(){const s=undo.pop();if(!s)return durum('Geri alınacak işlem yok.');state=M.clean(JSON.parse(s));secili=null;fiyatli=null;kaydet();ciz();panel();adimlar();if(gorunum==='3d')uc3();}
function durum(t,hata=false){const d=$('durum');d.textContent=t;d.classList.toggle('hata',hata);}
function ipucu(t){$('ipucu').textContent=t||'';}

// ---------- Harita ----------
const map=L.map('harita',{doubleClickZoom:false,preferCanvas:true,maxZoom:21,zoomSnap:0.5}).setView(state.geo?[state.geo.lat,state.geo.lng]:[39.0,35.2],state.geo?17:6);
const uydu=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{maxNativeZoom:19,maxZoom:21,attribution:'Esri World Imagery'}).addTo(map);
const adlar=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',{maxNativeZoom:19,maxZoom:21,opacity:.9}).addTo(map);
const osm=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap katkıcıları'});
L.control.layers({'Uydu':uydu,'Harita':osm},{'Yer adları':adlar},{position:'bottomright'}).addTo(map);
L.control.scale({imperial:false,position:'bottomleft'}).addTo(map);
const katman=L.layerGroup().addTo(map),gecici=L.layerGroup().addTo(map),tutamaclar=L.layerGroup().addTo(map);
const ll=p=>{const g=M.toLatLng(p,state.geo);return [g.lat,g.lng];};
const pt=e=>M.fromLatLng({lat:e.lat,lng:e.lng},state.geo);
const mPx=()=>40075016.686*Math.cos(map.getCenter().lat*Math.PI/180)/2**(map.getZoom()+8);
function kokEnsure(latlng){if(!state.geo){state.geo={lat:latlng.lat,lng:latlng.lng};}}

function ikon(metin,renk,boyut=26){return L.divIcon({className:'',html:`<div class="isaret" style="width:${boyut}px;height:${boyut}px;background:${renk}">${metin}</div>`,iconSize:[boyut,boyut],iconAnchor:[boyut/2,boyut/2]});}
const FIT_IKON={tee:'T',elbow:'L',valve:'V',reducer:'R',cap:'■',coupling:'M',filter:'F',pump:'P',airValve:'H',manometer:'B',regulator:'D',meter:'S',fertilizer:'G',solenoid:'E'};
const FIT_RENK={valve:'#c0392b',pump:'#16a085',filter:'#e67e22',airValve:'#2980b9',manometer:'#b7950b',regulator:'#d35400',meter:'#1abc9c',fertilizer:'#27ae60',solenoid:'#c0392b'};

function ciz(){
 katman.clearLayers();tutamaclar.clearLayers();
 if(!state.geo){serit();return;}
 const b=state.boundary;
 if(b.length>2){const pol=L.polygon(b.map(ll),{color:secili==='tarla'?'#ffffff':'#ffd43b',weight:secili==='tarla'?4:3,fillColor:'#ffd43b',fillOpacity:.08,dashArray:secili==='tarla'?'6 6':null}).addTo(katman);
  pol.on('click',e=>{if(arac==='sec'){L.DomEvent.stopPropagation(e);sec('tarla');}});
  if(secili==='tarla'){b.forEach((p,i)=>tutamac(p,q=>{degistir(()=>{state.boundary[i]=q;});}));
   // Ortadaki ✥ tutamaç tarlayı tüm boru ve parçalarla birlikte taşır.
   const c=M.centroid(b);const tas=L.marker(ll(c),{draggable:true,icon:ikon('✥','#123b31',30),title:'Tarlayı borularla birlikte taşı'}).addTo(tutamaclar);
   tas.on('dragend',()=>{const q=pt(tas.getLatLng()),dx=q.x-c.x,dy=q.y-c.y,k=p=>({x:p.x+dx,y:p.y+dy});degistir(()=>{state.boundary=state.boundary.map(k);for(const it of state.items){if(it.points)it.points=it.points.map(k);else it.p=k(it.p);}state.analysis=null;});durum('Tarla taşındı. Konum değiştiği için analizi yenileyin.');});}}
 for(const it of state.items){
  const T=M.TYPES[it.type],sel=secili===it.id;
  if(T.line){const w=it.type==='main'?6:it.type==='manifold'?5:it.type==='lateral'&&it.drip?2:3;
   const l=L.polyline(it.points.map(ll),{color:sel?'#ff4081':T.color==='#222222'?'#1b1b1b':T.color,weight:sel?w+3:w,opacity:.95}).addTo(katman);
   l.on('click',e=>{if(arac==='sec'){L.DomEvent.stopPropagation(e);sec(it.id);}});
   if(sel)it.points.forEach((p,i)=>tutamac(p,q=>degistir(()=>{const x=state.items.find(y=>y.id===it.id);if(x)x.points[i]=q;})));}
  else if(it.type==='head'){
   if(map.getZoom()>=16)L.circle(ll(it.p),{radius:it.range,color:'#4fc3f7',weight:1,fillOpacity:.08,interactive:false}).addTo(katman);
   const c=L.circleMarker(ll(it.p),{radius:sel?7:4,color:'#fff',weight:1,fillColor:sel?'#ff4081':'#f2b134',fillOpacity:1}).addTo(katman);
   c.on('click',e=>{if(arac==='sec'){L.DomEvent.stopPropagation(e);sec(it.id);}});
   if(sel)tutamac(it.p,q=>degistir(()=>{const x=state.items.find(y=>y.id===it.id);if(x)x.p=q;}));}
  else{const ic=it.type==='source'?ikon('💧','#1e88e5',34):ikon(FIT_IKON[it.kind]||'•',FIT_RENK[it.kind]||'#8e44ad',sel?26:20);
   const mk=L.marker(ll(it.p),{icon:ic,draggable:arac==='sec',title:it.type==='source'?M.SOURCE_KINDS[it.kind]:M.FITTINGS[it.kind]?.label}).addTo(katman);
   mk.on('click',e=>{if(arac==='sec'){L.DomEvent.stopPropagation(e);sec(it.id);}});
   mk.on('dragend',()=>{const q=pt(mk.getLatLng());degistir(()=>{const x=state.items.find(y=>y.id===it.id);if(x)x.p=q;});});
   if(sel)L.circleMarker(ll(it.p),{radius:18,color:'#ff4081',weight:2,fill:false,interactive:false}).addTo(katman);}
 }
 serit();
}
function tutamac(p,bitince){const m=L.marker(ll(p),{draggable:true,icon:L.divIcon({className:'',html:'<div class="tutamac"></div>',iconSize:[12,12],iconAnchor:[6,6]})}).addTo(tutamaclar);m.on('dragend',()=>bitince(pt(m.getLatLng())));}
function sec(id){secili=id;ciz();if(sekme!=='proje')sekmeAc('proje');else panel();}
function serit(){const s=M.summary(state);const a=state.analysis?.terrain;
 $('serit').innerHTML=state.boundary.length>2?`<span><b>${n(s.area)}</b> m²</span><span><b>${n(s.dekar)}</b> dekar</span><span>Çevre <b>${n(s.perimeter)}</b> m</span><span>Boru <b>${n(s.pipe)}</b> m</span>${a&&!a.error?`<span>Eğim <b>%${n(a.slope)}</b> · ${esc(a.aspect)}</span>`:''}`:state.geo?'<span>Tarla sınırı henüz çizilmedi</span>':'';
 $('atif').textContent=gorunum==='3d'?imageryCredit+' · '+terrainCredit:'';}

// ---------- Araçlar ----------
const SATIR_ARACLARI={main:'Ana boru',manifold:'Dağıtım borusu',lateral:'Hat borusu',tarla:'Tarla sınırı',olc:'Ölçüm'};
function aracSec(a){
 if(a==='geri')return geriAl();
 if(a==='sil')return silSecili();
 if(a==='otomatik'){sekmeAc('proje');return otomatik();}
 taslakIptal();arac=a;secili=null;
 document.querySelectorAll('#araclar button').forEach(b=>b.classList.toggle('secili',b.dataset.arac===a));
 map.getContainer().style.cursor=a==='sec'?'':'crosshair';
 const ip={sec:'',tarla:'Tarlanın köşelerine sırayla tıklayın. Bitirmek için çift tıklayın veya Enter.',dikdortgen:`Tarlanın merkezine tıklayın (${n(opts.width)} × ${n(opts.length)} m). Ölçüyü sağ panelden değiştirebilirsiniz.`,
  source:'Su kaynağının yerine tıklayın (kuyu, depo, kanal veya şebeke).',main:'Ana borunun geçeceği noktalara tıklayın; kaynağa veya boruya yakın tıklarsanız uç uca bağlanır. Çift tıkla bitir.',
  manifold:'Dağıtım borusunun başlangıç ve bitiş noktalarına tıklayın. Çift tıkla bitir.',lateral:'Hat borusu için noktalara tıklayın. Çift tıkla bitir.',head:'Başlık koymak istediğiniz yerlere tıklayın.',
  fitting:'Sağ panelden parça türünü seçin, sonra boru üzerine tıklayın (boruya otomatik oturur).',olc:'Ölçmek istediğiniz noktalara tıklayın. Çift tıkla bitir.'}[a]||'';
 ipucu(ip);if(gorunum==='3d'&&a!=='sec')gorunumSec('2d');
 ciz();panel();
}
function taslakIptal(){taslak=null;gecici.clearLayers();$('bitir').hidden=true;}
function taslakCiz(){gecici.clearLayers();if(!taslak||!state.geo)return;const pts=taslak.points.map(ll);
 if(taslak.tur==='tarla'&&pts.length>1)L.polygon(pts,{color:'#ffd43b',weight:2,dashArray:'5 5',fillOpacity:.1}).addTo(gecici);else if(pts.length>1)L.polyline(pts,{color:'#ff4081',weight:4,dashArray:'6 6'}).addTo(gecici);
 pts.forEach(p=>L.circleMarker(p,{radius:4,color:'#fff',fillColor:'#ff4081',fillOpacity:1,weight:1}).addTo(gecici));
 const len=M.polyLength(taslak.points);$('bitir').hidden=taslak.points.length<2;
 durum(taslak.tur==='tarla'?`${taslak.points.length} köşe · ${n(M.polyArea(taslak.points))} m²`:`${SATIR_ARACLARI[taslak.tur]||'Çizgi'}: ${n(len)} m`);}
/** Yakındaki kaynak, boru ucu veya köşeye yapıştırır (12 piksel). */
function yapistir(p){const tol=12*mPx();let best=null,bd=tol;
 for(const it of state.items){const cand=it.points??[it.p];for(const q of cand){const d=M.dist(p,q);if(d<bd){bd=d;best=q;}}}
 for(const q of state.boundary){const d=M.dist(p,q);if(d<bd*0.6){bd=d;best=q;}}
 return best?{...best}:p;}
/** Boru üzerindeki en yakın noktaya oturtur. */
function boruyaOturt(p){const tol=15*mPx();let best=null,bd=tol,od=null;
 for(const it of state.items){if(!it.points)continue;for(let i=1;i<it.points.length;i++){const a=it.points[i-1],b=it.points[i],dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy,t=l?Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l)):0,q={x:a.x+t*dx,y:a.y+t*dy},d=M.dist(p,q);if(d<bd){bd=d;best=q;od=it.od;}}}
 return best?{p:best,od}:{p,od:null};}

map.on('click',e=>{
 if(arac==='sec'){if(secili){secili=null;ciz();panel();}return;}
 kokEnsure(e.latlng);let p=pt(e.latlng);
 if(['tarla','main','manifold','lateral','olc'].includes(arac)){
  if(arac!=='tarla')p=yapistir(p);
  if(!taslak)taslak={tur:arac,points:[]};taslak.points.push(p);taslakCiz();return;}
 if(arac==='dikdortgen'){degistir(()=>{state.boundary=M.rectangle(opts.width,opts.length,p);});adresDoldur();aracSec('source');durum('Tarla oluşturuldu. Şimdi su kaynağının yerine tıklayın.');return;}
 if(arac==='source'){degistir(()=>{state.items=state.items.filter(i=>i.type!=='source');state.items.push({id:M.uid(),type:'source',p,kind:opts.sourceKind,depth:opts.sourceKind==='well'?opts.wellDepth:0});});durum('Su kaynağı yerleştirildi. Boruları elle çizebilir veya ✨ Otomatik ile yerleştirebilirsiniz.');aracSec('sec');return;}
 if(arac==='head'){degistir(()=>state.items.push({id:M.uid(),type:'head',p,range:opts.headRange,flow:opts.headFlow}));return;}
 if(arac==='fitting'){const o=boruyaOturt(p);degistir(()=>state.items.push({id:M.uid(),type:'fitting',kind:opts.fittingKind,od:o.od||opts.fittingOd,p:o.p,manual:true}));durum(`${M.FITTINGS[opts.fittingKind].label} eklendi${o.od?` (Ø${o.od} boruya oturtuldu)`:''}.`);return;}
});
map.on('dblclick',e=>{if(taslak){L.DomEvent.stop(e);taslakBitir();}});
map.on('zoomend',()=>{if(state.items.some(i=>i.type==='head'))ciz();});
function taslakBitir(){
 if(!taslak)return;const t=taslak;
 // Çift tıklama son noktayı iki kez ekler; çok yakın ardışık noktalar birleştirilir.
 const pts=t.points.filter((p,i,a)=>i===0||M.dist(p,a[i-1])>0.2);taslakIptal();
 if(t.tur==='tarla'){if(pts.length<3)return durum('Tarla için en az 3 köşe gerekir.',true);degistir(()=>{state.boundary=pts;});adresDoldur();aracSec('source');durum(`Tarla: ${n(M.polyArea(pts))} m² (${n(M.polyArea(pts)/1000)} dekar). Şimdi su kaynağını koyun.`);return;}
 if(pts.length<2)return;
 if(t.tur==='olc'){durum(`Ölçülen mesafe: ${n(M.polyLength(pts))} m`);return;}
 const od=t.tur==='main'?(opts.mainDiameter||63):t.tur==='manifold'?(opts.mainDiameter?Math.max(32,PIPE_OD[Math.max(0,PIPE_OD.indexOf(opts.mainDiameter)-1)]):50):opts.lateralDiameter;
 degistir(()=>state.items.push({id:M.uid(),type:t.tur,points:pts,od,...(t.tur==='lateral'?{drip:state.method==='drip',emitterGap:opts.emitterGap,emitterFlow:opts.emitterFlow}:{})}));
 durum(`${SATIR_ARACLARI[t.tur]} eklendi: ${n(M.polyLength(pts))} m, Ø${od} mm.`);
}
function silSecili(){if(!secili)return durum('Silmek için önce ↖ Seç aracıyla bir öğeye tıklayın.');
 if(secili==='tarla'){if(!confirm('Tarla sınırı silinsin mi? Borular kalır.'))return;degistir(()=>{state.boundary=[];});}
 else degistir(()=>{state.items=state.items.filter(i=>i.id!==secili);});secili=null;ciz();panel();}
document.addEventListener('keydown',e=>{
 if(e.target.matches('input,textarea,select'))return;
 if(e.key==='Enter'&&taslak){e.preventDefault();taslakBitir();}
 else if(e.key==='Escape'){if(taslak)taslakIptal();else aracSec('sec');}
 else if(e.key==='Delete'||e.key==='Backspace'){if(secili){e.preventDefault();silSecili();}}
 else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();geriAl();}
});
$('bitirEvet').onclick=taslakBitir;$('bitirHayir').onclick=()=>{taslakIptal();durum('Çizim iptal edildi.');};
document.querySelectorAll('#araclar button').forEach(b=>b.onclick=()=>aracSec(b.dataset.arac));

// ---------- Adres / konum ----------
async function geocode(q){
 const m=q.trim().match(/^(-?\d+(?:[.,]\d+)?)\s*[,; ]\s*(-?\d+(?:[.,]\d+)?)$/);
 if(m){const lat=Number(m[1].replace(',','.')),lng=Number(m[2].replace(',','.'));if(Math.abs(lat)<=85&&Math.abs(lng)<=180)return [{ad:`${lat}, ${lng}`,lat,lng}];}
 const r=await fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&accept-language=tr&q='+encodeURIComponent(q));if(!r.ok)throw Error('Adres servisi yanıt vermedi.');
 return (await r.json()).map(x=>({ad:x.display_name,lat:Number(x.lat),lng:Number(x.lon),kutu:x.boundingbox}));}
async function adresDoldur(){if(state.address||!state.geo||state.boundary.length<3)return;try{const c=M.toLatLng(M.centroid(state.boundary),state.geo);const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=16&accept-language=tr&lat=${c.lat}&lon=${c.lng}`);if(r.ok){const j=await r.json();state.address=j.display_name||'';kaydet();panel();}}catch{}}
function konumaGit(s){
 const yeni={lat:s.lat,lng:s.lng};
 if(state.geo&&(state.boundary.length||state.items.length)){const d=M.dist(M.fromLatLng(yeni,state.geo),{x:0,y:0});if(d>3000){if(confirm('Mevcut tarla çizimi yeni konuma taşınsın mı?\n\n"Tamam": çizim buraya taşınır · "İptal": yalnız harita kayar'))degistir(()=>{state.geo=yeni;state.address=s.ad;});}}
 else degistir(()=>{state.geo=yeni;state.address=s.ad;});
 map.flyTo([s.lat,s.lng],s.kutu?Math.min(18,Math.max(14,map.getBoundsZoom([[+s.kutu[0],+s.kutu[2]],[+s.kutu[1],+s.kutu[3]]]))):17,{duration:1.2});
 $('araOneri').hidden=true;durum('Konum: '+s.ad+'. Şimdi ⬟ Tarla ile sınırı çizin veya ▭ Ölçüyle tarla oluşturun.');if(!state.boundary.length)aracSec('tarla');}
$('araForm').onsubmit=async e=>{e.preventDefault();const q=$('araMetin').value.trim();if(q.length<2)return;durum('Adres aranıyor…');
 try{const l=await geocode(q);if(!l.length)return durum('Adres bulunamadı. Köy/mahalle, ilçe ve il adını birlikte yazmayı deneyin.',true);
  if(l.length===1)return konumaGit(l[0]);const o=$('araOneri');o.innerHTML='';for(const s of l){const b=document.createElement('button');b.type='button';b.textContent=s.ad;b.onclick=()=>konumaGit(s);o.append(b);}o.hidden=false;durum(l.length+' sonuç bulundu, birini seçin.');}
 catch(err){durum(err.message,true);}};
document.addEventListener('click',e=>{if(!e.target.closest('#araForm'))$('araOneri').hidden=true;});

// ---------- Otomatik yerleşim ----------
function otomatik(){
 if(state.boundary.length<3)return durum('Otomatik yerleşim için önce tarla sınırını çizin.',true);
 try{const r=M.autoLayout(state,{method:state.method,material:opts.material,mainDiameter:opts.mainDiameter,lateralDiameter:opts.lateralDiameter,rowGap:opts.rowGap,emitterGap:state.method==='drip'?opts.emitterGap:opts.headRange,emitterFlow:state.method==='drip'?opts.emitterFlow:opts.headFlow,
   sourceType:opts.sourceKind,wellDepth:opts.wellDepth,accessories:opts.accessories,elevation:state.analysis?.terrain?.diff||0});
  degistir(()=>{state.items=r.items;});
  durum(`Otomatik yerleşim: ${r.calc.lateralCount} hat, ${r.calc.sections} bölüm, ana hat Ø${r.calc.mainOd} mm, pompa ≈${r.calc.pumpKw} kW. Öğeleri ↖ Seç ile düzenleyebilirsiniz.`);
  aiEkle('mia',[...r.calc.notes,...r.calc.warnings].join('\n')||'Yerleşim hazır.');return r;}
 catch(e){durum(e.message,true);}}

// ---------- Panel ----------
function sekmeAc(s){sekme=s;document.querySelectorAll('.sekmeler button').forEach(b=>b.classList.toggle('secili',b.dataset.sekme===s));panel();}
document.querySelectorAll('.sekmeler button').forEach(b=>b.onclick=()=>sekmeAc(b.dataset.sekme));
const sec2=(id,deger,secenekler)=>`<select id="${id}">${secenekler.map(([v,t])=>`<option value="${esc(v)}"${String(v)===String(deger)?' selected':''}>${esc(t)}</option>`).join('')}</select>`;
const odSec=(id,v,oto)=>sec2(id,v,[...(oto?[[0,'Otomatik']]:[]),...PIPE_OD.map(o=>[o,'Ø'+o+' mm'])]);
function panel(){const k=$('icerik');k.innerHTML=sekme==='proje'?projePaneli():sekme==='analiz'?analizPaneli():aiPaneli();baglaPanel();}
function seciliKart(){
 if(arac==='fitting')return `<div class="secim"><h3>Ek parça seçin</h3><div class="parca-sec">${Object.entries(M.FITTINGS).map(([k,f])=>`<button data-parca="${k}" class="${opts.fittingKind===k?'secili':''}">${esc(f.label)}</button>`).join('')}</div><div class="alanlar" style="margin-top:8px"><label>Boruda değilse çap${odSec('pFitOd',opts.fittingOd)}</label></div></div>`;
 if(!secili)return '';
 if(secili==='tarla')return `<div class="secim"><b>Tarla sınırı</b> · ${n(M.polyArea(state.boundary))} m², ${state.boundary.length} köşe<div class="kucuk">Beyaz noktaları sürükleyerek köşeleri taşıyın.</div><div class="dugmeler"><button data-sil>🗑 Sınırı sil</button></div></div>`;
 const it=state.items.find(i=>i.id===secili);if(!it){secili=null;return '';}
 const T=M.TYPES[it.type];let f='';
 if(it.points)f=`<label>Çap${odSec('pOd',it.od)}</label><label>Uzunluk<input value="${n(M.polyLength(it.points))} m" disabled></label>${it.type==='lateral'?`<label>Tür${sec2('pDrip',it.drip?1:0,[[1,'Damla borusu'],[0,'PE hat borusu']])}</label><label>Damlatıcı arası (m)<input id="pEg" type="number" step="0.05" value="${it.emitterGap}"></label>`:''}`;
 else if(it.type==='source')f=`<label>Tür${sec2('pKind',it.kind,Object.entries(M.SOURCE_KINDS))}</label><label>Kuyu derinliği (m)<input id="pDepth" type="number" value="${it.depth||0}"></label>`;
 else if(it.type==='head')f=`<label>Debi (m³/sa)<input id="pFlow" type="number" step="0.1" value="${it.flow}"></label><label>Atış yarıçapı (m)<input id="pRange" type="number" value="${it.range}"></label>`;
 else f=`<label>Parça${sec2('pKind',it.kind,Object.entries(M.FITTINGS).map(([a,b])=>[a,b.label]))}</label><label>Çap${odSec('pOd',it.od)}</label>`;
 return `<div class="secim"><b>${T.icon} ${esc(T.label)}</b><div class="alanlar" style="margin-top:6px">${f}</div><div class="dugmeler"><button data-sil>🗑 Sil</button></div></div>`;}
function projePaneli(){
 const s=M.summary(state),drip=state.method==='drip';
 const bom=fiyatli??M.materials(state,{material:opts.material});const h=M.hydraulics(state,{elevation:state.analysis?.terrain?.diff||0});
 let gr='',rows='';for(const r of bom){if(r.group!==gr){gr=r.group;rows+=`<tr class="grup"><td colspan="4">${esc(gr)}</td></tr>`;}rows+=`<tr><td>${esc(r.name)}${r.size?` <span class="kucuk">${esc(r.size)}</span>`:''}${r.stock?`<div class="kucuk">${esc(r.stock)}</div>`:''}</td><td class="s">${n(r.qty)} ${esc(r.unit)}</td><td class="s">${r.price!=null?para(r.price):''}</td><td class="s">${r.total!=null?para(r.total):''}</td></tr>`;}
 const top=bom.reduce((a,r)=>a+(r.total||0),0),kdv=bom.reduce((a,r)=>a+(r.totalVat||0),0);
 return `${seciliKart()}
 <h3>Proje</h3><div class="alanlar"><label class="tam">Proje adı<input id="fAd" maxlength="80" value="${esc(state.name)}"></label><label class="tam">Adres<input id="fAdres" maxlength="200" value="${esc(state.address)}" placeholder="Haritadan otomatik doldurulur"></label>
 <label>Ürün<input id="fUrun" list="urunler" maxlength="60" value="${esc(state.crop)}" placeholder="mısır, domates…"><datalist id="urunler">${Object.keys(M.CROPS).map(c=>`<option value="${esc(c)}">`).join('')}</datalist></label>
 <label>Sulama${sec2('fYontem',state.method,[['drip','Damla'],['sprinkler','Yağmurlama'],['minisprinkler','Mini yağmurlama']])}</label>
 <label>Ölçüyle en (m)<input id="fEn" type="number" min="2" value="${opts.width}"></label><label>Ölçüyle boy (m)<input id="fBoy" type="number" min="2" value="${opts.length}"></label></div>
 <h3>Otomatik yerleşim ayarları</h3><div class="alanlar">
 <label>Su kaynağı${sec2('oKaynak',opts.sourceKind,Object.entries(M.SOURCE_KINDS))}</label><label>Kuyu derinliği (m)<input id="oDerin" type="number" value="${opts.wellDepth}"></label>
 <label>Boru malzemesi${sec2('oMalz',opts.material,Object.entries(MATERIALS).map(([k,v])=>[k,v.label]))}</label><label>Ana boru${odSec('oAna',opts.mainDiameter,true)}</label>
 <label>Hat arası (m)<input id="oSira" type="number" step="0.1" value="${opts.rowGap}"></label><label>Hat borusu${odSec('oHat',opts.lateralDiameter)}</label>
 ${drip?`<label>Damlatıcı arası (m)<input id="oDamla" type="number" step="0.05" value="${opts.emitterGap}"></label><label>Damlatıcı debisi (l/sa)<input id="oDebi" type="number" step="0.1" value="${opts.emitterFlow}"></label>`:`<label>Başlık arası (m)<input id="oBas" type="number" value="${opts.headRange}"></label><label>Başlık debisi (m³/sa)<input id="oBDebi" type="number" step="0.1" value="${opts.headFlow}"></label>`}
 <label class="tam">Aksesuarlar<span class="parca-sec">${Object.entries(ACCESSORIES).map(([k,v])=>`<button type="button" data-aks="${k}" class="${opts.accessories.includes(k)?'secili':''}">${esc(v)}</button>`).join('')}</span></label></div>
 <div class="dugmeler"><button class="ana" data-oto>✨ Otomatik yerleştir</button><button data-temizle>Boruları temizle</button></div>
 <h3>Özet</h3><div class="olcu"><div><b>${n(s.dekar)}</b><small>dekar</small></div><div><b>${n(s.pipe)}</b><small>m boru</small></div><div><b>${state.items.filter(i=>i.type==='head').length}</b><small>başlık</small></div>
 <div><b>${n(h.totalFlow)}</b><small>m³/sa toplam</small></div><div><b>${h.head}</b><small>m basma</small></div><div><b>${h.kw}</b><small>kW pompa ≈</small></div></div>
 <h3>Malzeme listesi</h3>${bom.length?`<table><thead><tr><th>Malzeme</th><th class="s">Miktar</th><th class="s">Birim</th><th class="s">Tutar</th></tr></thead><tbody>${rows}</tbody></table>
 ${fiyatli?`<div class="toplam"><span>KDV hariç</span><span>${para(top)}</span></div><div class="toplam"><span>KDV dahil</span><span>${para(kdv)}</span></div>`:''}
 <div class="dugmeler"><button data-fiyat>💰 Fiyatları stoktan getir</button></div><p class="kucuk">Metraj çizimden hesaplanır (%2–3 fire dahil). Bağlantı parçaları çizime göre önerilir; saha keşfiyle doğrulayın.</p>`:'<p class="kucuk">Boru veya başlık çizdikçe malzeme listesi burada oluşur.</p>'}`;}
function analizPaneli(){
 const a=state.analysis;let h=`<div class="dugmeler"><button class="ana" data-analiz>🔬 Analizi ${a?'yenile':'başlat'}</button></div><p class="kucuk">Toprak: ISRIC SoilGrids (250 m tahmin) · Hava ve iklim: Open-Meteo · Eğim: Copernicus DEM. Laboratuvar analizinin yerine geçmez.</p>`;
 if(!a)return h+'<p class="kucuk">Tarlayı çizdikten sonra analizi başlatın; sonuçlar PDF teklifin altına eklenir.</p>';
 h+=`<p class="kucuk">${new Date(a.at).toLocaleString('tr-TR')} · ${a.point.lat.toFixed(5)}, ${a.point.lng.toFixed(5)}</p>`;
 return h+analizHtml(a,false);}
function analizHtml(a,rapor){
 let h='';const s=a.soil,w=a.weather,t=a.terrain,i=a.irrigation;
 if(i)h+=`<div class="kart"><h4>💧 Sulama önerisi</h4><p><b>Bu hafta:</b> ${esc(i.text)}</p>${i.peak?`<p><b>Tasarım (zirve):</b> ${esc(i.peak.text)}</p><div class="olcu"><div><b>${n(i.peak.etc)}</b><small>mm/gün zirve tüketim</small></div><div><b>${n(i.peak.dailyM3)}</b><small>m³/gün zirve su</small></div><div><b>${i.peak.interval??'—'}</b><small>gün aralık</small></div></div>`:`<div class="olcu"><div><b>${n(i.etc)}</b><small>mm/gün tüketim</small></div><div><b>${n(i.dailyM3)}</b><small>m³/gün su</small></div><div><b>${i.interval??'—'}</b><small>gün aralık</small></div></div>`}${!i.recommendDrip&&state.method==='drip'?'<p class="kucuk">Bu ürün genelde yağmurlama/salma ile sulanır; damla ekonomisini kontrol edin.</p>':''}</div>`;
 if(s.error)h+=`<div class="kart hata"><h4>🟤 Toprak</h4>${esc(s.error)}</div>`;
 else h+=`<div class="kart"><h4>🟤 Toprak analizi (0–30 cm)</h4><div class="olcu"><div><b>${n(s.ph)}</b><small>pH</small></div><div><b>${esc(s.texture)}</b><small>tekstür</small></div><div><b>%${n(s.organicMatter)}</b><small>organik madde</small></div>
  <div><b>%${n(s.clay)}</b><small>kil</small></div><div><b>%${n(s.sand)}</b><small>kum</small></div><div><b>%${n(s.silt)}</b><small>silt</small></div><div><b>${n(s.nitrogen)}</b><small>g/kg azot</small></div><div><b>${n(s.cec)}</b><small>KDK cmol/kg</small></div><div><b>${n(s.bulkDensity)}</b><small>hacim ağ. g/cm³</small></div></div>
  <ul class="notlar"><li>${esc(s.phNote)}</li><li>Organik madde: ${esc(s.omNote)}</li><li>${esc(s.waterNote)} (infiltrasyon ≈${s.infiltration} mm/sa, kullanılabilir su ≈${s.availableWater} mm/m)</li>${s.wrb?.name?`<li>WRB toprak grubu: ${esc(s.wrb.name)}</li>`:''}${s.advice.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`;
 if(t.error)h+=`<div class="kart uyari"><h4>⛰ Arazi</h4>${esc(t.error)}</div>`;
 else h+=`<div class="kart"><h4>⛰ Arazi yüksekliği ve eğim</h4><div class="olcu"><div><b>${t.min}–${t.max}</b><small>m rakım</small></div><div><b>${n(t.diff)}</b><small>m kot farkı</small></div><div><b>%${n(t.slope)}</b><small>eğim · ${esc(t.aspect)}e bakıyor</small></div></div><p class="kucuk">${esc(t.note)}</p></div>`;
 if(w.error)h+=`<div class="kart hata"><h4>🌤 Meteoroloji</h4>${esc(w.error)}</div>`;
 else{h+=`<div class="kart"><h4>🌤 Meteoroloji · 7 günlük tahmin</h4><div class="gunler">${w.days.map(d=>`<div><b>${new Date(d.date).toLocaleDateString('tr-TR',{weekday:'short'})}</b><br>${Math.round(d.max)}° / ${Math.round(d.min)}°<br>💧${n(d.rain)} mm<br>ET₀ ${n(d.et0)}</div>`).join('')}</div>
  <ul class="notlar">${w.alerts.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`;
  if(w.climate)h+=`<div class="kart"><h4>📅 Son 12 ay iklim özeti</h4><div class="olcu"><div><b>${w.climate.rain}</b><small>mm yağış</small></div><div><b>${w.climate.et0}</b><small>mm buharlaşma (ET₀)</small></div><div><b>${w.climate.deficit}</b><small>mm su açığı</small></div>
   <div><b>${w.climate.gdd}</b><small>büyüme gün-derece (10 °C)</small></div><div><b>${w.climate.frostDays}</b><small>donlu gün</small></div><div><b>${w.climate.lastSpringFrost?new Date(w.climate.lastSpringFrost).toLocaleDateString('tr-TR',{day:'numeric',month:'long'}):'—'}</b><small>son ilkbahar donu</small></div></div>
   ${rapor?`<table><thead><tr><th>Ay</th>${w.climate.months.map(m=>`<th class="s">${m.month.slice(5)}</th>`).join('')}</tr></thead><tbody><tr><td>Yağış mm</td>${w.climate.months.map(m=>`<td class="s">${m.rain}</td>`).join('')}</tr><tr><td>ET₀ mm</td>${w.climate.months.map(m=>`<td class="s">${m.et0}</td>`).join('')}</tr></tbody></table>`:''}</div>`;}
 return h;}
function aiPaneli(){
 return `<div class="ai-kutu"><p class="kucuk">Tarlanızı anlatın; yapay zekâ adresi haritada bulur, tarlayı ölçüsüne göre çizer, su kaynağını yerleştirir, boruları döşer, malzemeyi ve analizi hazırlar.</p>
 <textarea id="aiMetin" maxlength="1500" placeholder="Örn: Kayseri Develi Sindelhöyük'te 12 dekar mısır tarlası. Kuyu tarlanın kuzeyinde 40 m uzakta, 80 m derin. Damla sulama, ana hat 75'lik PE100, filtre ve gübre tankı olsun."></textarea>
 <div class="dugmeler"><button class="ana" data-ai>🤖 Projeyi hazırla</button><button data-aiyorum>Mevcut çizimi yorumla</button><button data-aiayar>Bağlantı ayarı</button></div>
 <div class="ai-log">${aiLog.map(m=>`<p class="${m.kim==='ben'?'ben':''}">${esc(m.metin)}</p>`).join('')}</div></div>`;}
function aiEkle(kim,metin){if(!metin)return;aiLog.push({kim,metin});if(aiLog.length>30)aiLog.shift();if(sekme==='ai')panel();}

function baglaPanel(){
 const k=$('icerik'),q=s=>k.querySelector(s);
 const deger=(id,fn)=>{const e=q('#'+id);if(e)e.onchange=()=>fn(e.value);};
 const sayi=v=>Number(String(v).replace(',','.'));
 deger('fAd',v=>degistir(()=>state.name=v.slice(0,80)||'Yeni tarla'));deger('fAdres',v=>degistir(()=>state.address=v.slice(0,200)));deger('fUrun',v=>degistir(()=>state.crop=v.slice(0,60)));
 deger('fYontem',v=>{degistir(()=>state.method=v);});
 deger('fEn',v=>{opts.width=Math.max(2,sayi(v)||100);kaydet();});deger('fBoy',v=>{opts.length=Math.max(2,sayi(v)||200);kaydet();});
 const o=(id,key,fn=sayi)=>deger(id,v=>{opts[key]=fn(v);kaydet();panel();});
 o('oKaynak','sourceKind',v=>v);o('oDerin','wellDepth');o('oMalz','material',v=>v);o('oAna','mainDiameter');o('oSira','rowGap');o('oHat','lateralDiameter');o('oDamla','emitterGap');o('oDebi','emitterFlow');o('oBas','headRange');o('oBDebi','headFlow');o('pFitOd','fittingOd');
 k.querySelectorAll('[data-aks]').forEach(b=>b.onclick=()=>{const a=b.dataset.aks;opts.accessories=opts.accessories.includes(a)?opts.accessories.filter(x=>x!==a):[...opts.accessories,a];kaydet();panel();});
 k.querySelectorAll('[data-parca]').forEach(b=>b.onclick=()=>{opts.fittingKind=b.dataset.parca;kaydet();panel();});
 q('[data-oto]')&&(q('[data-oto]').onclick=otomatik);
 q('[data-temizle]')&&(q('[data-temizle]').onclick=()=>{if(confirm('Tüm borular, başlıklar ve ek parçalar silinsin mi? Su kaynağı ve tarla kalır.'))degistir(()=>state.items=state.items.filter(i=>i.type==='source'));});
 q('[data-sil]')&&(q('[data-sil]').onclick=silSecili);
 q('[data-fiyat]')&&(q('[data-fiyat]').onclick=fiyatGetir);
 q('[data-analiz]')&&(q('[data-analiz]').onclick=analizYap);
 q('[data-ai]')&&(q('[data-ai]').onclick=()=>aiHazirla(q('#aiMetin').value));
 q('[data-aiyorum]')&&(q('[data-aiyorum]').onclick=aiYorum);
 q('[data-aiayar]')&&(q('[data-aiayar]').onclick=()=>post({action:'designSettings'}));
 // Seçili öğe özellikleri
 const it=state.items.find(i=>i.id===secili);if(it){
  deger('pOd',v=>degistir(()=>{const x=state.items.find(y=>y.id===it.id);x.od=Number(v);}));
  deger('pDrip',v=>degistir(()=>{state.items.find(y=>y.id===it.id).drip=v==='1';}));deger('pEg',v=>degistir(()=>{state.items.find(y=>y.id===it.id).emitterGap=Math.max(0.1,sayi(v)||0.33);}));
  deger('pKind',v=>degistir(()=>{state.items.find(y=>y.id===it.id).kind=v;}));deger('pDepth',v=>degistir(()=>{state.items.find(y=>y.id===it.id).depth=Math.max(0,Math.min(500,sayi(v)||0));}));
  deger('pFlow',v=>degistir(()=>{state.items.find(y=>y.id===it.id).flow=Math.max(0.05,sayi(v)||1.2);}));deger('pRange',v=>degistir(()=>{state.items.find(y=>y.id===it.id).range=Math.max(1,Math.min(60,sayi(v)||12));}));}
}

// ---------- Stok fiyatları (program üzerinden) ----------
let stokBekleyen=null;
function stokAra(metin){return new Promise((res,rej)=>{if(!web)return rej(Error('Fiyatlar yalnız MiapaxERP içinde getirilebilir.'));const t=setTimeout(()=>{stokBekleyen=null;rej(Error('Stok yanıtı gelmedi.'));},10000);stokBekleyen={res:v=>{clearTimeout(t);res(v);},rej:e=>{clearTimeout(t);rej(e);}};post({action:'stockSearch',search:metin});});}
async function fiyatGetir(){
 durum('Stok fiyatları getiriliyor…');
 try{if(!stok){const map2=new Map();for(const w of ['','boru','damla','te','dirsek','vana','tapa','manşon','filtre','pompa','yağmurlama','priz','redüksiyon','hava','manometre','kelepçe','teflon','sayaç','gübre','regülatör','selenoid','yükseltme','damlatıcı','kolye']){const rows=await stokAra(w);for(const r of rows)map2.set(r.id,r);}stok=[...map2.values()];}
  fiyatli=matchPrices(M.materials(state,{material:opts.material}),stok);const eksik=fiyatli.filter(r=>r.price==null).length;
  durum(eksik?`${fiyatli.length-eksik} kalem fiyatlandı; ${eksik} kalem stokta eşleşmedi (stok adında çap ve ürün adı geçmeli).`:'Tüm kalemler stoktan fiyatlandı.');panel();}
 catch(e){durum(e.message,true);}}

// ---------- Analiz ----------
async function analizYap(){
 if(!state.geo)return durum('Önce konumu bulun.',true);durum('Toprak, hava ve eğim verileri alınıyor… (10–30 sn)');
 try{const a=await analyse(state);degistir(()=>state.analysis=a);sekmeAc('analiz');const h=[a.soil,a.weather,a.terrain].filter(x=>x.error).length;durum(h?'Analiz tamamlandı; bazı veriler alınamadı (ayrıntı panelde).':'Analiz tamamlandı. Sonuçlar PDF teklifin altına eklenecek.');}
 catch(e){durum('Analiz yapılamadı: '+e.message,true);}}

// ---------- Yapay zekâ ----------
function aiSor(action,prompt,context){return new Promise((res,rej)=>{if(!web)return rej(Error('Yapay zekâ yalnız MiapaxERP içinde çalışır.'));const id=M.uid();const t=setTimeout(()=>{aiBekleyen.delete(id);rej(Error('Yapay zekâ yanıt vermedi.'));},75000);aiBekleyen.set(id,{res:v=>{clearTimeout(t);res(v);},rej:e=>{clearTimeout(t);rej(e);}});post({action,id,prompt,context});});}
const baglam=()=>{const s=M.summary(state);return JSON.stringify({ad:state.name,adres:state.address,urun:state.crop,yontem:state.method,alanM2:s.area,dekar:s.dekar,boruM:s.pipe,kaynak:state.items.find(i=>i.type==='source')?.kind,egim:state.analysis?.terrain?.slope,toprak:state.analysis?.soil?.texture,ph:state.analysis?.soil?.ph}).slice(0,1800);};
/** Yerel çözümleyici: büyük harfle başlayan yer adlarını ve "Adres:" satırını yakalar. */
function adresCikar(t){const a=t.match(/adres\s*[:：]\s*([^\n.]+)/i);if(a)return a[1].trim();
 const ad=[...t.matchAll(/([A-ZÇĞİÖŞÜ][a-zçğıöşü]+(?:\s+[A-ZÇĞİÖŞÜ][a-zçğıöşü]+){0,2})(?:['’]?(?:de|da|te|ta|nde|nda|ndeki|ndaki|deki|daki))?\b/g)].map(m=>m[1]).filter(w=>!/^(Kuyu|Damla|Ana|Tarla|Su|Pompa|Filtre|Mısır|Domates|Yağmurlama|Depo|Kanal|Şebeke|PE|PVC)$/i.test(w));
 return ad.slice(0,3).join(', ');}
async function aiHazirla(metin){
 metin=String(metin||'').trim();if(metin.length<5)return durum('Tarlanızı birkaç cümleyle anlatın.',true);
 aiEkle('ben',metin);durum('Yapay zekâ projeyi hazırlıyor…');
 let o=null,notlar='';
 try{const r=await aiSor('studioAsk',metin,baglam());const j=r.text;const a=j.indexOf('{'),b=j.lastIndexOf('}');const raw=a>=0&&b>a?JSON.parse(j.slice(a,b+1)):null;
  if(raw){o={...fromAi(JSON.stringify(raw))};for(const k of ['address','areaDekar','notes'])if(raw[k]!=null)o[k]=raw[k];notlar=String(raw.notes||'').slice(0,800);}}
 catch(e){aiEkle('mia','Yapay zekâ sunucusuna ulaşılamadı ('+e.message+'). Anlatımınız yerleşik çözümleyiciyle okunuyor.');}
 if(!o){o=parseText(metin);o.address=adresCikar(metin);const dk=metin.toLocaleLowerCase('tr-TR').replace(',','.').match(/(\d+(?:\.\d+)?)\s*(dekar|dönüm|donum)/);if(dk)o.areaDekar=Number(dk[1]);}
 // 1) Konum
 if(o.address){try{const l=await geocode(String(o.address));if(l.length){const s=l[0];degistir(()=>{if(!state.geo||!state.boundary.length||M.dist(M.fromLatLng(s,state.geo),{x:0,y:0})>3000){state.geo={lat:s.lat,lng:s.lng};state.boundary=[];state.items=[];}state.address=s.ad;});map.flyTo([s.lat,s.lng],17,{duration:1});aiEkle('mia','📍 Konum bulundu: '+s.ad);}else aiEkle('mia','Adres haritada bulunamadı; tarla mevcut harita merkezine çiziliyor. Konumu üstteki arama kutusundan düzeltebilirsiniz.');}catch{}}
 if(!state.geo){const c=map.getCenter();state.geo={lat:c.lat,lng:c.lng};}
 // 2) Tarla
 let W=Number(o.width),Lh=Number(o.length);if(!(W>0&&Lh>0)&&Number(o.areaDekar)>0){const z=M.sizeFromArea(Number(o.areaDekar)*1000);W=z.width;Lh=z.length;}
 if(W>0&&Lh>0)degistir(()=>{state.boundary=M.rectangle(W,Lh,{x:0,y:0});});
 else if(state.boundary.length<3)degistir(()=>{state.boundary=M.rectangle(opts.width,opts.length,{x:0,y:0});});
 if(o.crop)state.crop=String(o.crop).slice(0,60);if(o.method)state.method=['drip','sprinkler','minisprinkler'].includes(o.method)?o.method:state.method;
 // 3) Su kaynağı
 const bb=M.bbox(state.boundary),W2=bb.maxX-bb.minX,L2=bb.maxY-bb.minY,d=Number(o.sourceDistance)||20,off=Number.isFinite(Number(o.sourceOffset))?Number(o.sourceOffset):0.5;
 const side=o.sourceSide||'south';const sp=side==='north'?{x:bb.minX+W2*off,y:bb.maxY+d}:side==='east'?{x:bb.maxX+d,y:bb.minY+L2*off}:side==='west'?{x:bb.minX-d,y:bb.minY+L2*off}:{x:bb.minX+W2*off,y:bb.minY-d};
 const kind=o.sourceType||opts.sourceKind;
 Object.assign(opts,{sourceKind:kind,wellDepth:Number(o.wellDepth)||opts.wellDepth,...(o.material?{material:o.material}:{}),...(o.mainDiameter?{mainDiameter:Number(o.mainDiameter)}:{}),...(o.lateralDiameter?{lateralDiameter:Number(o.lateralDiameter)}:{}),...(o.rowGap?{rowGap:Number(o.rowGap)}:{}),
  ...(o.emitterGap?(state.method==='drip'?{emitterGap:Number(o.emitterGap)}:{headRange:Number(o.emitterGap)}):{}),...(o.emitterFlow?(state.method==='drip'?{emitterFlow:Number(o.emitterFlow)}:{headFlow:Number(o.emitterFlow)}):{}),...(Array.isArray(o.accessories)&&o.accessories.length?{accessories:o.accessories.filter(a=>ACCESSORIES[a])}:{})});
 degistir(()=>{state.items=[{id:M.uid(),type:'source',p:sp,kind,depth:kind==='well'?opts.wellDepth:0}];});
 // 4) Yerleşim, 5) analiz, 6) fiyat
 const r=otomatik();map.fitBounds(L.latLngBounds([...state.boundary,sp].map(ll)).pad(0.25));
 if(notlar)aiEkle('mia','💡 '+notlar);
 if(r)aiEkle('mia',`✅ Proje hazır: ${n(M.polyArea(state.boundary)/1000)} dekar, ${r.calc.lateralCount} hat, ana hat Ø${r.calc.mainOd} mm, ${r.calc.sections} bölüm, pompa ≈${r.calc.pumpKw} kW (${r.calc.head} m). Şimdi toprak/hava analizi ve fiyatlar alınıyor.`);
 aracSec('sec');
 await analizYap();if(web)await fiyatGetir().catch(()=>{});sekmeAc('ai');
 aiEkle('mia','Tarla tam yerinde değilse: ↖ Seç ile sınıra tıklayın, ortadaki ✥ işaretini sürükleyerek tarlayı borularıyla birlikte gerçek yerine taşıyın; köşe noktalarıyla sınırı düzeltin.');
 durum('Proje hazır. Çizimi düzenleyebilir, 3D uydu görünümüne geçebilir veya PDF teklif alabilirsiniz.');}
async function aiYorum(){
 if(!state.items.length)return durum('Yorum için önce boru veya başlık çizin.',true);
 const bom=M.materials(state,{material:opts.material}).map(r=>`${r.name} ${r.size} ${r.qty} ${r.unit}`).join('; ').slice(0,720);
 aiEkle('ben','Mevcut çizimi yorumla');
 try{const r=await aiSor('studioReview','Bu sulama projesini değerlendir. Malzeme: '+bom,baglam().slice(0,1400));aiEkle('mia',r.text||'Yanıt boş.');degistir(()=>state.ai=(r.text||'').slice(0,4000));}
 catch(e){aiEkle('mia','Yorum alınamadı: '+e.message);}}

// ---------- 3D ----------
async function uc3(fit=false){try{if(!s3)s3=createStudio3D($('uc'));await s3.show(state,{fit});serit();}catch(e){durum(e.message,true);}}
function gorunumSec(g){gorunum=g;$('v2').classList.toggle('secili',g==='2d');$('v3').classList.toggle('secili',g==='3d');$('harita').style.visibility=g==='2d'?'visible':'hidden';$('uc').hidden=g!=='3d';$('kamera').hidden=g!=='3d';
 if(g==='3d'){taslakIptal();ipucu('');durum('3D uydu görünümü yükleniyor… Sürükleyerek döndürün, tekerlekle yaklaşın.');uc3(true).then(()=>durum('3D uydu görünümü hazır.'));}else{map.invalidateSize();ciz();}serit();}
$('v2').onclick=()=>gorunumSec('2d');$('v3').onclick=()=>{if(state.boundary.length<3&&!state.items.length)return durum('3D için önce tarlayı çizin.',true);gorunumSec('3d');};
document.querySelectorAll('[data-kam]').forEach(b=>b.onclick=()=>s3?.view(b.dataset.kam));
let abarti=1.5;$('kabart').onclick=()=>{abarti=abarti===1.5?3:abarti===3?1:1.5;$('kabart').textContent='⛰ ×'+String(abarti).replace('.',',');s3?.setExaggeration(abarti);uc3();};

// ---------- Adımlar ----------
function adimlar(){const d={konum:!!state.geo,tarla:state.boundary.length>2,kaynak:state.items.some(i=>i.type==='source'),boru:state.items.some(i=>['main','lateral','manifold','head'].includes(i.type)),analiz:!!state.analysis,pdf:!!state.pdfAt};
 const ilk=Object.keys(d).find(k=>!d[k]);document.querySelectorAll('#adimlar button').forEach(b=>{b.classList.toggle('tamam',d[b.dataset.adim]);b.classList.toggle('simdi',b.dataset.adim===ilk);});}
document.querySelectorAll('#adimlar button').forEach(b=>b.onclick=()=>({konum:()=>$('araMetin').focus(),tarla:()=>aracSec('tarla'),kaynak:()=>aracSec('source'),boru:()=>{sekmeAc('proje');if(state.boundary.length>2)otomatik();else aracSec('main');},analiz:analizYap,pdf:pdf})[b.dataset.adim]());

// ---------- Dosya ----------
$('btnKaydet').onclick=()=>{const blob=new Blob([JSON.stringify({...state,opts},null,1)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(state.name||'arazi').replace(/[^\wçğıöşüÇĞİÖŞÜ -]/g,'')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000);};
$('btnAc').onclick=()=>$('dosya').click();
$('dosya').onchange=async()=>{const f=$('dosya').files[0];if(!f)return;if(f.size>20e6)return durum('Dosya çok büyük.',true);try{const raw=JSON.parse(await f.text());degistir(()=>{state=M.clean(raw);});opts={...VARS,...(raw.opts||{})};if(state.geo)map.setView([state.geo.lat,state.geo.lng],17);if(state.boundary.length>2)map.fitBounds(L.latLngBounds(state.boundary.map(ll)).pad(.2));panel();durum('Proje açıldı.');}catch{durum('Dosya okunamadı.',true);}$('dosya').value='';};
$('btnEski').onclick=()=>{location.href='/index.html?v=arazi1';};

// ---------- PDF ----------
async function pdf(){
 if(state.boundary.length<3)return durum('PDF için önce tarlayı çizin.',true);
 durum('PDF hazırlanıyor: uydu görüntüleri işleniyor…');
 let ust='',aci='';try{if(!s3)s3=createStudio3D($('uc'));await s3.show(state,{fit:true});ust=s3.snapshot('above');aci=s3.snapshot('angle');}catch(e){durum('Uydu görüntüsü alınamadı: '+e.message+' — PDF görselsiz hazırlanıyor.',true);}
 const bom=fiyatli??M.materials(state,{material:opts.material}),h=M.hydraulics(state,{elevation:state.analysis?.terrain?.diff||0}),s=M.summary(state),c=state.geo?M.toLatLng(M.centroid(state.boundary),state.geo):null;
 let gr='',rows='';for(const r of bom){if(r.group!==gr){gr=r.group;rows+=`<tr class="grup"><td colspan="6">${esc(gr)}</td></tr>`;}rows+=`<tr><td>${esc(r.name)}</td><td>${esc(r.size||'')}</td><td class="s">${n(r.qty)} ${esc(r.unit)}</td><td class="s">${r.price!=null?para(r.price):''}</td><td class="s">${r.vat!=null?'%'+r.vat:''}</td><td class="s">${r.total!=null?para(r.total):''}</td></tr>`;}
 const top=bom.reduce((a,r)=>a+(r.total||0),0),kdv=bom.reduce((a,r)=>a+(r.totalVat||0),0);
 $('rapor').innerHTML=`<div class="bas"><img src="${esc(logo||'miapaxerp.png')}" alt=""><div><h1>${esc(state.name)} · Sulama projesi ve fiyat teklifi</h1><div>${esc(state.address||'')}</div><div>${c?`${c.lat.toFixed(5)}, ${c.lng.toFixed(5)} · `:''}${new Date().toLocaleDateString('tr-TR')}</div></div></div>
 <h2>Proje özeti</h2><div class="olcu"><div><b>${n(s.area)} m²</b><small>${n(s.dekar)} dekar</small></div><div><b>${esc(state.crop||'—')}</b><small>ürün</small></div><div><b>${state.method==='drip'?'Damla':state.method==='sprinkler'?'Yağmurlama':'Mini yağmurlama'}</b><small>sulama</small></div>
 <div><b>${n(s.pipe)} m</b><small>toplam boru</small></div><div><b>${n(h.totalFlow)} m³/sa</b><small>${h.sections} bölüm · ${n(h.flow)} m³/sa/bölüm</small></div><div><b>${h.head} m · ${h.kw} kW</b><small>pompa basma / güç ≈</small></div></div>
 ${ust||aci?`<h2>Uydu görünümleri</h2><div class="gorsel">${ust?`<figure><img src="${ust}" alt=""><figcaption>Yukarıdan uydu görünümü</figcaption></figure>`:''}${aci?`<figure><img src="${aci}" alt=""><figcaption>3D uydu görünümü (arazi yüksekliği ×${String(abarti).replace('.',',')})</figcaption></figure>`:''}</div>`:''}
 <h2>Malzeme listesi ve teklif</h2><table><thead><tr><th>Malzeme</th><th>Ölçü</th><th class="s">Miktar</th><th class="s">Birim fiyat</th><th class="s">KDV</th><th class="s">Tutar</th></tr></thead><tbody>${rows}</tbody></table>
 ${fiyatli?`<div class="toplam"><span>Toplam (KDV hariç)</span><span>${para(top)}</span></div><div class="toplam"><span>Toplam (KDV dahil)</span><span>${para(kdv)}</span></div>`:'<p class="kucuk">Fiyatlar stoktan getirilmedi; yalnız metraj listesidir.</p>'}
 ${state.ai?`<h2>Yapay zekâ değerlendirmesi</h2><p style="white-space:pre-wrap">${esc(state.ai)}</p>`:''}
 ${state.analysis?`<div class="sayfa"></div><h2>Toprak, meteoroloji ve arazi analizi</h2>${analizHtml(state.analysis,true)}<p class="kucuk">Kaynaklar: ${esc(state.analysis.soil?.source||'')} · ${esc(state.analysis.weather?.source||'')} · ${esc(state.analysis.terrain?.source||'')}. Tahmine dayalı ön değerlendirmedir; laboratuvar toprak analizi ve saha ölçümüyle doğrulayın.</p>`:''}
 <p class="kucuk">${esc(imageryCredit)} · ${esc(terrainCredit)} · Harita verisi © OpenStreetMap katkıcıları. Bu teklif ön projedir; basınç, debi ve pompa seçimi saha keşfiyle kesinleşir.</p>`;
 state.pdfAt=new Date().toISOString();kaydet();adimlar();
 document.body.classList.add('fp-printing');
 await new Promise(r=>setTimeout(r,400));
 if(web)post({action:'pdf',file:((state.name||'Arazi')+' - Sulama Teklifi.pdf').replace(/[\\/:*?"<>|]/g,'').slice(0,80)});
 else{window.print();document.body.classList.remove('fp-printing');}
 durum('PDF kaydetme penceresi açıldı.');}
$('btnPdf').onclick=pdf;

// ---------- Program mesajları ----------
web?.addEventListener('message',e=>{const m=e.data;if(!m||typeof m!=='object')return;
 if(m.action==='stockResult'&&stokBekleyen){const b=stokBekleyen;stokBekleyen=null;m.error?b.rej(Error(m.error)):b.res(m.rows||[]);}
 else if((m.action==='studioResult'||m.action==='designResult')&&aiBekleyen.has(m.id)){const b=aiBekleyen.get(m.id);aiBekleyen.delete(m.id);m.error?b.rej(Error(m.error)):b.res(m);}
 else if(m.action==='logo'&&typeof m.url==='string'&&m.url.startsWith('data:image/')){logo=m.url;$('logo').src=m.url;}
});
window.addEventListener('afterprint',()=>document.body.classList.remove('fp-printing'));

// ---------- Başlat ----------
aracSec('sec');panel();adimlar();ciz();
if(state.boundary.length>2&&state.geo)map.fitBounds(L.latLngBounds(state.boundary.map(ll)).pad(.25));
if(!state.geo)durum('Başlamak için üstteki kutuya adres (ör. "Develi, Kayseri") veya koordinat yazın.');
post({action:'ready'});
