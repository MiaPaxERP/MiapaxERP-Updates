// MiapaxERP Kroki · AI proje sihirbazı hesap motoru.
// Tarla ölçüsü, sulama türü, boru, aksesuar ve su kaynağından sulama yerleşimi, hidrolik özet ve malzeme listesi üretir.
// Bağlantısız çalışır; yapay zekâ yalnız serbest anlatımı parametreye çevirir, hesap her zaman burada yapılır.

export const METHODS={
 drip:{label:'Damla sulama',rowGap:1,emitterGap:0.33,emitterFlow:2,pressure:10,lateral:16,maxLateral:120,flowUnit:'l/sa'},
 sprinkler:{label:'Yağmurlama',rowGap:12,emitterGap:12,emitterFlow:1.2,pressure:30,lateral:50,maxLateral:150,flowUnit:'m³/sa'},
 minisprinkler:{label:'Mini yağmurlama',rowGap:6,emitterGap:6,emitterFlow:0.15,pressure:20,lateral:25,maxLateral:90,flowUnit:'m³/sa'}
};
export const MATERIALS={PE100:{label:'PE100 boru',C:150,coil:100,sdr:11},PVC:{label:'PVC boru',C:150,coil:6,sdr:21},LDPE:{label:'LDPE (alçak yoğunluk) boru',C:140,coil:100,sdr:9}};
export const SOURCES={well:'Kuyu',tank:'Depo / havuz',canal:'Kanal / gölet',network:'Şebeke'};
export const ACCESSORIES={filter:'Filtre (disk / kum)',fertilizer:'Gübre tankı',airValve:'Hava tahliye vanası',pressureRegulator:'Basınç düzenleyici',flushValve:'Hat sonu yıkama vanası',manometer:'Manometre',pump:'Pompa',waterMeter:'Su sayacı',timer:'Sulama kontrol cihazı'};
export const PIPE_OD=[16,20,25,32,40,50,63,75,90,110,125,140,160,180,200,225,250,280,315];
const SIDES=['north','south','east','west'];

export function defaults(){return {project:'',width:100,length:200,method:'drip',crop:'',rowGap:1,emitterGap:0.33,emitterFlow:2,material:'PE100',mainDiameter:0,lateralDiameter:16,pieceLength:0,
 sourceType:'well',sourceSide:'south',sourceDistance:50,sourceOffset:0.5,wellDepth:40,elevation:0,hoursPerDay:10,accessories:['filter','manometer','airValve','flushValve','pump']};}

const num=(v,min,max,def)=>{const n=typeof v==='string'?Number(v.replace(',','.')):Number(v);return Number.isFinite(n)?Math.min(max,Math.max(min,n)):def;};
/** Dışarıdan gelen (form, yapay zekâ, kayıt) her değeri sınırlar ve tutarlı hale getirir. */
export function normalize(input={}){
 const d=defaults(),src=input&&typeof input==='object'?input:{},i={...d,...src};
 const method=METHODS[i.method]?i.method:d.method,m=METHODS[method];
 // Yönteme bağlı değerler (sıra arası, damlatıcı/başlık arası, debi) verilmemişse seçilen yöntemin varsayılanı kullanılır.
 const pick=(k,min,max)=>num(src[k]??m[k],min,max,m[k]);
 const out={
  project:String(i.project??'').replace(/[\u0000-\u001f<>]/g,'').slice(0,80),
  width:num(i.width,2,5000,d.width),length:num(i.length,2,5000,d.length),method,
  crop:String(i.crop??'').replace(/[\u0000-\u001f<>]/g,'').slice(0,60),
  rowGap:pick('rowGap',0.2,60),emitterGap:pick('emitterGap',0.1,60),emitterFlow:pick('emitterFlow',0.05,50),
  material:MATERIALS[i.material]?i.material:d.material,
  mainDiameter:PIPE_OD.includes(Number(i.mainDiameter))?Number(i.mainDiameter):0,
  lateralDiameter:PIPE_OD.includes(Number(src.lateralDiameter))?Number(src.lateralDiameter):m.lateral,
  pieceLength:num(i.pieceLength,0,1000,0),
  sourceType:SOURCES[i.sourceType]?i.sourceType:d.sourceType,sourceSide:SIDES.includes(i.sourceSide)?i.sourceSide:d.sourceSide,
  sourceDistance:num(i.sourceDistance,0,20000,d.sourceDistance),sourceOffset:num(i.sourceOffset,0,1,0.5),
  wellDepth:num(i.wellDepth,0,500,d.wellDepth),elevation:num(i.elevation,-200,500,0),hoursPerDay:num(i.hoursPerDay,1,24,d.hoursPerDay),
  accessories:Array.isArray(i.accessories)?[...new Set(i.accessories.filter(a=>ACCESSORIES[a]))]:d.accessories
 };
 if(out.sourceType!=='well')out.wellDepth=0;
 if(out.emitterGap>out.length)out.emitterGap=out.length;if(out.rowGap>out.width)out.rowGap=out.width;
 return out;
}

/** Türkçe serbest anlatımdan (yapay zekâ bağlı değilken) değer çıkarır: "100x200 metre damla, kuyu 300 m güneyde, 90'lık PE ana hat". */
export function parseText(text,base=defaults()){
 const t=' '+String(text||'').toLocaleLowerCase('tr-TR').replace(/,/g,'.')+' ',o={};const n=s=>Number(s);
 let m=t.match(/(\d+(?:\.\d+)?)\s*(?:m|metre)?\s*[x×*]\s*(\d+(?:\.\d+)?)/);if(m){o.width=n(m[1]);o.length=n(m[2]);}
 else{const e=t.match(/en[iı]?\s*(\d+(?:\.\d+)?)/),b=t.match(/boy[uü]?\s*(\d+(?:\.\d+)?)/);if(e)o.width=n(e[1]);if(b)o.length=n(b[1]);
  const dk=t.match(/(\d+(?:\.\d+)?)\s*(dekar|dönüm|donum|da\b)/),ha=t.match(/(\d+(?:\.\d+)?)\s*(hektar|ha\b)/);const area=dk?n(dk[1])*1000:ha?n(ha[1])*10000:0;
  if(area&&!e&&!b){o.width=Math.round(Math.sqrt(area/2));o.length=Math.round(area/o.width);}}
 if(/mini\s*yağmur|mini\s*sprink/.test(t))o.method='minisprinkler';else if(/damla|damlama/.test(t))o.method='drip';else if(/yağmur|sprink|tabanc/.test(t))o.method='sprinkler';
 if(/pvc/.test(t))o.material='PVC';else if(/ldpe|alçak yoğunluk/.test(t))o.material='LDPE';else if(/pe\s*100|polietilen|\bpe\b/.test(t))o.material='PE100';
 if(/kuyu|sondaj/.test(t))o.sourceType='well';else if(/depo|havuz/.test(t))o.sourceType='tank';else if(/kanal|gölet|dere|baraj/.test(t))o.sourceType='canal';else if(/şebeke|belediye/.test(t))o.sourceType='network';
 const yon=t.match(/(kuzey|güney|doğu|batı)/);if(yon)o.sourceSide={kuzey:'north',güney:'south',doğu:'east',batı:'west'}[yon[1]];
 m=t.match(/(?:kuyu|depo|kaynak|kanal|gölet|havuz|şebeke|dere|su)[^.]{0,30}?(\d+(?:\.\d+)?)\s*(m\b|metre|km)/)||t.match(/(\d+(?:\.\d+)?)\s*(m\b|metre|km)\s*(?:uzak|mesafe|ötede|ileride)/);
 if(m)o.sourceDistance=n(m[1])*(m[2]==='km'?1000:1);
 m=t.match(/(\d+)\s*(?:metre|m)?\s*derin/)||t.match(/derinli[ğk][iı]?\s*(\d+)/);if(m)o.wellDepth=n(m[1]);
 m=t.match(/(\d+)\s*(?:mm|'?l[iıuü]k)\s*(?:pe\s*100\s*|pvc\s*|pe\s*)?ana/)||t.match(/ana\s*(?:hat|boru)[^.]{0,15}?(\d+)\s*(?:mm|'?l[iıuü]k)/);if(m&&PIPE_OD.includes(n(m[1])))o.mainDiameter=n(m[1]);
 m=t.match(/sıra\s*arası\s*(\d+(?:\.\d+)?)/)||t.match(/hat\s*arası\s*(\d+(?:\.\d+)?)/);if(m)o.rowGap=n(m[1]);
 m=t.match(/(?:damlatıcı|başlık|tabanca)\s*arası\s*(\d+(?:\.\d+)?)\s*(cm|m)?/);if(m)o.emitterGap=n(m[1])/(m[2]==='cm'?100:1);
 m=t.match(/(\d+(?:\.\d+)?)\s*(?:metre|m)\s*(?:boy|uzunlu)[^.]{0,8}boru/)||t.match(/boru\s*boyu\s*(\d+(?:\.\d+)?)/);if(m)o.pieceLength=n(m[1]);
 m=t.match(/günde\s*(\d+)\s*saat/);if(m)o.hoursPerDay=n(m[1]);
 m=t.match(/(\d+(?:\.\d+)?)\s*(?:m|metre)\s*(?:yüksek|eğim|kot)/);if(m)o.elevation=n(m[1]);
 const crop=t.match(/(mısır|domates|biber|pamuk|buğday|ceviz|elma|kiraz|zeytin|üzüm|bağ|çilek|patates|şeker pancarı|ayçiçeği|karpuz|kavun|fındık|fıstık|yonca)/);if(crop)o.crop=crop[1];
 const acc=new Set(base.accessories||[]);
 const toggles={filter:/filtre/,fertilizer:/gübre/,airValve:/hava\s*(tahliye|vana)/,pressureRegulator:/basınç\s*(düzenle|regül)/,flushValve:/yıkama|flush/,manometer:/manometre/,pump:/pompa|dalgıç|hidrofor/,waterMeter:/sayaç/,timer:/zaman|otomasyon|kontrol cihaz|timer/};
 for(const [k,re] of Object.entries(toggles)){if(re.test(t)){const neg=new RegExp('(istemiyorum|yok|olmasın|hariç)').test(t.slice(t.search(re),t.search(re)+30));if(neg)acc.delete(k);else acc.add(k);}}
 if(/şebeke|depo/.test(t)&&!/pompa/.test(t))acc.delete('pump');
 o.accessories=[...acc];
 return o;
}

/** Yapay zekâ yanıtındaki JSON'dan yalnız izinli alanları alır. */
export function fromAi(text){
 if(typeof text!=='string')return null;const a=text.indexOf('{'),b=text.lastIndexOf('}');if(a<0||b<=a)return null;
 let j;try{j=JSON.parse(text.slice(a,b+1));}catch{return null;}
 const allowed=['width','length','method','crop','rowGap','emitterGap','emitterFlow','material','mainDiameter','lateralDiameter','pieceLength','sourceType','sourceSide','sourceDistance','sourceOffset','wellDepth','elevation','hoursPerDay','accessories'];
 const o={};for(const k of allowed)if(j[k]!==undefined&&j[k]!==null)o[k]=j[k];return o;
}

const r1=x=>Math.round(x*10)/10,r2=x=>Math.round(x*100)/100;
/** İç çap (mm): SDR'ye göre dış çaptan. */
export const innerDiameter=(od,sdr)=>od-2*od/sdr;
/** Hazen–Williams sürtünme kaybı (m). q: m³/sa, L: m, d: iç çap mm. */
export function headLoss(q,L,d,C=150){if(q<=0||L<=0)return 0;const Q=q/3600,D=d/1000;return 10.67*L*Math.pow(Q,1.852)/(Math.pow(C,1.852)*Math.pow(D,4.87));}
export const velocity=(q,d)=>q<=0?0:(q/3600)/(Math.PI*Math.pow(d/2000,2));
/** Hıza (≤1,5 m/s) ve kayba (≤%2·L) göre en küçük uygun dış çap. */
export function chooseDiameter(q,L,mat,minOd=32){for(const od of PIPE_OD){if(od<minOd)continue;const id=innerDiameter(od,mat.sdr);if(velocity(q,id)<=1.5&&headLoss(q,L,id,mat.C)<=Math.max(1.5,0.02*L))return od;}return PIPE_OD[PIPE_OD.length-1];}

/**
 * Proje hesabı. Yerleşim: hatlar (lateral) tarla boyu yönünde, dağıtım borusu (manifold) en yönünde.
 * Hat boyu yöntemin sınırını aşarsa manifold tarlanın ortasına alınır ve hatlar iki yana açılır.
 * Kaynak debisi sınırlıysa tarla eşit vanalı bölümlere ayrılır (sırayla sulanır).
 */
export function calculate(raw){
 const p=normalize(raw),m=METHODS[p.method],mat=MATERIALS[p.material],notes=[],warn=[];
 const W=p.width,L=p.length,area=W*L;
 const split=L>m.maxLateral;const lateralRun=split?L/2:L;const lateralCount=Math.max(1,Math.floor(W/p.rowGap));
 const rows=Array.from({length:lateralCount},(_,i)=>r2(p.rowGap/2+i*p.rowGap+(W-lateralCount*p.rowGap)/2));
 const sides=split?2:1,lateralLen=Math.max(0,lateralRun-(p.method==='drip'?0.5:p.emitterGap/2));
 const emittersPerLateral=Math.max(1,Math.floor(lateralLen/p.emitterGap)+(p.method==='drip'?0:1));
 const lateralTotal=r1(lateralCount*sides*lateralLen),emitters=lateralCount*sides*emittersPerLateral;
 // Debi (m³/sa)
 const emitterM3=p.method==='drip'?p.emitterFlow/1000:p.emitterFlow;const lateralFlow=emittersPerLateral*emitterM3;
 const totalFlow=emitters*emitterM3;
 const sourceLimit={well:40,tank:60,canal:120,network:15}[p.sourceType];
 const sections=Math.max(1,Math.min(lateralCount,Math.ceil(totalFlow/sourceLimit)));
 const sectionFlow=totalFlow/sections;
 // Ana hat güzergâhı: kaynak → tarla kenarı → manifold başlangıcı
 const manifoldY=split?L/2:(p.sourceSide==='north'||((p.sourceSide==='east'||p.sourceSide==='west')&&p.sourceOffset>=0.5))?L:0;
 const src=sourcePoint(p);const entry=entryPoint(p,manifoldY);
 const route=[{x:src.x,y:src.y},{x:src.edgeX,y:src.edgeY},{x:entry.x,y:entry.y}].filter((q,i,a)=>i===0||Math.hypot(q.x-a[i-1].x,q.y-a[i-1].y)>0.01);
 const mainLen=r1(route.reduce((s,q,i)=>i?s+Math.hypot(q.x-route[i-1].x,q.y-route[i-1].y):0,0));
 let corners=0;for(let i=2;i<route.length;i++){const a=route[i-1],b=route[i],z=route[i-2];if(Math.abs((a.x-z.x)*(b.y-a.y)-(a.y-z.y)*(b.x-a.x))>0.01)corners++;}
 const mainOd=p.mainDiameter||chooseDiameter(sectionFlow,Math.max(mainLen,1),mat,40);
 const manifoldLen=r1(Math.min(W,lateralCount*p.rowGap));
 const manifoldOd=chooseDiameter(sectionFlow,Math.max(1,manifoldLen/2),mat,32);
 const latId=p.method==='drip'?p.lateralDiameter*0.88:innerDiameter(p.lateralDiameter,mat.sdr);
 // Kayıplar (m)
 const hMain=headLoss(sectionFlow,mainLen,innerDiameter(mainOd,mat.sdr),mat.C);
 const hManifold=headLoss(sectionFlow,manifoldLen,innerDiameter(manifoldOd,mat.sdr),mat.C)*0.38;
 const hLateral=headLoss(lateralFlow,lateralLen,latId,140)*0.36;
 const hFilter=p.accessories.includes('filter')?5:0,hFittings=0.1*(hMain+hManifold);
 const lift=p.sourceType==='well'?p.wellDepth:0;
 const head=r1(m.pressure+hMain+hManifold+hLateral+hFilter+hFittings+p.elevation+lift);
 const pumpKw=r2(9.81*(sectionFlow/3600)*head/0.62);
 const irrigationHours=r1(sections*({drip:2.5,sprinkler:3,minisprinkler:2}[p.method]));
 const precip=p.method==='drip'?r2(p.emitterFlow/(p.rowGap*p.emitterGap)):r2(p.emitterFlow*1000/(p.rowGap*p.emitterGap));
 const sectionWidth=r1(W/sections);
 const latVar=m.pressure>0?hLateral/m.pressure:0;
 // Uyarılar ve öneriler
 if(split)notes.push(`Hat boyu ${r1(L)} m, ${m.label.toLowerCase()} için önerilen ${m.maxLateral} m sınırını aşıyor; dağıtım borusu tarlanın ortasına alındı, hatlar iki yana ${r1(lateralRun)} m açıldı.`);
 if(sections>1)notes.push(`${SOURCES[p.sourceType]} için ${sourceLimit} m³/sa varsayımıyla tarla ${sections} vanalı bölüme ayrıldı (her biri ≈${sectionWidth} m genişlik, ${r1(sectionFlow)} m³/sa). Kaynağın gerçek debisini girerseniz bölüm sayısı netleşir.`);
 if(latVar>0.2)warn.push(`Hat içi basınç farkı ≈%${Math.round(latVar*100)}; %20'yi aşıyor. ${p.lateralDiameter} mm yerine ${PIPE_OD.find(x=>x>p.lateralDiameter)} mm hat borusu veya basınç ayarlı (PC) damlatıcı önerilir.`);
 if(p.mainDiameter&&velocity(sectionFlow,innerDiameter(p.mainDiameter,mat.sdr))>1.5)warn.push(`Seçilen ${p.mainDiameter} mm ana hatta su hızı ${r2(velocity(sectionFlow,innerDiameter(p.mainDiameter,mat.sdr)))} m/s; 1,5 m/s üstü koç darbesi ve kayıp riski taşır. Önerilen: ${chooseDiameter(sectionFlow,mainLen,mat,40)} mm.`);
 if(!p.mainDiameter)notes.push(`Ana hat çapı debi ve ${r1(mainLen)} m mesafeye göre ${mainOd} mm seçildi (hız ${r2(velocity(sectionFlow,innerDiameter(mainOd,mat.sdr)))} m/s).`);
 if(p.method==='drip'&&!p.accessories.includes('filter'))warn.push('Damla sulamada filtre olmadan damlatıcılar kısa sürede tıkanır; disk veya kum filtre eklenmesi önerilir.');
 if(p.method==='drip'&&!p.accessories.includes('pressureRegulator')&&head>35)notes.push('Pompa basıncı yüksek; bölüm vanalarından sonra basınç düzenleyici eklemek damla borusunu korur.');
 if(p.sourceType==='well'&&!p.accessories.includes('pump'))warn.push('Kuyudan su alınacak ama pompa seçilmedi; listeye dalgıç pompa eklenmesi gerekir.');
 if(mainLen>300&&!p.accessories.includes('airValve'))notes.push('Ana hat 300 metreden uzun; yüksek noktalara hava tahliye vanası konmalı.');
 if(p.sourceType==='network'&&totalFlow>sourceLimit)notes.push('Şebeke suyu debisi sınırlıdır; bölümleri sırayla sulayın veya depo + hidrofor düşünün.');
 if(area>500000)warn.push(`Tarla ${r1(area/10000)} hektar; bu büyüklükte proje birden fazla bağımsız bloğa (ayrı ana hat ve vana grubu) bölünmeli. Buradaki hesap ön tasarımdır.`);
 if(head>70)warn.push(`Toplam basma yüksekliği ${head} m; tek kademeli pompa yetmeyebilir, kaynak yeri ve çaplar gözden geçirilmeli.`);
 if(irrigationHours>p.hoursPerDay)warn.push(`Bütün bölümler günde ≈${irrigationHours} saatte sulanır; ${p.hoursPerDay} saatlik çalışma için bölümler iki güne bölünmeli veya kaynak debisi artırılmalı.`);
 const bom=billOfMaterials(p,{mat,mainOd,manifoldOd,mainLen,manifoldLen,lateralTotal,lateralCount:lateralCount*sides,outlets:lateralCount,emitters,sections,split,head,pumpKw,sectionFlow,totalFlow,src,entry,corners});
 return {input:p,method:m,material:mat,area,dekar:r2(area/1000),split,lateralCount:lateralCount*sides,lateralRows:rows,lateralRun:r1(lateralRun),lateralLen:r1(lateralLen),emittersPerLateral,emitters,
  lateralTotal,mainLen,mainOd,manifoldLen,manifoldOd,manifoldY,sections,sectionWidth,totalFlow:r2(totalFlow),sectionFlow:r2(sectionFlow),
  losses:{main:r2(hMain),manifold:r2(hManifold),lateral:r2(hLateral),filter:hFilter,fittings:r2(hFittings),elevation:p.elevation,lift},head,pumpKw,precip,irrigationHours,
  source:src,entry,route,corners,notes,warnings:warn,bom};
}

/** Kaynağın tarla koordinatındaki yeri (x: en, y: boy; tarla 0..W × 0..L) ve kenardaki giriş noktası. */
export function sourcePoint(p){
 const W=p.width,L=p.length,o=p.sourceOffset,d=p.sourceDistance;
 switch(p.sourceSide){
  case 'north':return {x:W*o,y:L+d,edgeX:W*o,edgeY:L};
  case 'east':return {x:W+d,y:L*o,edgeX:W,edgeY:L*o};
  case 'west':return {x:-d,y:L*o,edgeX:0,edgeY:L*o};
  default:return {x:W*o,y:-d,edgeX:W*o,edgeY:0};
 }
}
function entryPoint(p,manifoldY){return {x:Math.min(p.width,Math.max(0,p.sourceSide==='east'?p.width:p.sourceSide==='west'?0:p.width*p.sourceOffset)),y:manifoldY};}

const piece=(len,unit)=>Math.max(1,Math.ceil(len/unit));
/** Ürün bazında malzeme listesi. key alanı stok eşleştirmesi için arama anahtarıdır. */
export function billOfMaterials(p,c){
 const rows=[],add=(group,name,size,qty,unit,key,note='')=>{if(qty>0)rows.push({group,name,size,qty:unit==='m'?r1(qty):Math.ceil(qty),unit,key,note});};
 const mat=c.mat,pipeUnit=p.pieceLength||mat.coil;
 const mainPieces=piece(c.mainLen,pipeUnit),manPieces=piece(c.manifoldLen,pipeUnit);
 add('Ana hat',`${mat.label} ana hat`,`Ø${c.mainOd} mm`,c.mainLen*1.03,'m',`${c.mainOd}`,`%3 fire dahil · ${mainPieces} ${pipeUnit>=50?'kangal':'boy'} (${pipeUnit} m)`);
 add('Ana hat','Ana hat ek parçası (manşon)',`Ø${c.mainOd} mm`,mainPieces-1,'adet',`manşon ${c.mainOd}`);
 add('Ana hat','Dirsek 90°',`Ø${c.mainOd} mm`,c.corners,'adet',`dirsek ${c.mainOd}`);
 add('Dağıtım','Dağıtım borusu (manifold)',`Ø${c.manifoldOd} mm`,c.manifoldLen*1.03,'m',`${c.manifoldOd}`,`${manPieces} ${pipeUnit>=50?'kangal':'boy'}`);
 add('Dağıtım','Te (ana hat → dağıtım)',`Ø${c.mainOd}×${c.manifoldOd} mm`,1,'adet',`te ${c.mainOd}`);
 if(c.mainOd!==c.manifoldOd)add('Dağıtım','İndirgeme (redüksiyon)',`Ø${c.mainOd}/${c.manifoldOd} mm`,c.sections,'adet',`redüksiyon ${c.mainOd}`);
 add('Dağıtım','Kör tapa (dağıtım sonu)',`Ø${c.manifoldOd} mm`,2,'adet',`tapa ${c.manifoldOd}`);
 add('Dağıtım','Bölüm vanası',`Ø${c.manifoldOd} mm`,c.sections,'adet',`vana ${c.manifoldOd}`,c.sections>1?'Bölümler sırayla açılır':'');
 const latName=p.method==='drip'?'Damla borusu (lateral)':'Lateral boru';
 const latCoil=p.method==='drip'?400:(p.pieceLength||100);
 add('Hatlar',latName,`Ø${p.lateralDiameter} mm`,c.lateralTotal*1.02,'m',`${p.lateralDiameter}`,`${piece(c.lateralTotal*1.02,latCoil)} rulo (${latCoil} m)`);
 add('Hatlar',p.method==='drip'?'Başlangıç bağlantısı (mini vana + conta)':'Lateral çıkış (priz kolye)',`${c.manifoldOd}×${p.lateralDiameter} mm`,p.method==='drip'?c.lateralCount:c.outlets,'adet',`priz ${c.manifoldOd}`);
 if(c.split&&p.method!=='drip')add('Hatlar','Te (iki yana lateral)',`Ø${p.lateralDiameter} mm`,c.outlets,'adet',`te ${p.lateralDiameter}`);
 add('Hatlar','Hat sonu tapası',`Ø${p.lateralDiameter} mm`,c.lateralCount,'adet',`tapa ${p.lateralDiameter}`);
 add('Hatlar','Hat eki (manşon, rulo birleşimi)',`Ø${p.lateralDiameter} mm`,Math.max(0,piece(c.lateralTotal,latCoil)-1),'adet',`manşon ${p.lateralDiameter}`);
 if(p.method==='drip')add('Sulama elemanı',`Damlatıcı (${p.emitterFlow} l/sa, ${Math.round(p.emitterGap*100)} cm ara)`,'',c.emitters,'adet','damlatıcı','Damla borusu tümleşik ise ayrıca alınmaz');
 else{
  add('Sulama elemanı',p.method==='sprinkler'?`Yağmurlama başlığı (${p.emitterFlow} m³/sa)`:`Mini yağmurlama başlığı (${Math.round(p.emitterFlow*1000)} l/sa)`,'',c.emitters,'adet',p.method==='sprinkler'?'yağmurlama':'mini');
  add('Sulama elemanı','Yükseltme borusu + adaptör','',c.emitters,'adet','yükseltme');
  add('Sulama elemanı','Te / priz (başlık bağlantısı)',`Ø${p.lateralDiameter} mm`,c.emitters,'adet',`te ${p.lateralDiameter}`);
 }
 const A=p.accessories,flowLabel=`${Math.ceil(c.sectionFlow)} m³/sa`;
 if(A.includes('pump'))add('Kaynak',p.sourceType==='well'?'Dalgıç pompa':'Santrifüj pompa',`${flowLabel} · ${c.head} m · ≈${Math.max(0.37,Math.ceil(c.pumpKw*1.15*10)/10)} kW`,1,'adet','pompa','Pompa seçimini üreticinin eğrisiyle doğrulayın');
 if(A.includes('pump')&&p.sourceType==='well')add('Kaynak','Pompa çıkış borusu (kuyu içi)',`Ø${c.mainOd} mm`,p.wellDepth+5,'m',`${c.mainOd}`);
 if(A.includes('pump'))add('Kaynak','Çek valf',`Ø${c.mainOd} mm`,1,'adet',`çek valf ${c.mainOd}`);
 if(A.includes('filter'))add('Kaynak',p.sourceType==='canal'?'Kum + disk filtre grubu':'Disk filtre',flowLabel,1,'adet','filtre');
 if(A.includes('fertilizer'))add('Kaynak','Gübre tankı + enjektör','100 l',1,'adet','gübre');
 if(A.includes('waterMeter'))add('Kaynak','Su sayacı',`Ø${c.mainOd} mm`,1,'adet','sayaç');
 if(A.includes('manometer'))add('Kontrol','Manometre (0–10 bar)','',1+c.sections,'adet','manometre');
 if(A.includes('airValve'))add('Kontrol','Hava tahliye vanası','',Math.max(1,Math.ceil(c.mainLen/300))+c.sections,'adet','hava');
 if(A.includes('pressureRegulator'))add('Kontrol','Basınç düzenleyici',`Ø${c.manifoldOd} mm`,c.sections,'adet','regülatör');
 if(A.includes('flushValve'))add('Kontrol','Hat sonu yıkama vanası',`Ø${c.manifoldOd} mm`,c.sections,'adet','yıkama');
 if(A.includes('timer'))add('Kontrol',`Sulama kontrol cihazı (${c.sections} istasyon)`,'',1,'adet','kontrol');
 if(A.includes('timer'))add('Kontrol','Selenoid vana',`Ø${c.manifoldOd} mm`,c.sections,'adet','selenoid');
 add('Montaj','Kelepçe / boru askısı','',Math.ceil(c.mainLen/6),'adet','kelepçe');
 add('Montaj','Teflon bant','',Math.max(2,Math.ceil(c.sections*1.5)),'adet','teflon');
 return rows;
}

/** Stoktan gelen fiyatları ürün satırlarıyla eşler: önce çap + anahtar sözcük, sonra yalnız anahtar sözcük. */
export function matchPrices(bom,stock){
 const norm=s=>String(s||'').toLocaleLowerCase('tr-TR');
 return bom.map(row=>{
  const key=norm(row.key).split(' ');const dia=Number(key.find(k=>/^\d+$/.test(k)));const words=key.filter(k=>!/^\d+$/.test(k));
  const cand=stock.filter(s=>{const n=norm(s.name)+' '+norm(s.code);const sizeOk=!dia||Number(s.diameter)===dia||new RegExp('(^|[^0-9])'+dia+'([^0-9]|$)').test(n);
   const wordOk=words.length?words.every(w=>n.includes(w)):/(boru|pipe|hortum)/.test(n);return sizeOk&&wordOk&&(s.retail!=null||s.dealer!=null);});
  const hit=cand[0];if(!hit)return {...row,price:null,vat:null,stock:null};
  const vat=hit.vat??20,price=hit.retail??hit.dealer,priceIncl=hit.retailVatIncluded!==false;
  const net=priceIncl?price/(1+vat/100):price;
  return {...row,stock:`${hit.code} · ${hit.name}`,currency:hit.currency||'TRY',vat,price:r2(net),total:r2(net*row.qty),totalVat:r2(net*row.qty*(1+vat/100))};
 });
}
