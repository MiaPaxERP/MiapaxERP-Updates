﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName PresentationFramework
$panelRoot=Split-Path $PSScriptRoot -Parent
$privateFolder=Join-Path $env:USERPROFILE 'BoruERP_GizliAnahtarlar\BayiPaneli30'
$dbPath=Join-Path $privateFolder 'portal.sqlite'
$title='MiaPax Yönetim Paneli - Parola sıfırlama'
try {
    if(-not (Test-Path -LiteralPath $dbPath)) { throw "Panel veritabanı bulunamadı: $dbPath" }
    $answer=[Windows.MessageBox]::Show("Yönetici hesabına yeni bir geçici parola verilecek.`n`nÖnce veritabanı yedeklenir. Müşteri, lisans ve cihaz kayıtları değişmez. Açık panel oturumları kapanır ve ilk girişte yeni parolanızı belirlemeniz istenir.`n`nDevam edilsin mi?",$title,'YesNo','Warning')
    if($answer -ne 'Yes') { return }
    $nodeCommand=Get-Command node -ErrorAction SilentlyContinue
    $nodePath=if($nodeCommand) {$nodeCommand.Source} else {Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'}
    if(-not (Test-Path -LiteralPath $nodePath)) { throw 'Node.js 24 bulunamadı. https://nodejs.org/en/download adresinden kurulmalıdır.' }
    $env:DB_PATH=$dbPath
    Push-Location $panelRoot
    try { $raw=& $nodePath (Join-Path $panelRoot 'src\reset-owner.js') 2>$null } finally { Pop-Location }
    $result=$raw | ConvertFrom-Json
    if(-not $result.ok) { throw $result.error }
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
    $file=Join-Path $privateFolder ("yeni-giris-$stamp.txt")
    "MiaPax Yönetim Paneli - yalnız size özel`r`nAdres: http://127.0.0.1:5290`r`nKullanıcı: $($result.username)`r`nGeçici parola: $($result.password)`r`nİlk girişte yeni parola belirlemeniz istenir (en az 14 karakter).`r`nParolayı değiştirdikten sonra bu dosyayı silin.`r`nSıfırlama öncesi yedek: $($result.backup)`r`n" | Set-Content -LiteralPath $file -Encoding UTF8
    Set-Clipboard -Value $result.password
    [Windows.MessageBox]::Show("Kullanıcı: $($result.username)`nGeçici parola: $($result.password)`n`nParola panoya kopyalandı ve şu dosyaya da yazıldı:`n$file`n`nGirişten sonra yeni parolanızı belirleyin.",$title,'OK','Information') | Out-Null
    $opener=Join-Path $PSScriptRoot 'Masaustu-Ac.ps1'
    if(Test-Path -LiteralPath $opener) { & $opener } else { Start-Process 'http://127.0.0.1:5290' }
} catch {
    [Windows.MessageBox]::Show($_.Exception.Message,$title,'OK','Error') | Out-Null
    exit 1
}
