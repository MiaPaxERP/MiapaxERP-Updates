using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>Hazır roller: yoksa bir kez oluşturulur ve önerilen yetkilerle doldurulur; sonradan yapılan yetki değişikliklerine dokunulmaz.</summary>
public static class RolSemasi
{
 public static readonly (string Ad,string Aciklama,string[] Yetkiler)[] Varsayilanlar=[
  ("Muhasebe","Muhasebe, finans, cari ve raporlar",["ACCOUNTING.%","FINANCE.%","CUSTOMER.%","REPORT.VIEW","SALES.VIEW","SALES.PAYMENT","PURCHASE.VIEW","PURCHASE.PAYMENT","PURCHASE.MATCH","STOCK.VIEW","STOCK.PRICE","CHECKNOTE.%","HR.VIEW","DASHBOARD.VIEW","CALENDAR.VIEW","CALENDAR.CREATE","CALENDAR.COMPLETE","CHAT.%","MOBILE.ACCESS","MOBILE.FINANCE","MOBILE.CHAT"]),
  ("Saha Pazarlama","Saha ziyaretleri, müşteriler ve mobil saha",["FIELD.%","CRM.%","CUSTOMER.VIEW","CUSTOMER.EDIT","SALES.VIEW","STOCK.VIEW","DASHBOARD.VIEW","CALENDAR.VIEW","CALENDAR.CREATE","CALENDAR.COMPLETE","CHAT.%","MOBILE.ACCESS","MOBILE.FIELD","MOBILE.SALES","MOBILE.CHAT"]),
  ("Depo Sorumlusu","Stok, depo, sevkiyat (fiyat görmez)",["STOCK.VIEW","STOCK.CREATE","STOCK.EDIT","STOCK.HISTORY","STOCK.ISSUE","STOCK.RECEIVE","STOCK.MINIMUM","STOCK.OPENING","STOCK.STATUS","WAREHOUSE.%","SHIPMENT.%","DASHBOARD.VIEW","CALENDAR.VIEW","CALENDAR.COMPLETE","CHAT.%","MOBILE.ACCESS","MOBILE.STOCK","MOBILE.CHAT"]),
  ("Satın Alma","Satın alma, tedarikçi ve alış fiyatları",["PURCHASE.%","STOCK.VIEW","STOCK.HISTORY","STOCK.PRICE","STOCK.CREATE","CUSTOMER.VIEW","CUSTOMER.EDIT","TRADE.VIEW","REPORT.VIEW","DASHBOARD.VIEW","CALENDAR.VIEW","CALENDAR.CREATE","CALENDAR.COMPLETE","CHAT.%","MOBILE.ACCESS","MOBILE.PURCHASE","MOBILE.CHAT"]),
  ("Üretimci","Üretim emirleri, reçeteler ve basınç testleri",["PRODUCTION.VIEW","PRODUCTION.START","PRODUCTION.QUANTITY","PRODUCTION.COMPLETE","RECIPE.VIEW","PRESSURE.VIEW","PRESSURE.EDIT","STOCK.VIEW","STOCK.HISTORY","STOCK.ISSUE","DASHBOARD.VIEW","CALENDAR.VIEW","CALENDAR.COMPLETE","CHAT.%","MOBILE.ACCESS","MOBILE.PRODUCTION","MOBILE.CHAT"]),
  ("Mal Kabul","Gelen malın kabulü ve depoya girişi",["STOCK.VIEW","STOCK.RECEIVE","STOCK.HISTORY","WAREHOUSE.VIEW","WAREHOUSE.TRANSFER","PURCHASE.VIEW","SHIPMENT.VIEW","DASHBOARD.VIEW","CALENDAR.VIEW","CALENDAR.COMPLETE","CHAT.%","MOBILE.ACCESS","MOBILE.STOCK","MOBILE.CHAT"])];

 public static void Hazirla(SqlConnection c)
 {
  using var tx=c.BeginTransaction(System.Data.IsolationLevel.Serializable);
  foreach(var (ad,aciklama,yetkiler) in Varsayilanlar)
  {
   using var q=new SqlCommand("""
IF NOT EXISTS(SELECT 1 FROM dbo.KullaniciRolleri WITH(UPDLOCK,HOLDLOCK) WHERE RolAdi=@ad)
BEGIN
 INSERT dbo.KullaniciRolleri(RolAdi,Aciklama,Aktif,KayitTarihiUtc) VALUES(@ad,@aciklama,1,SYSUTCDATETIME());
 DECLARE @rol int=SCOPE_IDENTITY();
 INSERT dbo.RolYetkileri(RolId,YetkiId,AtamaTarihiUtc)
 SELECT DISTINCT @rol,y.Id,SYSUTCDATETIME() FROM dbo.Yetkiler y JOIN OPENJSON(@yetkiler) j ON y.YetkiKodu LIKE j.value WHERE y.Aktif=1;
END
""",c,tx);
   q.Parameters.AddWithValue("@ad",ad);q.Parameters.AddWithValue("@aciklama",aciklama);q.Parameters.AddWithValue("@yetkiler",System.Text.Json.JsonSerializer.Serialize(yetkiler));
   q.ExecuteNonQuery();
  }
  tx.Commit();
 }

 public static int Ekle(SqlConnection c,string ad,string aciklama)
 {
  ad=ad.Trim();if(ad.Length<2||ad.Length>60)throw new ArgumentException("Rol adı 2–60 karakter olmalı.");
  using var q=new SqlCommand("IF EXISTS(SELECT 1 FROM dbo.KullaniciRolleri WHERE RolAdi=@ad) THROW 51000,N'Bu adda bir rol zaten var.',1; INSERT dbo.KullaniciRolleri(RolAdi,Aciklama,Aktif,KayitTarihiUtc) OUTPUT INSERTED.Id VALUES(@ad,@a,1,SYSUTCDATETIME());",c);
  q.Parameters.AddWithValue("@ad",ad);q.Parameters.AddWithValue("@a",aciklama.Trim().Length==0?DBNull.Value:aciklama.Trim());
  return Convert.ToInt32(q.ExecuteScalar());
 }

 public static (int Id,string Kod,string Ad,bool Var)[] Yetkiler(SqlConnection c,int rol)
 {
  using var q=new SqlCommand("SELECT y.Id,y.YetkiKodu,COALESCE(NULLIF(y.Aciklama,N''),y.YetkiKodu),CAST(CASE WHEN r.YetkiId IS NULL THEN 0 ELSE 1 END AS bit) FROM dbo.Yetkiler y LEFT JOIN dbo.RolYetkileri r ON r.YetkiId=y.Id AND r.RolId=@r WHERE y.Aktif=1 ORDER BY y.YetkiKodu",c);
  q.Parameters.AddWithValue("@r",rol);using var rd=q.ExecuteReader();var l=new List<(int,string,string,bool)>();while(rd.Read())l.Add((rd.GetInt32(0),rd.GetString(1),rd.GetString(2),rd.GetBoolean(3)));return l.ToArray();
 }

 public static void YetkileriKaydet(SqlConnection c,int rol,IEnumerable<int> yetkiler)
 {
  using var tx=c.BeginTransaction(System.Data.IsolationLevel.Serializable);
  using(var chk=new SqlCommand("SELECT RolAdi FROM dbo.KullaniciRolleri WHERE Id=@r",c,tx)){chk.Parameters.AddWithValue("@r",rol);if(chk.ExecuteScalar() is not string ad)throw new ArgumentException("Rol bulunamadı.");if(ad=="Yönetici")throw new InvalidOperationException("Yönetici rolü tüm yetkilere sahiptir; değiştirilemez.");}
  using(var d=new SqlCommand("DELETE dbo.RolYetkileri WHERE RolId=@r",c,tx)){d.Parameters.AddWithValue("@r",rol);d.ExecuteNonQuery();}
  using(var i=new SqlCommand("INSERT dbo.RolYetkileri(RolId,YetkiId,AtamaTarihiUtc) SELECT @r,y.Id,SYSUTCDATETIME() FROM dbo.Yetkiler y JOIN OPENJSON(@ids) j ON y.Id=CAST(j.value AS int)",c,tx)){i.Parameters.AddWithValue("@r",rol);i.Parameters.AddWithValue("@ids",System.Text.Json.JsonSerializer.Serialize(yetkiler.Distinct().ToArray()));i.ExecuteNonQuery();}
  tx.Commit();
 }
}
