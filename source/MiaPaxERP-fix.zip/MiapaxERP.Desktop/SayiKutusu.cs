using DataObject = System.Windows.DataObject;
using System.Globalization;
using System.Windows;
using System.Windows.Input;
namespace MiapaxERP.Desktop;

/// <summary>
/// Türkçe sayı kutusu: yazarken yalnız rakam, virgül ve nokta kabul eder; kutudan çıkınca binlik ayırıcı ve ondalık virgülle
/// biçimlendirir (1500,5 → 1.500,5). Tam sayı alanlarında (ondalık=0) virgül hiç eklenmez.
/// </summary>
public static class SayiKutusu
{
 static readonly CultureInfo tr=CultureInfo.GetCultureInfo("tr-TR");

 /// <summary>"1.500,25", "1500,25", "1500.25", "1.500" (=1500) ve "12.5" (=12,5) biçimlerini okur.</summary>
 public static bool Oku(string? metin,out decimal deger){
  deger=0;var t=(metin??"").Trim().Replace(" ","").Replace(" ","");
  if(t.Length==0)return false;
  bool neg=t.StartsWith('-');if(neg)t=t[1..];
  if(t.Length==0||t.Any(ch=>!char.IsDigit(ch)&&ch!=','&&ch!='.'))return false;
  string norm;
  if(t.Contains(',')){
   if(t.Count(ch=>ch==',')>1)return false;
   var parts=t.Split(',');if(!BinlikGecerli(parts[0]))return false;norm=parts[0].Replace(".","")+"."+parts[1];
  }else if(t.Contains('.')){
   var g=t.Split('.');
   // Noktadan sonra tam 3 rakamlı gruplar Türkçe binlik ayırıcıdır; aksi halde tek nokta ondalık kabul edilir.
   if(g.Length>1&&g.Skip(1).All(x=>x.Length==3)&&g[0].Length is >0 and <=3)norm=t.Replace(".","");
   else if(g.Length==2)norm=t;
   else return false;
  }else norm=t;
  if(!decimal.TryParse(norm,NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out deger))return false;
  if(neg)deger=-deger;return true;
 }
 static bool BinlikGecerli(string tamKisim){
  if(!tamKisim.Contains('.'))return true;
  var g=tamKisim.Split('.');return g[0].Length is >0 and <=3&&g.Skip(1).All(x=>x.Length==3);
 }

 public static string Yaz(decimal deger,int ondalik)=>deger.ToString("#,0"+(ondalik>0?"."+new string('#',ondalik):""),tr);

 /// <summary>Kutuyu bağlar. <paramref name="ondalik"/> izin verilen en fazla ondalık basamaktır; 0 ise yalnız tam sayı.</summary>
 public static void Bagla(System.Windows.Controls.TextBox kutu,int ondalik=3){
  kutu.PreviewTextInput+=(_,e)=>{e.Handled=e.Text.Any(ch=>!(char.IsDigit(ch)||(ondalik>0&&(ch==','||ch=='.'))));};
  DataObject.AddPastingHandler(kutu,(_,e)=>{if(e.DataObject.GetData(typeof(string)) is string s&&!Oku(s,out decimal _))e.CancelCommand();});
  kutu.LostFocus+=(_,_)=>Bicimle(kutu,ondalik);
  kutu.KeyDown+=(_,e)=>{if(e.Key==Key.Enter)Bicimle(kutu,ondalik);};
 }
 static void Bicimle(System.Windows.Controls.TextBox kutu,int ondalik){
  if(!Oku(kutu.Text,out var d))return;
  if(ondalik==0)d=decimal.Truncate(d);else d=decimal.Round(d,ondalik);
  var yeni=Yaz(d,ondalik);if(yeni!=kutu.Text)kutu.Text=yeni;
 }
}
