import {defaults,normalize,calculate,parseText,fromAi,matchPrices,METHODS,ACCESSORIES,SOURCES,PIPE_OD} from './ai-project.mjs?v=ai1';
import {createProjectViewer} from './ai-project-3d.mjs?v=ai1';

const $=id=>document.getElementById(id),form=$('apForm');
const tr=new Intl.NumberFormat('tr-TR',{maximumFractionDigits:2}),money=new Intl.NumberFormat('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2});
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const desktop=!!window.chrome?.webview;const STORE='miapax-ai-proje-v1';
let state=load(),result=null,priced=null,logo='miapaxerp.png',viewer=null;

// ---- form kurulum ----
for(const od of PIPE_OD.filter(x=>x>=32))form.querySelector('[name=mainDiameter]').add(new Option(`Ø${od} mm`,od));
for(const od of PIPE_OD.filter(x=>x<=75))form.querySelector('[name=lateralDiameter]').add(new Option(`Ø${od} mm`,od));
$('apAccessories').innerHTML=Object.entries(ACCESSORIES).map(([k,v])=>`<label><input type="checkbox" name="acc" value="${k}">${esc(v)}</label>`).join('');
try{viewer=createProjectViewer($('ap3d'));}catch(e){$('ap3d').innerHTML='<p style="padding:20px">3D görünüm açılamadı (grafik kartı / WebGL). Hesap ve malzeme listesi çalışmaya devam eder.</p>';}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>viewer?.view(b.dataset.view));

function load(){try{const j=JSON.parse(localStorage.getItem(STORE)||'null');return j?normalize(j):defaults();}catch{return defaults();}}
function save(){try{localStorage.setItem(STORE,JSON.stringify(state));}catch{}}
function fill(p){
 for(const k of Object.keys(p)){if(k==='accessories')continue;const el=form.querySelector(`[name="${k}"]`);if(el)el.value=p[k];}
 form.querySelectorAll('input[name=acc]').forEach(c=>c.checked=p.accessories.includes(c.value));
 labels(p);
}
function labels(p){
 const drip=p.method==='drip';$('apEmitterGapLabel').textContent=drip?'Damlatıcı arası (m)':'Başlık arası (m)';
 $('apEmitterFlowLabel').textContent=drip?'Damlatıcı debisi (l/sa)':'Başlık debisi (m³/sa)';
 $('apWellLabel').hidden=p.sourceType!=='well';$('apOffsetOut').textContent=`%${Math.round(p.sourceOffset*100)}`;
}
function read(){
 const o={};for(const el of form.querySelectorAll('[name]')){if(el.name==='acc')continue;o[el.name]=el.value;}
 o.accessories=[...form.querySelectorAll('input[name=acc]:checked')].map(c=>c.value);return o;
}
let timer=0;
form.addEventListener('input',e=>{
 const raw=read();
 if(e.target.name==='method'){const m=METHODS[raw.method];Object.assign(raw,{rowGap:m.rowGap,emitterGap:m.emitterGap,emitterFlow:m.emitterFlow,lateralDiameter:m.lateral});}
 state=normalize(raw);if(e.target.name==='method')fill(state);labels(state);clearTimeout(timer);timer=setTimeout(run,220);
});
form.addEventListener('submit',e=>e.preventDefault());

function run(){
 result=calculate(state);priced=null;save();
 viewer?.show(result);renderKpis();renderSummary();renderBom(result.bom);
}
function renderKpis(){
 const r=result;$('apKpis').innerHTML=[[tr.format(r.dekar),'dekar'],[r.lateralCount,'hat (lateral)'],[tr.format(r.lateralTotal)+' m','hat borusu'],[tr.format(r.mainLen)+' m · Ø'+r.mainOd,'ana hat'],[tr.format(r.emitters),r.input.method==='drip'?'damlatıcı':'başlık'],[r.sections,'vanalı bölüm'],[tr.format(r.head)+' m','pompa basma yük.'],[tr.format(r.pumpKw)+' kW','pompa gücü (≈)']]
  .map(([v,t])=>`<div><b>${esc(v)}</b><span>${esc(t)}</span></div>`).join('');
}
function summaryRows(){
 const r=result,l=r.losses,p=r.input;
 return [['Sulama türü',METHODS[p.method].label],['Su kaynağı',`${SOURCES[p.sourceType]} · ${p.sourceDistance} m`],['Toplam debi',tr.format(r.totalFlow)+' m³/sa'],['Bölüm debisi',tr.format(r.sectionFlow)+' m³/sa'],
  ['Hat boyu',`${tr.format(r.lateralLen)} m${r.split?' (iki yana)':''}`],['Dağıtım borusu',`Ø${r.manifoldOd} · ${tr.format(r.manifoldLen)} m`],['Ana hat kaybı',tr.format(l.main)+' m'],['Dağıtım kaybı',tr.format(l.manifold)+' m'],['Hat içi kayıp',tr.format(l.lateral)+' m'],
  ['Filtre kaybı',tr.format(l.filter)+' m'],['Kot farkı + kuyu',tr.format(l.elevation+l.lift)+' m'],['Çalışma basıncı',tr.format(METHODS[p.method].pressure/10)+' bar'],['Toplam basma yüksekliği',tr.format(r.head)+' m'],
  ['Yağış / uygulama hızı',tr.format(r.precip)+' mm/sa'],['Tüm bölümler için süre',tr.format(r.irrigationHours)+' saat']];
}
function renderSummary(){
 $('apSummary').innerHTML=summaryRows().map(([a,b])=>`<dt>${esc(a)}</dt><dd>${esc(b)}</dd>`).join('');
 $('apNotes').innerHTML=[...result.warnings.map(t=>`<li class="warn">⚠ ${esc(t)}</li>`),...result.notes.map(t=>`<li>💡 ${esc(t)}</li>`)].join('')||'<li>Tasarım dengeli görünüyor; ek öneri yok.</li>';
}
function bomHtml(rows){
 let g='',html='';const hasPrice=rows.some(r=>r.price!=null);
 for(const r of rows){if(r.group!==g){g=r.group;html+=`<tr class="grp"><td colspan="10">${esc(g)}</td></tr>`;}
  html+=`<tr><td></td><td>${esc(r.name)}</td><td>${esc(r.size)}</td><td class="n">${tr.format(r.qty)}</td><td>${esc(r.unit==='m'?'metre':r.unit)}</td><td class="${r.stock?'':'muted'}">${esc(r.stock??(priced?'Stokta eşleşme yok':'—'))}</td>`+
   `<td class="n">${r.price!=null?money.format(r.price)+' '+esc(r.currency):'—'}</td><td class="n">${r.vat!=null?'%'+tr.format(r.vat):'—'}</td><td class="n">${r.totalVat!=null?money.format(r.totalVat)+' '+esc(r.currency):'—'}</td><td class="muted">${esc(r.note)}</td></tr>`;}
 let foot='';
 if(hasPrice){const by={};for(const r of rows)if(r.total!=null){const c=r.currency||'TRY';by[c]??={net:0,gross:0};by[c].net+=r.total;by[c].gross+=r.totalVat;}
  foot=Object.entries(by).map(([c,v])=>`<tr><td colspan="6">Eşleşen ürünler toplamı (${esc(c)})</td><td class="n">${money.format(v.net)}</td><td class="n">KDV ${money.format(v.gross-v.net)}</td><td class="n">${money.format(v.gross)}</td><td></td></tr>`).join('');}
 return {body:html,foot};
}
function renderBom(rows){const {body,foot}=bomHtml(rows);$('apBom').tBodies[0].innerHTML=body;$('apBom').tFoot.innerHTML=foot;}

// ---- yapay zekâ ----
const pending=new Map();let stockWait=null;
window.chrome?.webview?.addEventListener('message',e=>{
 const d=e.data||{};
 if(d.action==='projectResult'&&pending.has(d.id)){pending.get(d.id)(d);pending.delete(d.id);}
 else if(d.action==='stockResult'&&stockWait){const w=stockWait;stockWait=null;w(d);}
 else if(d.action==='logo'&&typeof d.url==='string'&&d.url.startsWith('data:image/png'))logo=d.url;
});
function status(id,text,err=false){const el=$(id);el.textContent=text;el.classList.toggle('err',err);}
$('apAsk').onclick=async()=>{
 const text=$('apPrompt').value.trim();if(!text){status('apAskStatus','Önce tarlanızı birkaç cümleyle anlatın.',true);return;}
 const local=parseText(text,state);state=normalize({...state,...local});fill(state);run();
 const found=Object.keys(local).filter(k=>k!=='accessories');
 status('apAskStatus',found.length?`Anlatımdan okunan: ${found.length} bilgi. Hesap güncellendi.`:'Anlatımdan ölçü okunamadı; değerleri soldan girebilirsiniz.');
 if(!desktop)return;
 const id=crypto.randomUUID();$('apAsk').disabled=true;status('apAskStatus',$('apAskStatus').textContent+' Yapay zekâ da inceliyor…');
 const reply=await new Promise(res=>{pending.set(id,res);window.chrome.webview.postMessage({action:'projectAsk',id,prompt:text,context:JSON.stringify(state)});setTimeout(()=>{if(pending.delete(id))res({error:'Yapay zekâ zamanında yanıt vermedi; yerleşik çözümleme kullanıldı.'});},65000);});
 $('apAsk').disabled=false;
 if(reply.error){status('apAskStatus',reply.error,!/yerleşik/.test(reply.error));return;}
 const ai=fromAi(reply.text);if(!ai||!Object.keys(ai).length){status('apAskStatus','Yapay zekâ yanıtı okunamadı; yerleşik çözümleme kullanıldı.');return;}
 state=normalize({...state,...ai});fill(state);run();status('apAskStatus',`Yapay zekâ ${Object.keys(ai).length} bilgiyi işledi; hesap, 3D ve malzeme listesi güncellendi.`);
};
$('apAiSettings').onclick=()=>desktop?window.chrome.webview.postMessage({action:'designSettings'}):status('apAskStatus','Yapay zekâ bağlantısı masaüstü uygulamasında ayarlanır.',true);
$('apReset').onclick=()=>{state=defaults();$('apPrompt').value='';fill(state);run();status('apAskStatus','Yeni proje başlatıldı.');};

// ---- stok fiyatları ----
const searchStock=term=>new Promise(res=>{stockWait=res;window.chrome.webview.postMessage({action:'stockSearch',search:term});setTimeout(()=>{if(stockWait===res){stockWait=null;res({error:'Stok yanıtı gelmedi.'});}},20000);});
$('apPrices').onclick=async()=>{
 if(!desktop){status('apBomStatus','Stok fiyatları masaüstü uygulamasında getirilir.',true);return;}
 const terms=new Set(['boru']);for(const r of result.bom)for(const w of String(r.key).split(' '))if(!/^\d+$/.test(w)&&w.length>2)terms.add(w);
 $('apPrices').disabled=true;const all=new Map();let error='';
 for(const t of [...terms].slice(0,20)){status('apBomStatus',`Stokta aranıyor: ${t}…`);const d=await searchStock(t);if(d.error){error=d.error;if(/yetki|lisans/i.test(d.error))break;continue;}for(const s of d.rows||[])all.set(s.id,s);}
 $('apPrices').disabled=false;
 priced=matchPrices(result.bom,[...all.values()]);renderBom(priced);
 const n=priced.filter(r=>r.price!=null).length;
 status('apBomStatus',error&&!all.size?error:`${n}/${priced.length} kalem stok fiyatıyla eşleşti. KDV oranı stok “Birim fiyat ve KDV” listesinden alınır; tanımsızsa %20 kabul edilir.`,!!error&&!all.size);
};

// ---- çıktılar ----
$('apCsv').onclick=()=>{
 const rows=priced||result.bom,head=['Grup','Ürün','Ölçü','Miktar','Birim','Stok','Birim fiyat (KDV hariç)','KDV %','Tutar (KDV dahil)','Not'];
 const cell=v=>{let s=String(v??'');if(/^[=+\-@]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';};
 const csv='﻿'+[head,...rows.map(r=>[r.group,r.name,r.size,tr.format(r.qty),r.unit,r.stock??'',r.price!=null?money.format(r.price):'',r.vat??'',r.totalVat!=null?money.format(r.totalVat):'',r.note])].map(r=>r.map(cell).join(';')).join('\r\n');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download=fileName('csv');a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000);
};
function fileName(ext){const n=(state.project||'Sulama-Projesi').replace(/[^\p{L}\p{N} _-]/gu,'').trim().replace(/\s+/g,'-').slice(0,50)||'Sulama-Projesi';return `MiapaxERP-${n}.${ext}`;}
$('apPdf').onclick=async()=>{
 const r=result,p=r.input,img=viewer?.snapshot()??'';const {body,foot}=bomHtml(priced||r.bom);
 $('apReport').innerHTML=`<header><div><h1>${esc(p.project||'Sulama projesi')}</h1><div>${esc(METHODS[p.method].label)} · ${esc(p.width)} × ${esc(p.length)} m · ${esc(tr.format(r.dekar))} dekar${p.crop?' · '+esc(p.crop):''} · ${new Date().toLocaleDateString('tr-TR')}</div></div><img class="logo" data-brand-logo src="${esc(logo)}" alt="MiapaxERP"></header>
 ${img?`<img class="view" src="${img}" alt="3D proje görünümü">`:''}
 <div class="cols"><div><h2>Mühendislik özeti</h2><dl>${summaryRows().map(([a,b])=>`<dt>${esc(a)}</dt><dd>${esc(b)}</dd>`).join('')}</dl></div>
 <div><h2>Öneriler ve uyarılar</h2><ul>${[...r.warnings,...r.notes].map(t=>`<li>${esc(t)}</li>`).join('')||'<li>Ek öneri yok.</li>'}</ul></div></div>
 <h2>Malzeme listesi</h2><table><thead><tr><th>Grup</th><th>Ürün</th><th>Ölçü</th><th class="n">Miktar</th><th>Birim</th><th>Stok</th><th class="n">Birim fiyat</th><th class="n">KDV</th><th class="n">Tutar</th><th>Not</th></tr></thead><tbody>${body}</tbody><tfoot>${foot}</tfoot></table>
 <p style="font-size:9px;color:#666;margin-top:8px">MiapaxERP Kroki · Yapay zekâ proje sihirbazı ön tasarımıdır. Pompa ve boru seçimini üretici eğrileri ve sahadaki gerçek debiyle doğrulayın.</p>`;
 await Promise.all([...$('apReport').querySelectorAll('img')].map(i=>i.decode().catch(()=>{})));
 if(desktop){document.body.classList.add('fp-printing');window.chrome.webview.postMessage({action:'pdf',file:fileName('pdf')});}
 else window.print();
};

fill(state);run();
window.chrome?.webview?.postMessage({action:'ready'});
