using System.Data;
namespace MiapaxERP.Desktop;

public sealed record MobilTakvimSatiri(int Id,DateTime Tarih,string Baslik,string Aciklama,string Tur,string Durum);

public sealed partial class YardimciEkranServisi
{
    /// <summary>Mobil için iş takvimi: bugünden 7 gün önce ile 45 gün sonrası; CALENDAR.ALL yoksa yalnız kendi planları.</summary>
    public MobilTakvimSatiri[] TakvimMobil()
    {
        if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<MobilTakvimSatiri[]>(connection,"YardimciEkranServisi.TakvimMobil","",Array.Empty<object?>());
        using var c=access.Ac();Yetki(c,null,"CALENDAR.VIEW");bool all=false;try{Yetki(c,null,"CALENDAR.ALL");all=true;}catch(UnauthorizedAccessException){}
        using var q=Q(c,null,"SELECT TOP(300) Id,PlanTarihi,Baslik,COALESCE(Aciklama,N''),Tur,Durum FROM dbo.IsTakvimi WHERE PlanTarihi>=@ilk AND PlanTarihi<@son AND (@all=1 OR OlusturanKullaniciId=@u OR AtananKullaniciId=@u) ORDER BY PlanTarihi,Id",
            ("@ilk",DateTime.Today.AddDays(-7)),("@son",DateTime.Today.AddDays(46)),("@all",all),("@u",user));
        using var r=q.ExecuteReader();var list=new List<MobilTakvimSatiri>();
        while(r.Read())list.Add(new(r.GetInt32(0),r.GetDateTime(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetString(5)));
        return list.ToArray();
    }
}
