using TabControl = System.Windows.Controls.TabControl;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using DataGridCell = System.Windows.Controls.DataGridCell;
using RadioButton = System.Windows.Controls.RadioButton;
namespace MiapaxERP.Desktop;

/// <summary>
/// Tema okunurluğu: her metnin, gerçekte üzerinde durduğu yüzeyle en az 4,5:1 kontrastta olmasını sağlar.
/// Koyu görünümde ekranlara sabit yazılmış açık zeminler (beyaz, açık gri/mavi kutular, açık butonlar) koyu karşılığına çevrilir;
/// açık görünüme dönülünce özgün renkler geri yüklenir. Degrade ve resim zeminler ortalama renkleriyle değerlendirilir.
/// </summary>
public static class TemaOkunurlugu
{
 static bool started;
 static readonly ConditionalWeakTable<DependencyObject,Brush> ozgunZemin=new();
 static readonly Color koyuYuzey=Color.FromRgb(0x1E,0x29,0x3B);
 internal static double Parlaklik(Color c){double F(byte x){double v=x/255d;return v<=.04045?v/12.92:Math.Pow((v+.055)/1.055,2.4);}return .2126*F(c.R)+.7152*F(c.G)+.0722*F(c.B);}
 internal static double Kontrast(Color a,Color b){double x=Parlaklik(a),y=Parlaklik(b);return(Math.Max(x,y)+.05)/(Math.Min(x,y)+.05);}
 internal static Color Uyumlu(Color text,Color surface){text=Color.FromRgb(text.R,text.G,text.B);if(Kontrast(text,surface)>=4.5)return text;Color target=Kontrast(Colors.Black,surface)>=Kontrast(Colors.White,surface)?Colors.Black:Colors.White;for(int i=1;i<=40;i++){double k=i/40d;var next=Color.FromRgb((byte)Math.Round(text.R+(target.R-text.R)*k),(byte)Math.Round(text.G+(target.G-text.G)*k),(byte)Math.Round(text.B+(target.B-text.B)*k));if(Kontrast(next,surface)>=4.5)return next;}return target;}
 /// <summary>Açık bir zemin rengini koyu görünüm için karşılığına çevirir (tonu hafifçe korunur).</summary>
 internal static Color KoyuKarsilik(Color c){const double k=.86;return Color.FromArgb(c.A,(byte)Math.Round(c.R*(1-k)+koyuYuzey.R*k),(byte)Math.Round(c.G*(1-k)+koyuYuzey.G*k),(byte)Math.Round(c.B*(1-k)+koyuYuzey.B*k));}

 public static void Baslat(){
  if(started)return;started=true;
  // Kodla sonradan eklenen veya rengi değişen yazılar için etkin pencere 2 sn'de bir yeniden denetlenir.
  var denetim=new System.Windows.Threading.DispatcherTimer(DispatcherPriority.Background){Interval=TimeSpan.FromSeconds(2)};
  denetim.Tick+=(_,_)=>{if(Application.Current is not {} app)return;foreach(Window w in app.Windows)if(w.IsActive){try{Uygula(w);}catch(InvalidOperationException){}break;}};
  denetim.Start();
  foreach(var type in new[]{typeof(TextBlock),typeof(Control),typeof(Border),typeof(Panel)})EventManager.RegisterClassHandler(type,FrameworkElement.LoadedEvent,new RoutedEventHandler((s,_)=>Duzelt((DependencyObject)s)));
  foreach(var ev in new[]{DataGridCell.SelectedEvent,DataGridCell.UnselectedEvent})EventManager.RegisterClassHandler(typeof(DataGridCell),ev,new RoutedEventHandler((s,_)=>{var cell=(DataGridCell)s;cell.Dispatcher.BeginInvoke(()=>Uygula(cell),DispatcherPriority.Render);}));
  // Sekme değişince seçili/seçilmemiş başlıkların zemini değişir; başlıklar yeniden denetlenir.
  EventManager.RegisterClassHandler(typeof(TabControl),System.Windows.Controls.Primitives.Selector.SelectionChangedEvent,new SelectionChangedEventHandler((s,e)=>{if(ReferenceEquals(e.OriginalSource,s)){var tc=(TabControl)s;tc.Dispatcher.BeginInvoke(()=>Uygula(tc),DispatcherPriority.Render);}}));
 }
 static DependencyObject? Parent(DependencyObject node){try{return VisualTreeHelper.GetParent(node)??LogicalTreeHelper.GetParent(node);}catch(InvalidOperationException){return LogicalTreeHelper.GetParent(node);}}
 static Brush? Zemin(DependencyObject p)=>p switch{Control c when c is not CheckBox and not RadioButton=>c.Background,Border border=>border.Background,Panel panel=>panel.Background,TextBlock t=>t.Background,_=>null};
 static DependencyProperty? ZeminOzelligi(DependencyObject p)=>p switch{Control=>Control.BackgroundProperty,Border=>Border.BackgroundProperty,Panel=>Panel.BackgroundProperty,_=>null};
 /// <summary>Fırçanın görünen ortalama rengi: düz renk, degrade (durakların ortalaması) veya resim (temaya göre tahmin).</summary>
 static Color? Ortalama(Brush? b){
  switch(b){
   case SolidColorBrush s:return s.Color.A==0?null:Color.FromArgb((byte)Math.Round(s.Color.A*b.Opacity),s.Color.R,s.Color.G,s.Color.B);
   case GradientBrush g when g.GradientStops.Count>0:{double a=0,r=0,gr=0,bl=0;foreach(var st in g.GradientStops){a+=st.Color.A;r+=st.Color.R;gr+=st.Color.G;bl+=st.Color.B;}int n=g.GradientStops.Count;return Color.FromArgb((byte)Math.Round(a/n*b.Opacity),(byte)(r/n),(byte)(gr/n),(byte)(bl/n));}
   case ImageBrush:return Tema170.KoyuMu?Color.FromArgb(200,30,41,59):Color.FromArgb(160,240,244,248);
   default:return null;
  }
 }
 static Color Surface(DependencyObject node){
  double remain=1,red=0,green=0,blue=0;
  for(var p=node;p is not null&&remain>.001;p=Parent(p)){
   if(Ortalama(Zemin(p)) is not Color c||c.A==0)continue;
   double alpha=c.A/255d;red+=c.R*alpha*remain;green+=c.G*alpha*remain;blue+=c.B*alpha*remain;remain*=1-alpha;
  }
  Color fallback=Tema170.KoyuMu?Color.FromRgb(23,35,51):Colors.White;
  return Color.FromRgb((byte)Math.Round(red+fallback.R*remain),(byte)Math.Round(green+fallback.G*remain),(byte)Math.Round(blue+fallback.B*remain));
 }
 /// <summary>Ekrana sabit yazılmış (kaynak bağlamasız) açık zeminleri koyu görünümde koyulaştırır; açık görünümde özgün rengi geri koyar.</summary>
 static void ZeminiDuzelt(DependencyObject node){
  if(ZeminOzelligi(node) is not DependencyProperty prop)return;
  if(ozgunZemin.TryGetValue(node,out var ozgun)){
   if(!Tema170.KoyuMu){node.SetCurrentValue(prop,ozgun);ozgunZemin.Remove(node);}
   return;
  }
  if(!Tema170.KoyuMu||node.GetValue(prop) is not SolidColorBrush s||s.Color.A<40)return;
  var kaynak=DependencyPropertyHelper.GetValueSource(node,prop);
  if(kaynak.BaseValueSource!=BaseValueSource.Local||kaynak.IsExpression)return;// yalnız sabit yazılmış renkler; tema kaynakları zaten koyu
  if(Parlaklik(s.Color)<.55)return;
  ozgunZemin.AddOrUpdate(node,s);
  node.SetCurrentValue(prop,new SolidColorBrush(KoyuKarsilik(s.Color)));
 }
 static readonly System.Runtime.CompilerServices.ConditionalWeakTable<DependencyObject,Brush> ozgunYazi=new();
 static void Duzelt(DependencyObject node){
  ZeminiDuzelt(node);
  DependencyProperty? property=node is TextBlock?TextBlock.ForegroundProperty:node is Control?Control.ForegroundProperty:null;
  if(property is null)return;
  // Tema değişince önceki temaya göre düzeltilmiş renk kalmasın: özgün renkten yeniden hesaplanır.
  if(ozgunYazi.TryGetValue(node,out var ozgun)){node.SetCurrentValue(property,ozgun);ozgunYazi.Remove(node);}
  if(node.GetValue(property) is not SolidColorBrush fg||fg.Color.A==0)return;
  Color surface=Surface(node),current=fg.Color;
  var visible=Color.FromRgb((byte)Math.Round(current.R*current.A/255d+surface.R*(1-current.A/255d)),(byte)Math.Round(current.G*current.A/255d+surface.G*(1-current.A/255d)),(byte)Math.Round(current.B*current.A/255d+surface.B*(1-current.A/255d)));
  if(Kontrast(visible,surface)<4.5){ozgunYazi.AddOrUpdate(node,fg);node.SetCurrentValue(property,new SolidColorBrush(Uyumlu(visible,surface)));}
 }
 /// <summary>Tema değiştiğinde açık tüm pencereleri yeniden denetler.</summary>
 public static void HepsiniYenile(){
  if(Application.Current is not {} app)return;
  app.Dispatcher.BeginInvoke(()=>{foreach(Window w in app.Windows){try{Uygula(w);}catch(InvalidOperationException){}}},DispatcherPriority.Background);
 }
 public static void Uygula(DependencyObject root){Duzelt(root);for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++)Uygula(VisualTreeHelper.GetChild(root,i));}
}
