using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace MiapaxERP.Desktop;

/// <summary>
/// "Nane Cam" teması kabuğu: degrade zeminin üzerinde yüzen, yuvarlak köşeli koyu yeşil menü;
/// yuvarlak üst başlık bandı ve ferah kartlar. Diğer temalara geçildiğinde özgün kabuk geri yüklenir.
/// </summary>
public partial class MainWindow
{
    private void NaneCamKabugu(GorunumTercihleri a)
    {
        bool nane = a.Tema == "Nane Cam" && !Tema170.KoyuMu;
        bool ust = Tema170.Yerlesim(a) == "Üst menü";
        var baslik = TemaIcerik.Children.OfType<Border>().FirstOrDefault(b => Grid.GetRow(b) == 0);
        if (nane)
        {
            TemaKabuk.SetResourceReference(Panel.BackgroundProperty, "ErpZemin");
            // Yüzen menünün kenar boşlukları menü yazılarını daraltmasın.
            if (Tema170.Yerlesim(a) == "Sol menü") TemaKabuk.ColumnDefinitions[0].Width = new GridLength(285);
            else if (Tema170.Yerlesim(a) == "Sağ menü") TemaKabuk.ColumnDefinitions[1].Width = new GridLength(285);
            TemaMenu.Margin = ust ? new Thickness(14, 14, 14, 0) : new Thickness(14);
            TemaMenu.CornerRadius = new CornerRadius(28);
            TemaMenu.Effect = new DropShadowEffect { BlurRadius = 28, ShadowDepth = 6, Direction = 270, Opacity = .18, Color = Color.FromRgb(0x0B, 0x2A, 0x22) };
            TemaIcerik.Margin = ust ? new Thickness(14) : new Thickness(0, 14, 14, 14);
            if (baslik != null)
            {
                baslik.CornerRadius = new CornerRadius(24);
                baslik.BorderThickness = new Thickness(0);
                baslik.Margin = new Thickness(0, 0, 0, 12);
                baslik.Effect = new DropShadowEffect { BlurRadius = 22, ShadowDepth = 4, Direction = 270, Opacity = .14, Color = Color.FromRgb(0x0B, 0x2A, 0x22) };
            }
            foreach (Button b in TemaMenuOgeleri.Children.OfType<Button>()) b.Margin = new Thickness(ust ? 4 : 12, 3, ust ? 4 : 12, 3);
            // Yüzen menü dar olduğundan marka alanı sıkılaştırılır; firma adı kesilmez.
            TemaMarka.Margin = new Thickness(16, 22, 12, 22);
            TxtFirmaBasligi.FontSize = 21;
            TxtFirmaBasligi.MaxWidth = 150;
        }
        else
        {
            TemaKabuk.ClearValue(Panel.BackgroundProperty);
            TemaMenu.ClearValue(FrameworkElement.MarginProperty);
            TemaMenu.ClearValue(Border.CornerRadiusProperty);
            TemaMenu.Effect = null;
            TemaIcerik.ClearValue(FrameworkElement.MarginProperty);
            TemaMarka.Margin = new Thickness(20, 25, 20, 30);
            TxtFirmaBasligi.FontSize = 27;
            TxtFirmaBasligi.MaxWidth = 220;
            if (baslik != null)
            {
                baslik.ClearValue(Border.CornerRadiusProperty);
                baslik.BorderThickness = new Thickness(0, 0, 0, 1);
                baslik.ClearValue(FrameworkElement.MarginProperty);
                baslik.Effect = null;
            }
        }
    }
}
