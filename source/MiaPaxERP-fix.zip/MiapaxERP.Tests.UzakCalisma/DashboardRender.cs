﻿using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using MiapaxERP.Desktop;

// Gerçek WPF ağacı; müşteri SQL'i, oturum açma veya güncelleme başlatılmaz.
internal static class DashboardRender
{
    static int checks;
    static void Check(bool ok, string name) { if (!ok) throw new InvalidOperationException(name); Console.WriteLine("PASS " + name); checks++; }
    static void Pump() { var f = new DispatcherFrame(); Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => f.Continue = false)); Dispatcher.PushFrame(f); }
    public static void Run(string output)
    {
        Directory.CreateDirectory(output);
        var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
        app.Resources.MergedDictionaries.Add(new ResourceDictionary { Source = new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/ModernKontroller.xaml") });
        Tema170.Uygula(new GorunumTercihleri());
        TemaPencereServisi.Baslat();
        var w = new MainWindow(true);
        var root = (FrameworkElement)w.Content;
        var oldCards = GorunumTercihleri.Kartlar.Select(k => w.FindName("Kart" + k.Id)).OfType<FrameworkElement>().ToArray();
        var calendar = (Border)w.FindName("BrdIsTakvimi");
        void Layout(int width) { root.Measure(new Size(width, 940)); root.Arrange(new Rect(0, 0, width, 940)); root.UpdateLayout(); Pump(); TemaOkunurlugu.Uygula(root); root.UpdateLayout(); }
        Grid Pano() => (Grid)typeof(MainWindow).GetField("camPano", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(w)!;
        try
        {
            foreach (var theme in Tema170.Adlar.Where(Tema170.CamMi))
            {
                w.GorunumuUygula(new GorunumTercihleri { Tema = theme });
                // Yalnız önizlemede menüler gösterilir; gerçek yetki denetimi değiştirilmez.
                foreach (var b in ((Panel)w.FindName("TemaMenuOgeleri")).Children.OfType<Button>()) b.Visibility = Visibility.Visible;
                ((FrameworkElement)w.FindName("AnaSayfaIcerik")).Visibility = Visibility.Visible;
                calendar.Visibility = Visibility.Visible;
                Layout(1600);
                var pano = Pano();
                Check(pano.ActualWidth > 1080 && pano.ColumnDefinitions[2].ActualWidth > 0, theme + " geniş iki sütun");
                Check(oldCards.All(c => c.Parent != null), theme + " mevcut kartlar korundu");
                Check(Descendants(pano).OfType<Calendar>().Count() == 1, theme + " takvim tekrarlanmıyor");
                calendar.Visibility = Visibility.Collapsed; Pump();
                Check(calendar.Visibility == Visibility.Collapsed && !Descendants(pano).OfType<Calendar>().Any(c => !Descendants(calendar).Contains(c)), theme + " takvim yetkisi korunuyor");
                calendar.Visibility = Visibility.Visible; Pump();
                var hiddenMenu = (Button)w.FindName("BtnMenuStok"); hiddenMenu.Visibility = Visibility.Collapsed; Pump();
                var hero = (Border)typeof(MainWindow).GetField("camKarsilama", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(w)!;
                var actions = ((StackPanel)hero.Child).Children.OfType<WrapPanel>().Single().Children.OfType<Button>().ToArray();
                Check(actions.All(b => b.Foreground is SolidColorBrush f && b.Background is SolidColorBrush bg && TemaOkunurlugu.Kontrast(f.Color, bg.Color) >= 4.5), theme + " kısayol yazıları okunur");
                Check(actions.Any(b => b.Content.ToString()!.Contains("Stok") && b.Visibility == Visibility.Collapsed), theme + " stok kısayolu yetkisi korunuyor");
                hiddenMenu.Visibility = Visibility.Visible;
                // Örnek veri üretmeden boş ERP kartlarını görsel kontrolde göster.
                foreach (var c in oldCards) c.Visibility = Visibility.Visible;
                foreach (var b in ((Panel)w.FindName("KartKisayol")).Children.OfType<Button>()) b.Visibility = Visibility.Visible;
                Layout(1600); Save(root, Path.Combine(output, theme.Replace(' ', '_') + ".png"));
                Layout(1000);
                Check(pano.ColumnDefinitions[2].ActualWidth < 1 && Grid.GetRow(pano.Children[1]) == 1, theme + " dar tek sütun");
                Check(root.DesiredSize.Width <= 1000.1, theme + " yatay taşma yok");
                Save(root, Path.Combine(output, theme.Replace(' ', '_') + "-dar.png"));
                w.GorunumuUygula(new GorunumTercihleri { Tema = theme, Golge = false, Vurgu = "#FFFF00", FirmaLogoBoyutu = 60 }); Layout(1600);
                hero = (Border)typeof(MainWindow).GetField("camKarsilama", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(w)!;
                var nav = (Border)w.FindName("TemaMenu");
                Check(nav.Effect is null && hero.Effect is null && ((Grid)w.FindName("TemaIcerik")).Children.OfType<Border>().First(b => Grid.GetRow(b) == 0).Effect is null, theme + " gölge kapatma tercihi");
                actions = ((StackPanel)hero.Child).Children.OfType<WrapPanel>().Single().Children.OfType<Button>().ToArray();
                Check(actions.All(b => b.Foreground is SolidColorBrush f && b.Background is SolidColorBrush bg && TemaOkunurlugu.Kontrast(f.Color, bg.Color) >= 4.5), theme + " özel vurgu rengi okunur");
                var rail = typeof(MainWindow).GetMethod("RayDurumu", BindingFlags.Instance | BindingFlags.NonPublic)!;
                rail.Invoke(w, [true, false]);
                Check(((FrameworkElement)w.FindName("ImgFirmaLogosu")).Width == 60, theme + " açık menü logo tercihi");
                rail.Invoke(w, [false, false]);
                Check(((FrameworkElement)w.FindName("ImgFirmaLogosu")).Width <= 40, theme + " dar menü logo taşmıyor");
                w.GorunumuUygula(new GorunumTercihleri { Tema = "Açık" }); Layout(1600);
                Check(calendar.Parent is StackPanel && oldCards.All(c => c.Parent != null), theme + " özgün düzen geri yüklendi");
            }
            Console.WriteLine($"Dashboard: {checks} kontrol geçti. SQL veya müşteri verisi kullanılmadı.");
        }
        finally { w.Close(); app.Shutdown(); }
    }
    static IEnumerable<DependencyObject> Descendants(DependencyObject root)
    {
        foreach (var c in LogicalTreeHelper.GetChildren(root).OfType<DependencyObject>()) { yield return c; foreach (var d in Descendants(c)) yield return d; }
    }
    static void Save(FrameworkElement root, string path)
    {
        var bmp = new RenderTargetBitmap((int)root.ActualWidth, (int)root.ActualHeight, 96, 96, PixelFormats.Pbgra32); bmp.Render(root);
        var enc = new PngBitmapEncoder(); enc.Frames.Add(BitmapFrame.Create(bmp)); using var file = File.Create(path); enc.Save(file);
    }
}
