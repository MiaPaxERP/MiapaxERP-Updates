// İnternet lisans panelinin adresi. Kendi Cloudflare hesabınıza taşıdığınızda
// gizli ayarlara LICENSE_CLOUD_ORIGIN=https://lisans.firmaniz.com ekleyin.
export const DEFAULT_CLOUD_ORIGIN='https://boruerp-lisans-yonetimi.ali-can-0001.chatgpt.site';
export function cloudOrigin(env={}){
 const raw=String(env.LICENSE_CLOUD_ORIGIN||DEFAULT_CLOUD_ORIGIN).trim();let u;
 try{u=new URL(raw);}catch{throw Error('LICENSE_CLOUD_ORIGIN geçersiz.');}
 if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||(u.pathname!=='/'&&u.pathname!==''))throw Error('LICENSE_CLOUD_ORIGIN yalnız https kök adresi olabilir.');
 return u.origin;
}
