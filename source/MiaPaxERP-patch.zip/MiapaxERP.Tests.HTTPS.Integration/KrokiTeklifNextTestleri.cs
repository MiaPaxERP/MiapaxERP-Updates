using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class KrokiTeklifNextTestleri
{
 static void Sql(SqlConnection c,string s){using var q=new SqlCommand(s,c);q.ExecuteNonQuery();}
 [Fact] public void StokFiyatlariYetkiliKullaniciIcinOkunurMaliyetSizmazVeYetkiIptaliAnindaUygulanir(){
  string name="MiapaxKrokiNext_"+Guid.NewGuid().ToString("N");using var master=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=5");master.Open();Sql(master,"CREATE DATABASE ["+name+"]");
  try{string cs=new SqlConnectionStringBuilder(master.ConnectionString){InitialCatalog=name}.ConnectionString;using var c=new SqlConnection(cs);c.Open();Sql(c,"""
   CREATE TABLE dbo.Kullanicilar(Id int PRIMARY KEY,Aktif bit);INSERT dbo.Kullanicilar VALUES(1,1),(2,1),(3,0);
   CREATE TABLE dbo.KullaniciRolleri(Id int PRIMARY KEY,RolAdi nvarchar(80),Aktif bit);
   CREATE TABLE dbo.KullaniciRolAtamalari(KullaniciId int,RolId int);
   CREATE TABLE dbo.Yetkiler(YetkiKodu varchar(80),Aktif bit);INSERT dbo.Yetkiler VALUES('STOCK.VIEW',1),('KROKI.VIEW',1);
   CREATE TABLE dbo.TestYetki(KullaniciId int,YetkiKodu varchar(80),Yetkili bit);INSERT dbo.TestYetki VALUES(1,'STOCK.VIEW',1),(1,'KROKI.VIEW',1),(2,'KROKI.VIEW',1),(3,'STOCK.VIEW',1),(3,'KROKI.VIEW',1);
   CREATE TABLE dbo.StokKartlari(Id int PRIMARY KEY,StokKodu nvarchar(50),StokAdi nvarchar(200),Birim nvarchar(20),CapMm decimal(12,3),UzunlukMetre decimal(12,3),Aktif bit);
   INSERT dbo.StokKartlari VALUES(1,'75-5',N'75 mm 5 m boru',N'Adet',75,5,1),(2,'NOTPRICED',N'Kör tapa',N'Adet',75,NULL,1),(3,'HIDDEN',N'Pasif boru',N'Adet',75,5,0);
   CREATE TABLE dbo.StokFiyatlari(StokKartId int,AlisMaliyeti decimal(18,4),BayiSatisFiyati decimal(18,4),PerakendeSatisFiyati decimal(18,4),ParaBirimi varchar(3));INSERT dbo.StokFiyatlari VALUES(1,33,90,100,'TRY');
   """);Sql(c,"CREATE VIEW dbo.vw_KullaniciEtkinYetkileri AS SELECT * FROM dbo.TestYetki");
   var service=new KrokiTeklifServisi(cs,1,_=>{});var rows=service.StokAra("");Assert.Equal(2,rows.Length);var pipe=Assert.Single(service.StokAra("75-5"));Assert.Equal(100,pipe.retail);Assert.Equal(90,pipe.dealer);Assert.Equal(5,pipe.length);Assert.Null(Assert.Single(service.StokAra("NOTPRICED")).retail);
   Assert.DoesNotContain("AlisMaliyeti",System.Text.Json.JsonSerializer.Serialize(rows));Assert.Empty(service.StokAra("' OR 1=1 --"));
   Assert.Throws<UnauthorizedAccessException>(()=>new KrokiTeklifServisi(cs,2,_=>{}).StokAra(""));Assert.Throws<UnauthorizedAccessException>(()=>new KrokiTeklifServisi(cs,3,_=>{}).StokAra(""));
   Sql(c,"UPDATE dbo.TestYetki SET Yetkili=0 WHERE KullaniciId=1 AND YetkiKodu='KROKI.VIEW'");Assert.Throws<UnauthorizedAccessException>(()=>service.StokAra(""));
   using var price=new SqlCommand("SELECT PerakendeSatisFiyati FROM dbo.StokFiyatlari WHERE StokKartId=1",c);Assert.Equal(100m,price.ExecuteScalar());
  }finally{if(!System.Text.RegularExpressions.Regex.IsMatch(name,"^MiapaxKrokiNext_[a-f0-9]{32}$"))throw new InvalidOperationException();Sql(master,"ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]");}
 }
 [Fact]public void HttpsYalnizStokOkumaIsleminiTanimlar(){Assert.Contains("KrokiTeklifServisi.StokAra",HttpsIslemKatalogu.Adlar);Assert.DoesNotContain("KrokiTeklifServisi.Kaydet",HttpsIslemKatalogu.Adlar);}
 [Fact]public void UzunAramaVeritabaninaGitmedenReddedilir(){Assert.Throws<ArgumentException>(()=>new KrokiTeklifServisi("",0).StokAra(new string('x',101)));}
}
