using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;

public class StokFiyatKdvTestleri
{
 static void Sql(SqlConnection c,string sql){using var q=new SqlCommand(sql,c);q.ExecuteNonQuery();}

 [Fact]public void KdvDahilHaricDonusumleriDogru(){
  Assert.Equal(100m,StokFiyatKdvServisi.KdvHaric(120m,true,20m));
  Assert.Equal(120m,StokFiyatKdvServisi.KdvDahil(100m,false,20m));
  Assert.Equal(100m,StokFiyatKdvServisi.KdvHaric(100m,false,20m));
  Assert.Equal(101m,StokFiyatKdvServisi.KdvDahil(100m,false,1m));
  var row=new StokFiyatSatiri(1,"A","A","Adet","Mamul",true,120m,true,null,180m,false,20m,"TRY",null,null);
  Assert.Equal(100m,row.AlisKdvHaric);Assert.Equal(216m,row.PerakendeKdvDahil);Assert.Equal(80.0m,row.KarOrani);
 }

 [Fact]public void UretilenVeMevcutStokFiyatlariKdvIleKaydedilir(){
  string name="MiapaxKdv_"+Guid.NewGuid().ToString("N");
  using var master=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=5");master.Open();Sql(master,"CREATE DATABASE ["+name+"]");
  try{
   string cs=new SqlConnectionStringBuilder(master.ConnectionString){InitialCatalog=name}.ConnectionString;using var c=new SqlConnection(cs);c.Open();
   Sql(c,"""
    CREATE TABLE dbo.StokKartlari(Id int PRIMARY KEY,StokKodu nvarchar(50) UNIQUE,StokAdi nvarchar(200),StokTipi nvarchar(30),Birim nvarchar(20),Aktif bit);
    INSERT dbo.StokKartlari VALUES(1,'BORU-32',N'32 mm boru',N'Mamul','Metre',1),(2,'GRANUL',N'PE granül',N'Hammadde','Kg',1),(3,'PASIF',N'Pasif',N'Hammadde','Adet',0);
    CREATE TABLE dbo.StokFiyatlari(StokKartId int PRIMARY KEY REFERENCES dbo.StokKartlari(Id),AlisMaliyeti decimal(18,4) NULL,BayiSatisFiyati decimal(18,4) NULL,PerakendeSatisFiyati decimal(18,4) NULL,ParaBirimi char(3) NOT NULL DEFAULT 'TRY',GuncellemeUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
    INSERT dbo.StokFiyatlari(StokKartId,AlisMaliyeti,PerakendeSatisFiyati,ParaBirimi) VALUES(2,40,NULL,'TRY');
    CREATE TABLE dbo.StokAlimKayitlari(Id bigint IDENTITY PRIMARY KEY,StokKartId int,CariKartId int,AlimTarihi date,Miktar decimal(18,3),BirimFiyat decimal(18,4),ParaBirimi char(3),Aciklama nvarchar(200),KayitUtc datetime2,StokHareketId bigint);
    INSERT dbo.StokAlimKayitlari(StokKartId,CariKartId,AlimTarihi,Miktar,BirimFiyat,ParaBirimi) VALUES(2,1,'2026-11-01',1000,38.5,'TRY'),(2,1,'2026-11-10',500,41.25,'TRY');
    CREATE TABLE dbo.UretimReceteleri(Id int PRIMARY KEY,MamulStokId int);INSERT dbo.UretimReceteleri VALUES(1,1);
    CREATE TABLE dbo.UretimEmirleri(Id int PRIMARY KEY,MamulStokId int);
    """);
   var granted=new HashSet<string>{"STOCK.VIEW","STOCK.PRICE"};
   var s=new StokFiyatKdvServisi(cs,1,(_,_,code)=>{if(!granted.Contains(code))throw new UnauthorizedAccessException(code);});
   var all=s.Liste("",false);Assert.Equal(2,all.Length);
   var produced=Assert.Single(s.Liste("",true));Assert.Equal(1,produced.Id);Assert.True(produced.Uretilen);
   var granul=all.Single(x=>x.Id==2);Assert.Equal(40m,granul.Alis);Assert.Equal(41.25m,granul.SonAlis);Assert.Equal(StokFiyatKdvServisi.VarsayilanKdv,granul.KdvOrani);Assert.False(granul.AlisKdvDahil);
   Assert.Equal(2,s.Kaydet([new(1,12m,false,15m,24m,true,20m,"TRY"),new(2,42m,true,null,null,true,1m,"USD")]));
   var boru=s.Fiyat(1)!;Assert.Equal(24m,boru.Perakende);Assert.True(boru.SatisKdvDahil);Assert.Equal(24m,boru.PerakendeKdvDahil);Assert.Equal(20m,boru.KdvOrani);
   var g2=s.Fiyat(2)!;Assert.Equal("USD",g2.ParaBirimi);Assert.Equal(1m,g2.KdvOrani);Assert.True(g2.AlisKdvDahil);
   Assert.Throws<ArgumentException>(()=>s.Kaydet([new(1,-1m,false,null,null,true,20m,"TRY")]));
   Assert.Throws<ArgumentException>(()=>s.Kaydet([new(1,1m,false,null,null,true,150m,"TRY")]));
   Assert.Throws<ArgumentException>(()=>s.Kaydet([new(99,1m,false,null,null,true,20m,"TRY")]));
   Assert.Equal(24m,s.Fiyat(1)!.Perakende);
   granted.Remove("STOCK.PRICE");Assert.Throws<UnauthorizedAccessException>(()=>s.Liste("",false));Assert.Throws<UnauthorizedAccessException>(()=>s.Kaydet([new(1,1m,false,null,null,true,20m,"TRY")]));
  }
  finally{SqlConnection.ClearAllPools();Sql(master,"ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]");}
 }
}
