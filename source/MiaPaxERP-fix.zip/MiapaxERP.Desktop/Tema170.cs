using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace MiapaxERP.Desktop;

public sealed record Tema170(string Zemin, string Yuzey, string Menu, string Vurgu, double Kose)
{
    public static GorunumTercihleri Mevcut { get; private set; } = new();
    /// <summary>Etkin görünüm koyu mu (Koyu tema veya Windows koyu moddayken Sistem teması).</summary>
    public static bool KoyuMu { get; private set; }
    public static string AnaSayfaDuzeni(GorunumTercihleri a) => a.AnaSayfaDuzeni != "Temaya göre" ? a.AnaSayfaDuzeni : a.Tema is "VIP" or "Eskitme" ? "Modül odaklı" : a.Tema is "Doğal" or "Kültürel" ? "Haber odaklı" : "Takvim odaklı";
    public static readonly string[] Adlar = ["Nane Cam", "Okyanus Cam", "Lavanta Cam", "Gün Batımı Cam", "Gece Cam", "VIP", "Modern", "Doğal", "Eskitme", "Kültürel", "Klasik", "Canlı", "Yenilikçi", "Varsayılan", "Açık", "Koyu", "Sistem"];
    public static string Yerlesim(GorunumTercihleri a) => a.Yerlesim != "Temaya göre" ? a.Yerlesim : a.Tema is "Modern" or "Yenilikçi" ? "Üst menü" : a.Tema == "Kültürel" ? "Sağ menü" : "Sol menü";
    public static string Yogunluk(GorunumTercihleri a) => a.Yogunluk != "Temaya göre" ? a.Yogunluk : a.Tema is "VIP" or "Doğal" || CamMi(a.Tema) ? "Ferah" : a.Tema is "Eskitme" or "Klasik" ? "Kompakt" : "Dengeli";
    public static Tema170 Sec(string ad) => ad switch
    {
        // Nane Cam: nane yeşilinden şeftaliye yumuşak degrade zemin, koyu yeşil yüzen menü, beyaz yuvarlak kartlar.
        "Nane Cam" => new("#E6F4EE","#FFFFFF","#123B31","#1F9D73",22),
        // Cam ailesi: aynı gösterge paneli düzeni (ince ikon menü, karşılama kartı, sağda takvim) farklı renk havalarında.
        "Okyanus Cam" => new("#E3F1FA","#FFFFFF","#0F2F4A","#1C7ED6",22),
        "Lavanta Cam" => new("#EFEAFB","#FFFFFF","#2D2251","#7B5CD6",22),
        "Gün Batımı Cam" => new("#FBEDE4","#FFFFFF","#4A2328","#E0703A",22),
        "Gece Cam" => new("#0D1B26","#16283A","#091521","#2CC69B",22),
        "VIP" => new("#F3F1EC","#FFFEFA","#1D252B","#8B652C",18),
        "Eskitme" => new("#E8DFCD","#F8F0DE","#44372E","#875D3B",2),
        "Kültürel" => new("#EAF2F1","#FFFCF5","#133E48","#A94935",7),
        "Doğal" => new("#EDF3EC","#FFFFFA","#244539","#237250",14),
        "Canlı" => new("#FFF4EE","#FFFCFA","#481F42","#B03F54",16),
        "Klasik" => new("#EFEEE9","#FFFEFA","#363C45","#475875",3),
        "Yenilikçi" => new("#F1EEFF","#FEFDFF","#2E2353","#6441BA",18),
        "Koyu" => new("#172333","#203044","#101A28","#366AC6",10),
        _ => new("#EDF3F8","#FFFFFF","#112C45","#0869A6",10)
    };
    /// <summary>Cam ailesi temaları (gösterge paneli düzeni: ince ikon menü, karşılama kartı, sağda takvim).</summary>
    public static bool CamMi(string? ad)=>ad is not null&&ad.EndsWith(" Cam",StringComparison.Ordinal);
    /// <summary>Cam temalarının degrade zemini: üç durak, sol üstten sağ alta.</summary>
    public static Brush CamZemin(string ad)
    {
        string[] d=ad switch{
            "Okyanus Cam"=>["#CFE6F7","#EAF3FA","#E7F6F2"],
            "Lavanta Cam"=>["#E2D9FA","#F3EFFB","#FBEDE6"],
            "Gün Batımı Cam"=>["#FBDCCB","#FBF0E8","#F3E6F2"],
            "Gece Cam"=>["#0B2A2A","#0E1C2A","#1A1530"],
            _=>["#CDEFE0","#EAF5F0","#F7EEE4"]};
        var g=new LinearGradientBrush{StartPoint=new System.Windows.Point(0,0),EndPoint=new System.Windows.Point(1,1)};
        g.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(d[0]),0));
        g.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(d[1]),.48));
        g.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(d[2]),1));
        g.Freeze();return g;
    }
    public static Brush NaneZemin()=>CamZemin("Nane Cam");
    public static Brush Firca(string value) => new SolidColorBrush((Color)ColorConverter.ConvertFromString(value));
    public static void Uygula(GorunumTercihleri tercih)
    {
        if(Application.Current is not {} app)return;
        Mevcut = tercih.Kopya();
        var renk = Sec(tercih.Tema);
        bool dark = tercih.Tema == "Koyu" || tercih.Tema == "Gece Cam" || tercih.Tema == "Sistem" && Convert.ToInt32(Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize","AppsUseLightTheme",1))==0;
        KoyuMu = dark;
        if(dark&&!CamMi(tercih.Tema)) renk=Sec("Koyu");
#pragma warning disable WPF0001 // .NET 10 yerleşik Fluent teması
        app.ThemeMode = dark ? ThemeMode.Dark : ThemeMode.Light;
#pragma warning restore WPF0001
        var r=app.Resources;
        bool cam=CamMi(tercih.Tema);
        r["ErpZemin"]=cam?CamZemin(tercih.Tema):Firca(renk.Zemin);
        // Cam temalarında kartlar buzlu cam gibi hafif saydamdır; degrade zemin hafifçe görünür.
        r["ErpKart"]=cam?Firca(dark?"#E6182A3C":"#EBFFFFFF"):Firca(renk.Yuzey);
        r["ErpMenu"]=Firca(renk.Menu);
        r["ErpVurgu"]=Firca(tercih.Vurgu=="#2563EB"?renk.Vurgu:tercih.Vurgu);
        r["ErpMetin"]=Firca(dark?"#F2F7FF":"#182E42");
        r["ErpCizgi"]=Firca(dark?"#435568":"#D4DEE6");
        r["ErpKose"]=new CornerRadius(tercih.Kose < 0 ? renk.Kose : tercih.Kose);
        r["ControlCornerRadius"]=new CornerRadius((tercih.Kose < 0 ? renk.Kose : tercih.Kose)/2);
        r["ErpFont"] = new FontFamily(tercih.YaziTipi);
        r["ErpBosluk"] = new Thickness(14, Yogunluk(tercih) == "Ferah" ? 12 : Yogunluk(tercih) == "Kompakt" ? 5 : 8,14,Yogunluk(tercih) == "Ferah" ? 12 : Yogunluk(tercih) == "Kompakt" ? 5 : 8);
        r["ErpSatir"] = Yogunluk(tercih) == "Ferah" ? 44d : Yogunluk(tercih) == "Kompakt" ? 28d : 36d;
        foreach (Window window in app.Windows) { TemaPencereServisi.Uygula(window); GorunumRenkleri.Uygula(window, tercih);TemaOkunurlugu.Uygula(window); }
        TemaOkunurlugu.HepsiniYenile();
    }
    public static Border Kart(UIElement child,string baslik)
    {
        var panel=new DockPanel();
        var text=new TextBlock{Text=baslik,FontSize=16,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,12)};
        text.SetResourceReference(TextBlock.ForegroundProperty,"ErpMetin");
        DockPanel.SetDock(text,Dock.Top);panel.Children.Add(text);panel.Children.Add(child);
        var b=new Border{Child=panel,Padding=new Thickness(16),Margin=new Thickness(0,0,10,0),BorderThickness=new Thickness(1)};
        b.SetResourceReference(Border.BackgroundProperty,"ErpKart");
        b.SetResourceReference(Border.BorderBrushProperty,"ErpCizgi");
        b.SetResourceReference(Border.CornerRadiusProperty,"ErpKose");
        return b;
    }
    public static Border Baslik(string modul,string baslik)
    {
        var stack=new StackPanel();
        stack.Children.Add(new TextBlock{Text=modul,FontSize=12,Foreground=Brushes.White,Opacity=.83});
        stack.Children.Add(new TextBlock{Text=baslik,FontSize=23,FontWeight=FontWeights.SemiBold,Foreground=Brushes.White,Margin=new Thickness(0,3,0,0)});
        var b=new Border{Child=stack,Padding=new Thickness(20,12,20,13),Margin=new Thickness(0,0,0,14)};
        b.SetResourceReference(Border.BackgroundProperty,"ErpMenu");b.SetResourceReference(Border.CornerRadiusProperty,"ErpKose");
        return b;
    }
}
