using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
namespace MiapaxERP.Desktop;

public sealed partial class KolayBaglantiPaneli : UserControl
{
    readonly ComboBox rol=new(){ItemsSource=new[]{"Ana sunucu","Yan PC","Mobil"},MinHeight=38};
    readonly TextBox address=new(){MinHeight=36,MaxLength=300},port=new(){MinHeight=36,MaxLength=5,Width=120,HorizontalAlignment=System.Windows.HorizontalAlignment.Left,Text="443"},ip=new(){MinHeight=36,MaxLength=15},code=new(){AcceptsReturn=true,MinHeight=80,TextWrapping=TextWrapping.Wrap,MaxLength=8192};
    readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,16,0,0)},info=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,14)};
    readonly StackPanel server=new(),root=new(){Margin=new Thickness(26),MaxWidth=800};
    readonly Window owner;bool busy;readonly CancellationTokenSource stop=new();
    string Rol=>rol.SelectedIndex switch{1=>"Yan",2=>"Mobil",_=>"Ana"};
    readonly StackPanel manual=new();
    public KolayBaglantiPaneli(Window owner,Action local)
    {
        this.owner=owner;Content=new ScrollViewer{Content=root,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        root.Children.Add(new TextBlock{Text="Bağlantı",FontSize=26,FontWeight=FontWeights.SemiBold});
        root.Children.Add(new TextBlock{Text="Tek düğmeye basın: program işyerindeki ana sunucuyu arar, panodaki bağlantı kodunu okur, adresi ve portu doğrular, bağlantıyı kurar. Şehir dışındaysanız önce yöneticinizin gönderdiği bağlantı kodunu kopyalayın.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,16)});
        var auto=new Button{Content="🤖  Yapay zekâ ile otomatik bağlan",FontSize=17,FontWeight=FontWeights.SemiBold,Padding=new Thickness(18,12,18,12),HorizontalAlignment=System.Windows.HorizontalAlignment.Left,Background=new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x25,0x63,0xEB)),Foreground=System.Windows.Media.Brushes.White,BorderThickness=new Thickness(0)};
        root.Children.Add(auto);
        auto.Click+=async(_,_)=>{if(busy)return;busy=true;auto.IsEnabled=false;try{await OtomatikBaglan();}catch(OperationCanceledException){status.Text="İşlem iptal edildi.";}catch(Exception e){status.Text=e.Message;await YapayZekayaSorOneri();}finally{busy=false;auto.IsEnabled=true;}};
        status.FontSize=14;root.Children.Add(status);
        root.Children.Add(new Expander{Header="Manuel bağlantı",Content=manual,Margin=new Thickness(0,22,0,0),IsExpanded=false,FontWeight=FontWeights.SemiBold});
        var m=manual;m.Margin=new Thickness(0,8,0,0);
        Field(m,"Bu cihaz",rol);m.Children.Add(info);
        Field(m,"Sunucunun HTTPS adresi",address);m.Children.Add(new TextBlock{Text="Örnek: https://erp.firmaniz.com (portu buraya yazmayın)",FontWeight=FontWeights.Normal,Margin=new Thickness(0,4,0,0)});
        Field(m,"Port",port);m.Children.Add(new TextBlock{Text="Varsayılan 443. Modemde farklı bir dış port yönlendirdiyseniz (ör. 9443) buraya yazın; program ve telefon bağlantıyı bu porttan kurar.",TextWrapping=TextWrapping.Wrap,FontWeight=FontWeights.Normal,Margin=new Thickness(0,4,0,10)});
        Field(server,"Sabit dış IP",ip);var setup=new WrapPanel();server.Children.Add(setup);
        Button(setup,"HTTPS sunucusunu hazırla",Hazirla);Button(setup,"Yerel veritabanı ayarları",local);
        m.Children.Add(server);
        var actions=new WrapPanel();m.Children.Add(actions);
        Button(actions,"Kaydet",()=>{Profil().Kaydet();status.Text="Bağlantı adresi kaydedildi.";});
        AsyncButton(actions,"Bağlantıyı kontrol et",async()=>{var p=Profil();p.Dogrula(true);status.Text="Bağlantı kontrol ediliyor…";status.Text=(await Kontrol(TamAdres(),Rol=="Ana"?ip.Text.Trim():"")).Mesaj;});
        Button(actions,"Programa bağlan",ProgramaBaglan);
        AkilliKurulumuEkle(actions);
        Field(m,"Bağlantı kodu",code);var shares=new WrapPanel();m.Children.Add(shares);
        Button(shares,"Kod oluştur",()=>code.Text=Profil().PaylasimKodu());
        Button(shares,"Kopyala",()=>{if(code.Text.Length==0)throw new ArgumentException("Önce kod oluşturun.");Clipboard.SetText(code.Text);status.Text="Adres kodu kopyalandı. Kod giriş yetkisi veya parola içermez.";});
        Button(shares,"Kodu uygula",()=>{var p=KolayBaglantiProfili.KoduOku(code.Text.Trim(),Rol);AdresiGoster(Rol=="Mobil"&&p.MobilHttps.Length>0?p.MobilHttps:p.MasaustuHttps);status.Text="Sunucu adresi alındı. Firmanızın adresiyle karşılaştırıp kaydedin.";});
        m.Children.Add(new TextBlock{Text="Ana sunucu açık ve internete bağlı kalmalı. DNS kaydı sabit dış IP'yi göstermeli; modemde 80 ve yukarıdaki port ana sunucuya yönlenmeli. SQL portunu internete açmayın.",TextWrapping=TextWrapping.Wrap,FontWeight=FontWeights.Normal,Margin=new Thickness(0,20,0,0),FontSize=12});
        rol.SelectionChanged+=(_,_)=>{server.Visibility=Rol=="Ana"?Visibility.Visible:Visibility.Collapsed;info.Text=Rol switch{"Ana"=>"Yerel veritabanı bilgileri yalnız bu bilgisayarda tutulur. PC ve telefon için tek HTTPS adresi hazırlayın.","Yan"=>"Program bu bilgisayarda açılır. İşlemler ana sunucuya güvenli bağlantıyla gönderilir. ERP kullanıcı adınız ve şifrenizle giriş yapın.",_=>"Telefondaki MiaPaxERP uygulaması aynı HTTPS adresine ve porta bağlanır. Her çalışan kendi eşleme kodunu kullanır."};};
        try{var p=KolayBaglantiProfili.Oku();AdresiGoster(p.MasaustuHttps.Length>0?p.MasaustuHttps:p.MobilHttps);ip.Text=p.SabitDisIp;rol.SelectedIndex=p.Rol switch{"Yan"=>1,"Mobil"=>2,_=>0};}catch(Exception e)when(e is IOException or System.Text.Json.JsonException or ArgumentException or UnauthorizedAccessException){rol.SelectedIndex=0;status.Text="Kayıtlı adres okunamadı. Otomatik bağlanmayı deneyin veya manuel bağlantıdan adresi girin.";}
        owner.Closed+=(_,_)=>stop.Cancel();
    }
    async Task<KolayKontrolSonucu> Kontrol(string url,string disIp)
    {
        var dns=await KolayBaglantiKontrolu.Dns(url,disIp,true,stop.Token);if(!dns.Basarili)return dns;
        var https=await KolayBaglantiKontrolu.Https(url,true,stop.Token);return new(https.Basarili,dns.Mesaj+"\n\n"+https.Mesaj);
    }
    void ProgramaBaglan()
    {
        if(Rol=="Ana"){status.Text="Ana sunucuda mevcut yerel ERP hesabınızla çalışın. Diğer cihazlara bağlantı kodunu verin.";return;}
        Profil().Kaydet();
        if(Rol=="Mobil"){status.Text="Android uygulamasında bu bağlantı kodunu kullanın. Yöneticinizin verdiği kişisel eşleme koduyla giriş yapın.";return;}
        if(Application.Current.MainWindow is MainWindow)
        {
            var start=new ProcessStartInfo(Environment.ProcessPath!){UseShellExecute=true};start.ArgumentList.Add("--https-client");Process.Start(start);
        }
        owner.DialogResult=true;
    }
    /// <summary>
    /// Tek düğmeli bağlantı: bağlantı kodu (kutu veya pano) → işyeri ağında ana sunucu → kayıtlı adres sırasıyla dener,
    /// adresi/portu DNS ve HTTPS ile doğrular, kaydeder ve bağlanır. Başarısızlıkta yapılandırılmış yapay zekâdan açıklama ister.
    /// Parola, SQL bilgisi veya lisans anahtarı hiçbir yere gönderilmez.
    /// </summary>
    async Task OtomatikBaglan()
    {
        status.Text="1/3 Bağlantı kodu aranıyor…";
        string kod=code.Text.Trim();
        if(!kod.StartsWith("MPX-CONNECT1:",StringComparison.Ordinal))try{if(Clipboard.ContainsText()){var c=Clipboard.GetText().Trim();if(c.StartsWith("MPX-CONNECT1:",StringComparison.Ordinal)&&c.Length<=8192)kod=c;}}catch(System.Runtime.InteropServices.ExternalException){}
        string? adres=null,kaynak=null;
        if(kod.StartsWith("MPX-CONNECT1:",StringComparison.Ordinal)){var p=KolayBaglantiProfili.KoduOku(kod,"Yan");adres=p.MasaustuHttps.Length>0?p.MasaustuHttps:p.MobilHttps;kaynak="bağlantı kodu";}
        if(adres is null)
        {
            status.Text="2/3 İşyeri ağında MiaPaxERP ana sunucusu aranıyor…";
            var found=(await HttpsAgKesfi.Bul(stop.Token)).Where(x=>x.SqlHazir).ToArray();
            var self=found.FirstOrDefault(x=>string.Equals(x.Bilgisayar,Environment.MachineName,StringComparison.OrdinalIgnoreCase));
            if(self is not null&&found.Length==1){await AnaSunucuHazirla(self.Adres);return;}
            var others=found.Where(x=>x!=self&&!string.IsNullOrWhiteSpace(x.Adres)).ToArray();
            if(others.Length>1)throw new InvalidOperationException("Ağda birden fazla ana sunucu bulundu: "+string.Join(" · ",others.Select(x=>x.Bilgisayar))+". Doğru işyerinin bağlantı kodunu kopyalayıp tekrar deneyin.");
            if(others.Length==1){adres=others[0].Adres;kaynak=others[0].Bilgisayar+" ana sunucusu";}
            else if(found.Any(x=>x!=self&&string.IsNullOrWhiteSpace(x.Adres)))throw new InvalidOperationException("Ana bilgisayar bulundu fakat HTTPS sunucusu hazır değil. Ana bilgisayarda bu düğmeye bir kez basın veya Manuel bağlantı → HTTPS sunucusunu hazırla adımını tamamlayın.");
        }
        if(adres is null){var old=KolayBaglantiProfili.Oku();if(old.Rol=="Yan"&&old.MasaustuHttps.Length>0){adres=old.MasaustuHttps;kaynak="kayıtlı adres";}}
        if(adres is null)throw new InvalidOperationException("Ana sunucu bulunamadı. İşyerindeyseniz ana bilgisayarın ve MiaPaxERP'nin açık olduğunu kontrol edin. Şehir dışındaysanız yöneticinizden bağlantı kodunu (MPX-CONNECT1: ile başlar) alıp kopyalayın ve tekrar basın.");
        status.Text="3/3 "+kaynak+" doğrulanıyor: "+adres+" …";
        var check=await Kontrol(adres,"");
        if(!check.Basarili)throw new InvalidOperationException("Sunucu bulundu ("+kaynak+") fakat bağlantı doğrulanamadı; ayarlar değiştirilmedi.\n"+check.Mesaj);
        AdresiGoster(adres);rol.SelectedIndex=1;Profil().Kaydet();
        status.Text="✓ Bağlantı hazır: "+adres+" ("+kaynak+"). Program ana sunucuya bağlanıyor; kendi kullanıcı adınız ve şifrenizle giriş yapın.";
        ProgramaBaglan();
    }
    async Task AnaSunucuHazirla(string kayitliAdres)
    {
        var p=KolayBaglantiProfili.Oku();string adres=kayitliAdres.Length>0?kayitliAdres:p.MasaustuHttps;
        rol.SelectedIndex=0;
        if(adres.Length==0){manual.Parent?.SetValue(Expander.IsExpandedProperty,true);status.Text="Bu bilgisayar ana sunucu. Diğer cihazların bağlanabilmesi için bir kez HTTPS adresi gerekir: Manuel bağlantı bölümünde alan adını, portu ve sabit dış IP'yi girip 'HTTPS sunucusunu hazırla' düğmesine basın.";return;}
        AdresiGoster(adres);status.Text="Bu bilgisayar ana sunucu. HTTPS adresi doğrulanıyor…";
        var check=await Kontrol(adres,p.SabitDisIp);
        code.Text=new KolayBaglantiProfili{Rol="Ana",MasaustuHttps=adres,MobilHttps=adres}.PaylasimKodu();
        try{Clipboard.SetText(code.Text);}catch(System.Runtime.InteropServices.ExternalException){}
        status.Text=(check.Basarili?"✓ Ana sunucu hazır. ":"Ana sunucu bulundu fakat dışarıdan erişim doğrulanamadı: "+check.Mesaj+"\n")+"Diğer bilgisayar ve telefonlar için bağlantı kodu panoya kopyalandı. Kodu gönderin; orada da bu düğmeye basmaları yeterli.";
    }
    async Task YapayZekayaSorOneri()
    {
        string file=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","Baglanti","asistan.json");
        AsistanAyari setting;try{setting=AsistanAyari.Oku(file);}catch(Exception e)when(e is IOException or System.Text.Json.JsonException or UnauthorizedAccessException or ArgumentException){return;}
        if(setting.Tur=="Yerleşik rehber"){status.Text+="\n\nAyrıntılı açıklama için Manuel bağlantı → Yapay zekâ bağlantısı bölümünden bir yapay zekâ sunucusu tanımlayabilirsiniz.";return;}
        if(MessageBox.Show(owner,"Bağlantı sonucu ve sunucu adresi şu yapay zekâ sunucusuna gönderilip çözüm önerisi istensin mi?\n"+setting.Adres+"\nSQL parolası veya lisans anahtarı gönderilmez.","Yapay zekâ bağlantı yardımı",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;
        string diagnostic=status.Text;status.Text+="\n\nYapay zekâ çözüm önerisi hazırlıyor…";
        var reply=await new AsistanIstemcisi().SorAsync(setting,"MiaPaxERP otomatik bağlantısı başarısız oldu. Sonucu normal bir kullanıcıya açıklayıp en fazla üç sonraki adımı öner. Sertifika doğrulamasını kapatmayı veya SQL portunu internete açmayı önerme. Sonuç: "+diagnostic,"Ağ kurulum asistanı",[],stop.Token);
        status.Text=diagnostic+"\n\nYapay zekâ önerisi:\n"+(reply.Metin??reply.Durum);
    }
    string TamAdres()=>KolayBaglantiProfili.Birlestir(address.Text,port.Text);
    void AdresiGoster(string url){var (a,p)=KolayBaglantiProfili.Ayir(url);address.Text=a;port.Text=p;}
    KolayBaglantiProfili Profil()
    {
        string url=TamAdres();
        return new(){Rol=Rol,SabitDisIp=Rol=="Ana"?ip.Text.Trim():"",MasaustuHttps=url,MobilHttps=url};
    }
    static void Field(Panel p,string label,Control c){p.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,12,0,5)});p.Children.Add(c);}
    void Button(Panel p,string label,Action action){var b=new Button{Content=label,Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,10,8,0)};p.Children.Add(b);b.Click+=(_,_)=>{if(busy)return;try{action();}catch(Exception e){status.Text=e.Message;}};}
    void AsyncButton(Panel p,string label,Func<Task> action){var b=new Button{Content=label,Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,10,8,0)};p.Children.Add(b);b.Click+=async(_,_)=>{if(busy)return;busy=true;b.IsEnabled=false;try{await action();}catch(OperationCanceledException){status.Text="Kontrol iptal edildi.";}catch(Exception e){status.Text=e.Message;}finally{busy=false;b.IsEnabled=true;}};}
    void Hazirla()
    {
        var p=Profil();p.Dogrula(true);p.Kaydet();var exe=SunucuAraciBul()??throw new FileNotFoundException("Tam kurulum paketindeki MobilKurulum / Sunucu klasörü bulunamadı.");
        var start=new ProcessStartInfo(exe){UseShellExecute=true,Verb="runas",WorkingDirectory=Path.GetDirectoryName(exe)!};start.ArgumentList.Add("setup");start.ArgumentList.Add(p.MasaustuHttps);Process.Start(start);
        status.Text="Ana sunucu kurulum penceresi açıldı. Veritabanı ve lisans bilgilerini bu pencerede girin.";
    }
    public static string? SunucuAraciBul()=>new[]{Path.Combine(AppContext.BaseDirectory,"MobilKurulum","Sunucu","MiapaxERP.MobileServer.exe"),Path.Combine(AppContext.BaseDirectory,"..","MobilKurulum","Sunucu","MiapaxERP.MobileServer.exe")}.Select(Path.GetFullPath).FirstOrDefault(File.Exists);
}
public static class KolayKurulumRehberi
{
    public static string Metin(KolayBaglantiProfili p)=>$"MiaPaxERP HTTPS kurulumu\nSunucu: {p.MasaustuHttps}\nSabit dış IP: {p.SabitDisIp}\n\n1. DNS A kaydını sabit dış IP'ye yönlendirin.\n2. Modemde TCP 80 ve HTTPS portunu (genellikle 443) ana bilgisayara yönlendirin. SQL portunu internete açmayın.\n3. Ana sunucu panelinden HTTPS sunucusunu hazırlayın.\n4. Yan PC'de sunucu adresini veya adres kodunu girip ERP hesabınızla giriş yapın.\n5. Android uygulamasında aynı adresi ve kişisel eşleme kodunu kullanın.\n6. Farklı internet bağlantısından bağlantıyı doğrulayın.\n";
}
