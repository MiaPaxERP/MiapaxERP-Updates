// MiaPaxERP sektör kataloğu (katalog sürümü 2).
// Program tarafındaki MiapaxERP.Lisans.Core/LisansSozlesmesi.cs ile aynı kodları içermelidir.
// 2.8.x ve öncesi istemciler yalnız LEGACY_SECTORS kodlarını tanır; bu istemcilere imzalanan
// lisansta sektör "legacy" karşılığına çevrilir. Böylece eski kurulumlar yeni kodlarla bozulmaz.
export const SECTOR_CATALOG_VERSION=2;
export const LEGACY_SECTORS=['BORU','YEDEK','RESTORAN','SUNGER','GENEL'];
export const sectorGroups=[['URETIM','Üretim'],['TICARET','Ticaret'],['YEMEICME','Yeme-içme'],['HIZMET','Hizmet ve diğer']];
const s=(code,name,group,legacy,modules,branches,description)=>({code,name,group,legacy,modules,branches,description});
export const sectorCatalog=[
 s('BORU','Boru ve plastik profil üretimi','URETIM','BORU',['STOK','URETIM','SATIS','FINANS','KROKI','RAPOR'],['PE / PPRC boru','Damla sulama','Profil ve hortum'],'Metre, adet ve KG kendi stok birimleriyle izlenir; paketleme ve sulama projeleri.'),
 s('SUNGER','Sünger ve köpük üretimi','URETIM','SUNGER',['STOK','URETIM','SATIS','FINANS','RAPOR'],['Yatak / döşeme süngeri','Kesim ve levha','Ambalaj köpüğü'],'KG, M3, M2 ve adet dönüşümleri yalnız açık reçete verisiyle yapılır.'),
 s('PLASTIK','Plastik ve ambalaj üretimi','URETIM','GENEL',['STOK','URETIM','SATIS','FINANS','SATINALMA','LABORATUVAR','RAPOR'],['Enjeksiyon','Şişirme','Film ve poşet','Ambalaj'],'Granül tüketimi, kalıp / makine bazlı üretim emirleri ve kalite kontrol.'),
 s('GIDA','Gıda üretimi','URETIM','GENEL',['STOK','URETIM','SATIS','FINANS','SATINALMA','LABORATUVAR','RAPOR'],['Unlu mamul','Süt ürünleri','Et ürünleri','Konserve / kuru gıda','İçecek'],'Parti ve son kullanma takibi, reçeteli tüketim ve kalite kayıtları.'),
 s('TEKSTIL','Tekstil ve konfeksiyon','URETIM','GENEL',['STOK','URETIM','SATIS','FINANS','SATINALMA','IK','RAPOR'],['Hazır giyim','Ev tekstili','Kumaş / iplik','Fason üretim'],'Kumaş metre, beden-renk varyantı, kesim-dikim emirleri ve fason işçilik.'),
 s('METAL','Metal işleme ve makine imalatı','URETIM','GENEL',['STOK','URETIM','SATIS','FINANS','SATINALMA','RAPOR'],['Talaşlı imalat','Sac işleme','Kaynaklı imalat','Makine imalatı'],'Sac, profil ve parça tüketimi; iş emri ve makine süresi takibi.'),
 s('MOBILYA','Mobilya ve ahşap','URETIM','GENEL',['STOK','URETIM','SATIS','FINANS','SATINALMA','RAPOR'],['Ev mobilyası','Ofis mobilyası','Mutfak / dolap','Ahşap doğrama'],'Levha, kenar bandı ve aksesuar tüketimiyle ürün reçetesi.'),
 s('KIMYA','Kimya, boya ve temizlik ürünleri','URETIM','GENEL',['STOK','URETIM','SATIS','FINANS','SATINALMA','LABORATUVAR','RAPOR'],['Boya / vernik','Temizlik ürünleri','Kozmetik','Gübre / tarım kimyasalı'],'Formül bazlı parti üretimi, ambalajlama ve kalite kontrol.'),
 s('YAPIURETIM','Yapı malzemesi üretimi','URETIM','GENEL',['STOK','URETIM','SATIS','FINANS','LABORATUVAR','RAPOR'],['Hazır beton','Briket / parke taşı','Prefabrik','Çatı / yalıtım'],'Parti üretimi, numune / dayanım kayıtları ve sevkiyat.'),
 s('YEDEK','Yedek parça ticareti','TICARET','YEDEK',['STOK','SATIS','FINANS','SATINALMA','RAPOR'],['Otomotiv','İş makinesi','Tarım makinesi','Beyaz eşya'],'Parça kodu, muadil ve birim bazında stok, alış ve satış.'),
 s('TOPTAN','Toptan ticaret ve dağıtım','TICARET','GENEL',['STOK','SATIS','FINANS','SATINALMA','CRM','MOBIL','RAPOR'],['Gıda toptan','Kırtasiye / ambalaj','Elektrik / elektronik','Hırdavat'],'Çok depolu stok, müşteri fiyat listeleri, saha satışı ve sevkiyat.'),
 s('PERAKENDE','Perakende ve market','TICARET','GENEL',['STOK','SATIS','FINANS','SATINALMA','RAPOR'],['Market / bakkal','Giyim mağazası','Elektronik','Kırtasiye / kitap'],'Barkodlu hızlı satış, kasa, raf ve stok sayımı.'),
 s('YAPIMARKET','Yapı ve inşaat malzemesi ticareti','TICARET','GENEL',['STOK','SATIS','FINANS','SATINALMA','RAPOR'],['Nalbur / hırdavat','Seramik / vitrifiye','Demir / çimento','Boya / yalıtım'],'Ton, M2 ve torba gibi farklı birimlerle stok; şantiye teslimatı.'),
 s('ONLINE','E-ticaret satıcısı','TICARET','GENEL',['STOK','SATIS','FINANS','ETICARET','RAPOR'],['Pazaryeri satıcısı','Kendi web mağazası','Sosyal medya satışı'],'Web sitesi ve pazaryeri siparişleri, stok eşitleme ve kargo.'),
 s('RESTORAN','Restoran ve lokanta','YEMEICME','RESTORAN',['STOK','URETIM','SATIS','FINANS','RESTORAN','RAPOR'],['Restoran','Esnaf lokantası','Fast food'],'Masa, adisyon, mutfak, ödeme ve reçeteli tüketim.'),
 s('KAFE','Kafe ve kahve dükkânı','YEMEICME','RESTORAN',['STOK','URETIM','SATIS','FINANS','RESTORAN','RAPOR'],['Kafe','Kahve dükkânı','Pastane-kafe','Bar'],'Masa / paket sipariş, adisyon ve menü reçeteleriyle malzeme tüketimi.'),
 s('FIRIN','Fırın ve pastane','YEMEICME','GENEL',['STOK','URETIM','SATIS','FINANS','SATINALMA','RAPOR'],['Ekmek fırını','Pastane','Unlu mamul imalathanesi'],'Günlük üretim planı, reçeteli un-malzeme tüketimi ve tezgâh satışı.'),
 s('CATERING','Catering ve toplu yemek','YEMEICME','GENEL',['STOK','URETIM','SATIS','FINANS','SATINALMA','RAPOR'],['Kurumsal yemek','Okul / hastane mutfağı','Organizasyon'],'Kurum sözleşmeleri, günlük porsiyon planı ve porsiyon maliyeti.'),
 s('SERVIS','Teknik servis ve tamir','HIZMET','GENEL',['STOK','SATIS','FINANS','CRM','MOBIL','RAPOR'],['Beyaz eşya / elektronik','Oto servis','Klima / ısıtma','Bilgisayar / telefon'],'Servis kaydı, parça kullanımı, işçilik ve tahsilat.'),
 s('TARIM','Tarım ve sulama','HIZMET','GENEL',['STOK','SATIS','FINANS','KROKI','CRM','MOBIL','RAPOR'],['Sulama sistemleri','Tarım girdileri','Sera','Peyzaj'],'Sulama projeleri, kroki, saha ziyaretleri ve malzeme teklifleri.'),
 s('INSAAT','İnşaat ve taahhüt','HIZMET','GENEL',['STOK','SATIS','FINANS','SATINALMA','IK','RAPOR'],['Konut','Altyapı','Tadilat / dekorasyon','Elektrik / mekanik taahhüt'],'Şantiye bazlı malzeme, taşeron ve hakediş takibi.'),
 s('LOJISTIK','Lojistik ve nakliye','HIZMET','GENEL',['STOK','SATIS','FINANS','IK','MOBIL','RAPOR'],['Yurt içi nakliye','Depolama','Kurye','Uluslararası taşımacılık'],'Sefer, araç, sürücü ve depo hareketleri.'),
 s('GENEL','Genel KOBİ / işletme','HIZMET','GENEL',['STOK','SATIS','FINANS','RAPOR'],['Hizmet işletmesi','Danışmanlık','Diğer'],'Sektör bağımsız stok, cari, satış ve muhasebe.')
];
export const sectors=sectorCatalog.map(x=>[x.code,x.name]);
export const isSector=code=>sectorCatalog.some(x=>x.code===code);
// İstemci katalog sürümüne göre imzalanacak sektör kodu.
export function sectorForClient(code,catalog){const sector=sectorCatalog.find(x=>x.code===code);if(!sector)return 'GENEL';return Number(catalog)>=SECTOR_CATALOG_VERSION?sector.code:(LEGACY_SECTORS.includes(sector.code)?sector.code:sector.legacy);}
