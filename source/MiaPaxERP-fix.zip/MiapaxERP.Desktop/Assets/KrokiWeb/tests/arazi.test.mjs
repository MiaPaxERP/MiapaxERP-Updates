import test from 'node:test';
import assert from 'node:assert/strict';
import * as M from '../js/arazi-model.mjs';

test('yerel koordinat ↔ enlem/boylam gidiş-dönüş', () => {
  const g = { lat: 38.36, lng: 35.5 }, p = { x: 120, y: -80 };
  const b = M.fromLatLng(M.toLatLng(p, g), g);
  assert.ok(Math.abs(b.x - 120) < 1e-6 && Math.abs(b.y + 80) < 1e-6);
});

test('otomatik yerleşim hatları tarla içinde tutar ve malzeme üretir', () => {
  const s = M.empty(); s.geo = { lat: 38.36, lng: 35.5 }; s.boundary = M.rectangle(100, 200);
  s.items = [{ id: 'k', type: 'source', p: { x: 0, y: 130 }, kind: 'well', depth: 60 }];
  const r = M.autoLayout(s, { method: 'drip', accessories: ['filter', 'pump'] });
  const lats = r.items.filter(i => i.type === 'lateral');
  assert.ok(lats.length > 50);
  assert.ok(lats.every(l => l.points.every(q => Math.abs(q.x) <= 50.01 && Math.abs(q.y) <= 100.01)));
  s.items = r.items;
  const bom = M.materials(s, {});
  assert.ok(bom.some(b => b.group === 'Ana hat' && b.unit === 'm'));
  assert.ok(bom.some(b => /pompa/i.test(b.name)));
  assert.ok(bom.some(b => /kuyu içi/.test(b.name)));
  assert.ok(M.hydraulics(s).head > 60, 'basma yüksekliği kuyu derinliğini içermeli');
});

test('elle çizilen öğeler: dirsek ve bağlı hat sayımı', () => {
  const s = M.empty(); s.geo = { lat: 39, lng: 35 }; s.boundary = M.rectangle(50, 50);
  s.items = [
    { id: 'm', type: 'main', od: 63, points: [{ x: -40, y: 0 }, { x: -25, y: 0 }, { x: -25, y: 20 }] },
    { id: 'l1', type: 'lateral', od: 16, drip: true, emitterGap: 0.5, emitterFlow: 2, points: [{ x: -25, y: 10 }, { x: 20, y: 10 }] },
    { id: 'f', type: 'fitting', kind: 'valve', od: 63, p: { x: -25, y: 5 }, manual: true }
  ];
  const bom = M.materials(s, {});
  assert.equal(bom.find(b => b.name === 'Dirsek 90°')?.qty, 1);
  assert.equal(bom.find(b => b.name === 'Vana')?.qty, 1);
  assert.equal(bom.find(b => /Damlatıcı/.test(b.name))?.qty, 90);
});

test('toprak tekstürü ve sulama ihtiyacı', () => {
  assert.equal(M.texture(20, 45, 35), 'Kil');
  assert.equal(M.texture(40, 20, 40), 'Tın');
  assert.equal(M.texture(90, 3, 7), 'Kum');
  const a = M.irrigationAdvice({ et0: 6, rain: 0, cropName: 'mısır', areaM2: 10000, texture: 'Tın', method: 'drip' });
  assert.ok(Math.abs(a.etc - 7.2) < 0.01);
  assert.ok(Math.abs(a.dailyM3 - 80) < 1);
  assert.equal(M.irrigationAdvice({ et0: 2, rain: 10, cropName: 'buğday', areaM2: 1000, texture: 'Tın', method: 'sprinkler' }).need, 0);
});

test('dışarıdan gelen proje dosyası temizlenir', () => {
  const c = M.clean({ items: [{ type: 'x' }, { type: 'main', points: [{ x: 0, y: 0 }] }, { type: 'head', p: { x: 1, y: 1 }, flow: 99 }], boundary: [{ x: 'a' }], name: '<b>' });
  assert.equal(c.items.length, 1);
  assert.equal(c.items[0].flow, 50);
  assert.equal(c.boundary.length, 0);
  assert.ok(!c.name.includes('<'));
});
