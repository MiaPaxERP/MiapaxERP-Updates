using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
namespace MiapaxERP.Desktop;

/// <summary>Makine yönetimi: her makine için canlı kart (durum, hız, sayaç, sıcaklık…), geçmiş grafiği ve bağlantı düzenleme.</summary>
public sealed class MakinePaneli:UserControl
{
 sealed class Canli{public MakineTanimi Makine=null!;public MakineOkuyucu Okuyucu=null!;public MakineOkumaSonucu? Son;public readonly Queue<double> Gecmis=new();public DateTime SonrakiOkuma;public bool Okunuyor;public Border Kart=null!;}
 static readonly CultureInfo tr=CultureInfo.GetCultureInfo("tr-TR");
 readonly string connection;readonly int user;readonly MakineServisi service;
 readonly WrapPanel kartlar=new();readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,6,0,8)};
 readonly DispatcherTimer saat=new(){Interval=TimeSpan.FromMilliseconds(500)};readonly CancellationTokenSource stop=new();
 readonly List<Canli> canlilar=[];bool yonetebilir;

 public MakinePaneli(string connection,int user,bool yonetebilir)
 {
  this.connection=connection;this.user=user;this.yonetebilir=yonetebilir;service=new(connection,user);
  var root=new DockPanel{Margin=new Thickness(22)};Content=root;
  var top=new StackPanel();DockPanel.SetDock(top,Dock.Top);root.Children.Add(top);
  top.Children.Add(new TextBlock{Text="MAKİNE YÖNETİMİ · CANLI ÜRETİM",FontSize=24,FontWeight=FontWeights.Bold});
  top.Children.Add(new TextBlock{Text="Makine firmasından aldığınız bağlantı bilgisini (OPC UA, Modbus TCP, MQTT veya HTTP/JSON) girin. Bu bilgisayar makinelerle aynı ağdaysa durum, hız, sayaç ve diğer değerler anlık görünür. Kartın üzerine tıklayınca ayrıntı açılır.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,10)});
  var bar=new WrapPanel();top.Children.Add(bar);
  if(yonetebilir){Btn(bar,"+ Makine ekle",()=>Duzenle(null));}
  Btn(bar,"Listeyi yenile",()=>_=Yukle());
  top.Children.Add(status);
  root.Children.Add(new ScrollViewer{Content=kartlar,VerticalScrollBarVisibility=ScrollBarVisibility.Auto});
  saat.Tick+=(_,_)=>Tik();
  Loaded+=async(_,_)=>{await Yukle();saat.Start();};
  Unloaded+=async(_,_)=>{saat.Stop();stop.Cancel();foreach(var c in canlilar)await c.Okuyucu.DisposeAsync();canlilar.Clear();};
 }

 async Task Yukle(){
  try{
   var list=await Task.Run(service.Liste);
   foreach(var c in canlilar)await c.Okuyucu.DisposeAsync();canlilar.Clear();kartlar.Children.Clear();
   foreach(var m in list.Where(x=>x.Aktif)){var c=new Canli{Makine=m,Okuyucu=new MakineOkuyucu(m),SonrakiOkuma=DateTime.UtcNow};c.Kart=KartOlustur(c);canlilar.Add(c);kartlar.Children.Add(c.Kart);}
   status.Text=list.Length==0?(yonetebilir?"Henüz makine yok. '+ Makine ekle' ile başlayın.":"Henüz makine tanımlanmamış. Yetkili kullanıcıdan makine eklemesini isteyin."):canlilar.Count+" makine izleniyor"+(list.Length>canlilar.Count?" · "+(list.Length-canlilar.Count)+" pasif":"")+".";
  }catch(Exception e){DestekIzleme.Bildir(e,"MAKINA");status.Text=e.Message;}
 }

 void Tik(){
  var now=DateTime.UtcNow;
  foreach(var c in canlilar.Where(x=>!x.Okunuyor&&x.SonrakiOkuma<=now)){
   c.Okunuyor=true;c.SonrakiOkuma=now.AddSeconds(Math.Max(1,c.Makine.OkumaSaniye));
   _=Task.Run(async()=>{try{return await c.Okuyucu.OkuAsync(stop.Token);}catch(OperationCanceledException){return null;}}).ContinueWith(t=>Dispatcher.BeginInvoke(()=>{c.Okunuyor=false;if(t.Result is { } r){c.Son=r;Gecmise(c,r);KartGuncelle(c);}}),TaskScheduler.Default);
  }
 }
 static void Gecmise(Canli c,MakineOkumaSonucu r){
  var ana=c.Makine.Alanlar.FirstOrDefault(a=>a.Rol=="Hiz")??c.Makine.Alanlar.FirstOrDefault(a=>a.Rol!="Durum");
  if(ana is null||!r.Basarili||r.Degerler.GetValueOrDefault(ana.Ad) is not double v)return;
  c.Gecmis.Enqueue(v);while(c.Gecmis.Count>120)c.Gecmis.Dequeue();
 }

 public static (string Metin,Color Renk) Durum(MakineTanimi m,MakineOkumaSonucu? r){
  if(r is null)return ("Bağlanıyor…",Colors.SlateGray);
  if(!r.Basarili)return ("Bağlantı yok",Color.FromRgb(0x6B,0x72,0x80));
  var alan=m.Alanlar.FirstOrDefault(a=>a.Rol=="Durum");
  if(alan is null||r.Degerler.GetValueOrDefault(alan.Ad) is not double v){var hiz=m.Alanlar.FirstOrDefault(a=>a.Rol=="Hiz");return hiz is not null&&r.Degerler.GetValueOrDefault(hiz.Ad) is double h?(h>0?("Çalışıyor",Color.FromRgb(0x16,0xA3,0x4A)):("Duruyor",Color.FromRgb(0xD9,0x77,0x06))):("Veri alınıyor",Color.FromRgb(0x25,0x63,0xEB));}
  string metin=DurumMetni(alan.Esleme,v);
  string k=metin.ToLowerInvariant();
  var renk=k.Contains("arıza")||k.Contains("alarm")||k.Contains("hata")?Color.FromRgb(0xDC,0x26,0x26):k.Contains("çalış")||k.Contains("üretim")?Color.FromRgb(0x16,0xA3,0x4A):k.Contains("bakım")?Color.FromRgb(0x7C,0x3A,0xED):Color.FromRgb(0xD9,0x77,0x06);
  return (metin,renk);
 }
 /// <summary>"0=Durdu;1=Çalışıyor;2=Arıza" eşlemesi; eşleme yoksa 0=Duruyor, 1=Çalışıyor, diğer=Arıza.</summary>
 public static string DurumMetni(string esleme,double v){
  foreach(var p in (esleme??"").Split(';',StringSplitOptions.RemoveEmptyEntries)){var kv=p.Split('=',2);if(kv.Length==2&&double.TryParse(kv[0].Trim(),NumberStyles.Float,CultureInfo.InvariantCulture,out double k)&&Math.Abs(k-v)<1e-9)return kv[1].Trim();}
  return v switch{0=>"Duruyor",1=>"Çalışıyor",_=>"Arıza ("+v.ToString("0.##",tr)+")"};
 }

 Border KartOlustur(Canli c){
  var b=new Border{Width=330,Margin=new Thickness(0,0,14,14),Padding=new Thickness(14),CornerRadius=new CornerRadius(12),BorderThickness=new Thickness(1),BorderBrush=Brushes.LightGray,Background=Brushes.White,Cursor=System.Windows.Input.Cursors.Hand};
  b.MouseLeftButtonUp+=(_,_)=>Ayrinti(c);
  KartIcerik(c,b);return b;
 }
 void KartGuncelle(Canli c)=>KartIcerik(c,c.Kart);
 void KartIcerik(Canli c,Border b){
  var p=new StackPanel();var (durum,renk)=Durum(c.Makine,c.Son);
  var head=new DockPanel();var pill=new Border{Background=new SolidColorBrush(renk),CornerRadius=new CornerRadius(9),Padding=new Thickness(8,2,8,2),Child=new TextBlock{Text=durum,Foreground=Brushes.White,FontSize=11,FontWeight=FontWeights.SemiBold}};DockPanel.SetDock(pill,Dock.Right);head.Children.Add(pill);
  head.Children.Add(new TextBlock{Text=c.Makine.Ad,FontSize=17,FontWeight=FontWeights.SemiBold,TextTrimming=TextTrimming.CharacterEllipsis});p.Children.Add(head);
  p.Children.Add(new TextBlock{Text=string.Join(" · ",new[]{(c.Makine.Marka+" "+c.Makine.Model).Trim(),c.Makine.Bolum,Protokol(c.Makine.Protokol)}.Where(x=>x.Length>0)),FontSize=11,Foreground=Brushes.SlateGray,Margin=new Thickness(0,2,0,8)});
  var grid=new System.Windows.Controls.Primitives.UniformGrid{Columns=2};
  foreach(var a in c.Makine.Alanlar.Where(a=>a.Rol!="Durum").Take(6)){
   var cell=new StackPanel{Margin=new Thickness(0,0,8,6)};cell.Children.Add(new TextBlock{Text=a.Ad,FontSize=10,Foreground=Brushes.SlateGray});
   string val=c.Son?.Degerler.GetValueOrDefault(a.Ad) is double v?v.ToString(Math.Abs(v)>=100?"N0":"N2",tr)+(a.Birim.Length>0?" "+a.Birim:""):"—";
   cell.Children.Add(new TextBlock{Text=val,FontSize=18,FontWeight=FontWeights.SemiBold});grid.Children.Add(cell);
  }
  p.Children.Add(grid);
  if(VerimYuzdesi(c.Makine,c.Son) is double ver)p.Children.Add(new TextBlock{Text="Hedefe göre: %"+ver.ToString("0",tr),FontSize=11,Margin=new Thickness(0,2,0,4)});
  p.Children.Add(Grafik(c.Gecmis.ToArray(),300,46,renk));
  p.Children.Add(new TextBlock{Text=c.Son is null?"İlk okuma bekleniyor…":c.Son.Basarili?"Son okuma "+c.Son.Zaman.ToString("HH:mm:ss",tr):c.Son.Hata??"",FontSize=10,Foreground=c.Son is {Basarili:false}?Brushes.Firebrick:Brushes.SlateGray,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,0)});
  b.Child=p;
 }
 static double? VerimYuzdesi(MakineTanimi m,MakineOkumaSonucu? r){
  var say=m.Alanlar.FirstOrDefault(a=>a.Rol=="Sayac");var hedef=m.Alanlar.FirstOrDefault(a=>a.Rol=="Hedef");
  if(r is not {Basarili:true}||say is null||hedef is null)return null;
  return r.Degerler.GetValueOrDefault(say.Ad) is double s&&r.Degerler.GetValueOrDefault(hedef.Ad) is double h&&h>0?Math.Clamp(s/h*100,0,999):null;
 }
 static string Protokol(string p)=>p switch{"OPCUA"=>"OPC UA","MODBUS"=>"Modbus TCP","MQTT"=>"MQTT",_=>"HTTP/JSON"};
 static FrameworkElement Grafik(double[] v,double w,double h,Color renk){
  var c=new Canvas{Width=w,Height=h,Background=new SolidColorBrush(Color.FromRgb(0xF8,0xFA,0xFC)),Margin=new Thickness(0,4,0,0)};
  if(v.Length<2)return c;double min=v.Min(),max=v.Max();if(max-min<1e-9){max+=1;min-=1;}
  var line=new Polyline{Stroke=new SolidColorBrush(renk),StrokeThickness=2};
  for(int i=0;i<v.Length;i++)line.Points.Add(new System.Windows.Point(i*(w-4)/(v.Length-1)+2,h-3-(v[i]-min)/(max-min)*(h-6)));
  c.Children.Add(line);return c;
 }

 void Ayrinti(Canli c){
  var w=new Window{Title="MiaPaxERP • "+c.Makine.Ad,Width=620,Height=640,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=Window.GetWindow(this)};
  var p=new StackPanel{Margin=new Thickness(18)};w.Content=new ScrollViewer{Content=p};
  var title=new TextBlock{FontSize=20,FontWeight=FontWeights.SemiBold};p.Children.Add(title);
  p.Children.Add(new TextBlock{Text=c.Makine.Ozet+" · "+Protokol(c.Makine.Protokol)+" · "+c.Makine.Adres+(c.Makine.Port is { } po?":"+po:"")+(c.Makine.SeriNo.Length>0?" · Seri "+c.Makine.SeriNo:""),TextWrapping=TextWrapping.Wrap,Foreground=Brushes.SlateGray,Margin=new Thickness(0,4,0,10)});
  var table=new Grid{Margin=new Thickness(0,0,0,10)};table.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});table.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});table.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});p.Children.Add(table);
  var chart=new ContentControl();p.Children.Add(chart);
  var bar=new WrapPanel{Margin=new Thickness(0,12,0,0)};p.Children.Add(bar);
  if(yonetebilir){
   Btn(bar,"Bağlantıyı düzenle",()=>{w.Close();Duzenle(c.Makine);});
   Btn(bar,"Makineyi sil",async()=>{if(MessageBox.Show(w,c.Makine.Ad+" silinsin mi? Makinenin kendisine dokunulmaz, yalnız bu programdaki bağlantı kaydı silinir.","Makine",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;await Task.Run(()=>service.Sil(c.Makine.Id));w.Close();await Yukle();});
  }
  void Ciz(){
   var (durum,renk)=Durum(c.Makine,c.Son);title.Text=c.Makine.Ad+" · "+durum;table.Children.Clear();table.RowDefinitions.Clear();int row=0;
   foreach(var a in c.Makine.Alanlar){
    table.RowDefinitions.Add(new RowDefinition());string val=a.Rol=="Durum"&&c.Son?.Degerler.GetValueOrDefault(a.Ad) is double dv?DurumMetni(a.Esleme,dv):c.Son?.Degerler.GetValueOrDefault(a.Ad) is double v?v.ToString("N3",tr)+" "+a.Birim:"—";
    void Hucre(string t,int col,bool bold=false){var tb=new TextBlock{Text=t,Margin=new Thickness(0,3,10,3),FontWeight=bold?FontWeights.SemiBold:FontWeights.Normal};Grid.SetRow(tb,row);Grid.SetColumn(tb,col);table.Children.Add(tb);}
    Hucre(a.Ad,0,true);Hucre(val,1);Hucre(a.Kaynak,2);row++;
   }
   chart.Content=Grafik(c.Gecmis.ToArray(),560,160,renk);
  }
  Ciz();var t=new DispatcherTimer{Interval=TimeSpan.FromSeconds(1)};t.Tick+=(_,_)=>Ciz();t.Start();w.Closed+=(_,_)=>t.Stop();w.Show();
 }

 void Duzenle(MakineTanimi? m){
  var w=new MakineDuzenlePenceresi(service,m){Owner=Window.GetWindow(this)};
  if(w.ShowDialog()==true)_=Yukle();
 }
 Button Btn(Panel p,string t,Action a){var b=new Button{Content=t,Padding=new Thickness(12,7,12,7),Margin=new Thickness(0,0,8,6)};b.Click+=(_,_)=>{try{a();}catch(Exception e){status.Text=e.Message;}};p.Children.Add(b);return b;}
 Button Btn(Panel p,string t,Func<Task> a){var b=new Button{Content=t,Padding=new Thickness(12,7,12,7),Margin=new Thickness(0,0,8,6)};b.Click+=async(_,_)=>{b.IsEnabled=false;try{await a();}catch(Exception e){status.Text=e.Message;}finally{b.IsEnabled=true;}};p.Children.Add(b);return b;}
}

/// <summary>Makine bağlantısını ve okunacak veri alanlarını düzenler; kaydetmeden önce bağlantıyı dener.</summary>
public sealed class MakineDuzenlePenceresi:Window
{
 public sealed class Alan{public string Ad{get;set;}="";public string Kaynak{get;set;}="";public string Birim{get;set;}="";public double Carpan{get;set;}=1;public string Rol{get;set;}="Diger";public string Esleme{get;set;}="";}
 readonly ObservableCollection<Alan> alanlar=[];
 readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,0)};
 public MakineDuzenlePenceresi(MakineServisi service,MakineTanimi? m)
 {
  Title=m is null?"MiaPaxERP • Makine ekle":"MiaPaxERP • "+m.Ad;Width=900;Height=780;WindowStartupLocation=WindowStartupLocation.CenterOwner;
  var p=new StackPanel{Margin=new Thickness(18)};Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
  TextBox Kutu(string etiket,string deger,double w=260){var sp=new StackPanel{Margin=new Thickness(0,0,12,8)};sp.Children.Add(new TextBlock{Text=etiket,FontWeight=FontWeights.SemiBold});var tb=new TextBox{Text=deger,Width=w,Margin=new Thickness(0,3,0,0)};sp.Children.Add(tb);row.Children.Add(sp);return tb;}
  WrapPanel row=new();p.Children.Add(row);
  var ad=Kutu("Makine adı",m?.Ad??"");var marka=Kutu("Marka",m?.Marka??"",160);var model=Kutu("Model",m?.Model??"",160);var seri=Kutu("Seri no",m?.SeriNo??"",140);var bolum=Kutu("Bölüm / hat",m?.Bolum??"",160);
  row=new WrapPanel();p.Children.Add(row);
  var protokolSp=new StackPanel{Margin=new Thickness(0,0,12,8)};protokolSp.Children.Add(new TextBlock{Text="Bağlantı türü",FontWeight=FontWeights.SemiBold});
  var protokol=new ComboBox{ItemsSource=new[]{"OPC UA","Modbus TCP","MQTT","HTTP/JSON"},Width=150,Margin=new Thickness(0,3,0,0),SelectedIndex=Math.Max(0,Array.IndexOf(MakineServisi.Protokoller,m?.Protokol??"MODBUS"))};protokolSp.Children.Add(protokol);row.Children.Add(protokolSp);
  var adres=Kutu("Adres (IP, opc.tcp://… veya http://…)",m?.Adres??"",300);var port=Kutu("Port",m?.Port?.ToString(CultureInfo.InvariantCulture)??"",80);var birim=Kutu("Modbus birim no",(m?.BirimNo??1).ToString(CultureInfo.InvariantCulture),110);var sure=Kutu("Okuma (sn)",(m?.OkumaSaniye??2).ToString(CultureInfo.InvariantCulture),80);
  var aktif=new System.Windows.Controls.CheckBox{Content="Aktif (panelde izlensin)",IsChecked=m?.Aktif??true,Margin=new Thickness(0,0,0,8)};p.Children.Add(aktif);
  var ipucu=new TextBlock{TextWrapping=TextWrapping.Wrap,FontSize=11,Foreground=Brushes.SlateGray,Margin=new Thickness(0,0,0,8)};p.Children.Add(ipucu);
  void Ipucu(){ipucu.Text=protokol.SelectedIndex switch{
   0=>"OPC UA: adres opc.tcp://192.168.1.50:4840. Veri adresi düğüm kimliğidir: ns=2;s=Hat1.Hiz. Yalnız okuma yapılır; sunucuda güvenlik \"None\" ve anonim giriş açık olmalı (makine firmasından isteyin).",
   1=>"Modbus TCP: adres makinenin IP'si, port genelde 502. Veri adresi HR:40001 (holding), IR:30001 (input), COIL:1, DI:1; 32 bit için :F32, :U32, :S32, kelime sırası ters ise :SW ekleyin.",
   2=>"MQTT: adres broker IP'si, port genelde 1883. Veri adresi konu adıdır (fabrika/hat1/hiz); JSON mesajda alan için konu#veri.hiz yazın.",
   _=>"HTTP/JSON: adres makinenin veya IoT kutusunun veri adresi (http://192.168.1.60/api/durum). Veri adresi JSON yoludur: veri.hiz veya hatlar.0.sayac."};}
  protokol.SelectionChanged+=(_,_)=>Ipucu();Ipucu();
  p.Children.Add(new TextBlock{Text="Okunacak veriler",FontSize=16,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,8,0,4)});
  p.Children.Add(new TextBlock{Text="Rol: Durum (çalışıyor/duruyor/arıza), Hiz, Sayac (üretilen adet/metre), Hedef, Sicaklik, Basinc, Enerji, Diger. Durum için eşleme örneği: 0=Durdu;1=Çalışıyor;2=Arıza;3=Bakım",TextWrapping=TextWrapping.Wrap,FontSize=11,Foreground=Brushes.SlateGray});
  foreach(var a in m?.Alanlar??[new("Durum","HR:40001","",1,"Durum","0=Durdu;1=Çalışıyor;2=Arıza"),new("Hız","HR:40002","m/dk",0.1,"Hiz",""),new("Üretilen","HR:40003:U32","adet",1,"Sayac",""),new("Sıcaklık","HR:40005","°C",0.1,"Sicaklik","")])
   alanlar.Add(new Alan{Ad=a.Ad,Kaynak=a.Kaynak,Birim=a.Birim,Carpan=a.Carpan,Rol=a.Rol,Esleme=a.Esleme});
  var grid=new DataGrid{ItemsSource=alanlar,AutoGenerateColumns=false,CanUserAddRows=true,CanUserDeleteRows=true,Height=240,Margin=new Thickness(0,6,0,0)};
  grid.Columns.Add(new DataGridTextColumn{Header="Ad",Binding=new System.Windows.Data.Binding("Ad"),Width=130});
  grid.Columns.Add(new DataGridTextColumn{Header="Veri adresi",Binding=new System.Windows.Data.Binding("Kaynak"),Width=220});
  grid.Columns.Add(new DataGridTextColumn{Header="Birim",Binding=new System.Windows.Data.Binding("Birim"),Width=70});
  grid.Columns.Add(new DataGridTextColumn{Header="Çarpan",Binding=new System.Windows.Data.Binding("Carpan"){ConverterCulture=CultureInfo.GetCultureInfo("tr-TR")},Width=70});
  grid.Columns.Add(new DataGridComboBoxColumn{Header="Rol",ItemsSource=MakineServisi.Roller,SelectedItemBinding=new System.Windows.Data.Binding("Rol"),Width=95});
  grid.Columns.Add(new DataGridTextColumn{Header="Durum eşlemesi",Binding=new System.Windows.Data.Binding("Esleme"),Width=new DataGridLength(1,DataGridLengthUnitType.Star)});
  p.Children.Add(grid);
  var bar=new WrapPanel{Margin=new Thickness(0,10,0,0)};p.Children.Add(bar);var dene=new Button{Content="Bağlantıyı dene",Padding=new Thickness(12,7,12,7),Margin=new Thickness(0,0,8,0)};var kaydet=new Button{Content="Kaydet",Padding=new Thickness(16,7,16,7),IsDefault=true};bar.Children.Add(dene);bar.Children.Add(kaydet);
  p.Children.Add(status);
  MakineTanimi Tanim(){
   grid.CommitEdit(DataGridEditingUnit.Row,true);
   int? po=port.Text.Trim().Length==0?null:int.TryParse(port.Text.Trim(),NumberStyles.None,CultureInfo.InvariantCulture,out int x)?x:throw new ArgumentException("Port sayı olmalı.");
   if(!int.TryParse(birim.Text.Trim(),NumberStyles.None,CultureInfo.InvariantCulture,out int bn))throw new ArgumentException("Birim numarası sayı olmalı.");
   if(!int.TryParse(sure.Text.Trim(),NumberStyles.None,CultureInfo.InvariantCulture,out int sn))throw new ArgumentException("Okuma aralığı saniye olarak sayı olmalı.");
   return MakineServisi.Dogrula(new(m?.Id??0,ad.Text,marka.Text,model.Text,seri.Text,bolum.Text,MakineServisi.Protokoller[Math.Max(0,protokol.SelectedIndex)],adres.Text,po,bn,sn,alanlar.Where(a=>a.Ad.Trim().Length>0||a.Kaynak.Trim().Length>0).Select(a=>new MakineAlani(a.Ad,a.Kaynak,a.Birim,a.Carpan,a.Rol,a.Esleme)).ToArray(),aktif.IsChecked==true));
  }
  dene.Click+=async(_,_)=>{dene.IsEnabled=false;status.Text="Makineye bağlanılıyor…";try{var t=Tanim();using var cts=new CancellationTokenSource(TimeSpan.FromSeconds(20));var r=await Task.Run(()=>MakineOkuyucu.TekSeferAsync(t,cts.Token));
    status.Text=r.Basarili?"✓ Bağlantı başarılı:\n"+string.Join("\n",t.Alanlar.Select(a=>"• "+a.Ad+": "+(r.Degerler.GetValueOrDefault(a.Ad) is double v?(a.Rol=="Durum"?MakinePaneli.DurumMetni(a.Esleme,v):v.ToString("N3",CultureInfo.GetCultureInfo("tr-TR"))+" "+a.Birim):"okunamadı"))):"Bağlanılamadı: "+r.Hata;}
   catch(Exception e){status.Text=e.Message;}finally{dene.IsEnabled=true;}};
  kaydet.Click+=async(_,_)=>{kaydet.IsEnabled=false;try{var t=Tanim();await Task.Run(()=>service.Kaydet(t));DialogResult=true;}catch(Exception e){status.Text="Kaydedilmedi: "+e.Message;}finally{kaydet.IsEnabled=true;}};
 }
}
