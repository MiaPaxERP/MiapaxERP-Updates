using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace MiapaxERP.Desktop;

/// <summary>WhatsApp Business Cloud API ayarları (sunucu bilgisayarında saklanır; erişim anahtarı DPAPI ile korunur).</summary>
public sealed record WhatsAppAyari(string TelefonNumarasiId, string IsletmeHesapId, bool AnahtarVar, string TestNumarasi);

/// <summary>
/// Meta WhatsApp Business Cloud API istemcisi. İşletmenin başlattığı mesajlar (müşteri son 24 saatte yazmadıysa)
/// Meta'nın onayladığı bir şablonla gönderilmelidir; 24 saat içinde serbest metin de gönderilebilir.
/// </summary>
public static class WhatsAppBulut
{
    static readonly HttpClient http = new(new HttpClientHandler { AllowAutoRedirect = false }) { Timeout = TimeSpan.FromSeconds(30) };
    const string ApiSurumu = "v21.0";
    static readonly byte[] ek = Encoding.UTF8.GetBytes("MiapaxERP-WhatsApp-1");
    static string Klasor => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "MiapaxERP", "WhatsApp");
    static string AyarDosyasi => Path.Combine(Klasor, "ayar.json");

    sealed class Kayit { public string TelefonNumarasiId { get; set; } = ""; public string IsletmeHesapId { get; set; } = ""; public string Anahtar { get; set; } = ""; public string TestNumarasi { get; set; } = ""; }

    static Kayit Oku()
    {
        try { if (File.Exists(AyarDosyasi)) return JsonSerializer.Deserialize<Kayit>(File.ReadAllText(AyarDosyasi)) ?? new(); }
        catch (Exception e) when (e is IOException or JsonException or UnauthorizedAccessException) { }
        return new();
    }

    public static WhatsAppAyari Ayar() { var k = Oku(); return new(k.TelefonNumarasiId, k.IsletmeHesapId, k.Anahtar.Length > 0, k.TestNumarasi); }

    /// <summary>Anahtar boş bırakılırsa mevcut anahtar korunur.</summary>
    public static void Kaydet(string telefonNumarasiId, string isletmeHesapId, string? anahtar, string testNumarasi)
    {
        telefonNumarasiId = (telefonNumarasiId ?? "").Trim(); isletmeHesapId = (isletmeHesapId ?? "").Trim();
        if (telefonNumarasiId.Length > 0 && !Regex.IsMatch(telefonNumarasiId, "^[0-9]{5,30}$")) throw new ArgumentException("Telefon numarası kimliği (Phone number ID) yalnız rakamlardan oluşur. Meta uygulamanızın WhatsApp > API Kurulumu sayfasından kopyalayın; telefon numaranızın kendisi değildir.");
        if (isletmeHesapId.Length > 0 && !Regex.IsMatch(isletmeHesapId, "^[0-9]{5,30}$")) throw new ArgumentException("WhatsApp işletme hesabı kimliği yalnız rakamlardan oluşur.");
        var k = Oku(); k.TelefonNumarasiId = telefonNumarasiId; k.IsletmeHesapId = isletmeHesapId; k.TestNumarasi = (testNumarasi ?? "").Trim();
        if (!string.IsNullOrWhiteSpace(anahtar))
        {
            if (anahtar.Trim().Length > 1000 || anahtar.Trim().Any(char.IsWhiteSpace)) throw new ArgumentException("Erişim anahtarı geçersiz görünüyor.");
            k.Anahtar = Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(anahtar.Trim()), ek, DataProtectionScope.LocalMachine));
        }
        Directory.CreateDirectory(Klasor);
        File.WriteAllText(AyarDosyasi, JsonSerializer.Serialize(k));
    }

    static string AnahtarAc(Kayit k)
    {
        if (k.Anahtar.Length == 0) throw new InvalidOperationException("WhatsApp erişim anahtarı girilmemiş. 'WhatsApp ayarları' düğmesinden Meta erişim anahtarını kaydedin.");
        try { return Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(k.Anahtar), ek, DataProtectionScope.LocalMachine)); }
        catch (CryptographicException) { throw new InvalidOperationException("WhatsApp erişim anahtarı bu bilgisayarda açılamadı. Anahtarı ayarlardan yeniden girin."); }
    }

    /// <summary>Türkiye numaralarını uluslararası biçime çevirir: 0532..., 532..., +90 532... → 90532...</summary>
    public static string Numara(string telefon)
    {
        string d = new((telefon ?? "").Where(char.IsDigit).ToArray());
        if (d.StartsWith("00")) d = d[2..];
        if (d.Length == 11 && d.StartsWith("0")) d = "90" + d[1..];
        else if (d.Length == 10 && d.StartsWith("5")) d = "90" + d;
        if (d.Length < 10 || d.Length > 15) throw new ArgumentException("Telefon numarası geçersiz: " + telefon);
        return d;
    }

    /// <summary>Hazır mesajdaki alanları doldurur ve Markdown kalınlığını (**metin**) WhatsApp biçimine (*metin*) çevirir.</summary>
    public static string MetniHazirla(string metin, string musteriAdi, string sehir)
    {
        var s = (metin ?? "").Replace("[Müşteri Adı]", musteriAdi, StringComparison.OrdinalIgnoreCase)
            .Replace("[Musteri Adi]", musteriAdi, StringComparison.OrdinalIgnoreCase)
            .Replace("[Şehir]", sehir, StringComparison.OrdinalIgnoreCase)
            .Replace("[Tarih]", DateTime.Now.ToString("dd.MM.yyyy"), StringComparison.OrdinalIgnoreCase);
        return s.Replace("**", "*");
    }

    /// <summary>Mesajı gönderir ve WhatsApp mesaj kimliğini döndürür.</summary>
    public static string Gonder(string numara, string metin, string? metaSablon, string dil, bool adParametresi, string musteriAdi)
    {
        var k = Oku();
        if (k.TelefonNumarasiId.Length == 0) throw new InvalidOperationException("WhatsApp telefon numarası kimliği (Phone number ID) girilmemiş. 'WhatsApp ayarları' düğmesinden kaydedin.");
        string anahtar = AnahtarAc(k);
        object govde = string.IsNullOrWhiteSpace(metaSablon)
            ? new { messaging_product = "whatsapp", recipient_type = "individual", to = numara, type = "text", text = new { preview_url = false, body = metin } }
            : new
            {
                messaging_product = "whatsapp", to = numara, type = "template",
                template = adParametresi
                    ? (object)new { name = metaSablon!.Trim(), language = new { code = string.IsNullOrWhiteSpace(dil) ? "tr" : dil.Trim() }, components = new object[] { new { type = "body", parameters = new object[] { new { type = "text", text = musteriAdi } } } } }
                    : new { name = metaSablon!.Trim(), language = new { code = string.IsNullOrWhiteSpace(dil) ? "tr" : dil.Trim() } }
            };
        using var istek = new HttpRequestMessage(HttpMethod.Post, $"https://graph.facebook.com/{ApiSurumu}/{k.TelefonNumarasiId}/messages")
        { Content = new StringContent(JsonSerializer.Serialize(govde), Encoding.UTF8, "application/json") };
        istek.Headers.Authorization = new AuthenticationHeaderValue("Bearer", anahtar);
        using var yanit = http.Send(istek);
        string json = yanit.Content.ReadAsStringAsync().GetAwaiter().GetResult();
        if (!yanit.IsSuccessStatusCode) throw new InvalidOperationException(HataAciklamasi(json, (int)yanit.StatusCode));
        try { using var doc = JsonDocument.Parse(json); return doc.RootElement.GetProperty("messages")[0].GetProperty("id").GetString() ?? ""; }
        catch (Exception e) when (e is JsonException or KeyNotFoundException or InvalidOperationException or IndexOutOfRangeException) { return ""; }
    }

    static string HataAciklamasi(string json, int durum)
    {
        int kod = 0; string mesaj = "";
        try { using var doc = JsonDocument.Parse(json); var e = doc.RootElement.GetProperty("error"); kod = e.TryGetProperty("code", out var c) ? c.GetInt32() : 0; mesaj = e.TryGetProperty("message", out var m) ? m.GetString() ?? "" : ""; }
        catch (Exception e) when (e is JsonException or KeyNotFoundException or InvalidOperationException) { }
        string aciklama = kod switch
        {
            131047 =>"Müşteri son 24 saatte size yazmadığı için serbest metin gönderilemez. Bu hazır mesaja Meta'da onaylanmış bir şablon adı girin.",
            131026 => "Bu numara WhatsApp kullanmıyor ya da mesajı alamıyor.",
            132000 or 132001 => "Meta şablon adı veya dili bulunamadı ya da şablondaki değişken sayısı uyuşmuyor. Şablon adını ve 'müşteri adı değişkeni' seçeneğini kontrol edin.",
            190 => "WhatsApp erişim anahtarının süresi dolmuş veya geçersiz. Meta'dan kalıcı (sistem kullanıcısı) anahtarı alıp ayarlara girin.",
            100 => "Telefon numarası kimliği veya istek hatalı. Ayarlardaki 'Phone number ID' değerini kontrol edin.",
            131030 => "Test modunda yalnız Meta'da izin verilen alıcı numaralarına mesaj gönderilebilir.",
            130429 or 131056 => "Çok hızlı gönderim: WhatsApp gönderim sınırı aşıldı. Biraz sonra tekrar deneyin.",
            _ => ""
        };
        return (aciklama.Length > 0 ? aciklama + " " : "") + $"(WhatsApp hata {kod}, HTTP {durum}{(mesaj.Length > 0 ? ": " + mesaj : "")})";
    }

    /// <summary>Otomatik gönderim ayarı yoksa: WhatsApp masaüstü/web sohbetini mesaj hazır hâlde açar (gönder tuşuna kullanıcı basar).</summary>
    public static string SohbetAdresi(string numara, string metin) => "https://wa.me/" + numara + "?text=" + Uri.EscapeDataString(metin);
}
