using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>Bir stok kartının içindeki parça (alt stok) satırı.</summary>
public sealed record StokBileseni(int Bilesen,string Kod,string Ad,string Birim,decimal Miktar,string Aciklama,string Barkodlar,int AltParcaSayisi);
/// <summary>Parça ağacında bir satır: seviye 1 doğrudan parçadır; Toplam, ana üründen bu parçaya kadar çarpılmış miktardır.</summary>
public sealed record StokAgacSatiri(int Seviye,int Ust,int Bilesen,string Kod,string Ad,string Birim,decimal Miktar,decimal Toplam,string Barkodlar);
public sealed record StokSecimi(int Id,string Kod,string Ad,string Birim,string Tip);

internal static class StokBilesenSemasi
{
 internal const string Ddl="""
IF OBJECT_ID('dbo.MPXNext_StokBilesen','U') IS NULL CREATE TABLE dbo.MPXNext_StokBilesen(Ana int NOT NULL REFERENCES dbo.StokKartlari(Id),Bilesen int NOT NULL REFERENCES dbo.StokKartlari(Id),Miktar decimal(18,3) NOT NULL CHECK(Miktar>0),Aciklama nvarchar(200) NULL,Olusturan int NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),CONSTRAINT PK_MPXNext_StokBilesen PRIMARY KEY(Ana,Bilesen),CONSTRAINT CK_MPXNext_StokBilesen_Kendisi CHECK(Ana<>Bilesen));
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MPXNext_StokBilesen') AND name='IX_StokBilesen_Bilesen') CREATE INDEX IX_StokBilesen_Bilesen ON dbo.MPXNext_StokBilesen(Bilesen);
""";
 static readonly System.Collections.Concurrent.ConcurrentDictionary<string,bool> hazir=new(StringComparer.OrdinalIgnoreCase);
 /// <summary>Kurulu veritabanlarında tabloyu bir kez, kilitle ve idempotent olarak oluşturur.</summary>
 internal static void Hazirla(SqlConnection c){
  string anahtar=c.DataSource+"|"+c.Database;
  if(hazir.ContainsKey(anahtar))return;
  using(var check=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.MPXNext_StokBilesen','U') IS NULL THEN 0 ELSE 1 END",c))if(Convert.ToInt32(check.ExecuteScalar())==1){hazir[anahtar]=true;return;}
  using var tx=c.BeginTransaction(IsolationLevel.Serializable);
  try{
   using(var gate=ErpModulServisi.Komut(c,tx,"DECLARE @r int;EXEC @r=sys.sp_getapplock @Resource='MiaPaxNextSchema',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;IF @r<0 THROW 51000,'Stok parca kurulumu kilidi alinamadi',1"))gate.ExecuteNonQuery();
   using(var q=ErpModulServisi.Komut(c,tx,Ddl))q.ExecuteNonQuery();
   tx.Commit();hazir[anahtar]=true;
  }catch{tx.Rollback();throw;}
 }
}

/// <summary>
/// Stok içinde stok: bir ürünün parçalarını (ve parçaların kendi parçalarını) tanımlar.
/// Parçalar normal stok kartıdır; barkod, etiket ve stok hareketleri aynen çalışır.
/// Döngü (A→B→A) ve 10 seviyeden derin ağaç engellenir.
/// </summary>
public sealed class StokBilesenServisi(string connection,int user)
{
 public const int EnFazlaSeviye=10;
 readonly ErpModulServisi access=new(connection,user);
 readonly Action<SqlConnection,SqlTransaction?,string>? fixtureCheck;
 /// <summary>Yalnız testler: lisans oturumu olmadan yetki denetimini verilen kurala bırakır.</summary>
 internal StokBilesenServisi(string connection,int user,Action<SqlConnection,SqlTransaction?,string> check):this(connection,user){fixtureCheck=check;}
 void Yetki(SqlConnection c,SqlTransaction? t,string code){if(fixtureCheck is not null)fixtureCheck(c,t,code);else access.Yetki(c,t,code);}
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps)=>ErpModulServisi.Komut(c,t,sql,ps);
 SqlConnection Ac(){var c=access.Ac();try{StokBilesenSemasi.Hazirla(c);return c;}catch{c.Dispose();throw;}}
 const string BarkodListesi="ISNULL(STUFF((SELECT ', '+b.Barkod FROM dbo.MPXNext_Barkod b WHERE b.Stok=s.Id ORDER BY b.Barkod FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,2,''),N'')";

 public StokBileseni[] Bilesenler(int ana){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<StokBileseni[]>(connection,"StokBilesenServisi.Bilesenler","",[ana]);
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");
  using var q=Q(c,null,"SELECT s.Id,s.StokKodu,s.StokAdi,s.Birim,x.Miktar,ISNULL(x.Aciklama,N''),"+BarkodListesi+",(SELECT COUNT(*) FROM dbo.MPXNext_StokBilesen a WHERE a.Ana=s.Id) FROM dbo.MPXNext_StokBilesen x JOIN dbo.StokKartlari s ON s.Id=x.Bilesen WHERE x.Ana=@a ORDER BY s.StokKodu",("@a",ana));
  using var r=q.ExecuteReader();var rows=new List<StokBileseni>();
  while(r.Read())rows.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetDecimal(4),r.GetString(5),r.GetString(6),r.GetInt32(7)));
  return rows.ToArray();
 }

 public StokAgacSatiri[] Agac(int ana){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<StokAgacSatiri[]>(connection,"StokBilesenServisi.Agac","",[ana]);
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");
  using var q=Q(c,null,"""
WITH t AS(
 SELECT 1 AS Seviye,x.Ana AS Ust,x.Bilesen,x.Miktar,CAST(x.Miktar AS decimal(38,6)) AS Toplam,CAST('/'+CAST(x.Ana AS varchar(12))+'/'+CAST(x.Bilesen AS varchar(12))+'/' AS varchar(900)) AS Yol FROM dbo.MPXNext_StokBilesen x WHERE x.Ana=@a
 UNION ALL
 SELECT t.Seviye+1,x.Ana,x.Bilesen,x.Miktar,CAST(t.Toplam*x.Miktar AS decimal(38,6)),CAST(t.Yol+CAST(x.Bilesen AS varchar(12))+'/' AS varchar(900)) FROM t JOIN dbo.MPXNext_StokBilesen x ON x.Ana=t.Bilesen
 WHERE t.Seviye<@m AND CHARINDEX('/'+CAST(x.Bilesen AS varchar(12))+'/',t.Yol)=0)
SELECT TOP(2000) t.Seviye,t.Ust,s.Id,s.StokKodu,s.StokAdi,s.Birim,t.Miktar,CAST(t.Toplam AS decimal(18,3)),
""" + BarkodListesi + " FROM t JOIN dbo.StokKartlari s ON s.Id=t.Bilesen ORDER BY t.Yol OPTION(MAXRECURSION 20)",("@a",ana),("@m",EnFazlaSeviye));
  using var r=q.ExecuteReader();var rows=new List<StokAgacSatiri>();
  while(r.Read())rows.Add(new(r.GetInt32(0),r.GetInt32(1),r.GetInt32(2),r.GetString(3),r.GetString(4),r.GetString(5),r.GetDecimal(6),r.GetDecimal(7),r.GetString(8)));
  return rows.ToArray();
 }

 public StokSecimi[] Ara(string metin){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<StokSecimi[]>(connection,"StokBilesenServisi.Ara","",[metin]);
  metin=(metin??"").Trim();if(metin.Length is 0 or >100)throw new ArgumentException("Aranacak stok kodu, adı veya barkodu girin.");
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");
  using var q=Q(c,null,"SELECT TOP(30) s.Id,s.StokKodu,s.StokAdi,s.Birim,s.StokTipi FROM dbo.StokKartlari s WHERE s.Aktif=1 AND (s.StokKodu=@t OR s.StokKodu LIKE @l ESCAPE '\\' OR s.StokAdi LIKE @l ESCAPE '\\' OR EXISTS(SELECT 1 FROM dbo.MPXNext_Barkod b WHERE b.Stok=s.Id AND b.Barkod=@b)) ORDER BY CASE WHEN s.StokKodu=@t THEN 0 ELSE 1 END,s.StokKodu",
   ("@t",metin),("@l","%"+metin.Replace("\\","\\\\").Replace("%","\\%").Replace("_","\\_").Replace("[","\\[")+"%"),("@b",metin.Length<=100&&metin.All(ch=>ch>='!'&&ch<='~')?metin:"\u0001"));
  using var r=q.ExecuteReader();var rows=new List<StokSecimi>();
  while(r.Read())rows.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetString(4)));
  return rows.ToArray();
 }

 /// <summary>Parçayı ekler veya miktarını günceller. Döngü oluşturacak bağlantıyı reddeder.</summary>
 public void Kaydet(int ana,int bilesen,decimal miktar,string aciklama){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"StokBilesenServisi.Kaydet","",[ana,bilesen,miktar,aciklama]);return;}
  if(ana==bilesen)throw new ArgumentException("Bir ürün kendi parçası olamaz.");
  if(miktar<=0||miktar>1_000_000||decimal.Round(miktar,3)!=miktar)throw new ArgumentException("Parça miktarı pozitif ve en fazla 3 ondalıklı olmalı.");
  aciklama=(aciklama??"").Trim();if(aciklama.Length>200)throw new ArgumentException("Açıklama en fazla 200 karakter olmalı.");
  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);
  try{
   Yetki(c,t,"STOCK.VIEW");Yetki(c,t,"STOCK.EDIT");
   using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.StokKartlari WITH(HOLDLOCK) WHERE Id IN(@a,@b) AND Aktif=1",("@a",ana),("@b",bilesen)))if(Convert.ToInt32(q.ExecuteScalar())!=2)throw new ArgumentException("Ana ürün ve parça etkin stok kartı olmalı.");
   using(var q=Q(c,t,"""
WITH y AS(SELECT x.Bilesen,1 AS d FROM dbo.MPXNext_StokBilesen x WITH(UPDLOCK,HOLDLOCK) WHERE x.Ana=@b
 UNION ALL SELECT x.Bilesen,y.d+1 FROM y JOIN dbo.MPXNext_StokBilesen x ON x.Ana=y.Bilesen WHERE y.d<25)
SELECT CASE WHEN EXISTS(SELECT 1 FROM y WHERE Bilesen=@a) THEN 1 ELSE 0 END OPTION(MAXRECURSION 30)
""",("@a",ana),("@b",bilesen)))if(Convert.ToInt32(q.ExecuteScalar())==1)throw new InvalidOperationException("Bu bağlantı döngü oluşturur: seçilen parça, ana ürünü zaten kendi içinde içeriyor.");
   using(var q=Q(c,t,"UPDATE dbo.MPXNext_StokBilesen SET Miktar=@m,Aciklama=NULLIF(@d,N'') WHERE Ana=@a AND Bilesen=@b;IF @@ROWCOUNT=0 INSERT dbo.MPXNext_StokBilesen(Ana,Bilesen,Miktar,Aciklama,Olusturan) VALUES(@a,@b,@m,NULLIF(@d,N''),@u)",("@a",ana),("@b",bilesen),("@m",miktar),("@d",aciklama),("@u",user)))q.ExecuteNonQuery();
   t.Commit();
  }catch{t.Rollback();throw;}
 }

 public void Sil(int ana,int bilesen){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"StokBilesenServisi.Sil","",[ana,bilesen]);return;}
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");Yetki(c,null,"STOCK.EDIT");
  using var q=Q(c,null,"DELETE dbo.MPXNext_StokBilesen WHERE Ana=@a AND Bilesen=@b",("@a",ana),("@b",bilesen));q.ExecuteNonQuery();
 }

 /// <summary>Ana ürünün stok tipi kimliği: yeni parça kartı aynı tiple açılır.</summary>
 public int AnaTipi(int ana){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<int>(connection,"StokBilesenServisi.AnaTipi","",[ana]);
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");
  using var q=Q(c,null,"SELECT TOP(1) t.Id FROM dbo.StokKartlari s JOIN dbo.StokTipleri t ON t.Ad=s.StokTipi AND t.Aktif=1 WHERE s.Id=@a",("@a",ana));
  return q.ExecuteScalar() is int id?id:throw new InvalidOperationException("Ana ürünün stok tipi etkin değil. Stok tiplerini kontrol edin.");
 }

 /// <summary>Ana ürün koduna göre sıradaki boş parça kodunu önerir (ör. KOD-P01).</summary>
 public string SonrakiParcaKodu(int ana){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<string>(connection,"StokBilesenServisi.SonrakiParcaKodu","",[ana]);
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");
  string kod;using(var q=Q(c,null,"SELECT StokKodu FROM dbo.StokKartlari WHERE Id=@a",("@a",ana)))kod=Convert.ToString(q.ExecuteScalar())??throw new ArgumentException("Ana ürün bulunamadı.");
  string kok=kod.Length>44?kod[..44]:kod;
  for(int i=1;i<1000;i++){string aday=kok+"-P"+i.ToString(i<100?"00":"000");using var q=Q(c,null,"SELECT COUNT(*) FROM dbo.StokKartlari WHERE StokKodu=@k",("@k",aday));if(Convert.ToInt32(q.ExecuteScalar())==0)return aday;}
  throw new InvalidOperationException("Bu ürün için boş parça kodu kalmadı.");
 }

 public int IdBul(string stokKodu){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<int>(connection,"StokBilesenServisi.IdBul","",[stokKodu]);
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");
  using var q=Q(c,null,"SELECT Id FROM dbo.StokKartlari WHERE StokKodu=@k",("@k",(stokKodu??"").Trim()));
  return q.ExecuteScalar() is int id?id:throw new ArgumentException("Stok kartı bulunamadı: "+stokKodu);
 }

 /// <summary>Firma içi kullanım için benzersiz, kısa EAN-8 barkod üretir (8 hane, 2 ile başlar; mağaza içi aralık).</summary>
 public string YeniBarkod(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<string>(connection,"StokBilesenServisi.YeniBarkod","",[]);
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");
  for(int deneme=0;deneme<50;deneme++){
   string aday=Ean8("2"+System.Security.Cryptography.RandomNumberGenerator.GetInt32(0,1_000_000).ToString("000000"));
   using var q=Q(c,null,"SELECT CASE WHEN EXISTS(SELECT 1 FROM dbo.MPXNext_Barkod WHERE Barkod=@b) OR EXISTS(SELECT 1 FROM dbo.StokKartlari WHERE StokKodu=@b) THEN 1 ELSE 0 END",("@b",aday));
   if(Convert.ToInt32(q.ExecuteScalar())==0)return aday;
  }
  throw new InvalidOperationException("Boş barkod bulunamadı; tekrar deneyin.");
 }

 /// <summary>7 haneye EAN-8 kontrol hanesini ekler.</summary>
 public static string Ean8(string yediHane){
  if(yediHane is null||yediHane.Length!=7||!yediHane.All(char.IsAsciiDigit))throw new ArgumentException("EAN-8 için 7 rakam gerekir.");
  int toplam=0;for(int i=0;i<7;i++)toplam+=(yediHane[i]-'0')*(i%2==0?3:1);
  return yediHane+((10-toplam%10)%10).ToString();
 }

 /// <summary>12 haneye EAN-13 kontrol hanesini ekler.</summary>
 public static string Ean13(string onikiHane){
  if(onikiHane is null||onikiHane.Length!=12||!onikiHane.All(char.IsAsciiDigit))throw new ArgumentException("EAN-13 için 12 rakam gerekir.");
  int toplam=0;for(int i=0;i<12;i++)toplam+=(onikiHane[i]-'0')*(i%2==0?1:3);
  return onikiHane+((10-toplam%10)%10).ToString();
 }
}
