namespace MiapaxERP.Desktop;
internal static class LisansYenilemeKurallari
{
 internal static string Anahtar(string? girilen,string? kayitli)=>
  (string.IsNullOrWhiteSpace(girilen)?kayitli??"":girilen).Trim().ToLowerInvariant();
 internal static bool CevrimdisiDevam(bool yeniAnahtarGirildi,bool gecerliBelge)=>!yeniAnahtarGirildi&&gecerliBelge;
}
