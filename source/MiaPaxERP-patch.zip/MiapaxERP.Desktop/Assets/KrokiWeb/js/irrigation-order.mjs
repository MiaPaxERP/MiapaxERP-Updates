import {PARTS,length} from './field-plan-core.mjs?v=kroki-next1';
const num=(v,min,max,fallback)=>Number.isFinite(Number(v))&&Number(v)>=min&&Number(v)<=max?Number(v):fallback;
export function cleanOrder(raw={}){return {pieceLength:num(raw.pieceLength,.5,1000,5),piecesPerHead:num(raw.piecesPerHead,1,100,2),waste:num(raw.waste,0,30,5),rows:Array.isArray(raw.rows)?raw.rows.slice(0,150).map(r=>({key:String(r.key||'').slice(0,80),stockId:Number.isInteger(r.stockId)?r.stockId:null,label:String(r.label||'').slice(0,200),unit:String(r.unit||'adet').slice(0,20),quantity:r.quantity==null?null:num(r.quantity,0,10000000,null),price:r.price==null?null:num(r.price,0,1000000000,null),currency:['TRY','USD','EUR','GBP'].includes(r.currency)?r.currency:'TRY',packLength:num(r.packLength,.01,10000,1)})):[]};}
const position=i=>i.p;
export function inferredAccessories(plan,options=cleanOrder(plan.order)){
 const lines=plan.items.filter(i=>PARTS[i.kind]?.line),points=plan.items.filter(i=>!PARTS[i.kind]?.line),result=[];
 const put=(kind,p,diameter)=>{if(!points.some(i=>i.kind===kind&&length(i.p,p)<.1))result.push({kind,p:{...p},diameter,id:'inferred-'+result.length,inferred:true});};
 for(const l of lines){const distance=length(l.a,l.b),pieces=Math.ceil((distance-1e-8)/options.pieceLength),manual=points.filter(i=>i.kind==='coupling'&&Math.abs(length(l.a,i.p)+length(i.p,l.b)-distance)<.02).length,count=Math.max(0,pieces-1-manual);if(count){const t=Math.min(.5,options.pieceLength/distance);result.push({kind:'coupling',p:{x:l.a.x+(l.b.x-l.a.x)*t,y:l.a.y+(l.b.y-l.a.y)*t},diameter:l.diameter||63,id:'inferred-'+result.length,inferred:true,bomQuantity:count});}}

 for(const i of points.filter(i=>i.kind==='sprinkler'))put('riser',i.p,i.diameter||0);
 const nodes=[];for(const l of lines)for(const p of [l.a,l.b])if(!nodes.some(n=>length(n.p,p)<.08))nodes.push({p,diameter:l.diameter||63});
 for(const n of nodes){const touching=lines.filter(l=>Math.abs(length(l.a,n.p)+length(n.p,l.b)-length(l.a,l.b))<.02),degree=touching.reduce((s,l)=>s+(length(l.a,n.p)<.08||length(l.b,n.p)<.08?1:2),0),closed=points.some(i=>['source','cap'].includes(i.kind)&&length(i.p,n.p)<.3);
 if(degree===1&&!closed)put('cap',n.p,n.diameter);
 if(degree>=3)put('tee',n.p,n.diameter);
 if(degree===2&&touching.length===2){const dirs=touching.map(l=>length(l.a,n.p)<.08?{x:l.b.x-n.p.x,y:l.b.y-n.p.y}:{x:l.a.x-n.p.x,y:l.a.y-n.p.y});if(Math.abs(dirs[0].x*dirs[1].y-dirs[0].y*dirs[1].x)>.01)put('elbow',n.p,n.diameter);else if(!points.some(i=>['source','tee','valve'].includes(i.kind)&&length(i.p,n.p)<.1))put('coupling',n.p,n.diameter);}
 }
 for(const i of points.filter(i=>i.kind==='tee')){const ds=new Set(lines.filter(l=>Math.abs(length(l.a,i.p)+length(i.p,l.b)-length(l.a,l.b))<.02).map(l=>l.diameter||63));if(ds.size>1)put('reducer',i.p,Math.min(...ds));}
 return result;
}
export function materials(plan,options=cleanOrder(plan.order)){
 const groups=new Map();for(const i of [...plan.items,...inferredAccessories(plan,options)]){const line=PARTS[i.kind]?.line,d=i.diameter||0,key=i.kind+'-'+d;if(!groups.has(key))groups.set(key,{key,kind:i.kind,diameter:d||null,label:PARTS[i.kind].label+(d?' · Ø'+d+' mm':''),unit:line?'m':'adet',quantity:0});groups.get(key).quantity+=line?length(i.a,i.b):(i.bomQuantity||1);}
 return [...groups.values()].map(r=>({...r,order:r.unit==='m'?Math.ceil(r.quantity*(1+options.waste/100)):r.quantity}));
}
export function quoteRows(plan,catalog=[],priceType='retail'){
 const order=cleanOrder(plan.order),saved=new Map(order.rows.map(r=>[r.key,r]));
 return materials(plan,order).map(r=>{const edit=saved.get(r.key),stock=catalog.find(s=>s.id===edit?.stockId),unit=stock?.unit||edit?.unit||r.unit,pack=unit.toLocaleLowerCase('tr-TR')==='adet'&&r.unit==='m'?(edit?.packLength||stock?.length||order.pieceLength):1,compatible=r.unit==='m'?['metre','m','adet'].includes(unit.toLocaleLowerCase('tr-TR')):['adet'].includes(unit.toLocaleLowerCase('tr-TR')),recommended=compatible?(unit.toLocaleLowerCase('tr-TR')==='adet'?Math.ceil(r.order/pack):r.order):null;
 const price=edit?.price??(stock?(priceType==='dealer'?stock.dealer:stock.retail):null),quantity=edit?.quantity??recommended;
 return {...r,stockId:edit?.stockId??null,label:stock?stock.code+' — '+stock.name:edit?.label||r.label,unit,packLength:pack,compatible,recommended,quantity,price,currency:edit?.currency||stock?.currency||'TRY',total:quantity!=null&&price!=null?Math.round(quantity*price*100)/100:null};});
}
export function quoteTotals(rows){const totals={};for(const r of rows)if(r.total!=null)totals[r.currency]=(totals[r.currency]||0)+Math.round(r.total*100);return Object.fromEntries(Object.entries(totals).map(([k,v])=>[k,v/100]));}
export function parseDesignSuggestion(text){const body=String(text).trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');const raw=JSON.parse(body);if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Yapay zekâ geçerli tasarım bilgisi döndürmedi.');const result={};for(const [key,lo,hi] of [['rowGap',.3,50],['headGap',1,50],['mainDiameter',10,1000],['lateralDiameter',10,1000],['pieceLength',.5,1000],['piecesPerHead',1,100]])if(raw[key]!=null){const n=Number(raw[key]);if(!Number.isFinite(n)||n<lo||n>hi)throw Error('Yapay zekâ ölçüsü sınır dışında: '+key);result[key]=n;}if(raw.method!=null){if(!['sprinkler','drip'].includes(raw.method))throw Error('Sulama türü geçersiz.');result.method=raw.method;}if(raw.side!=null){if(!['left','right'].includes(raw.side))throw Error('Ana hat konumu geçersiz.');result.side=raw.side;}if(!Object.keys(result).length)throw Error('Uygulanabilir tasarım ölçüsü gelmedi.');return result;}
