using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed record KrokiStokFiyati(int id,string code,string name,string unit,decimal? diameter,decimal? length,decimal? retail,decimal? dealer,string currency);
public sealed class KrokiTeklifServisi(string connection,int user)
{
 readonly Action<string>? testLicense;
 internal KrokiTeklifServisi(string connection,int user,Action<string> license):this(connection,user){testLicense=license;}
 void License(string module){if(testLicense is not null)testLicense(module);else LisansOturumu.Gerekli(module);}
 public KrokiStokFiyati[] StokAra(string search){
  if(search is null||search.Length>100)throw new ArgumentException("Arama en fazla 100 karakter olabilir.");
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<KrokiStokFiyati[]>(connection,"KrokiTeklifServisi.StokAra","",[search]);
  License("KROKI");if(MiapaxERP.Lisans.Core.UrunKatalogu.YetkiModulu("STOCK.VIEW") is string stockModule)License(stockModule);
  var access=new ErpModulServisi(connection,user);using var c=access.Ac();
  var permissions=new HashSet<string>(new MenuYetkiServisi(connection,user).Yetkiler(),StringComparer.OrdinalIgnoreCase);
  if(!permissions.Contains("STOCK.VIEW"))throw new UnauthorizedAccessException("Stok görüntüleme yetkisi gerekli.");
  if(!permissions.Contains("KROKI.VIEW")&&!permissions.Contains("USERS.MANAGE"))throw new UnauthorizedAccessException("Kroki yetkisi gerekli.");
  using var q=ErpModulServisi.Komut(c,null,"""
  SELECT TOP(100) s.Id,s.StokKodu,s.StokAdi,s.Birim,s.CapMm,s.UzunlukMetre,f.PerakendeSatisFiyati,f.BayiSatisFiyati,COALESCE(f.ParaBirimi,'TRY')
  FROM dbo.StokKartlari s LEFT JOIN dbo.StokFiyatlari f ON f.StokKartId=s.Id
  WHERE s.Aktif=1 AND (@s='' OR CHARINDEX(@s,s.StokKodu)>0 OR CHARINDEX(@s,s.StokAdi)>0)
  ORDER BY s.StokAdi,s.Id
  """,("@s",search.Trim()));using var r=q.ExecuteReader();var rows=new List<KrokiStokFiyati>();
  decimal? N(int i)=>r.IsDBNull(i)?null:Convert.ToDecimal(r.GetValue(i));
  while(r.Read())rows.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),N(4),N(5),N(6),N(7),r.GetString(8)));return rows.ToArray();
 }
}
