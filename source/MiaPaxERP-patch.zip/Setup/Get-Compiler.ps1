param([Parameter(Mandatory=$true)][string]$ToolDirectory)
$ErrorActionPreference='Stop'
$installed=Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6/ISCC.exe'
if(Test-Path -LiteralPath $installed){return $installed}
New-Item -ItemType Directory -Force -Path $ToolDirectory | Out-Null
$ToolDirectory=(Resolve-Path -LiteralPath $ToolDirectory).Path
$installer=Join-Path $ToolDirectory 'innosetup-6.7.4.exe'
Invoke-WebRequest -Uri 'https://github.com/jrsoftware/issrc/releases/download/is-6_7_4/innosetup-6.7.4.exe' -OutFile $installer
if((Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'a549929319f9120716677c685535ca4671e4b937b5fdc87e2585f32d8eb30e8c'){throw 'Compiler download hash mismatch'}
$signature=Get-AuthenticodeSignature -LiteralPath $installer
if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Pyrsys'){throw 'Compiler publisher signature invalid'}
$destination=Join-Path $ToolDirectory 'compiler'
$process=Start-Process -FilePath $installer -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART','/CURRENTUSER',('/DIR="'+$destination+'"')) -WindowStyle Hidden -Wait -PassThru
if($process.ExitCode -ne 0){throw 'Compiler installation failed'}
$compiler=Join-Path $destination 'ISCC.exe'
if(!(Test-Path -LiteralPath $compiler)){throw 'Compiler missing'}
return $compiler
