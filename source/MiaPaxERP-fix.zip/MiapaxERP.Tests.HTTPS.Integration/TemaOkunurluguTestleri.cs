using System.Windows.Media;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class TemaOkunurluguTestleri
{
 [Fact]public void TumPaletlerdeAcikKoyuVeUyariYazilariOkunur(){foreach(string theme in Tema170.Adlar){var p=Tema170.Sec(theme);foreach(string bg in new[]{p.Zemin,p.Yuzey,p.Menu,p.Vurgu})foreach(string fg in new[]{"#FFFFFF","#182E42","#64748B","#991B1B","#166534","#92400E"}){var surface=(Color)ColorConverter.ConvertFromString(bg);var result=TemaOkunurlugu.Uyumlu((Color)ColorConverter.ConvertFromString(fg),surface);Assert.True(TemaOkunurlugu.Kontrast(result,surface)>=4.5,theme+" "+bg+" "+fg);}}}
 [Fact]public void KoyuGorunumdeSabitAcikZeminlerKoyulasirVeAcikYaziOkunur(){foreach(string bg in new[]{"#FFFFFF","#E8EEF6","#F0FDF4","#FEE2E2","#E2E8F0","#F8FAFC","#FFF4EE"}){var c=(Color)ColorConverter.ConvertFromString(bg);var dark=TemaOkunurlugu.KoyuKarsilik(c);Assert.True(TemaOkunurlugu.Parlaklik(dark)<.1,bg);Assert.True(TemaOkunurlugu.Kontrast(Color.FromRgb(0xF2,0xF7,0xFF),dark)>=4.5,bg);}}
}
