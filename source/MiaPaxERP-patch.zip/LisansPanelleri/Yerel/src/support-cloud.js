import {signSupportRelay} from './legacy/support-relay.js';
const origin='https://boruerp-lisans-yonetimi.ali-can-0001.chatgpt.site';
export async function remoteSupport(env,license,action='read',issueId='',send=fetch){
 const body=await signSupportRelay(env,license,action,issueId);
 const r=await send(origin+'/api/support-relay',{method:'POST',redirect:'error',signal:AbortSignal.timeout(8000),headers:{'content-type':'application/json'},body:JSON.stringify(body)});
 if(r.status===404)return null;
 if(!r.ok)throw new Error('İnternet paneli cihaz bilgileri şu anda alınamadı.');
 const raw=await r.text();if(raw.length>2*1024*1024)throw new Error('Destek yanıtı sınırı aşıldı.');
 const data=JSON.parse(raw);if(action==='read'&&(!Array.isArray(data.devices)||!Array.isArray(data.issues)))throw new Error('Destek yanıtı geçersiz.');return data;
}
export function mergeSupport(local,remote){
 if(!remote)return {...local,supportSource:'Yerel lisans paneli',supportMessage:'İnternet panelinde aynı lisans bulunamadı; yerel kayıtlar gösteriliyor.'};
 const newest=(a,b,key)=>{const m=new Map(a.map(x=>[x[key],x]));for(const x of b){const old=m.get(x[key]);if(!old||x.last_seen>=old.last_seen)m.set(x[key],x);}return [...m.values()];};
 const devices=newest(local.devices,remote.devices,'device_id'),issues=newest(local.issues,remote.issues,'id');
 return {...local,devices,issues,registeredPcCount:Math.max(local.registeredPcCount,remote.registeredPcCount,devices.length),recentPcCount:devices.filter(x=>Date.parse(x.last_seen)>Date.now()-86400000).length,reportedDeviceCount:devices.length,supportSource:'Yerel + internet lisans paneli',supportMessage:'İnternet panelindeki aynı lisansa ait cihaz bilgileri güvenli bağlantıyla alındı.'};
}
