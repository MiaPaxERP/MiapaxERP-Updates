import assert from 'node:assert/strict';
import {seal,unseal} from '../worker/mail.js';
const env={LICENSE_PRIVATE_PKCS8:'test-only-not-a-real-key'};
const ciphertext=await seal(env,'refresh-secret');assert(!ciphertext.includes('refresh-secret'));assert.equal(await unseal(env,ciphertext),'refresh-secret');await assert.rejects(()=>unseal({...env,LICENSE_PRIVATE_PKCS8:'wrong'},ciphertext));
console.log('PASS Mail token encryption, decryption and wrong-key rejection');
