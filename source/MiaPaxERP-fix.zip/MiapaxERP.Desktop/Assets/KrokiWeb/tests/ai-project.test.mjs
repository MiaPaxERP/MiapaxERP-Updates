import test from 'node:test';import assert from 'node:assert/strict';
import {calculate,normalize,parseText,fromAi,matchPrices,headLoss,chooseDiameter,MATERIALS,defaults} from '../js/ai-project.mjs?v=ai1';

test('drip project splits long laterals, sizes main line and lists products',()=>{
 const r=calculate({width:100,length:200,method:'drip',sourceType:'well',sourceSide:'south',sourceDistance:50});
 assert.equal(r.split,true);assert.equal(r.lateralRun,100);assert.equal(r.lateralCount,200);
 assert.equal(r.mainLen,150);assert.ok(r.mainOd>=90&&r.mainOd<=125);
 assert.ok(r.sections>=3);assert.ok(r.head>40&&r.head<90);
 const names=r.bom.map(b=>b.name);
 for(const n of ['Damla borusu (lateral)','Hat sonu tapası','Bölüm vanası','Dalgıç pompa','Disk filtre'])assert.ok(names.includes(n),n);
 const lat=r.bom.find(b=>b.name==='Damla borusu (lateral)');assert.ok(lat.qty>=r.lateralTotal&&lat.qty<r.lateralTotal*1.05);
 assert.equal(r.bom.find(b=>b.name==='Hat sonu tapası').qty,200);
});
test('sprinkler from east source needs one elbow and gets method defaults',()=>{
 const r=calculate({width:120,length:140,method:'sprinkler',sourceType:'tank',sourceSide:'east',sourceDistance:80,sourceOffset:0.2,accessories:['pump']});
 assert.equal(r.input.rowGap,12);assert.equal(r.input.emitterGap,12);assert.equal(r.split,false);
 assert.equal(r.corners,1);assert.equal(r.bom.find(b=>b.name==='Dirsek 90°').qty,1);
 assert.equal(r.mainLen,r1(80+140*0.2));
 assert.equal(r.bom.find(b=>b.name.startsWith('Yağmurlama başlığı')).qty,r.emitters);
 assert.equal(r.bom.find(b=>b.name==='Santrifüj pompa').qty,1);
});
const r1=x=>Math.round(x*10)/10;
test('undersized manual main line and missing filter produce warnings',()=>{
 const r=calculate({width:100,length:100,method:'drip',mainDiameter:40,accessories:[]});
 assert.ok(r.warnings.some(w=>w.includes('40 mm')));assert.ok(r.warnings.some(w=>w.includes('filtre')));assert.ok(r.warnings.some(w=>w.includes('pompa')));
});
test('normalize clamps hostile and absurd values',()=>{
 const p=normalize({width:-5,length:1e9,method:'x',mainDiameter:77,accessories:['filter','rm -rf'],project:'<script>a</script>',sourceSide:'up'});
 assert.equal(p.width,2);assert.equal(p.length,5000);assert.equal(p.method,'drip');assert.equal(p.mainDiameter,0);assert.deepEqual(p.accessories,['filter']);
 assert.ok(!p.project.includes('<'));assert.equal(p.sourceSide,'south');
});
test('Turkish free text is understood without a server',()=>{
 const o=parseText("80x150 metre domates, damla sulama. Kuyu güneyde 300 metre uzakta, 60 metre derin. 90'lık PE ana hat, gübre tankı olsun",defaults());
 assert.equal(o.width,80);assert.equal(o.length,150);assert.equal(o.method,'drip');assert.equal(o.sourceType,'well');assert.equal(o.sourceSide,'south');
 assert.equal(o.sourceDistance,300);assert.equal(o.wellDepth,60);assert.equal(o.mainDiameter,90);assert.equal(o.crop,'domates');assert.ok(o.accessories.includes('fertilizer'));
 const d=parseText('20 dekar mısır yağmurlama, şebeke batıda 1 km, sıra arası 12',defaults());
 assert.equal(d.width*d.length,20000);assert.equal(d.method,'sprinkler');assert.equal(d.sourceDistance,1000);assert.equal(d.sourceSide,'west');assert.ok(!d.accessories.includes('pump'));
});
test('AI JSON is filtered to allowed fields',()=>{
 assert.deepEqual(fromAi('Tamam: {"width":50,"length":60,"evil":"x","method":"drip"}'),{width:50,length:60,method:'drip'});
 assert.equal(fromAi('json yok'),null);assert.equal(fromAi('{bozuk'),null);
});
test('hydraulics are monotonic',()=>{
 assert.ok(headLoss(20,100,80)>headLoss(20,100,100));assert.ok(headLoss(30,100,80)>headLoss(20,100,80));
 assert.ok(chooseDiameter(60,300,MATERIALS.PE100)>chooseDiameter(10,300,MATERIALS.PE100));
});
test('stock prices match by diameter and keyword with VAT',()=>{
 const r=calculate({width:50,length:60,method:'drip',accessories:['filter']});
 const stock=[{id:1,code:'PE-63',name:'PE100 boru 63 mm',diameter:63,retail:120,currency:'TRY',vat:20,retailVatIncluded:true},{id:2,code:'TPA',name:'Tapa 16 mm',diameter:16,retail:2,currency:'TRY',vat:20,retailVatIncluded:false},{id:3,code:'F',name:'Disk filtre 2"',retail:1000,currency:'TRY'}];
 const m=matchPrices(r.bom,stock);
 const tapa=m.find(x=>x.name==='Hat sonu tapası');assert.equal(tapa.price,2);assert.equal(tapa.totalVat,Math.round(2*tapa.qty*1.2*100)/100);
 const filter=m.find(x=>x.name==='Disk filtre');assert.equal(filter.vat,20);assert.ok(Math.abs(filter.price-1000/1.2)<0.01);
 if(r.mainOd===63)assert.equal(m.find(x=>x.name.includes('ana hat')).price,100);
});
