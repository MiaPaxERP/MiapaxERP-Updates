using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop
{
    /// <summary>Yüklenen resmî PDF'ten (vergi levhası, sicil gazetesi, imza sirküleri vb.) boş firma alanlarını doldurur.</summary>
    public partial class FirmaBilgileriPenceresi
    {
        private bool pdfOkunuyor;

        private void BelgedenDoldur_Click(object sender, RoutedEventArgs e) => Guvenli(() =>
        {
            using var con = Baglan();
            var (_, pdf) = BelgeOku(con, SecilenBelge());
            _ = PdfdenDoldurAsync(pdf, true);
        });

        /// <summary>PDF metnini okur, bulunan bilgileri yalnız BOŞ alanlara yazar (dolu alan değiştirilmez). Kaydetmek kullanıcıya bırakılır.</summary>
        private async Task PdfdenDoldurAsync(byte[] pdf, bool elle)
        {
            if (pdfOkunuyor) return;
            pdfOkunuyor = true;
            try
            {
                Durum.Text = "PDF okunuyor, firma bilgileri aranıyor…";
                string metin = await PdfMetinOkuyucu.MetinAsync(this, pdf);
                if (metin.Trim().Length < 20)
                {
                    Durum.Text = "PDF'te okunabilir metin bulunamadı (taranmış/resim PDF olabilir). Bilgileri elle girin.";
                    return;
                }
                var bulunan = FirmaBelgeAyiklayici.Ayikla(metin);
                var doldurulan = new System.Collections.Generic.List<string>();
                var atlanan = new System.Collections.Generic.List<string>();
                foreach (var (alan, deger) in bulunan)
                {
                    if (FindName(alan) is not TextBox kutu) continue;
                    if (string.IsNullOrWhiteSpace(kutu.Text)) { kutu.Text = deger; doldurulan.Add(Etiket(alan)); }
                    else if (!string.Equals(kutu.Text.Trim(), deger, StringComparison.CurrentCultureIgnoreCase)) atlanan.Add(Etiket(alan) + ": " + deger);
                }
                if (doldurulan.Count == 0 && atlanan.Count == 0)
                    Durum.Text = "PDF okundu ancak tanınan firma bilgisi bulunamadı.";
                else
                {
                    Durum.Text = (doldurulan.Count > 0 ? doldurulan.Count + " alan PDF'ten dolduruldu: " + string.Join(", ", doldurulan) + ". Kontrol edip 'Firma Bilgilerini Kaydet'e basın." : "Boş alan kalmadı.")
                        + (atlanan.Count > 0 ? " Dolu olduğu için değiştirilmeyen: " + string.Join(" · ", atlanan.Take(6)) : "");
                    if (elle && atlanan.Count > 0 && MessageBox.Show(this, "PDF'te mevcut kayıttan farklı " + atlanan.Count + " bilgi var:\n\n" + string.Join("\n", atlanan.Take(12)) + "\n\nBu alanlar PDF'teki değerlerle değiştirilsin mi?", "PDF'ten doldur", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        foreach (var (alan, deger) in bulunan) if (FindName(alan) is TextBox kutu) kutu.Text = deger;
                        Durum.Text = "PDF'teki bilgiler forma yazıldı. Kontrol edip kaydedin.";
                    }
                }
            }
            catch (Exception ex)
            {
                DestekIzleme.Bildir(ex, "FirmaBilgileri.PdfOku");
                Durum.Text = "PDF'ten bilgi okunamadı: " + ex.Message;
            }
            finally { pdfOkunuyor = false; }
        }

        private static string Etiket(string alan) => alan switch
        {
            "F_FirmaAdi" => "Unvan", "F_VergiNo" => "Vergi no", "F_VergiDairesi" => "Vergi dairesi", "F_MersisNo" => "MERSİS", "F_TicaretSicilNo" => "Sicil no",
            "F_TicaretSicilMudurlugu" => "Sicil müdürlüğü", "F_NaceKodu" => "NACE", "F_KurulusTarihi" => "Kuruluş tarihi", "F_FaaliyetKonusu" => "Faaliyet",
            "F_Iban" => "IBAN", "F_Eposta" => "E-posta", "F_KepAdresi" => "KEP", "F_WebSitesi" => "Web", "F_Telefon" => "Telefon", "F_Telefon2" => "2. telefon",
            "F_Adres" => "Adres", "F_Il" => "İl", "F_Ilce" => "İlçe", "F_PostaKodu" => "Posta kodu", "F_Ulke" => "Ülke", "F_YetkiliAdSoyad" => "Yetkili",
            "F_BankaAdi" => "Banka", "F_SubeAdi" => "Şube", "F_HesapNo" => "Hesap no", "F_OdaKayitNo" => "Oda kayıt no", "F_FirmaTuru" => "Firma türü", _ => alan
        };
    }
}
