using System.Data;
using System.IO;
using System.Net;
using System.Windows;
using Microsoft.Win32;
using Microsoft.Web.WebView2.Wpf;
namespace MiapaxERP.Desktop;
public static class PdfTabloRaporu
{
 public static async Task Kaydet(Window owner,string title,DataTable data){
  var save=new SaveFileDialog{Filter="PDF belgesi|*.pdf",FileName="MiaPaxERP-"+string.Concat(title.Where(c=>char.IsLetterOrDigit(c)||c==' ')).Replace(' ','-')+".pdf"};if(save.ShowDialog(owner)!=true)return;
  await Yaz(owner,title,data,save.FileName);
 }
 internal static async Task Yaz(Window owner,string title,DataTable data,string path){
  var window=new Window{Owner=owner,Title="MiaPaxERP • "+Dil.Cevir("PDF hazırlanıyor"),Width=920,Height=650,WindowStartupLocation=WindowStartupLocation.CenterOwner};using var web=new WebView2();window.Content=web;window.Show();try{
   await web.EnsureCoreWebView2Async();web.CoreWebView2.Settings.IsScriptEnabled=false;web.CoreWebView2.Settings.AreDevToolsEnabled=false;
   string E(object? v)=>WebUtility.HtmlEncode(v is byte[]?"":Convert.ToString(v,System.Globalization.CultureInfo.GetCultureInfo("tr-TR"))??"");
   var columns=data.Columns.Cast<DataColumn>().Where(c=>c.DataType!=typeof(byte[])&&c.ColumnName!="Veri").ToArray();
   // Başlık, sütun adları ve sabit metinler program diline çevrilir; tablo verisi olduğu gibi kalır.
   string T(string s)=>E(Dil.CevirKayitsiz(s));
   string html="<!doctype html><html lang='"+Dil.Mevcut+"'"+(Dil.SagdanSola?" dir='rtl'":"")+"><meta charset='utf-8'><style>@page{size:A4 landscape;margin:12mm}body{font:11px Arial;color:#183a4b}h1{border-bottom:3px solid #16806d;padding-bottom:12px}table{width:100%;border-collapse:collapse;table-layout:fixed}th,td{border-bottom:1px solid #cddce2;padding:7px;overflow-wrap:anywhere;text-align:start}th{background:#eaf2f4}thead{display:table-header-group}tr{break-inside:avoid}footer{margin-top:20px;color:#607784}</style><h1>MiaPaxERP · "+T(title)+"</h1><p>"+DateTime.Now.ToString("dd.MM.yyyy HH:mm")+" · "+T(data.Rows.Count+" kayıt")+"</p><table><thead><tr>"+string.Concat(columns.Select(c=>"<th>"+T(c.ColumnName)+"</th>"))+"</tr></thead><tbody>"+string.Concat(data.Rows.Cast<DataRow>().Select(r=>"<tr>"+string.Concat(columns.Select(c=>"<td>"+E(r[c])+"</td>"))+"</tr>"))+"</tbody></table><footer>"+T("MiaPaxERP · Üretim ve işletme kayıtları")+"</footer></html>";
   var loaded=new TaskCompletionSource<bool>();web.CoreWebView2.NavigationCompleted+=(_,e)=>loaded.TrySetResult(e.IsSuccess);web.NavigateToString(html);if(!await loaded.Task.WaitAsync(TimeSpan.FromSeconds(20)))throw new IOException("Rapor yüklenemedi.");var settings=web.CoreWebView2.Environment.CreatePrintSettings();settings.PageWidth=8.2677;settings.PageHeight=11.6929;settings.Orientation=Microsoft.Web.WebView2.Core.CoreWebView2PrintOrientation.Landscape;settings.ShouldPrintBackgrounds=true;settings.ShouldPrintHeaderAndFooter=false;if(!await web.CoreWebView2.PrintToPdfAsync(path,settings))throw new IOException("PDF kaydedilemedi.");
  }finally{window.Close();}
 }
}
