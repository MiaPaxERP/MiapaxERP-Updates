using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace MiapaxERP.Desktop
{
    public partial class TicariModullerPaneli
    {
        private bool dilHazirlaniyor;
        private CancellationTokenSource? dilCts;

        private void DilSeciminiHazirla()
        {
            dilHazirlaniyor = true;
            CmbDil.ItemsSource = Dil.Diller;
            CmbDil.SelectedItem = Dil.Diller.FirstOrDefault(d => d.Kod == Dil.Mevcut) ?? Dil.Diller[0];
            dilHazirlaniyor = false;
            DilDurumunuGoster();
        }

        private void DilDurumunuGoster()
        {
            BtnDilTamamla.IsEnabled = !Dil.Turkce && dilCts == null;
            TxtDilDurum.Text = Dil.Turkce
                ? "Türkçe kaynak dildir."
                : $"Menüler, düğmeler ve temel ekran başlıkları yerleşik sözlükten çevrilir. Bu oturumda sözlükte bulunmayan {Dil.EksikSayisi} metin görüldü; yapay zekâ bağlantısı varsa tamamlanabilir.";
        }

        private void CmbDil_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dilHazirlaniyor || CmbDil.SelectedItem is not Dil.Secenek secim) return;
            Dil.Degistir(secim.Kod);
            DilDurumunuGoster();
        }

        private async void DilTamamla_Click(object sender, RoutedEventArgs e)
        {
            if (dilCts != null) return;
            var ayar = AsistanAyari.Oku(Path.Combine(GorunumDeposu.Klasor(baglantiAdresi, kullaniciId), "asistan.json"));
            dilCts = new CancellationTokenSource(TimeSpan.FromMinutes(10));
            BtnDilTamamla.IsEnabled = false;
            try
            {
                var ilerleme = new Progress<string>(m => TxtDilDurum.Text = m);
                var (_, durum) = await Dil.YapayZekaIleTamamlaAsync(ayar, dilCts.Token, ilerleme);
                TxtDilDurum.Text = durum;
            }
            catch (OperationCanceledException) { TxtDilDurum.Text = "Çeviri zaman aşımına uğradı; tamamlanan kısım saklandı."; }
            finally
            {
                dilCts.Dispose(); dilCts = null;
                BtnDilTamamla.IsEnabled = !Dil.Turkce;
            }
        }
    }
}
