using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.Muhasebe280;

public sealed record PersonelUcreti(int PersonelId,string Sicil,string AdSoyad,string Departman,DateTime IseGiris,DateTime? IstenCikis,UcretEsasi? Esas,decimal? Ucret,SigortaTuru? Sigorta,int? CariId,bool AsgariIstisna);
public sealed record PersonelUcretGirdisi(int PersonelId,UcretEsasi Esas,decimal Ucret,SigortaTuru Sigorta,int? CariId,bool AsgariIstisna);
/// <summary>Bir çalışanın bu ay bugüne kadar hak ettiği ücret (prim günü = ayın geçen günü − ücretsiz izin/rapor günleri).</summary>
public sealed record GunlukHakedis(int PersonelId,string Sicil,string AdSoyad,string Departman,int Yil,int Ay,int CalisilanGun,decimal IzinsizGun,decimal AylikUcret,string Esas,decimal Brut,decimal Net,decimal IsverenMaliyeti,decimal GunlukNet,string Durum);

/// <summary>
/// Çalışan ücret tanımları ve günlük otomatik bordro (hak ediş) hesabı. Tanım yapılan her çalışan için bordro motoru
/// (2026 parametreleri) her gün çalıştırılır; ay sonunda tek tuşla tüm çalışanların taslak bordrosu hazırlanır.
/// Kümülatif gelir vergisi matrahı aynı yılın önceki bordrolarından otomatik alınır.
/// </summary>
public sealed class PersonelUcretDeposu
{
 internal const string Ddl="""
IF OBJECT_ID('dbo.BERP_Personel','U') IS NOT NULL AND OBJECT_ID('dbo.MPXNext_PersonelUcret','U') IS NULL
 CREATE TABLE dbo.MPXNext_PersonelUcret(
  PersonelId int NOT NULL CONSTRAINT PK_MPXNext_PersonelUcret PRIMARY KEY CONSTRAINT FK_MPXNext_PersonelUcret_Personel REFERENCES dbo.BERP_Personel(Id),
  Esas tinyint NOT NULL CONSTRAINT CK_MPXNext_PersonelUcret_Esas CHECK(Esas IN(0,1)),
  Ucret decimal(18,2) NOT NULL CONSTRAINT CK_MPXNext_PersonelUcret_Ucret CHECK(Ucret>0),
  Sigorta tinyint NOT NULL CONSTRAINT CK_MPXNext_PersonelUcret_Sigorta CHECK(Sigorta IN(0,1)),
  CariId int NULL,
  AsgariIstisna bit NOT NULL CONSTRAINT DF_MPXNext_PersonelUcret_Istisna DEFAULT 1,
  Guncelleyen int NOT NULL,
  Guncelleme datetime2(3) NOT NULL CONSTRAINT DF_MPXNext_PersonelUcret_Tarih DEFAULT SYSDATETIME());
""";
 static readonly System.Collections.Concurrent.ConcurrentDictionary<string,bool> hazir=new(StringComparer.OrdinalIgnoreCase);
 readonly string cs;readonly int user;readonly Action<SqlConnection,SqlTransaction?,string> check;
 public PersonelUcretDeposu(string connection,int userId){cs=connection;user=userId;check=new ErpModulServisi(cs,user).Yetki;}
 internal PersonelUcretDeposu(string connection,int userId,Action<SqlConnection,SqlTransaction?,string> permission){cs=connection;user=userId;check=permission;}

 SqlConnection Ac(){
  var c=new SqlConnection(cs);c.Open();
  try{
   string key=c.DataSource+"|"+c.Database;
   if(!hazir.ContainsKey(key)){
    using var t=c.BeginTransaction();
    using(var l=Q(c,t,"EXEC sp_getapplock @Resource='MiaPaxNextSchema',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;"))l.ExecuteNonQuery();
    using(var k=Q(c,t,Ddl))k.ExecuteNonQuery();t.Commit();hazir[key]=true;
   }
   return c;
  }catch{c.Dispose();throw;}
 }
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] p)=>ErpModulServisi.Komut(c,t,sql,p);

 /// <summary>Tüm çalışanlar (bordrosu olmayanlar dahil) ve ücret tanımları.</summary>
 public PersonelUcreti[] Liste(){
  if(HttpsOturumu.Uzak(cs))return HttpsOturumu.Cagir<PersonelUcreti[]>(cs,"PersonelUcretDeposu.Liste","",[]);
  using var c=Ac();check(c,null,"HR.PAYROLL.VIEW");
  using var q=Q(c,null,"SELECT p.Id,p.Sicil,p.AdSoyad,p.Departman,p.IseGiris,p.IstenCikis,u.Esas,u.Ucret,u.Sigorta,u.CariId,ISNULL(u.AsgariIstisna,1) FROM dbo.BERP_Personel p LEFT JOIN dbo.MPXNext_PersonelUcret u ON u.PersonelId=p.Id ORDER BY CASE WHEN p.IstenCikis IS NULL THEN 0 ELSE 1 END,p.AdSoyad");
  using var r=q.ExecuteReader();var list=new List<PersonelUcreti>();
  while(r.Read())list.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetDateTime(4),r.IsDBNull(5)?null:r.GetDateTime(5),r.IsDBNull(6)?null:(UcretEsasi)r.GetByte(6),r.IsDBNull(7)?null:r.GetDecimal(7),r.IsDBNull(8)?null:(SigortaTuru)r.GetByte(8),r.IsDBNull(9)?null:r.GetInt32(9),r.GetBoolean(10)));
  return list.ToArray();
 }

 public int Kaydet(PersonelUcretGirdisi[] rows){
  if(HttpsOturumu.Uzak(cs))return HttpsOturumu.Cagir<int>(cs,"PersonelUcretDeposu.Kaydet","",[rows]);
  if(rows is null||rows.Length is 0 or >2000)throw new ArgumentException("Kaydedilecek ücret tanımı yok.");
  foreach(var g in rows){if(g.Ucret<=0||g.Ucret>99_999_999m||decimal.Round(g.Ucret,2)!=g.Ucret||!Enum.IsDefined(g.Esas)||!Enum.IsDefined(g.Sigorta))throw new ArgumentException("Ücret pozitif ve en fazla iki ondalıklı olmalı.");}
  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"HR.PAYROLL.EDIT");
  foreach(var g in rows){
   using(var p=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP_Personel WHERE Id=@p",("@p",g.PersonelId)))if(Convert.ToInt32(p.ExecuteScalar())!=1)throw new ArgumentException("Çalışan bulunamadı.");
   if(g.CariId is int cari){using var k=Q(c,t,"SELECT COUNT(*) FROM dbo.CariKartlari WHERE Id=@c AND Aktif=1",("@c",cari));if(Convert.ToInt32(k.ExecuteScalar())!=1)throw new ArgumentException("Ücret cari kartı aktif değil.");}
   using var u=Q(c,t,"UPDATE dbo.MPXNext_PersonelUcret SET Esas=@e,Ucret=@u,Sigorta=@s,CariId=@c,AsgariIstisna=@i,Guncelleyen=@k,Guncelleme=SYSDATETIME() WHERE PersonelId=@p;IF @@ROWCOUNT=0 INSERT dbo.MPXNext_PersonelUcret(PersonelId,Esas,Ucret,Sigorta,CariId,AsgariIstisna,Guncelleyen) VALUES(@p,@e,@u,@s,@c,@i,@k)",
    ("@p",g.PersonelId),("@e",(byte)g.Esas),("@u",g.Ucret),("@s",(byte)g.Sigorta),("@c",g.CariId),("@i",g.AsgariIstisna),("@k",user));u.ExecuteNonQuery();
  }
  t.Commit();return rows.Length;
 }

 /// <summary>Verilen günün ayı için, o güne kadar hak edilen ücret. Bordrosu onaylanmış/ödenmiş ay da gösterilir.</summary>
 public GunlukHakedis[] GunlukHesap(DateTime gun){
  if(HttpsOturumu.Uzak(cs))return HttpsOturumu.Cagir<GunlukHakedis[]>(cs,"PersonelUcretDeposu.GunlukHesap","",[gun]);
  gun=gun.Date;using var c=Ac();check(c,null,"HR.PAYROLL.VIEW");
  var personel=Tanimli(c,null);var result=new List<GunlukHakedis>();
  foreach(var p in personel){
   var (yil,ay)=(gun.Year,gun.Month);var ayBas=new DateTime(yil,ay,1);
   DateTime bas=p.IseGiris>ayBas?p.IseGiris:ayBas;DateTime bit=p.IstenCikis is DateTime cik&&cik<gun?cik:gun;
   if(bit<bas){result.Add(new(p.PersonelId,p.Sicil,p.AdSoyad,p.Departman,yil,ay,0,0,p.Ucret!.Value,p.Esas.ToString()!,0,0,0,0,p.IstenCikis<ayBas?"İşten ayrıldı":"Henüz işe başlamadı"));continue;}
   decimal izinsiz=IzinsizGun(c,null,p.PersonelId,bas,bit);
   int gunSayisi=Math.Min(30,(bit-bas).Days+1);int prim=Math.Max(0,(int)Math.Floor(gunSayisi-izinsiz));
   if(prim==0){result.Add(new(p.PersonelId,p.Sicil,p.AdSoyad,p.Departman,yil,ay,0,izinsiz,p.Ucret!.Value,p.Esas.ToString()!,0,0,0,0,"Prim günü yok"));continue;}
   var (once,onceIst)=OncekiMatrah(c,null,p.PersonelId,yil,ay);
   decimal oransal=decimal.Round(p.Ucret!.Value*prim/30m,2);
   BordroSonuc s;try{s=BordroHesabi.Hesapla(new BordroGirdi(yil,ay,p.Esas!.Value,oransal,prim,p.Sigorta!.Value,once,onceIst,p.AsgariIstisna));}
   catch(ArgumentException e){result.Add(new(p.PersonelId,p.Sicil,p.AdSoyad,p.Departman,yil,ay,prim,izinsiz,p.Ucret!.Value,p.Esas.ToString()!,0,0,0,0,"Hesaplanamadı: "+e.Message));continue;}
   result.Add(new(p.PersonelId,p.Sicil,p.AdSoyad,p.Departman,yil,ay,prim,izinsiz,p.Ucret.Value,p.Esas.Value==UcretEsasi.Net?"Net":"Brüt",s.Brut,s.Net,s.IsverenMaliyeti,prim>0?decimal.Round(s.Net/prim,2):0,BordroDurumu(c,null,p.PersonelId,yil,ay)));
  }
  return result.ToArray();
 }

 /// <summary>Ayın tamamı için taslak bordroları hazırlar (zaten bordrosu olan ve ücret cari kartı tanımlı olmayan çalışanlar atlanır).</summary>
 public sealed record TaslakSonucu(int Hazirlanan,string[] Atlanan);
 public TaslakSonucu AySonuTaslaklari(int yil,int ay){
  if(HttpsOturumu.Uzak(cs))return HttpsOturumu.Cagir<TaslakSonucu>(cs,"PersonelUcretDeposu.AySonuTaslaklari","",[yil,ay]);
  if(yil is <2026 or >2100||ay is <1 or >12)throw new ArgumentException("Dönem geçersiz (bordro parametreleri 2026'dan itibaren).");
  var ayBas=new DateTime(yil,ay,1);var aySon=ayBas.AddMonths(1).AddDays(-1);
  List<PersonelUcreti> personel;using(var c=Ac()){check(c,null,"HR.PAYROLL.EDIT");personel=Tanimli(c,null);}
  var depo=new BordroDeposu(cs,user,check);int ok=0;var skip=new List<string>();
  foreach(var p in personel){
   try{
    using var c=Ac();
    if(BordroDurumu(c,null,p.PersonelId,yil,ay)!="Bordro yok"){skip.Add(p.AdSoyad+": bu ay bordrosu var");continue;}
    if(p.CariId is not int cari){skip.Add(p.AdSoyad+": ücret cari kartı tanımlı değil");continue;}
    DateTime bas=p.IseGiris>ayBas?p.IseGiris:ayBas,bit=p.IstenCikis is DateTime cik&&cik<aySon?cik:aySon;
    if(bit<bas){skip.Add(p.AdSoyad+": bu ay çalışmadı");continue;}
    decimal izinsiz=IzinsizGun(c,null,p.PersonelId,bas,bit);
    int tamAy=bas==ayBas&&bit==aySon?30:Math.Min(30,(bit-bas).Days+1);
    int prim=Math.Max(0,(int)Math.Floor(tamAy-izinsiz));if(prim==0){skip.Add(p.AdSoyad+": prim günü yok");continue;}
    var (once,onceIst)=OncekiMatrah(c,null,p.PersonelId,yil,ay);
    var g=new BordroGirdi(yil,ay,p.Esas!.Value,decimal.Round(p.Ucret!.Value*prim/30m,2),prim,p.Sigorta!.Value,once,onceIst,p.AsgariIstisna,IndirimDayanagi:"Otomatik aylık bordro");
    c.Dispose();
    depo.Hazirla(Guid.NewGuid(),p.PersonelId,cari,g,"Otomatik aylık bordro: "+prim+" prim günü, ücretsiz izin/rapor "+izinsiz.ToString("0.#")+" gün");ok++;
   }catch(Exception e){skip.Add(p.AdSoyad+": "+e.Message);}
  }
  return new(ok,skip.ToArray());
 }

 static List<PersonelUcreti> Tanimli(SqlConnection c,SqlTransaction? t){
  using var q=Q(c,t,"SELECT p.Id,p.Sicil,p.AdSoyad,p.Departman,p.IseGiris,p.IstenCikis,u.Esas,u.Ucret,u.Sigorta,u.CariId,u.AsgariIstisna FROM dbo.BERP_Personel p JOIN dbo.MPXNext_PersonelUcret u ON u.PersonelId=p.Id ORDER BY p.AdSoyad");
  using var r=q.ExecuteReader();var list=new List<PersonelUcreti>();
  while(r.Read())list.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetDateTime(4),r.IsDBNull(5)?null:r.GetDateTime(5),(UcretEsasi)r.GetByte(6),r.GetDecimal(7),(SigortaTuru)r.GetByte(8),r.IsDBNull(9)?null:r.GetInt32(9),r.GetBoolean(10)));
  return list;
 }
 /// <summary>Ücretsiz izin ve rapor günleri (onaylı/onaysız tüm kayıtlar), dönemle kesişen kısmı oranlanarak.</summary>
 static decimal IzinsizGun(SqlConnection c,SqlTransaction? t,int personel,DateTime bas,DateTime bit){
  using var q=Q(c,t,"SELECT Baslangic,Bitis,Miktar FROM dbo.BERP_IKIslem WHERE PersonelId=@p AND Tur IN(N'Ücretsiz İzin',N'Rapor') AND Bitis>=@b AND Baslangic<=@e",("@p",personel),("@b",bas),("@e",bit));
  using var r=q.ExecuteReader();decimal toplam=0;
  while(r.Read()){
   DateTime b=r.GetDateTime(0),e=r.GetDateTime(1);decimal m=r.GetDecimal(2);int tum=Math.Max(1,(e-b).Days+1);
   DateTime kb=b>bas?b:bas,ke=e<bit?e:bit;int kesisen=Math.Max(0,(ke-kb).Days+1);
   toplam+=m>0?m*kesisen/tum:kesisen;
  }
  return decimal.Round(toplam,1);
 }
 static (decimal Matrah,decimal Istisna) OncekiMatrah(SqlConnection c,SqlTransaction? t,int personel,int yil,int ay){
  if(ay==1)return (0,0);
  using var q=Q(c,t,"SELECT ISNULL((SELECT TOP(1) TRY_CONVERT(decimal(18,2),JSON_VALUE(Sonuc,'$.KumulatifMatrah')) FROM dbo.MPX280_Bordro WHERE PersonelId=@p AND Yil=@y AND Ay<@a AND Durum<>N'İptal' ORDER BY Ay DESC),0),ISNULL((SELECT SUM(TRY_CONVERT(decimal(18,2),JSON_VALUE(Sonuc,'$.IstisnaMatrahi'))) FROM dbo.MPX280_Bordro WHERE PersonelId=@p AND Yil=@y AND Ay<@a AND Durum<>N'İptal'),0)",("@p",personel),("@y",yil),("@a",ay));
  using var r=q.ExecuteReader();r.Read();return (r.GetDecimal(0),r.GetDecimal(1));
 }
 static string BordroDurumu(SqlConnection c,SqlTransaction? t,int personel,int yil,int ay){
  using var q=Q(c,t,"SELECT TOP(1) Durum FROM dbo.MPX280_Bordro WHERE PersonelId=@p AND Yil=@y AND Ay=@a AND Durum<>N'İptal'",("@p",personel),("@y",yil),("@a",ay));
  return q.ExecuteScalar() is string s?"Bordro: "+s:"Bordro yok";
 }
}
