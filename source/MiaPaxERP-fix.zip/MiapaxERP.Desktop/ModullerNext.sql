SET XACT_ABORT ON;
IF OBJECT_ID('dbo.MPXNext_Departman','U') IS NULL CREATE TABLE dbo.MPXNext_Departman(Id int IDENTITY PRIMARY KEY,Ad nvarchar(100) NOT NULL UNIQUE,Aktif bit NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.MPXNext_DepartmanUye','U') IS NULL CREATE TABLE dbo.MPXNext_DepartmanUye(Departman int NOT NULL REFERENCES dbo.MPXNext_Departman(Id),Kullanici int NOT NULL REFERENCES dbo.Kullanicilar(Id),PRIMARY KEY(Departman,Kullanici));
IF OBJECT_ID('dbo.MPXNext_Duyuru','U') IS NULL CREATE TABLE dbo.MPXNext_Duyuru(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,Kaynak nvarchar(180) NULL,Gonderen int NOT NULL,Baslik nvarchar(160) NOT NULL,Metin nvarchar(4000) NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MPXNext_Duyuru') AND name='UX_Duyuru_Kaynak') CREATE UNIQUE INDEX UX_Duyuru_Kaynak ON dbo.MPXNext_Duyuru(Kaynak) WHERE Kaynak IS NOT NULL;
IF OBJECT_ID('dbo.MPXNext_DuyuruAlici','U') IS NULL CREATE TABLE dbo.MPXNext_DuyuruAlici(Duyuru bigint NOT NULL REFERENCES dbo.MPXNext_Duyuru(Id),Kullanici int NOT NULL REFERENCES dbo.Kullanicilar(Id),Okundu datetime2 NULL,PRIMARY KEY(Duyuru,Kullanici));
IF OBJECT_ID('dbo.MPXNext_Mesaj','U') IS NULL CREATE TABLE dbo.MPXNext_Mesaj(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,Gonderen int NOT NULL REFERENCES dbo.Kullanicilar(Id),Alici int NULL REFERENCES dbo.Kullanicilar(Id),Departman int NULL REFERENCES dbo.MPXNext_Departman(Id),Metin nvarchar(4000) NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),CHECK((Alici IS NULL AND Departman IS NOT NULL) OR (Alici IS NOT NULL AND Departman IS NULL)));
IF OBJECT_ID('dbo.MPXNext_MesajOkuma','U') IS NULL CREATE TABLE dbo.MPXNext_MesajOkuma(Kullanici int NOT NULL REFERENCES dbo.Kullanicilar(Id),Mesaj bigint NOT NULL REFERENCES dbo.MPXNext_Mesaj(Id),PRIMARY KEY(Kullanici,Mesaj));
IF OBJECT_ID('dbo.MPXNext_Barkod','U') IS NULL CREATE TABLE dbo.MPXNext_Barkod(Barkod varchar(100) COLLATE Latin1_General_100_BIN2 PRIMARY KEY,Stok int NOT NULL REFERENCES dbo.StokKartlari(Id),Carpan decimal(18,3) NOT NULL DEFAULT 1 CHECK(Carpan>0),Olusturan int NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID('dbo.MPXNext_Maliyet','U') IS NULL CREATE TABLE dbo.MPXNext_Maliyet(Id bigint IDENTITY PRIMARY KEY,Emir int NOT NULL,Veri nvarchar(max) NOT NULL CHECK(ISJSON(Veri)=1),Olusturan int NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),Surum rowversion);
IF OBJECT_ID('dbo.MPXNext_Gunluk','U') IS NULL CREATE TABLE dbo.MPXNext_Gunluk(Tarih date PRIMARY KEY,Kayit datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID('dbo.Yetkiler','U') IS NOT NULL
 INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
 SELECT x.Kod,x.Modul,N'Kullan',x.Aciklama,1 FROM (VALUES
 ('MOBILE.ACCESS',N'Mobil',N'Mobil uygulamaya giriş'),
 ('MOBILE.STOCK',N'Mobil',N'Departman: Stok / barkod'),
 ('MOBILE.PURCHASE',N'Mobil',N'Departman: Satın alma'),
 ('MOBILE.SALES',N'Mobil',N'Departman: Satış'),
 ('MOBILE.PRODUCTION',N'Mobil',N'Departman: Üretim'),
 ('MOBILE.FINANCE',N'Mobil',N'Departman: Muhasebe / finans'),
 ('MOBILE.FIELD',N'Mobil',N'Departman: Saha pazarlama'),
 ('MOBILE.CHAT',N'Mobil',N'Departman: Departman ve kullanıcı mesajlaşma'),
 ('DATA.VIEW',N'Veri araçları',N'Excel ve yazdırma araçları ekranını aç'),
 ('DASHBOARD.VIEW',N'Ana sayfa',N'Ana sayfa ve yönetim özeti ekranını görüntüle'),
 ('ASSISTANT.VIEW',N'Asistan',N'ERP asistanını aç'),
 ('NOTIFICATION.PUBLISH',N'Bildirim',N'Departman ve kullanıcılara duyuru yayımla'),
 ('CHAT.VIEW',N'Mesajlaşma',N'Kendi ve üye departman konuşmalarını gör'),
 ('CHAT.SEND',N'Mesajlaşma',N'Kullanıcı ve üye departmanlarına mesaj gönder'),
 ('COST.VIEW',N'Maliyet',N'Ayrıntılı üretim maliyetini gör'),
 ('COST.EDIT',N'Maliyet',N'Maliyet çalışma tablosunu düzenle'),
 ('COST.PUBLISH',N'Maliyet',N'Günlük maliyet raporu oluştur ve bildir'),
 ('QUICKSALE.VIEW',N'Hızlı satış',N'Barkodla hızlı satış ekranını aç')) x(Kod,Modul,Aciklama)
 WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=x.Kod);

IF OBJECT_ID('dbo.MPXNext_MaliyetRevizyon','U') IS NULL CREATE TABLE dbo.MPXNext_MaliyetRevizyon(Id bigint IDENTITY PRIMARY KEY,Kayit bigint NOT NULL REFERENCES dbo.MPXNext_Maliyet(Id),Veri nvarchar(max) NOT NULL CHECK(ISJSON(Veri)=1),Kullanici int NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MPXNext_DuyuruAlici') AND name='IX_MPXNext_DuyuruUser') CREATE INDEX IX_MPXNext_DuyuruUser ON dbo.MPXNext_DuyuruAlici(Kullanici,Duyuru) INCLUDE(Okundu);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MPXNext_Mesaj') AND name='IX_MPXNext_MesajAlici') CREATE INDEX IX_MPXNext_MesajAlici ON dbo.MPXNext_Mesaj(Alici,Departman,Id);
IF OBJECT_ID('dbo.MPXNext_StokBilesen','U') IS NULL CREATE TABLE dbo.MPXNext_StokBilesen(Ana int NOT NULL REFERENCES dbo.StokKartlari(Id),Bilesen int NOT NULL REFERENCES dbo.StokKartlari(Id),Miktar decimal(18,3) NOT NULL CHECK(Miktar>0),Aciklama nvarchar(200) NULL,Olusturan int NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),CONSTRAINT PK_MPXNext_StokBilesen PRIMARY KEY(Ana,Bilesen),CONSTRAINT CK_MPXNext_StokBilesen_Kendisi CHECK(Ana<>Bilesen));
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MPXNext_StokBilesen') AND name='IX_StokBilesen_Bilesen') CREATE INDEX IX_StokBilesen_Bilesen ON dbo.MPXNext_StokBilesen(Bilesen);
IF OBJECT_ID('dbo.MPXNext_StokKdv','U') IS NULL CREATE TABLE dbo.MPXNext_StokKdv(StokKartId int NOT NULL CONSTRAINT PK_MPXNext_StokKdv PRIMARY KEY REFERENCES dbo.StokKartlari(Id),KdvOrani decimal(5,2) NOT NULL CONSTRAINT CK_MPXNext_StokKdv_Oran CHECK(KdvOrani>=0 AND KdvOrani<=100),AlisKdvDahil bit NOT NULL DEFAULT 0,SatisKdvDahil bit NOT NULL DEFAULT 1,Guncelleyen int NOT NULL,Guncelleme datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
-- Makine yönetimi (MAKINA modülü): bağlantı tanımları ve yetkiler
IF OBJECT_ID('dbo.MPXNext_Makine','U') IS NULL CREATE TABLE dbo.MPXNext_Makine(Id int IDENTITY CONSTRAINT PK_MPXNext_Makine PRIMARY KEY,Ad nvarchar(120) NOT NULL CONSTRAINT UX_MPXNext_Makine_Ad UNIQUE,Marka nvarchar(80) NOT NULL DEFAULT N'',Model nvarchar(80) NOT NULL DEFAULT N'',SeriNo nvarchar(80) NOT NULL DEFAULT N'',Bolum nvarchar(80) NOT NULL DEFAULT N'',Protokol varchar(10) NOT NULL CONSTRAINT CK_MPXNext_Makine_Protokol CHECK(Protokol IN('OPCUA','MODBUS','MQTT','HTTP')),Adres nvarchar(300) NOT NULL,Port int NULL CONSTRAINT CK_MPXNext_Makine_Port CHECK(Port BETWEEN 1 AND 65535),Ayar nvarchar(max) NOT NULL CONSTRAINT CK_MPXNext_Makine_Ayar CHECK(ISJSON(Ayar)=1),Aktif bit NOT NULL DEFAULT 1,Olusturan int NOT NULL,Guncelleme datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID('dbo.Yetkiler','U') IS NOT NULL
 INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
 SELECT x.Kod,N'Makine yönetimi',x.Islem,x.Aciklama,1 FROM (VALUES('MACHINE.VIEW',N'Canlı makine paneli',N'Makinelerin anlık üretim, hız ve durum bilgilerini görür'),('MACHINE.MANAGE',N'Makine bağlantıları',N'Makine ekler, bağlantı ve veri alanlarını düzenler')) x(Kod,Islem,Aciklama)
 WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=x.Kod);
-- Üretim emri: gün içinde stoğa işlenen sağlam ürün
IF OBJECT_ID('dbo.MPXNext_UretimGunlukStok','U') IS NULL
 CREATE TABLE dbo.MPXNext_UretimGunlukStok(
  UretimEmriId int NOT NULL CONSTRAINT PK_MPXNext_UretimGunlukStok PRIMARY KEY CONSTRAINT FK_MPXNext_UretimGunlukStok_Emir REFERENCES dbo.UretimEmirleri(Id),
  IslenenMiktar decimal(18,3) NOT NULL CONSTRAINT CK_MPXNext_UretimGunlukStok_Miktar CHECK(IslenenMiktar>=0),
  Guncelleme datetime2(3) NOT NULL CONSTRAINT DF_MPXNext_UretimGunlukStok_Tarih DEFAULT SYSDATETIME());
-- Stok fiyat görme yetkisi
IF OBJECT_ID('dbo.Yetkiler','U') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu=N'STOCK.PRICE')
BEGIN
 INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif) VALUES(N'STOCK.PRICE',N'Stok',N'Fiyat',N'Stok alış/satış fiyatlarını ve KDV oranlarını gör ve gir',1);
 IF OBJECT_ID('dbo.RolYetkileri','U') IS NOT NULL
  INSERT dbo.RolYetkileri(RolId,YetkiId,AtamaTarihiUtc)
  SELECT DISTINCT ry.RolId,(SELECT Id FROM dbo.Yetkiler WHERE YetkiKodu=N'STOCK.PRICE'),SYSUTCDATETIME()
  FROM dbo.RolYetkileri ry JOIN dbo.Yetkiler y ON y.Id=ry.YetkiId
  WHERE y.YetkiKodu LIKE N'PURCHASE.%' OR y.YetkiKodu LIKE N'ACCOUNTING.%' OR y.YetkiKodu LIKE N'FINANCE.%' OR y.YetkiKodu LIKE N'SALES.%';
END
