using System.Data;
using System.IO;
using System.Text.Json;
namespace MiapaxERP.Desktop;

/// <summary>Raporlar: saha pazarlamanın Türkiye haritasına eklediği müşteriler (ad soyad, şehir, telefon, tarla büyüklüğü, açıklama).</summary>
public sealed partial class SahaServisi
{
 static Dictionary<string,string>? yerAdlari;
 static Dictionary<string,string> YerAdlari(){
  if(yerAdlari is not null)return yerAdlari;
  var d=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
  foreach(var f in new[]{"provinces.json","districts.json"}){
   try{var p=Path.Combine(AppContext.BaseDirectory,"Assets","SahaWeb",f);if(!File.Exists(p))continue;
    using var doc=JsonDocument.Parse(File.ReadAllBytes(p));
    foreach(var x in doc.RootElement.EnumerateArray())if(x.TryGetProperty("id",out var id)&&x.TryGetProperty("name",out var ad))d[id.GetString()!]=ad.GetString()!;}
   catch(Exception e) when(e is IOException or JsonException or UnauthorizedAccessException){}
  }
  return yerAdlari=d;
 }

 public DataTable RaporMusteriler(DateTime bas,DateTime son){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<DataTable>(connection,"SahaServisi.RaporMusteriler","",[bas,son]);
  LisansOturumu.Gerekli("SAHA");using var c=access.Ac();Yetki(c,null,"FIELD.VIEW");
  var t=new DataTable("SahaMusterileri");
  foreach(var (ad,tip) in new (string,Type)[]{("Ad Soyad",typeof(string)),("Şehir",typeof(string)),("İlçe",typeof(string)),("Köy / Mahalle",typeof(string)),("Telefon",typeof(string)),("Tarla büyüklüğü",typeof(decimal)),("Birim",typeof(string)),("Ürünler",typeof(string)),("Su kaynağı",typeof(string)),("Açıklama",typeof(string)),("Ekleyen",typeof(string)),("Kayıt tarihi",typeof(DateTime))})t.Columns.Add(ad,tip);
  using var q=ErpModulServisi.Komut(c,null,"SELECT TOP(5000) m.Veri,COALESCE(NULLIF(k.AdSoyad,N''),k.KullaniciAdi,N''),m.Olusturma FROM dbo.BERP210_SahaMusteri m LEFT JOIN dbo.Kullanicilar k ON k.Id=m.Olusturan WHERE m.Olusturma>=@bas AND m.Olusturma<DATEADD(day,1,@son) AND (@own=0 OR m.Olusturan=@user) ORDER BY m.Olusturma DESC",("@bas",bas.Date),("@son",son.Date),("@own",Own),("@user",user));
  using var r=q.ExecuteReader();var adlar=YerAdlari();
  while(r.Read()){
   SahaMusterisi? m;try{m=JsonSerializer.Deserialize<SahaMusterisi>(r.GetString(0),Json);}catch(JsonException){continue;}if(m is null)continue;
   t.Rows.Add(m.Ad,adlar.GetValueOrDefault(m.IlId,m.IlId),adlar.GetValueOrDefault(m.IlceId,m.IlceId),m.Koy,m.Telefon,m.Alan.HasValue?m.Alan.Value:DBNull.Value,m.AlanBirimi,m.Urunler,m.SuKaynagi,m.Aciklama,r.GetString(1),DateTime.SpecifyKind(r.GetDateTime(2),DateTimeKind.Utc).ToLocalTime());
  }
  return t;
 }
}
