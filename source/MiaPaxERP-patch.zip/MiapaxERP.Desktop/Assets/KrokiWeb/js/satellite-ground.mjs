import {toGeo} from './field-plan-alignment.mjs?v=kroki-next1';
import {bounds} from './field-plan-core.mjs?v=kroki-next1';
export const imageryCredit='Esri World Imagery · Esri, Vantor, Earthstar Geographics, and the GIS User Community';
export const satelliteUrl=(z,x,y)=>`https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`;
export function mercator(g,z){const n=2**z,lat=Math.max(-85,Math.min(85,g.lat))*Math.PI/180;return {x:(g.lng+180)/360*n,y:(1-Math.asinh(Math.tan(lat))/Math.PI)/2*n};}
export function satelliteLayout(plan){if(!plan.geo)throw Error('Uydu zemini için önce haritada tarla sınırı seçin.');const b=bounds(plan.boundary),pad=Math.max(b.maxX-b.minX,b.maxY-b.minY)*.35+5;
 const corners=[{x:b.minX-pad,y:b.minY-pad},{x:b.maxX+pad,y:b.minY-pad},{x:b.maxX+pad,y:b.maxY+pad},{x:b.minX-pad,y:b.maxY+pad}];let z=19,coords,rect;
 do{coords=corners.map(p=>mercator(toGeo(p,plan.geo),z));rect={x:Math.floor(Math.min(...coords.map(p=>p.x))),y:Math.floor(Math.min(...coords.map(p=>p.y))),right:Math.floor(Math.max(...coords.map(p=>p.x))),bottom:Math.floor(Math.max(...coords.map(p=>p.y)))};if((rect.right-rect.x+1)*(rect.bottom-rect.y+1)<=36)break;z--;}while(z>3);
 return {corners,z,...rect,width:rect.right-rect.x+1,height:rect.bottom-rect.y+1,uv:coords.map(p=>({u:(p.x-rect.x)/(rect.right-rect.x+1),v:1-(p.y-rect.y)/(rect.bottom-rect.y+1)}))};
}
export async function loadSatellite(plan){const layout=satelliteLayout(plan),canvas=document.createElement('canvas');canvas.width=layout.width*256;canvas.height=layout.height*256;const ctx=canvas.getContext('2d');let loaded=0;const jobs=[];
 for(let y=layout.y;y<=layout.bottom;y++)for(let x=layout.x;x<=layout.right;x++)jobs.push(new Promise((resolve,reject)=>{const image=new Image();image.crossOrigin='anonymous';const timeout=setTimeout(()=>{image.src='';reject(Error('Uydu görüntüsü zaman aşımına uğradı.'));},18000);image.onload=()=>{clearTimeout(timeout);ctx.drawImage(image,(x-layout.x)*256,(y-layout.y)*256,256,256);loaded++;resolve();};image.onerror=()=>{clearTimeout(timeout);reject(Error('Uydu görüntüsü yüklenemedi; bağlantıyı kontrol edin.'));};image.src=satelliteUrl(layout.z,x,y);}));
 await Promise.all(jobs);return {layout,canvas,loaded};
}
export const terrainCredit='Mapzen / Tilezen · SRTM/GMTED: USGS · ETOPO1: NOAA · EU-DEM: Copernicus / European Union';
export const decodeElevation=(r,g,b)=>r*256+g+b/256-32768;
export async function loadTerrain(plan){
 const layout=satelliteLayout(plan),z=Math.min(14,layout.z),geoCorners=layout.corners.map(p=>mercator(toGeo(p,plan.geo),z)),minX=Math.floor(Math.min(...geoCorners.map(p=>p.x))),maxX=Math.floor(Math.max(...geoCorners.map(p=>p.x))),minY=Math.floor(Math.min(...geoCorners.map(p=>p.y))),maxY=Math.floor(Math.max(...geoCorners.map(p=>p.y))),tiles=new Map();
 if((maxX-minX+1)*(maxY-minY+1)>36)throw Error('Yükseklik alanı çok geniş.');
 const jobs=[];for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++)jobs.push(new Promise((resolve,reject)=>{const image=new Image();image.crossOrigin='anonymous';const timer=setTimeout(()=>{image.src='';reject(Error('Arazi yüksekliği zaman aşımı.'));},12000);image.onload=()=>{clearTimeout(timer);try{const c=document.createElement('canvas');c.width=256;c.height=256;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(image,0,0,256,256);tiles.set(x+','+y,ctx.getImageData(0,0,256,256).data);resolve();}catch(e){reject(e);}};image.onerror=()=>{clearTimeout(timer);reject(Error('Arazi yüksekliği alınamadı.'));};image.src=`https://elevation-tiles-prod.s3.amazonaws.com/terrarium/${z}/${x}/${y}.png`;}));
 await Promise.all(jobs);
 const absolute=p=>{const g=mercator(toGeo(p,plan.geo),z),tx=Math.floor(g.x),ty=Math.floor(g.y),data=tiles.get(tx+','+ty);if(!data)return 0;const x=Math.min(254,Math.max(0,(g.x-tx)*256)),y=Math.min(254,Math.max(0,(g.y-ty)*256)),ix=Math.floor(x),iy=Math.floor(y),dx=x-ix,dy=y-iy;const at=(xx,yy)=>{const n=(yy*256+xx)*4;return decodeElevation(data[n],data[n+1],data[n+2]);};return at(ix,iy)*(1-dx)*(1-dy)+at(ix+1,iy)*dx*(1-dy)+at(ix,iy+1)*(1-dx)*dy+at(ix+1,iy+1)*dx*dy;};
 const b=bounds(plan.boundary),origin=absolute({x:(b.minX+b.maxX)/2,y:(b.minY+b.maxY)/2});return {height:p=>absolute(p)-origin,origin,tiles:tiles.size};
}
