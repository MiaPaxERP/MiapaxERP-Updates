using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using MiapaxERP.Desktop;

/// <summary>
/// Tema görsel denetimi: her temada ana pencerenin ana sayfasını, birkaç ekranını ve Görünüm ayarlarını
/// SQL'e bağlanmadan çizip PNG olarak kaydeder. CI bu dosyaları yapıt olarak yükler.
/// </summary>
internal static class TemaRender
{
 static void Bekle(){var frame=new DispatcherFrame();Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle,new Action(()=>frame.Continue=false));Dispatcher.PushFrame(frame);}
 static void Kaydet(FrameworkElement v,string path){
  v.UpdateLayout();Console.Out.Flush();int w=(int)Math.Max(1,Math.Ceiling(v.ActualWidth)),h=(int)Math.Max(1,Math.Ceiling(v.ActualHeight));
  var bmp=new RenderTargetBitmap(w,h,96,96,PixelFormats.Pbgra32);bmp.Render(v);
  var enc=new PngBitmapEncoder();enc.Frames.Add(BitmapFrame.Create(bmp));using var s=File.Create(path);enc.Save(s);
 }
 static string Dosya(string s)=>new string(s.Select(c=>char.IsLetterOrDigit(c)?c:'_').ToArray());
 public static void Run(string output,string? tek=null)
 {
  Directory.CreateDirectory(output);
  var app=Application.Current as App??new App();app.InitializeComponent();app.ShutdownMode=ShutdownMode.OnExplicitShutdown;
  TemaPencereServisi.Baslat();
  var temalar=Tema170.Adlar.Where(t=>t!="Sistem").ToList();if(tek is not null)temalar=[tek];
  string[] sayfalar=["", "StokIcerik", "YeniStokIcerik", "UretimIcerik", "StokHareketIcerik"];
  foreach(string tema in temalar)
  {
   string ad=Dosya(tema);var saat=System.Diagnostics.Stopwatch.StartNew();Console.WriteLine("BASLA "+tema);Console.Out.Flush();
   try
   {
    // Pencere gösterilmez (Loaded olayları oturum açma/SQL başlatmaz); içerik pencerenin kaynaklarıyla ölçülüp çizilir.
    var w=new MainWindow(true){Width=1500,Height=940};
    var icerik=(FrameworkElement)w.Content;
    void Yerlesim(){icerik.Measure(new Size(1500,940));icerik.Arrange(new Rect(0,0,1500,940));icerik.UpdateLayout();}
    Yerlesim();TemaPencereServisi.Uygula(w);Bekle();
    try{w.GorunumuUygula(new GorunumTercihleri{Tema=tema});}catch(Exception e){Console.WriteLine("UYARI "+tema+" GorunumuUygula: "+e.Message);}
    Yerlesim();Bekle();
    var hepsi=sayfalar.Where(s=>s.Length>0).Concat(["AnaSayfaArkaPlan","AnaSayfaIcerik"]).Select(n=>w.FindName(n)).OfType<FrameworkElement>().ToList();
    foreach(string sayfa in sayfalar)
    {
     foreach(var e in hepsi)e.Visibility=Visibility.Collapsed;
     if(sayfa.Length==0){foreach(var n in new[]{"AnaSayfaArkaPlan","AnaSayfaIcerik"})if(w.FindName(n) is FrameworkElement e)e.Visibility=Visibility.Visible;}
     else if(w.FindName(sayfa) is FrameworkElement hedef)hedef.Visibility=Visibility.Visible;
     Yerlesim();TemaOkunurlugu.Uygula(w);Yerlesim();
     Kaydet(icerik,Path.Combine(output,ad+"-"+(sayfa.Length==0?"AnaSayfa":sayfa)+".png"));
    }
    w.Close();
    var klasor=Path.Combine(Path.GetTempPath(),"tema-render-"+ad);Directory.CreateDirectory(klasor);
    var g=new GorunumPenceresi(klasor,new GorunumTercihleri{Tema=tema},()=>{},_=>{});
    var gi=(FrameworkElement)g.Content;double gw=double.IsNaN(g.Width)?900:g.Width,gh=double.IsNaN(g.Height)?760:g.Height;
    gi.Measure(new Size(gw,gh));gi.Arrange(new Rect(0,0,gw,gh));gi.UpdateLayout();TemaPencereServisi.Uygula(g);GorunumRenkleri.Uygula(g,Tema170.Mevcut);TemaOkunurlugu.Uygula(g);gi.UpdateLayout();
    Kaydet(gi,Path.Combine(output,ad+"-GorunumAyarlari.png"));g.Close();
    Console.WriteLine("RENDER "+tema+" "+saat.Elapsed.TotalSeconds.ToString("0")+" sn");
   }
   catch(Exception e){Console.WriteLine("RENDER HATASI "+tema+": "+e);}
  }
 }
}
