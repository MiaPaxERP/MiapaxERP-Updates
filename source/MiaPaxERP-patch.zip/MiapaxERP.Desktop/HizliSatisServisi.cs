using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed record HizliUrun(int Id,string Kod,string Ad,string Birim,decimal Carpan,decimal? Fiyat,string Para);
public sealed record UrunBarkodu(string Barkod,decimal Carpan);
public sealed class HizliSatisServisi(string connection,int user)
{
 readonly ErpModulServisi access=new(connection,user);
 readonly Action<SqlConnection,SqlTransaction?,string>? fixtureCheck;
 internal HizliSatisServisi(string connection,int user,Action<SqlConnection,SqlTransaction?,string> check):this(connection,user){fixtureCheck=check;}
 void Check(SqlConnection c,SqlTransaction? t,string code){if(fixtureCheck is not null)fixtureCheck(c,t,code);else access.Yetki(c,t,code);}
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps)=>ErpModulServisi.Komut(c,t,sql,ps);
 static void Barcode(string value){if(value is null||value.Length is <1 or >100||value.Any(c=>c<'!'||c>'~'))throw new ArgumentException("Barkod 1–100 görünür ASCII karakterinden oluşmalı; baştaki sıfırlar korunur.");}
 public UrunBarkodu[] Barkodlar(int stock){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<UrunBarkodu[]>(connection,"HizliSatisServisi.Barkodlar","",[stock]);
  using var c=access.Ac();Check(c,null,"STOCK.VIEW");using var q=Q(c,null,"SELECT Barkod,Carpan FROM dbo.MPXNext_Barkod WHERE Stok=@s ORDER BY Barkod",("@s",stock));using var r=q.ExecuteReader();var rows=new List<UrunBarkodu>();while(r.Read())rows.Add(new(r.GetString(0),r.GetDecimal(1)));return rows.ToArray();
 }
 public void BarkodKaydet(int stock,string barcode,decimal multiplier){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"HizliSatisServisi.BarkodKaydet","",[stock,barcode,multiplier]);return;}
  Barcode(barcode);if(multiplier<=0||multiplier>100000||decimal.Round(multiplier,3)!=multiplier)throw new ArgumentException("Birim çarpanı pozitif ve en fazla 3 ondalıklı olmalı.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Check(c,t,"STOCK.VIEW");Check(c,t,"STOCK.EDIT");using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.StokKartlari WITH(HOLDLOCK) WHERE Id=@s AND Aktif=1",("@s",stock)))if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Etkin stok seçin.");using(var code=Q(c,t,"SELECT COUNT(*) FROM dbo.StokKartlari WITH(HOLDLOCK) WHERE StokKodu=@b AND Id<>@s",("@b",barcode),("@s",stock)))if(Convert.ToInt32(code.ExecuteScalar())>0)throw new InvalidOperationException("Bu barkod başka ürünün stok koduyla çakışıyor.");
  using(var q=Q(c,t,"SELECT Stok FROM dbo.MPXNext_Barkod WITH(UPDLOCK,HOLDLOCK) WHERE Barkod=@b",("@b",barcode))){var existing=q.ExecuteScalar();if(existing is not null&&Convert.ToInt32(existing)!=stock)throw new InvalidOperationException("Bu barkod başka bir üründe kayıtlı.");}
  using var save=Q(c,t,"UPDATE dbo.MPXNext_Barkod SET Carpan=@m WHERE Barkod=@b AND Stok=@s;IF @@ROWCOUNT=0 INSERT dbo.MPXNext_Barkod(Barkod,Stok,Carpan,Olusturan) VALUES(@b,@s,@m,@u)",("@b",barcode),("@s",stock),("@m",multiplier),("@u",user));save.ExecuteNonQuery();t.Commit();
 }
 public void BarkodSil(int stock,string barcode){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"HizliSatisServisi.BarkodSil","",[stock,barcode]);return;}
  Barcode(barcode);using var c=access.Ac();Check(c,null,"STOCK.VIEW");Check(c,null,"STOCK.EDIT");using var q=Q(c,null,"DELETE dbo.MPXNext_Barkod WHERE Stok=@s AND Barkod=@b",("@s",stock),("@b",barcode));q.ExecuteNonQuery();
 }
 public HizliUrun[] UrunAra(string search,bool barcode){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<HizliUrun[]>(connection,"HizliSatisServisi.UrunAra","",[search,barcode]);
  if(search is null||search.Length>100)throw new ArgumentException();using var c=access.Ac();Check(c,null,"QUICKSALE.VIEW");Check(c,null,"SALES.VIEW");if(fixtureCheck is null)LisansOturumu.Gerekli("SATIS");
  if(barcode&&UrunEtiketServisi.PaketCoz(search.Trim(),out int package,out int sequence)){
   using var pack=Q(c,null,"SELECT s.Id,s.StokKodu,s.StokAdi,s.Birim,p.PaketIciAdet,f.PerakendeSatisFiyati,COALESCE(f.ParaBirimi,'TRY') FROM dbo.UretimPaketlemeKayitlari p JOIN dbo.UretimEmirleri u ON u.Id=p.UretimEmriId JOIN dbo.StokKartlari s ON s.Id=u.MamulStokId LEFT JOIN dbo.StokFiyatlari f ON f.StokKartId=s.Id WHERE p.Id=@p AND @n BETWEEN 1 AND p.PaketSayisi AND p.PaketIciAdet>0 AND s.Aktif=1 AND u.Durum IN(N'Üretimde',N'Tamamlandı')",("@p",package),("@n",sequence));using var pr=pack.ExecuteReader();if(pr.Read())return [new(pr.GetInt32(0),pr.GetString(1),pr.GetString(2),pr.GetString(3),Convert.ToDecimal(pr.GetValue(4)),pr.IsDBNull(5)?null:Convert.ToDecimal(pr.GetValue(5)),pr.GetString(6))];return [];
  }
  using var q=Q(c,null,"""
  SELECT TOP(100) s.Id,s.StokKodu,s.StokAdi,s.Birim,COALESCE(b.Carpan,1),f.PerakendeSatisFiyati,COALESCE(f.ParaBirimi,'TRY') FROM dbo.StokKartlari s
  LEFT JOIN dbo.MPXNext_Barkod b ON b.Stok=s.Id AND b.Barkod=@q COLLATE Latin1_General_100_BIN2 LEFT JOIN dbo.StokFiyatlari f ON f.StokKartId=s.Id
  WHERE s.Aktif=1 AND ((@b=1 AND (b.Barkod IS NOT NULL OR s.StokKodu=@q)) OR (@b=0 AND (CHARINDEX(@q,s.StokKodu)>0 OR CHARINDEX(@q,s.StokAdi)>0))) ORDER BY s.StokAdi,s.Id
  """,("@q",search.Trim()),("@b",barcode));using var r=q.ExecuteReader();var rows=new List<HizliUrun>();while(r.Read())rows.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),Convert.ToDecimal(r.GetValue(4)),r.IsDBNull(5)?null:Convert.ToDecimal(r.GetValue(5)),r.GetString(6)));return rows.ToArray();
 }
 public long Satis(SatisGirdisi g){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<long>(connection,"HizliSatisServisi.Satis","",[g]);
  using(var c=access.Ac()){Check(c,null,"QUICKSALE.VIEW");Check(c,null,"SALES.VIEW");}if(g.Teklif)throw new ArgumentException("Hızlı satış teklif oluşturmaz.");return (fixtureCheck is null?new IsletmeServisi(connection,user):new IsletmeServisi(connection,user,fixtureCheck)).SatisKaydet(g);
 }
 public long? Sonuc(Guid key){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<long?>(connection,"HizliSatisServisi.Sonuc","",[key]);
  using var c=access.Ac();Check(c,null,"SALES.VIEW");using var q=Q(c,null,"SELECT b.Id FROM dbo.MPX310_Kayit k JOIN dbo.BoruERP_YeniBelgeler b ON b.BelgeNo=JSON_VALUE(k.Veri,'$.no') AND b.YapanKullaniciId=k.Olusturan WHERE k.Anahtar=@k AND k.Tur='Satis' AND k.Olusturan=@u",("@k",key),("@u",user));var v=q.ExecuteScalar();return v is null?null:Convert.ToInt64(v);
 }
}
