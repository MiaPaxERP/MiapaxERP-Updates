using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class MenuYetki286Testleri
{
 static HashSet<string> P(params string[] p)=>new(p,StringComparer.OrdinalIgnoreCase);
 [Theory]
 [InlineData("BtnMenuStok","STOCK.VIEW",true)]
 [InlineData("BtnMenuFinans","STOCK.VIEW",false)]
 [InlineData("BtnMenuUretim","STOCK.VIEW",false)]
 [InlineData("BtnMenuFinans","FINANCE.VIEW",true)]
 [InlineData("BtnMenuStok","FINANCE.VIEW",false)]
 [InlineData("BtnMenuUretim","PRODUCTION.VIEW",true)]
 [InlineData("BtnMenuKullanici","PRODUCTION.VIEW",false)]
 [InlineData("BtnMenuSaha","FIELD.VIEW",true)]
 [InlineData("BtnMenuAnaSayfa","STOCK.VIEW",false)]
 [InlineData("BtnMenuAnaSayfa","DASHBOARD.VIEW",true)]
 [InlineData("BtnMenuFinans","REPORT.VIEW",false)]
 [InlineData("BtnMenuFinans","CUSTOMER.VIEW",false)]
 [InlineData("BtnMenuCari","CUSTOMER.VIEW",true)]
 [InlineData("BtnMenuTeklifSatis","SALES.VIEW",false)]
 [InlineData("BtnMenuRaporlar","REPORT.VIEW",true)]
 [InlineData("BtnMenuVeriAraclari","STOCK.VIEW",false)]
 [InlineData("BtnMenuVeriAraclari","DATA.VIEW",true)]
 public void YalnizTanimliModulGorunur(string menu,string code,bool visible)=>Assert.Equal(visible,MenuYetkiKurallari.Gorunur(menu,null,P(code),_=>true));
 [Fact]public void LisansEksigiYetkiyleAsilamaz()=>Assert.False(MenuYetkiKurallari.Gorunur("BtnMenuUretim",null,P("PRODUCTION.VIEW"),_=>false));
 [Fact]public void StokHareketleriIkiKosuluDaIster(){Assert.False(MenuYetkiKurallari.Gorunur("BtnMenuStokHareket",null,P("STOCK.VIEW"),_=>true));Assert.False(MenuYetkiKurallari.Gorunur("BtnMenuStokHareket",null,P("STOCK.HISTORY"),_=>true));Assert.True(MenuYetkiKurallari.Gorunur("BtnMenuStokHareket",null,P("STOCK.VIEW","STOCK.HISTORY"),_=>true));}
 [Fact]public void YeniModullerVeBilinmeyenMenuKapali(){Assert.False(MenuYetkiKurallari.Gorunur("","Depo",P("STOCK.VIEW"),_=>true));Assert.True(MenuYetkiKurallari.Gorunur("","Depo",P("WAREHOUSE.VIEW"),_=>true));Assert.False(MenuYetkiKurallari.Gorunur("Bilinmeyen","future",P("USERS.MANAGE"),_=>true));}
 [Fact]public void KrokiIcinAyriAtamaGerekir(){Assert.False(MenuYetkiKurallari.Gorunur("BtnMenuKroki",null,P("STOCK.VIEW"),_=>true));Assert.True(MenuYetkiKurallari.Gorunur("BtnMenuKroki",null,P("KROKI.VIEW"),_=>true));}
 [Fact]public void YetkiGeriAlinincaGizlenir(){var p=P("FINANCE.VIEW");Assert.True(MenuYetkiKurallari.Gorunur("BtnMenuFinans",null,p,_=>true));p.Clear();Assert.False(MenuYetkiKurallari.Gorunur("BtnMenuFinans",null,p,_=>true));}
 [Fact]public void SektoreGoreUretimMenusuSekillenir(){var p=P("PRODUCTION.VIEW","STOCK.VIEW");Assert.True(MenuYetkiKurallari.Gorunur("BtnMenuUretilenStok",null,p,_=>true,"GIDA"));Assert.False(MenuYetkiKurallari.Gorunur("BtnMenuUretilenStok",null,p,_=>true,"TOPTAN"));Assert.True(MenuYetkiKurallari.Gorunur("BtnMenuSektorUretim",null,p,_=>true,"GIDA"));Assert.False(MenuYetkiKurallari.Gorunur("BtnMenuUretim",null,p,_=>true,"GIDA"));Assert.True(MenuYetkiKurallari.Gorunur("BtnMenuUretim",null,p,_=>true,"BORU"));}
 [Fact]public void SektorKataloguEskiIstemciyiKorur(){foreach(var s in MiapaxERP.Lisans.Core.UrunKatalogu.Sektorler){Assert.Contains(s.EskiKod,MiapaxERP.Lisans.Core.UrunKatalogu.EskiSektorler);Assert.Contains(MiapaxERP.Lisans.Core.UrunKatalogu.EskiIstemciKodu(s.Kod),MiapaxERP.Lisans.Core.UrunKatalogu.EskiSektorler);Assert.Contains(s.Grup,MiapaxERP.Lisans.Core.UrunKatalogu.Gruplar.Select(g=>g.Kod));Assert.NotEmpty(s.AltDallar);MiapaxERP.Lisans.Core.UrunKatalogu.ModulDogrula(s.OnerilenModuller);}Assert.Equal("RESTORAN",MiapaxERP.Lisans.Core.UrunKatalogu.EskiIstemciKodu("KAFE"));Assert.Equal("RESTORAN",MiapaxERP.Lisans.Core.UrunKatalogu.Davranis("KAFE"));}
}
