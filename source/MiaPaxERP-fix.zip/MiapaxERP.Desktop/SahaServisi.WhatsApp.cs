using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record WhatsAppSablonu(int Id, string Ad, string Metin, string MetaSablon, string Dil, bool AdParametresi);
public sealed record WhatsAppSonucu(Guid MusteriId, string Ad, string Telefon, bool Basarili, string Mesaj);

/// <summary>Saha pazarlama müşteri listesi ve WhatsApp hazır mesaj gönderimi (tekli ve toplu).</summary>
public sealed partial class SahaServisi
{
 internal const string OrnekMesaj = """
🌿 *Sayın [Müşteri Adı],*

Bizimle gerçekleştirmiş olduğunuz değerli görüşme için öncelikle teşekkür ederiz.

*MiaPlast Plastik Boru Sulama Sistemleri*

🌱 Üretim anlayışımızın merkezinde kalite, dayanıklılık ve uzun ömürlü kullanım yer alırken; çiftçilerimizin, bayilerimizin ve iş ortaklarımızın ihtiyaçlarına en doğru çözümleri sunmayı hedefliyoruz.

Sizlere de bu anlayışımız doğrultusunda kaliteli ürünlerimizle hizmet vermekten ve uzun soluklu, güvene dayalı bir iş ortaklığı kurmaktan mutluluk duyarız.

🤝 *Sizi en kısa sürede fabrikamızda ağırlamaktan, üretim süreçlerimizi yerinde göstermekten ve sizlerle yüz yüze tanışmaktan onur duyarız.*

MiaPlast ailesi olarak, birlikte güzel işlere imza atmak dileğiyle...

*Saygılarımızla,*
*MİAPLAST PLASTİK BORU SULAMA SİSTEMLERİ*
🌐 Kaliteli Üretim • Güvenilir Çözüm • Güçlü İş Ortaklığı
""";

 static readonly HashSet<string> waHazir=new(StringComparer.Ordinal);
 void WaHazirla(SqlConnection c){
  lock(waHazir){if(waHazir.Contains(connection))return;}
  using(var q=ErpModulServisi.Komut(c,null,"""
IF OBJECT_ID(N'dbo.BERP298_WaSablon',N'U') IS NULL
 CREATE TABLE dbo.BERP298_WaSablon(Id int IDENTITY(1,1) PRIMARY KEY,Ad nvarchar(100) NOT NULL,Metin nvarchar(4000) NOT NULL,MetaSablon nvarchar(120) NOT NULL DEFAULT N'',Dil nvarchar(10) NOT NULL DEFAULT N'tr',AdParametresi bit NOT NULL DEFAULT 1,Aktif bit NOT NULL DEFAULT 1,Olusturan int NOT NULL,Olusturma datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID(N'dbo.BERP298_WaGonderim',N'U') IS NULL
 CREATE TABLE dbo.BERP298_WaGonderim(Id bigint IDENTITY(1,1) PRIMARY KEY,MusteriId uniqueidentifier NULL,Ad nvarchar(160) NOT NULL,Telefon nvarchar(30) NOT NULL,SablonAdi nvarchar(100) NOT NULL,Basarili bit NOT NULL,Sonuc nvarchar(1000) NOT NULL,MesajId nvarchar(200) NOT NULL DEFAULT N'',KullaniciId int NOT NULL,Zaman datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
"""))q.ExecuteNonQuery();
  using(var q=ErpModulServisi.Komut(c,null,"IF NOT EXISTS(SELECT 1 FROM dbo.BERP298_WaSablon) INSERT dbo.BERP298_WaSablon(Ad,Metin,MetaSablon,Dil,AdParametresi,Olusturan) VALUES(N'Görüşme sonrası teşekkür',@m,N'',N'tr',1,@u)",("@m",OrnekMesaj.Trim()),("@u",user)))q.ExecuteNonQuery();
  lock(waHazir)waHazir.Add(connection);
 }

 /// <summary>Saha pazarlamanın kaydettiği müşteriler (arama: ad, telefon, şehir, ilçe, köy veya ürün).</summary>
 public DataTable WaMusteriler(string arama){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<DataTable>(connection,"SahaServisi.WaMusteriler","",[arama]);
  LisansOturumu.Gerekli("SAHA");using var c=access.Ac();Yetki(c,null,"FIELD.VIEW");WaHazirla(c);
  var t=new DataTable("SahaMusterileri");
  foreach(var (ad,tip) in new (string,Type)[]{("Id",typeof(Guid)),("Ad Soyad",typeof(string)),("Telefon",typeof(string)),("Şehir",typeof(string)),("İlçe",typeof(string)),("Köy / Mahalle",typeof(string)),("Tarla büyüklüğü",typeof(string)),("Ürünler",typeof(string)),("Su kaynağı",typeof(string)),("Açıklama",typeof(string)),("Ekleyen",typeof(string)),("Kayıt tarihi",typeof(DateTime)),("Son WhatsApp",typeof(string))})t.Columns.Add(ad,tip);
  using var q=ErpModulServisi.Komut(c,null,"""
SELECT TOP(5000) m.Id,m.Veri,COALESCE(NULLIF(k.AdSoyad,N''),k.KullaniciAdi,N''),m.Olusturma,
 (SELECT TOP(1) CONVERT(nvarchar(16),DATEADD(minute,DATEDIFF(minute,SYSUTCDATETIME(),SYSDATETIME()),g.Zaman),120)+N' · '+CASE WHEN g.Basarili=1 THEN N'gönderildi' ELSE N'hata' END FROM dbo.BERP298_WaGonderim g WHERE g.MusteriId=m.Id ORDER BY g.Zaman DESC)
FROM dbo.BERP210_SahaMusteri m LEFT JOIN dbo.Kullanicilar k ON k.Id=m.Olusturan
WHERE (@own=0 OR m.Olusturan=@user) ORDER BY m.Olusturma DESC
""",("@own",Own),("@user",user));
  using var r=q.ExecuteReader();var adlar=YerAdlari();string ara=ExcelVeYazdirmaPenceresi.Anahtar(arama??"");
  while(r.Read()){
   SahaMusterisi? m;try{m=JsonSerializer.Deserialize<SahaMusterisi>(r.GetString(1),Json);}catch(JsonException){continue;}if(m is null)continue;
   string il=adlar.GetValueOrDefault(m.IlId,m.IlId),ilce=adlar.GetValueOrDefault(m.IlceId,m.IlceId);
   if(ara.Length>0&&!ExcelVeYazdirmaPenceresi.Anahtar(string.Join(" ",m.Ad,m.Telefon,il,ilce,m.Koy,m.Urunler,m.Aciklama)).Contains(ara))continue;
   t.Rows.Add(r.GetGuid(0),m.Ad,m.Telefon,il,ilce,m.Koy,m.Alan.HasValue?m.Alan.Value.ToString("0.##")+" "+m.AlanBirimi:"",m.Urunler,m.SuKaynagi,m.Aciklama,r.GetString(2),DateTime.SpecifyKind(r.GetDateTime(3),DateTimeKind.Utc).ToLocalTime(),r.IsDBNull(4)?"":r.GetString(4));
  }
  return t;
 }

 public List<WhatsAppSablonu> WaSablonlar(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<List<WhatsAppSablonu>>(connection,"SahaServisi.WaSablonlar","",[]);
  LisansOturumu.Gerekli("SAHA");using var c=access.Ac();Yetki(c,null,"FIELD.VIEW");WaHazirla(c);
  var l=new List<WhatsAppSablonu>();using var q=ErpModulServisi.Komut(c,null,"SELECT Id,Ad,Metin,MetaSablon,Dil,AdParametresi FROM dbo.BERP298_WaSablon WHERE Aktif=1 ORDER BY Ad");
  using var r=q.ExecuteReader();while(r.Read())l.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetBoolean(5)));return l;
 }

 public int WaSablonKaydet(WhatsAppSablonu s){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<int>(connection,"SahaServisi.WaSablonKaydet","",[s]);
  if(string.IsNullOrWhiteSpace(s.Ad)||s.Ad.Trim().Length>100)throw new ArgumentException("Hazır mesaj adı 1-100 karakter olmalı.");
  if(string.IsNullOrWhiteSpace(s.Metin)||s.Metin.Length>4000)throw new ArgumentException("Mesaj metni 1-4000 karakter olmalı.");
  if((s.MetaSablon??"").Trim().Length>0&&!System.Text.RegularExpressions.Regex.IsMatch(s.MetaSablon.Trim(),"^[a-z0-9_]{1,120}$"))throw new ArgumentException("Meta şablon adı yalnız küçük harf, rakam ve alt çizgi içerir (ör. gorusme_tesekkur).");
  LisansOturumu.Gerekli("SAHA");using var c=access.Ac();Yetki(c,null,"FIELD.EDIT");WaHazirla(c);
  using var q=ErpModulServisi.Komut(c,null,s.Id>0
   ?"UPDATE dbo.BERP298_WaSablon SET Ad=@a,Metin=@m,MetaSablon=@s,Dil=@d,AdParametresi=@p WHERE Id=@id AND Aktif=1;SELECT @id"
   :"INSERT dbo.BERP298_WaSablon(Ad,Metin,MetaSablon,Dil,AdParametresi,Olusturan) OUTPUT INSERTED.Id VALUES(@a,@m,@s,@d,@p,@u)",
   ("@id",s.Id),("@a",s.Ad.Trim()),("@m",s.Metin),("@s",(s.MetaSablon??"").Trim()),("@d",string.IsNullOrWhiteSpace(s.Dil)?"tr":s.Dil.Trim()),("@p",s.AdParametresi),("@u",user));
  return Convert.ToInt32(q.ExecuteScalar());
 }

 public void WaSablonSil(int id){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"SahaServisi.WaSablonSil","",[id]);return;}
  LisansOturumu.Gerekli("SAHA");using var c=access.Ac();Yetki(c,null,"FIELD.EDIT");WaHazirla(c);
  using var q=ErpModulServisi.Komut(c,null,"UPDATE dbo.BERP298_WaSablon SET Aktif=0 WHERE Id=@id",("@id",id));q.ExecuteNonQuery();
 }

 /// <summary>Bir müşteriye hazır mesajı WhatsApp Business Cloud API ile gönderir; sonuç gönderim geçmişine yazılır.</summary>
 public WhatsAppSonucu WaGonder(Guid musteriId,int sablonId,string metin){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<WhatsAppSonucu>(connection,"SahaServisi.WaGonder","",[musteriId,sablonId,metin]);
  LisansOturumu.Gerekli("SAHA");using var c=access.Ac();Yetki(c,null,"FIELD.EDIT");WaHazirla(c);
  var sablon=WaSablonOku(c,sablonId);
  string ad,telefon,il;
  using(var q=ErpModulServisi.Komut(c,null,"SELECT Veri FROM dbo.BERP210_SahaMusteri WHERE Id=@id AND (@own=0 OR Olusturan=@user)",("@id",musteriId),("@own",Own),("@user",user))){
   var v=q.ExecuteScalar() as string??throw new ArgumentException("Müşteri bulunamadı.");var m=JsonSerializer.Deserialize<SahaMusterisi>(v,Json)!;ad=m.Ad;telefon=m.Telefon;il=YerAdlari().GetValueOrDefault(m.IlId,m.IlId);
  }
  return WaGonderVeKaydet(c,musteriId,ad,telefon,il,sablon,metin);
 }

 /// <summary>Ayarlardaki test numarasına deneme mesajı gönderir.</summary>
 public WhatsAppSonucu WaTest(int sablonId,string metin){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<WhatsAppSonucu>(connection,"SahaServisi.WaTest","",[sablonId,metin]);
  LisansOturumu.Gerekli("SAHA");using var c=access.Ac();Yetki(c,null,"FIELD.EDIT");WaHazirla(c);
  var ayar=WhatsAppBulut.Ayar();if(ayar.TestNumarasi.Length==0)throw new InvalidOperationException("Önce WhatsApp ayarlarına kendi test numaranızı girin.");
  return WaGonderVeKaydet(c,null,"Test alıcısı",ayar.TestNumarasi,"",WaSablonOku(c,sablonId),metin);
 }

 WhatsAppSablonu WaSablonOku(SqlConnection c,int id){
  using var q=ErpModulServisi.Komut(c,null,"SELECT Id,Ad,Metin,MetaSablon,Dil,AdParametresi FROM dbo.BERP298_WaSablon WHERE Id=@id AND Aktif=1",("@id",id));
  using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Hazır mesaj bulunamadı.");return new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetBoolean(5));
 }

 WhatsAppSonucu WaGonderVeKaydet(SqlConnection c,Guid? musteriId,string ad,string telefon,string il,WhatsAppSablonu sablon,string metin){
  bool ok;string sonuc,mesajId="";
  try{
   string numara=WhatsAppBulut.Numara(telefon);
   string govde=WhatsAppBulut.MetniHazirla(string.IsNullOrWhiteSpace(metin)?sablon.Metin:metin,ad,il);
   if(govde.Length>4096)throw new ArgumentException("Mesaj 4096 karakteri geçemez.");
   mesajId=WhatsAppBulut.Gonder(numara,govde,sablon.MetaSablon,sablon.Dil,sablon.AdParametresi,ad);ok=true;sonuc="Gönderildi";
  }catch(Exception e) when(e is ArgumentException or InvalidOperationException or System.Net.Http.HttpRequestException or TaskCanceledException){ok=false;sonuc=e.Message;}
  using(var q=ErpModulServisi.Komut(c,null,"INSERT dbo.BERP298_WaGonderim(MusteriId,Ad,Telefon,SablonAdi,Basarili,Sonuc,MesajId,KullaniciId) VALUES(@m,@a,@t,@s,@b,@r,@i,@u)",
   ("@m",(object?)musteriId??DBNull.Value),("@a",Kes(ad,160)),("@t",Kes(telefon,30)),("@s",Kes(sablon.Ad,100)),("@b",ok),("@r",Kes(sonuc,1000)),("@i",Kes(mesajId,200)),("@u",user)))q.ExecuteNonQuery();
  return new(musteriId??Guid.Empty,ad,telefon,ok,sonuc);
 }
 static string Kes(string s,int n)=>(s??"").Length>n?s[..n]:s??"";

 public DataTable WaGecmis(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<DataTable>(connection,"SahaServisi.WaGecmis","",[]);
  LisansOturumu.Gerekli("SAHA");using var c=access.Ac();Yetki(c,null,"FIELD.VIEW");WaHazirla(c);
  var t=new DataTable("WhatsAppGecmisi");
  using var q=ErpModulServisi.Komut(c,null,"SELECT TOP(1000) DATEADD(minute,DATEDIFF(minute,SYSUTCDATETIME(),SYSDATETIME()),g.Zaman) AS [Zaman],g.Ad AS [Müşteri],g.Telefon,g.SablonAdi AS [Hazır mesaj],CASE WHEN g.Basarili=1 THEN N'✔ Gönderildi' ELSE N'✖ Gönderilemedi' END AS [Durum],g.Sonuc AS [Açıklama],COALESCE(NULLIF(k.AdSoyad,N''),k.KullaniciAdi,N'') AS [Gönderen] FROM dbo.BERP298_WaGonderim g LEFT JOIN dbo.Kullanicilar k ON k.Id=g.KullaniciId WHERE (@own=0 OR g.KullaniciId=@user) ORDER BY g.Zaman DESC",("@own",Own),("@user",user));
  using var r=q.ExecuteReader();t.Load(r);return t;
 }

 public WhatsAppAyari WaAyar(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<WhatsAppAyari>(connection,"SahaServisi.WaAyar","",[]);
  using var c=access.Ac();Yetki(c,null,"FIELD.EDIT");return WhatsAppBulut.Ayar();
 }

 public void WaAyarKaydet(string telefonNumarasiId,string isletmeHesapId,string anahtar,string testNumarasi){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"SahaServisi.WaAyarKaydet","",[telefonNumarasiId,isletmeHesapId,anahtar,testNumarasi]);return;}
  using var c=access.Ac();access.Yetki(c,null,"USERS.MANAGE");
  WhatsAppBulut.Kaydet(telefonNumarasiId,isletmeHesapId,anahtar,testNumarasi);
 }
}
