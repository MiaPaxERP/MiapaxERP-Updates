using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>
/// Maliyet ve MRP hesaplarında hammadde/malzeme birim fiyatı (TRY, KDV hariç). Sıra:
/// 1) Stok fiyat ve KDV modülündeki alış fiyatı (KDV dahil girildiyse KDV ayrılır),
/// 2) son geçerli alış kaydı (iptal edilenler hariç),
/// 3) son parti alış maliyeti.
/// Dövizli fiyatlar kurla çevrilmeden kullanılmaz; kaynak her satırda açıklanır.
/// </summary>
public static class MaliyetFiyatlari
{
 public const string Sql="""
DECLARE @f decimal(18,4)=NULL,@k nvarchar(80)=NULL;
IF OBJECT_ID('dbo.StokFiyatlari','U') IS NOT NULL AND OBJECT_ID('dbo.MPXNext_StokKdv','U') IS NOT NULL
 SELECT TOP(1) @f=CASE WHEN ISNULL(kv.AlisKdvDahil,0)=1 AND ISNULL(kv.KdvOrani,0)>0 THEN f.AlisMaliyeti/(1+kv.KdvOrani/100) ELSE f.AlisMaliyeti END,@k=N'Stok alış fiyatı'
 FROM dbo.StokFiyatlari f LEFT JOIN dbo.MPXNext_StokKdv kv ON kv.StokKartId=f.StokKartId
 WHERE f.StokKartId=@s AND f.AlisMaliyeti>0 AND ISNULL(f.ParaBirimi,'TRY')='TRY';
ELSE IF OBJECT_ID('dbo.StokFiyatlari','U') IS NOT NULL
 SELECT TOP(1) @f=f.AlisMaliyeti,@k=N'Stok alış fiyatı' FROM dbo.StokFiyatlari f WHERE f.StokKartId=@s AND f.AlisMaliyeti>0 AND ISNULL(f.ParaBirimi,'TRY')='TRY';
IF @f IS NULL AND OBJECT_ID('dbo.StokAlimKayitlari','U') IS NOT NULL
 SELECT TOP(1) @f=a.BirimFiyat,@k=N'Son alış ('+CONVERT(nvarchar(10),a.AlimTarihi,104)+N')'
 FROM dbo.StokAlimKayitlari a WHERE a.StokKartId=@s AND a.ParaBirimi='TRY' AND a.BirimFiyat>0 AND (a.Aciklama IS NULL OR a.Aciklama NOT LIKE N'\[İPTAL\]%' ESCAPE '\')
 ORDER BY a.AlimTarihi DESC,a.Id DESC;
IF @f IS NULL AND OBJECT_ID('dbo.MPX310_Lot','U') IS NOT NULL
 SELECT TOP(1) @f=l.BirimMaliyet,@k=N'Son parti maliyeti' FROM dbo.MPX310_Lot l WHERE l.StokId=@s AND l.BirimMaliyet>0 ORDER BY l.Id DESC;
SELECT @f,@k;
""";

 public static (decimal? Fiyat,string Kaynak) BirimFiyat(SqlConnection c,SqlTransaction? t,int stok){
  using var q=ErpModulServisi.Komut(c,t,Sql,("@s",stok));using var r=q.ExecuteReader();
  if(!r.Read()||r.IsDBNull(0))return (null,"Fiyat yok");
  return (decimal.Round(r.GetDecimal(0),4),r.IsDBNull(1)?"":r.GetString(1));
 }
}
