using System.Data;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmePaneli
{
 async Task DogrudanAlis(){
  var f=new IsletmeForm(pencere,"Satın alma evrakı · Depoya giriş");f.Text("no","Tedarikçi evrak / irsaliye numarası",max:80);f.Select("cari","Tedarikçi",await Task.Run(()=>db.AlisEvrakiSecimleri("cari")));f.Date("date","Evrak tarihi");f.Choice("currency","Para birimi",new[]{"TRY","USD","EUR","GBP"});f.Number("rate","Kur · TRY için 1",1);f.Text("note","Evrak açıklaması",max:350);
  var lines=f.Lines("lines","Teslim alınan ürünler",("Ürün",typeof(int)),("Raf",typeof(int)),("Miktar",typeof(decimal)),("Fiyat",typeof(decimal)),("KDV",typeof(decimal)),("Parti",typeof(string)));f.LineChoice("lines","Ürün",await Task.Run(()=>db.AlisEvrakiSecimleri("stok")));f.LineChoice("lines","Raf",await Task.Run(()=>db.AlisEvrakiSecimleri("raf")));f.Note("Kaydettiğinizde teslim alınan miktarlar depo, parti ve stok hareketlerine birlikte işlenir. Parti boşsa otomatik numara verilir. Kalite incelemesi gereken ürünler için sipariş üzerinden Mal kabul kullanın. Fatura sonradan bu kayıtla eşleştirilebilir.");
  if(f.ShowDialog()!=true)return;
  var g=new SatinAlmaGirdisi(Guid.NewGuid(),null,null,f.S("no"),f.I("cari"),f.D("date"),f.D("date"),f.S("currency"),f.N("rate"),lines.AsEnumerable().Select(r=>new SiparisKalemi((int)r["Ürün"],(int)r["Raf"],(decimal)r["Miktar"],(decimal)r["Fiyat"],r.IsNull("KDV")?20:(decimal)r["KDV"],Convert.ToString(r["Parti"])??"")).ToArray(),f.S("note"));
  long id=await Task.Run(()=>db.AlisEvrakiIleDepoyaAl(g));await Saved();status.Text="Alış #"+id+" depoya alındı; stok ve parti miktarları güncellendi.";
 }
}
