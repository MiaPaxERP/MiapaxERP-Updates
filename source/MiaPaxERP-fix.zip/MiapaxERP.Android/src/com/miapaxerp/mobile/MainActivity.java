package com.miapaxerp.mobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.security.keystore.*;
import android.util.Base64;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.SecretKey;
import java.security.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {
 final ExecutorService worker=Executors.newSingleThreadExecutor();
 final Handler ui=new Handler(Looper.getMainLooper());
 String scanRequest="";int scanGeneration; JSONObject state=new JSONObject(); WebView web; LinearLayout root; TextView status,localStatus;
 volatile boolean active=false,checking=false,locked=false; int generation=0;
 static final String ORIGIN="https://appassets.boruerp.local/";
 final Runnable ticker=new Runnable(){public void run(){if(active&&!locked&&!state.optString("token").isEmpty())sync();ui.postDelayed(this,5000);}};
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);try{load();}catch(Exception e){layout("Cihaz kaydı açılamadı");root.addView(text("Şifreli kayıt okunamadı. Veri kaybını önlemek için yeni eşleme yapılmadı. Uygulama verilerini silmeden destek alın.",16));return;}if(!state.optString("token").isEmpty()&&!locked)connect();else setup();}
 @Override public void onResume(){super.onResume();active=true;MobileUpdater.resume(this);ui.removeCallbacks(ticker);ui.post(ticker);}
 @Override public void onPause(){active=false;ui.removeCallbacks(ticker);super.onPause();}
 @Override public void onDestroy(){generation++;if(web!=null)web.destroy();worker.shutdownNow();super.onDestroy();}
 String appVersion(){try{return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception e){return "?";}}
 TextView text(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.rgb(25,43,53));v.setPadding(0,14,0,10);return v;}
 void layout(String title){if(web!=null){web.destroy();web=null;}root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,24,24,20);root.setBackgroundColor(Color.rgb(243,247,248));root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(16+insets.getSystemWindowInsetLeft(),16+insets.getSystemWindowInsetTop(),16+insets.getSystemWindowInsetRight(),16+insets.getSystemWindowInsetBottom());return insets;});setContentView(root);ImageView logo=new ImageView(this);logo.setImageResource(getResources().getIdentifier("miapaxerp","drawable",getPackageName()));root.addView(logo,new LinearLayout.LayoutParams(120,120));root.addView(text(title,25));Button update=new Button(this);update.setText("Uygulamayı güncelle");update.setOnClickListener(v->MobileUpdater.check(this));root.addView(update);}
 /** Bağlantı ekranındaki bildirim kutucuğu: hata ise kırmızı zeminde nedeni ve yapılacakları gösterir. */
 void box(String title,String reason,boolean error){
  String m=title+(reason==null||reason.isEmpty()?"":"\n\nNedeni / yapılacaklar: "+reason);
  if(status!=null){status.setText(m);status.setPadding(28,24,28,24);status.setBackgroundColor(error?Color.rgb(253,234,234):Color.rgb(230,245,236));status.setTextColor(error?Color.rgb(140,20,20):Color.rgb(20,90,50));}
  Toast.makeText(this,title,Toast.LENGTH_SHORT).show();
 }
 void notice(String message){if(status!=null)status.setText(message);if(localStatus!=null)localStatus.setText(message);Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
 void setup(){
  localStatus=null;generation++;layout("MiaPaxERP Mobil · "+appVersion());ScrollView setupScroll=new ScrollView(this);ViewParent previousParent=root.getParent();if(previousParent instanceof ViewGroup)((ViewGroup)previousParent).removeView(root);setupScroll.addView(root);setContentView(setupScroll);
  root.addView(text("1. Bilgisayarda Mobil bağlantı ekranında 'Telefon kodu üret ve kopyala'ya basın.\n2. Kodu bu telefona gönderin (WhatsApp, e-posta) ve kopyalayın.\n3. Aşağıdaki düğmeye basın.",16));
  EditText quick=new EditText(this);quick.setHint("Kodu buraya da yapıştırabilirsiniz");quick.setSingleLine();quick.setInputType(129);root.addView(quick);
  Button auto=new Button(this);auto.setText("🤖  Kodu yapıştır ve otomatik bağlan");auto.setTextSize(18);root.addView(auto);
  status=text("",15);root.addView(status);
  if(locked)box("Erişim kapalı.","Yönetici bu hesabı veya cihazı kapatmış. Bilgisayardan yeni telefon kodu isteyin.",true);
  else box("Bağlanmaya hazır.","Kod panodaysa kutuyu boş bırakıp düğmeye basmanız yeterli. Uygulama önce aynı Wi-Fi'yi, olmazsa dış IP'yi dener ve sorun olursa nedenini burada gösterir.",false);
  Button toggle=new Button(this);toggle.setText("Gelişmiş (sunucu adresiyle bağlan) ▾");root.addView(toggle);
  LinearLayout manual=new LinearLayout(this);manual.setOrientation(LinearLayout.VERTICAL);manual.setVisibility(View.GONE);root.addView(manual);
  toggle.setOnClickListener(v->{boolean show=manual.getVisibility()!=View.VISIBLE;manual.setVisibility(show?View.VISIBLE:View.GONE);toggle.setText(show?"Manuel bağlantı ▴":"Manuel bağlantı ▾");});
  LinearLayout main=root;root=manual;
  EditText code=new EditText(this);code.setHint("Eşleme kodu (bağlantı kodunda yoksa)");code.setInputType(129);code.setSingleLine();
  root.addView(text("Sunucu adresi",14));
  EditText address=new EditText(this);address.setHint("https://mobil.firmaniz.com");address.setSingleLine();address.setInputType(17);root.addView(address);
  root.addView(text("Port (varsayılan 443)",14));
  EditText port=new EditText(this);port.setHint("443");port.setSingleLine();port.setInputType(2);root.addView(port);root.addView(code);
  String savedBase=state.optString("base");if(state.optString("pin").isEmpty()&&!savedBase.isEmpty()){address.setText(ConnectionAssistant.host(savedBase));port.setText(ConnectionAssistant.port(savedBase));}else port.setText("443");
  Button b=new Button(this);b.setText("Hesabımı bağla");root.addView(b);b.setOnClickListener(v->{
   String key=code.getText().toString().trim();if(key.startsWith("BERP-LAN1:")){localPair(key,b,code);return;}
   if(key.startsWith("MPX-HTTPS1:")||key.startsWith("MPX-CONNECT1:")){internetPacket(key,address,port,code,b);return;}
   try{String base=ConnectionAssistant.address(address.getText().toString(),port.getText().toString());
    if(!key.matches("[0-9a-fA-F]{64}"))throw new Exception();
    beginPair(base,key,"",b,code);
   }catch(Exception ex){notice("Sunucu adresi, port ve 64 karakterlik eşleme kodunu kontrol edin.");}
  });
  Button health=new Button(this);health.setText("Bağlantıyı kontrol et");root.addView(health);health.setOnClickListener(v->{
   final String base;try{base=ConnectionAssistant.address(address.getText().toString(),port.getText().toString());}catch(Exception ex){notice("Önce geçerli sunucu adresi ve port girin.");return;}
   health.setEnabled(false);notice("HTTPS ve mobil servis kontrol ediliyor…");worker.execute(()->{try{JSONObject h=new JSONObject(net(base,"/api/mobile/v2/health",null,"",""));if(!h.optString("service").equals("MiapaxERP.MobileServer")||h.optInt("api")!=2)throw new IOException();ui.post(()->notice("HTTPS ve MiaPaxERP mobil servisi doğrulandı. Hesap erişimi eşleme sırasında doğrulanır."));}catch(Exception ex){String d=ConnectionAssistant.diagnosis(ex);ui.post(()->notice(d));}finally{ui.post(()->health.setEnabled(true));}});
  });
  root=main;
  auto.setOnClickListener(v->autoConnect(quick,code,address,port,b,auto));
 }
 /** Kod panoda veya kutudaysa okur; MPX-HTTPS1 / MPX-CONNECT1 / BERP-LAN1 / adres ayırt eder, sunucuyu doğrular ve onayla eşler. Hiçbir parola veya kod yapay zekâ servisine gönderilmez. */
 void autoConnect(EditText quick,EditText code,EditText address,EditText port,Button connectButton,Button auto){
  String raw=quick.getText().toString().trim();
  if(raw.isEmpty()){try{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null&&cm.hasPrimaryClip()&&cm.getPrimaryClip().getItemCount()>0){CharSequence c=cm.getPrimaryClip().getItemAt(0).coerceToText(this);String t=c==null?"":c.toString().trim();if((t.startsWith("MPX-HTTPS1:")||t.startsWith("MPX-CONNECT1:")||t.startsWith("BERP-LAN1:"))&&t.length()<=8192){raw=t;quick.setText(t);}}}catch(Exception ignored){}}
  if(raw.isEmpty()&&state.optString("pin").isEmpty())raw=state.optString("base");
  if(raw.isEmpty()){EditText in=new EditText(this);in.setHint("Bağlantı kodunu buraya yapıştırın");in.setMinLines(2);
   new AlertDialog.Builder(this).setTitle("Bağlantı kodu").setMessage("Bilgisayarda Mobil bağlantı ekranında 'Telefon kodu üret' düğmesine basın. Kodu bu telefona gönderin (WhatsApp, e-posta), kopyalayın ve buraya yapıştırın. Aynı Wi-Fi'de ve dışarıda aynı kod çalışır.")
    .setView(in).setNegativeButton("Vazgeç",null).setPositiveButton("Bağlan",(d,w)->{String t=in.getText().toString().trim();if(!t.isEmpty()){quick.setText(t);autoConnect(quick,code,address,port,connectButton,auto);}}).show();return;}
  if(raw.startsWith("BERP-LAN1:")){localPair(raw,connectButton,code);return;}
  String key=code.getText().toString().trim();final String base;
  try{
   if(raw.startsWith("MPX-HTTPS1:")||raw.startsWith("MPX-CONNECT1:")){String[] p=packet(raw);base=ConnectionAssistant.address(p[0]);if(!p[1].isEmpty())key=p[1];}
   else base=ConnectionAssistant.address(raw);
  }catch(Exception e){notice("Bağlantı kodu veya adres geçersiz. Ana sunucudan yeni bağlantı kodu alın.");return;}
  address.setText(ConnectionAssistant.host(base));port.setText(ConnectionAssistant.port(base));
  final String pairKey=key;auto.setEnabled(false);notice("Sunucu bulundu: "+base+"\nHTTPS sertifikası ve MiaPaxERP servisi doğrulanıyor…");
  worker.execute(()->{try{
   JSONObject h=new JSONObject(net(base,"/api/mobile/v2/health",null,"",""));if(!h.optString("service").equals("MiapaxERP.MobileServer")||h.optInt("api")!=2)throw new IOException();
   ui.post(()->{if(pairKey.matches("[0-9a-fA-F]{64}"))new AlertDialog.Builder(this).setTitle("Sunucu doğrulandı").setMessage(base+"\n\nBu adres firmanızın MiaPaxERP sunucusuysa hesabınızı bağlayın. Departmanlarınız ana programdan alınır.").setNegativeButton("Vazgeç",null).setPositiveButton("Bağlan",(d,w)->beginPair(base,pairKey,"",connectButton,code)).show();
    else notice("✓ Sunucu doğrulandı: "+base+"\nŞimdi yöneticinizin verdiği 15 dakikalık eşleme kodunu 'Eşleme kodu' kutusuna yazıp düğmeye tekrar basın.");});
  }catch(Exception e){String detail=ConnectionAssistant.diagnosis(e);ui.post(()->new AlertDialog.Builder(this).setTitle("Otomatik bağlantı").setMessage(detail+"\n\nAdres ve port: "+base+"\nSunucu ayarları ana bilgisayardaki Bağlantı ekranından yapılır.").setPositiveButton("Tamam",null).show());}finally{ui.post(()->auto.setEnabled(true));}});
 }
 /** Bağlantı kodunu çözer: {adres, eşleme kodu (yoksa boş)}. */
 static String[] packet(String raw)throws Exception{
  if(raw.length()>8192)throw new Exception();boolean pair=raw.startsWith("MPX-HTTPS1:");int prefix=pair?11:raw.startsWith("MPX-CONNECT1:")?13:0;if(prefix==0)throw new Exception();
  JSONObject packet=new JSONObject(new String(Base64.decode(raw.substring(prefix),Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP),StandardCharsets.UTF_8));
  if(pair&&packet.getInt("v")!=1)throw new Exception();String endpoint=pair?packet.getString("address"):packet.getString("MobilHttps");LanTls.validate(endpoint,"");
  String key=pair?packet.getString("code"):"";if(pair&&!key.matches("[0-9a-fA-F]{64}"))throw new Exception();
  return new String[]{endpoint,key};
 }
 void remoteConnection(){
  final String token=state.optString("token"),id=state.optJSONObject("profile")==null?"":state.optJSONObject("profile").optString("id");
  EditText input=new EditText(this);input.setHint("HTTPS alan adı veya MPX bağlantı kodu");input.setSingleLine();input.setText(state.optString("remoteBase",state.optString("pin").isEmpty()?state.optString("base"):""));
  new AlertDialog.Builder(this).setTitle("Şehir dışından aynı programa bağlan").setMessage("Ana sunucunuzun internet bağlantı kodunu veya HTTPS alan adını girin. Asistan aynı hesabı doğrulayıp adresi kaydeder. Modem ve DNS ayarı ana sunucuda tamamlanmış olmalıdır.").setView(input).setNegativeButton("Vazgeç",null).setPositiveButton("Doğrula ve uygula",(d,w)->{
   final String base;try{String raw=input.getText().toString().trim();if(raw.startsWith("MPX-CONNECT1:")||raw.startsWith("MPX-HTTPS1:")){boolean pair=raw.startsWith("MPX-HTTPS1:");if(raw.length()>8192)throw new Exception();JSONObject p=new JSONObject(new String(Base64.decode(raw.substring(pair?11:13),Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING),StandardCharsets.UTF_8));raw=p.getString(pair?"address":"MobilHttps");}base=ConnectionAssistant.address(raw);}catch(Exception e){notice("Geçerli HTTPS alan adı veya ana sunucu bağlantı kodu girin.");return;}
   worker.execute(()->{try{JSONObject h=new JSONObject(net(base,"/api/mobile/v2/health",null,"",""));if(!h.optString("service").equals("MiapaxERP.MobileServer")||h.optInt("api")!=2)throw new IOException();JSONObject p=new JSONObject(net(base,"/api/mobile/v2/profile",null,token,""));if(id.isEmpty()||!id.equals(p.optString("id"))||!p.has("departments"))throw new SecurityException("Farklı hesap veya eski sunucu");
    ui.post(()->{try{if(!token.equals(state.optString("token")))return;String old=state.optString("base"),pin=state.optString("pin");state.put("base",base);state.put("pin","");state.put("remoteBase",base);try{save();}catch(Exception e){state.put("base",old);state.put("pin",pin);throw e;}notice("Aynı program ve hesap doğrulandı. HTTPS adresi kaydedildi. Wi-Fi kapalıyken de bağlantıyı kontrol edin.");connect();}catch(Exception e){notice("Bağlantı kaydedilemedi; mevcut hesap korunuyor.");}});
   }catch(Exception e){String detail=e instanceof SecurityException||e instanceof ServerError?"Bu sunucuda aynı hesap doğrulanamadı. Mevcut bağlantınız korundu. Yöneticinizden aynı ana sunucunun bağlantı kodunu alın.":ConnectionAssistant.diagnosis(e);ui.post(()->new AlertDialog.Builder(this).setTitle("Bağlantı değişmedi").setMessage(detail).setPositiveButton("Tamam",null).show());}});
  }).show();
 }
 void internetPacket(String raw,EditText address,EditText port,EditText code,Button connectButton){try{
  String[] p=packet(raw);String endpoint=p[0],key=p[1];boolean pair=!key.isEmpty();
  new AlertDialog.Builder(this).setTitle("Ana sunucu adresini doğrula").setMessage(endpoint+"\n\nBu kodu kendi firmanızdaki MiaPaxERP ana sunucusundan aldıysanız uygulayın. Adres kodu tek başına erişim yetkisi vermez.")
   .setNegativeButton("Vazgeç",null).setPositiveButton("Bilgileri uygula",(dialog,which)->{address.setText(ConnectionAssistant.host(endpoint));port.setText(ConnectionAssistant.port(endpoint));code.setText(key);notice(pair?"Adres ve tek kullanımlık kod dolduruldu. 'Hesabımı bağla' düğmesine basın.":"Mobil adres dolduruldu. Yönetici hesabınızdan size özel 15 dakikalık eşleme kodunu alın.");}).show();
 }catch(Exception ex){notice("Bağlantı kodu geçersiz veya mobil HTTPS adresi içermiyor. Ana sunucudan yeni kod alın.");}}
 void localPair(String raw,Button button,EditText code){try{
  if(!raw.startsWith("BERP-LAN1:")||raw.length()>4096)throw new Exception();   JSONObject packet=new JSONObject(new String(Base64.decode(raw.substring(10),Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP),StandardCharsets.UTF_8));
   int v=packet.getInt("v");if(v!=1&&v!=2)throw new Exception();String endpoint=packet.getString("address"),pin=packet.getString("pin"),pairCode=packet.getString("code"),alt=packet.optString("alt","");
   if(!pairCode.matches("[0-9a-fA-F]{64}"))throw new Exception();LanTls.validate(endpoint,pin);if(!alt.isEmpty())LanTls.validate(alt,pin);
   new AlertDialog.Builder(this).setTitle("Fabrika bilgisayarını doğrula").setMessage("Adres: "+endpoint+(alt.isEmpty()?"":"\nDışarıdan: "+alt)+"\nBilgisayar kimliği: "+pin.substring(0,16)+"…\n\nBu kodu kendi ana bilgisayarınızdaki Miapax ERP ekranından aldıysanız bağlanın.")
    .setNegativeButton("Vazgeç",null).setPositiveButton("Bağlan",(dialog,which)->beginPair(endpoint,alt,pairCode,pin,button,code)).show();
 }catch(Exception ex){box("Kod okunamadı.","Kod eksik kopyalanmış olabilir. Bilgisayarda 'Telefon kodu üret ve kopyala'ya yeniden basın ve kodun tamamını yapıştırın.",true);}}
 void beginPair(String base,String key,String pin,Button button,EditText code){beginPair(base,"",key,pin,button,code);}
 void beginPair(String first,String alt,String key,String pin,Button button,EditText code){
  button.setEnabled(false);code.setText("");notice("Fabrika hesabı doğrulanıyor…");
  worker.execute(()->{try{
   JSONObject d=new JSONObject();d.put("code",key);d.put("name",Build.MANUFACTURER+" "+Build.MODEL);
   String base=first,other=alt;JSONObject paired;
   try{paired=new JSONObject(net1(base,"/api/mobile/v2/pair",d,"",pin));}
   catch(ServerError se){throw se;}
   catch(IOException ioe){if(other.isEmpty())throw ioe;ui.post(()->notice("Yerel ağ yanıt vermedi; dış IP deneniyor…"));paired=new JSONObject(net1(other,"/api/mobile/v2/pair",d,"",pin));other=base;base=alt;}
   if(state.optJSONArray("queue")!=null&&state.optJSONArray("queue").length()>0){if(!base.equals(state.optString("base"))||!paired.getString("id").equals(state.getJSONObject("profile").getString("id")))throw new IOException("Bekleyen kayıtlar farklı hesaba taşınamaz.");}
   else{state=new JSONObject();state.put("queue",new JSONArray());state.put("cache",new JSONObject());}
   state.put("base",base);state.put("alt",other);state.put("token",paired.getString("token"));state.put("pin",pin);save();locked=false;
   ui.post(()->{if(!isFinishing()&&!isDestroyed())connect();});
  }catch(Exception ex){ui.post(()->{button.setEnabled(true);box("Bağlanamadı.",ex instanceof ServerError?message(ex):neden(ex,alt.isEmpty()),true);});}});
 }
 /** Bağlantı hatasının nedenini telefonun durumuna göre açıklar. */
 String neden(Exception ex,boolean disYok){
  String d=ConnectionAssistant.diagnosis(ex);
  if(state.optString("pin").isEmpty()&&!(ex instanceof java.net.ConnectException||ex instanceof java.net.SocketTimeoutException))return d;
  return "Bilgisayara ulaşılamadı. Kontrol edin: (1) Ana program açık ve Mobil bağlantı ekranında 'Bağlantıyı başlat'a basılmış olmalı. (2) Fabrikadaysanız telefon aynı Wi-Fi'de olmalı. "
   +(disYok?"(3) Dışarıdaysanız: kodda dış IP yok; bilgisayarda dış IP yazıp yeni kod üretin.":"(3) Dışarıdaysanız: modemde dış porttan bilgisayarın 5189 portuna yönlendirme ve Windows dış IP izni gerekir; bilgisayardaki 'Yapay zekâ ile denetle ve düzelt' düğmesi eksik olanı gösterir.")+" (4) Kod 15 dakika geçerlidir; süresi geçtiyse yeni kod alın.";
 }
 static class ServerError extends IOException{int code;ServerError(int c,String msg){super(msg);code=c;}}
 String message(Exception e){if(e instanceof ServerError){int c=((ServerError)e).code;return c==403?"Hesap, cihaz, lisans veya modül erişimi kapalı.":c==409?"Çakışma: fabrika kaydı değişmiş; bekleyen kayıtları inceleyin.":c==400?"Girdi bilgilerini kontrol edin.":"Sunucu yanıtı: "+c;}return state.optString("pin").isEmpty()?"HTTPS bağlantısı kurulamadı. Mobil internet, sunucunun alan adı/sertifikası ve modemdeki port yönlendirmesini kontrol edin. Kodun süresi dolduysa yeni kod alın.":"Yerel bağlantı kurulamadı. Ana program, aynı Wi-Fi ve Windows yerel ağ iznini kontrol edin. Kodun süresi dolduysa yeni kod alın.";}
 String net(String base,String path,JSONObject body,String token)throws Exception{return net(base,path,body,token,state.optString("pin"));}
 /** Yerel adres yanıt vermezse eşlemedeki dış IP adresini (veya tersini) dener ve çalışanı öne alır. */
 String net(String base,String path,JSONObject body,String token,String pin)throws Exception{
  try{return net1(base,path,body,token,pin);}
  catch(ServerError e){throw e;}
  catch(IOException e){
   String alt=state.optString("alt");if(alt.isEmpty()||pin.isEmpty()||!base.equals(state.optString("base")))throw e;
   String r=net1(alt,path,body,token,pin);state.put("alt",base);state.put("base",alt);save();return r;
  }
 }
 String net1(String base,String path,JSONObject body,String token,String pin)throws Exception{
  LanTls.validate(base,pin);
  HttpsURLConnection c=(HttpsURLConnection)new URL(base+path).openConnection();
  if(!pin.isEmpty())c.setSSLSocketFactory(LanTls.factory(pin));
  try{c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setUseCaches(false);c.setRequestProperty("Accept","application/json");
   if(!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
   if(body!=null){c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}}
   int code=c.getResponseCode();if(code!=200)throw new ServerError(code,"HTTP "+code);
   ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){bytes.write(b,0,n);if(bytes.size()>4*1024*1024)throw new IOException("Yanıt çok büyük.");}}
   return new String(bytes.toByteArray(),StandardCharsets.UTF_8);
  }finally{c.disconnect();}
 }
 Object call(JSONObject body)throws Exception{String raw=net(state.getString("base"),"/api/mobile/v2/rpc",body,state.getString("token"));return new JSONTokener(raw).nextValue();}
 void profile()throws Exception{
  JSONObject profile=new JSONObject(net(state.getString("base"),"/api/mobile/v2/profile",null,state.getString("token")));
  if(!profile.has("departments"))throw new IOException("Ana HTTPS sunucusu 2.8.8 veya üstüne güncellenmeli.");long now=System.currentTimeMillis();state.put("profile",profile);state.put("verified",now);long until=java.time.OffsetDateTime.parse(profile.getString("offlineUntil")).toInstant().toEpochMilli();state.put("until",Math.min(until,now+7L*86400000));save();
 }
 boolean offlineAllowed(){long now=System.currentTimeMillis();return now>=state.optLong("verified")-300000&&now<state.optLong("until")&&state.has("profile")&&state.optJSONObject("profile").has("departments")&&!locked;}
 void connect(){layout("Hesap doğrulanıyor…");worker.execute(()->{try{profile();ui.post(()->dashboard());}
  catch(Exception ex){if(ex instanceof ServerError&&((ServerError)ex).code==403){locked=true;ui.post(()->setup());}
   else if(offlineAllowed())ui.post(()->dashboard());else ui.post(()->{setup();notice("Hesap çevrimiçi doğrulanmalı. "+message(ex));});}});}
 void dashboard(){
  generation++;layout(state.optJSONObject("profile").optString("ad")+" · "+state.optJSONObject("profile").optString("rol"));
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},77);
  root.removeAllViews();Button update=new Button(this);update.setText("MiaPaxERP Mobil "+appVersion()+" · Güncellemeleri kontrol et");update.setOnClickListener(v->MobileUpdater.check(this));root.addView(update);Button connection=new Button(this);connection.setText("Bağlantı asistanı · Şehir dışı erişim");connection.setOnClickListener(v->remoteConnection());root.addView(connection);Button degistir=new Button(this);degistir.setText("Hesap değiştir · yeni telefon kodu ile bağlan");degistir.setOnClickListener(v->hesapDegistir());root.addView(degistir);web=new WebView(this);WebView.setWebContentsDebuggingEnabled(false);
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setDomStorageEnabled(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSupportMultipleWindows(false);
  web.addJavascriptInterface(new Bridge(),"BoruMobile");
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !r.getUrl().toString().equals(ORIGIN+"index.html");}
   @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
    try{Uri u=r.getUrl();String path=u.getPath();if(!u.toString().startsWith(ORIGIN)||path==null||!path.matches("/[a-zA-Z0-9_.-]+"))throw new IOException();
     String mime=path.endsWith(".html")?"text/html":path.endsWith(".css")?"text/css":path.endsWith(".js")?"application/javascript":"application/json";
     Map<String,String> headers=new HashMap<>();headers.put("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'");headers.put("X-Content-Type-Options","nosniff");
     return new WebResourceResponse(mime,"utf-8",200,"OK",headers,getAssets().open(path.substring(1)));
    }catch(Exception e){return new WebResourceResponse("text/plain","utf-8",403,"Blocked",new HashMap<>(),new ByteArrayInputStream(new byte[0]));}
   }
   @Override public void onPageFinished(WebView v,String url){if(url.equals(ORIGIN+"index.html")){String p=state.optJSONObject("profile").toString();v.evaluateJavascript("window.mobileProfile="+p+"; window.dispatchEvent(new Event('mobile-ready'));",null);}}
  });root.addView(web,new LinearLayout.LayoutParams(-1,0,1));web.loadUrl(ORIGIN+"index.html");
 }
 String cacheKey(JSONObject d){String a=d.optString("action");if(a.equals("counts")||a.equals("notices")||a.equals("calendar")||a.equals("stockTypes")||a.equals("chatTargets"))return a;if(a.equals("report"))return "report:"+d.optString("section");return a.equals("province")?"province:"+d.optString("il")+":"+d.optString("ilce")+":"+d.optString("search")+":"+d.optInt("offset"):a.equals("load")?"load:"+d.optString("id"):a.equals("list")?"list:"+d.optString("il")+":"+d.optString("ilce")+":"+d.optString("koy"):"";}
 JSONArray queue()throws Exception{if(!state.has("queue"))state.put("queue",new JSONArray());return state.getJSONArray("queue");}
 /** Telefonu başka bir mobil hesaba (ör. patron yerine çalışan) bağlamak için mevcut eşlemeyi bu cihazdan kaldırır. */
 void hesapDegistir(){try{
  int bekleyen=queue().length();
  new AlertDialog.Builder(this).setTitle("Hesap değiştir").setMessage((bekleyen>0?"Gönderilmemiş "+bekleyen+" kayıt var; önce internet/Wi-Fi bağlantısında eşitlenmesini bekleyin. Devam ederseniz bu kayıtlar silinir.\n\n":"")+"Bu telefon şu hesaptan çıkarılacak: "+state.optJSONObject("profile").optString("ad")+". Sonra yeni çalışanın telefon kodunu yapıştırın. Eski hesabın cihaz kaydını bilgisayardan iptal edebilirsiniz.")
   .setNegativeButton("Vazgeç",null).setPositiveButton(bekleyen>0?"Sil ve değiştir":"Değiştir",(d,w)->{try{state=new JSONObject();state.put("queue",new JSONArray());state.put("cache",new JSONObject());save();locked=false;setup();}catch(Exception e){notice("Hesap değiştirilemedi.");}}).show();
 }catch(Exception e){notice("Hesap değiştirilemedi.");}}
 /** Telefonun bildirim çubuğuna MiaPaxERP bildirimi düşürür (Android 13+ için izin istenir). */
 void bildir(String title,String text){try{
  NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm==null)return;
  nm.createNotificationChannel(new NotificationChannel("miapax","MiaPaxERP bildirimleri",NotificationManager.IMPORTANCE_DEFAULT));
  PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(this,"miapax").setSmallIcon(getResources().getIdentifier("miapaxerp","drawable",getPackageName())).setContentTitle(title.length()>120?title.substring(0,120):title).setContentText(text.length()>300?text.substring(0,300):text).setStyle(new Notification.BigTextStyle().bigText(text.length()>1500?text.substring(0,1500):text)).setAutoCancel(true).setContentIntent(open).build();
  nm.notify((int)(System.currentTimeMillis()&0x7fffffff),n);
 }catch(Exception ignored){}}
 void remove(int i)throws Exception{queue().remove(i);save();}
 void sync(){if(checking||state.optString("token").isEmpty())return;checking=true;worker.execute(()->{try{profile();sendQueue();ui.post(()->{if(web!=null)web.evaluateJavascript("window.mobileProfile="+state.optJSONObject("profile").toString()+";window.dispatchEvent(new Event('mobile-permissions'));if(window.mobileProfile.departments.some(x=>x.kod==='saha'))window.dispatchEvent(new Event('mobile-sync'));",null);});}
  catch(Exception e){if(e instanceof ServerError&&((ServerError)e).code==403){locked=true;ui.post(()->{if(web!=null)web.evaluateJavascript("document.body.textContent='Mobil erişim kapalı. Yöneticinize başvurun.';",null);});}}
  finally{checking=false;}});}
 void sendQueue()throws Exception{
  for(int i=0;i<queue().length();){JSONObject item=queue().getJSONObject(i);if(item.has("error")){i++;continue;}
   try{call(item);state.put("cache",new JSONObject());remove(i);}
   catch(ServerError e){if(e.code==409||e.code==400||e.code==403){item.put("error",message(e));save();i++;}else throw e;}
  }
 }
 class Bridge{
  @JavascriptInterface public void postMessage(String raw){if(raw.length()>32768)return;final int stamp=generation;worker.execute(()->{String request="";JSONObject answer=new JSONObject();try{
   JSONObject d=new JSONObject(raw);request=d.getString("request");answer.put("request",request);
   if(locked||!offlineAllowed())throw new IOException("Hesap doğrulanmalı.");
   String action=d.optString("action");Object result;
   if(action.equals("queue"))result=queue();
   else if(action.equals("drop")){String op=d.getString("operation");for(int i=0;i<queue().length();i++)if(queue().getJSONObject(i).optString("operation").equals(op)){remove(i);break;}result=new JSONObject().put("ok",true);}
   else if(action.equals("logout")){if(queue().length()>0)throw new IOException("Gönderilmemiş kayıtlar var.");state=new JSONObject();save();locked=true;ui.post(()->setup());return;}
   else if(action.equals("notify")){bildir(d.optString("title","MiaPaxERP"),d.optString("text",""));result=new JSONObject().put("ok",true);}
   else if(action.equals("scanBarcode")){scanRequest=request;scanGeneration=stamp;ui.post(()->startActivityForResult(new Intent(MainActivity.this,BarcodeActivity.class),55));return;}
   else if(action.equals("save")){
    if(queue().length()>=1000)throw new IOException("1000 bekleyen kayıt sınırı doldu. Önce sunucuyla eşitleyin.");JSONObject data=d.getJSONObject("data");for(int i=0;i<queue().length();i++)if(queue().getJSONObject(i).getJSONObject("data").getString("id").equals(data.getString("id")))throw new IOException("Bu müşteri için bekleyen kayıt var. Önce eşitleyin veya çakışmayı çözün.");
    d.put("operation",UUID.randomUUID().toString());queue().put(d);save();
    try{sendQueue();}catch(Exception ex){if(ex instanceof ServerError&&((ServerError)ex).code==403){locked=true;throw ex;}}
    result=new JSONObject().put("queued",queue().length()>0);
   }else if(action.equals("list")||action.equals("load")||action.equals("province")||action.equals("counts")||action.equals("report")||action.equals("barcode")||action.equals("stockTypes")||action.equals("stockFields")||action.equals("createStock")||action.equals("notices")||action.equals("chatTargets")||action.equals("messages")||action.equals("sendMessage")||action.equals("noticesRead")||action.equals("calendar")||action.equals("calendarAdd")||action.equals("calendarDone")){
    String key=cacheKey(d);try{result=call(d);if(!key.isEmpty()){state.getJSONObject("cache").put(key,result);save();}}
    catch(IOException e){if(e instanceof ServerError)throw e;if(key.isEmpty()||!state.getJSONObject("cache").has(key))throw e;result=state.getJSONObject("cache").get(key);}
   }else throw new IOException("İşlem desteklenmiyor.");
   answer.put("result",result);
  }catch(Exception ex){try{answer.put("request",request);answer.put("error",ex instanceof IOException&&!(ex instanceof ServerError)&&ex.getMessage()!=null?ex.getMessage():message(ex));}catch(Exception ignored){}}
  final String response=answer.toString();ui.post(()->{if(stamp==generation&&web!=null)web.evaluateJavascript("window.mobileReceive("+response+");",null);});});}
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==55&&!scanRequest.isEmpty()){try{JSONObject answer=new JSONObject();answer.put("request",scanRequest);if(result==RESULT_OK&&data!=null)answer.put("result",data.getStringExtra("barcode"));else answer.put("error","Tarama iptal edildi; barkodu elle girebilirsiniz.");if(scanGeneration==generation&&web!=null)web.evaluateJavascript("window.mobileReceive("+answer.toString()+");",null);}catch(Exception ignored){}finally{scanRequest="";}}}
 SecretKey key()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("BoruERP.Mobile220")){KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder("BoruERP.Mobile220",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();}return (SecretKey)ks.getKey("BoruERP.Mobile220",null);}
 void save()throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());String iv=Base64.encodeToString(c.getIV(),Base64.NO_WRAP),data=Base64.encodeToString(c.doFinal(state.toString().getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);if(!getSharedPreferences("mobile220",MODE_PRIVATE).edit().putString("iv",iv).putString("data",data).commit())throw new IOException("Cihaz kaydı yazılamadı.");}
 void load()throws Exception{SharedPreferences p=getSharedPreferences("mobile220",MODE_PRIVATE);if(!p.contains("data"))return;Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(p.getString("iv",""),Base64.NO_WRAP)));state=new JSONObject(new String(c.doFinal(Base64.decode(p.getString("data",""),Base64.NO_WRAP)),StandardCharsets.UTF_8));}
}
