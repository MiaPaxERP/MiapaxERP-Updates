ALTER TABLE licenses ADD COLUMN module_expires TEXT NOT NULL DEFAULT '{}';
