import {build} from 'esbuild';
import {mkdirSync,copyFileSync,readFileSync} from 'node:fs';
import {resolve,dirname,relative} from 'node:path';
const root=process.cwd();
// Resolve this dependency-free Worker from its own files, without probing host ancestors.
const localSources={name:'local-worker-sources',setup(builder){builder.onResolve({filter:/.*/},args=>{const path=resolve(args.importer?dirname(args.importer):root,args.path);if(relative(root,path).startsWith('..'))throw Error('Worker imports must stay inside source');return {path,namespace:'site-source'};});builder.onLoad({filter:/.*/,namespace:'site-source'},args=>({contents:readFileSync(args.path,'utf8'),loader:'js'}));}};
await build({entryPoints:['./worker/index.js'],plugins:[localSources],bundle:true,format:'esm',platform:'browser',target:'es2022',outfile:'dist/server/index.js',minify:false});
mkdirSync('dist/.openai',{recursive:true});copyFileSync('.openai/hosting.json','dist/.openai/hosting.json');
console.log('Worker bundled with license, support and UI modules.');
