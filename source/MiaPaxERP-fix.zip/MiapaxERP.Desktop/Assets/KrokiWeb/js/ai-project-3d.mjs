// AI proje sihirbazı · 3D görünüm. Tarla, hatlar, dağıtım/ana hat, su kaynağı, vanalar ve sulama elemanları.
import * as THREE from '/lib/three/three.module.js';
import {OrbitControls} from '/lib/three/OrbitControls.js';

export function createProjectViewer(host){
 const scene=new THREE.Scene();scene.background=new THREE.Color('#dcedf4');
 const camera=new THREE.PerspectiveCamera(45,1,0.1,50000);
 const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.outputColorSpace=THREE.SRGBColorSpace;host.append(renderer.domElement);
 const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.maxPolarAngle=Math.PI/2-0.02;
 scene.add(new THREE.HemisphereLight('#ffffff','#5a6b3a',1.1));const sun=new THREE.DirectionalLight('#ffffff',1.4);sun.position.set(1,2,1.3);scene.add(sun);
 const group=new THREE.Group();scene.add(group);
 let size=100,raf=0;const focus=new THREE.Box3();
 const resize=()=>{const w=host.clientWidth||600,h=host.clientHeight||400;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();};
 new ResizeObserver(resize).observe(host);resize();
 const loop=()=>{raf=requestAnimationFrame(loop);controls.update();renderer.render(scene,camera);};loop();

 const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:0.75});
 const clear=()=>{group.traverse(o=>{o.geometry?.dispose?.();if(o.material)[].concat(o.material).forEach(m=>m.dispose());});group.clear();};
 // Tarla koordinatı (x: en, y: boy) → sahne (x, z). Boy kuzeye doğru (−z).
 const P=(x,y,h=0)=>new THREE.Vector3(x,h,-y);
 function tube(points,radius,color,minRadius=0){
  const r=Math.max(radius,minRadius);const g=new THREE.Group();
  for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=a.distanceTo(b);if(len<0.01)continue;
   const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,len,10),mat(color));m.position.copy(a).add(b).multiplyScalar(0.5);
   m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),b.clone().sub(a).normalize());g.add(m);}
  return g;
 }
 function label(text,pos,scale){
  const c=document.createElement('canvas');c.width=512;c.height=128;const x=c.getContext('2d');x.fillStyle='rgba(255,255,255,.92)';x.fillRect(0,0,512,128);x.fillStyle='#17495e';x.font='bold 44px Segoe UI, Arial';x.textAlign='center';x.textBaseline='middle';x.fillText(text,256,64);
  const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),depthTest:false}));s.scale.set(scale*4,scale,1);s.position.copy(pos);return s;
 }

 function show(r){
  clear();const p=r.input,W=p.width,L=p.length;size=Math.max(W,L,p.sourceDistance+Math.max(W,L)/2);
  const vis=Math.max(0.15,size/600);// uzaktan görünür kalınlık
  // Zemin ve tarla
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(size*2.2,size*2.2),mat('#a7b98a'));ground.rotation.x=-Math.PI/2;ground.position.set(W/2,-0.05,-L/2);group.add(ground);
  const field=new THREE.Mesh(new THREE.PlaneGeometry(W,L),mat(p.method==='drip'?'#8a6a45':'#6f9b4a'));field.rotation.x=-Math.PI/2;field.position.set(W/2,0,-L/2);group.add(field);
  const edge=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(W,0.01,L)),new THREE.LineBasicMaterial({color:'#2f4a1e'}));edge.position.set(W/2,0.02,-L/2);group.add(edge);
  // Bitki sıraları (görsel)
  const rowStep=Math.max(1,Math.ceil(r.lateralRows.length/150));const crop=new THREE.Group();
  for(let i=0;i<r.lateralRows.length;i+=rowStep){const x=r.lateralRows[i];const m=new THREE.Mesh(new THREE.BoxGeometry(Math.min(p.rowGap*0.35,0.6*vis+0.3),Math.min(0.5,vis),L*0.98),mat('#3f7d2c'));m.position.set(x+Math.min(p.rowGap*0.3,1),Math.min(0.25,vis/2),-L/2);crop.add(m);}
  group.add(crop);
  // Hatlar (lateral)
  const latR=Math.max(0.02,p.lateralDiameter/2000)*Math.max(1,vis*4),y0=r.manifoldY;
  for(let i=0;i<r.lateralRows.length;i+=rowStep){const x=r.lateralRows[i];
   const ends=r.split?[y0-r.lateralLen,y0+r.lateralLen]:[y0===0?r.lateralLen:L-r.lateralLen];
   for(const e of ends)group.add(tube([P(x,y0,0.08),P(x,e,0.08)],latR,p.method==='drip'?'#1b1b1b':'#2a6bb0'));}
  // Sulama elemanları (örnekleme)
  const heads=[];const stepE=p.method==='drip'?Math.max(p.emitterGap,L/40):p.emitterGap;
  for(let i=0;i<r.lateralRows.length;i+=rowStep){const x=r.lateralRows[i];for(let y=p.emitterGap/2;y<L;y+=stepE)heads.push([x,y]);}
  const headCount=Math.min(heads.length,6000);const hg=p.method==='drip'?new THREE.SphereGeometry(Math.max(0.05,vis*0.4),6,4):new THREE.CylinderGeometry(Math.max(0.05,vis*0.3),Math.max(0.05,vis*0.3),Math.max(0.6,vis*4),6);
  const inst=new THREE.InstancedMesh(hg,mat(p.method==='drip'?'#4aa3df':'#f2b134'),headCount);const tmp=new THREE.Object3D();
  for(let k=0;k<headCount;k++){const [x,y]=heads[k];tmp.position.copy(P(x,y,p.method==='drip'?0.1:Math.max(0.3,vis*2)));tmp.updateMatrix();inst.setMatrixAt(k,tmp.matrix);}group.add(inst);
  // Dağıtım borusu ve vanalar
  const manR=Math.max(r.manifoldOd/2000*Math.max(1,vis*6),0.05);const xs=r.lateralRows;const m0=Math.max(0,xs[0]-p.rowGap/2),m1=Math.min(W,xs[xs.length-1]+p.rowGap/2);
  group.add(tube([P(m0,y0,0.15),P(m1,y0,0.15)],manR,'#1f7a4d'));
  for(let s=0;s<r.sections;s++){const x=m0+(s+0.5)*(m1-m0)/r.sections;const box=new THREE.Mesh(new THREE.BoxGeometry(manR*8,manR*6,manR*8),mat('#c0392b'));box.position.copy(P(x,y0,manR*3));group.add(box);}
  // Ana hat: kaynak → giriş
  const mainR=Math.max(r.mainOd/2000*Math.max(1,vis*8),0.06);
  group.add(tube(r.route.map(q=>P(q.x,q.y,0.2)),mainR,'#0b5fa5'));
  // Su kaynağı
  const s=r.source;const sp=P(s.x,s.y,0);const k=Math.max(1.5,vis*6);
  if(p.sourceType==='well'){const w=new THREE.Mesh(new THREE.CylinderGeometry(k,k,k*0.8,24),mat('#7f8c8d'));w.position.copy(sp).setY(k*0.4);group.add(w);const water=new THREE.Mesh(new THREE.CircleGeometry(k*0.85,24),mat('#2e86de'));water.rotation.x=-Math.PI/2;water.position.copy(sp).setY(k*0.81);group.add(water);}
  else if(p.sourceType==='tank'){const t=new THREE.Mesh(new THREE.CylinderGeometry(k*1.3,k*1.3,k*2,24),mat('#dfe6e9'));t.position.copy(sp).setY(k);group.add(t);}
  else if(p.sourceType==='canal'){const c=new THREE.Mesh(new THREE.BoxGeometry(k*12,0.2,k*2),mat('#2e86de'));c.position.copy(sp).setY(0.05);if(p.sourceSide==='east'||p.sourceSide==='west')c.rotation.y=Math.PI/2;group.add(c);}
  else{const n=new THREE.Mesh(new THREE.BoxGeometry(k,k*1.4,k),mat('#95a5a6'));n.position.copy(sp).setY(k*0.7);group.add(n);}
  if(p.accessories.includes('pump')){const pump=new THREE.Mesh(new THREE.BoxGeometry(k*0.9,k*0.7,k*0.6),mat('#16a085'));pump.position.copy(sp).add(new THREE.Vector3(k*1.6,k*0.35,0));group.add(pump);}
  if(p.accessories.includes('filter')){const f=new THREE.Mesh(new THREE.CylinderGeometry(k*0.3,k*0.3,k*1.1,16),mat('#e67e22'));const q=r.route[1]||r.route[0];f.position.copy(P(q.x,q.y,k*0.55));group.add(f);}
  // Etiketler
  const ls=Math.max(2,size/30);
  group.add(label(`${W} × ${L} m · ${r.dekar} dekar`,P(W/2,L+ls*1.5,ls*0.8),ls));
  group.add(label(`Su kaynağı · ${p.sourceDistance} m`,P(s.x,s.y,k*2.2+ls*0.6),ls*0.9));
  group.add(label(`Ana hat Ø${r.mainOd}`,P((r.route[0].x+r.route[r.route.length-1].x)/2,(r.route[0].y+r.route[r.route.length-1].y)/2,ls*0.8),ls*0.8));
  const sp0=P(r.source.x,r.source.y,0);focus.makeEmpty();focus.expandByPoint(P(0,0,0));focus.expandByPoint(P(W,L,Math.max(2,vis*4)));focus.expandByPoint(sp0);
  view('angle');
 }
 function view(kind){
  const box=focus.isEmpty()?new THREE.Box3().setFromObject(group):focus;const c=box.getCenter(new THREE.Vector3()),d=Math.max(10,box.getSize(new THREE.Vector3()).length());
  controls.target.copy(c);
  if(kind==='above')camera.position.set(c.x,d*1.15,c.z+d*0.02);else if(kind==='ground')camera.position.set(c.x-d*0.45,Math.max(2,d*0.07),c.z+d*0.55);else camera.position.set(c.x+d*0.42,d*0.62,c.z+d*0.78);
  camera.near=Math.max(0.05,d/5000);camera.far=d*20;camera.updateProjectionMatrix();controls.update();
 }
 function snapshot(){renderer.render(scene,camera);return renderer.domElement.toDataURL('image/png');}
 function dispose(){cancelAnimationFrame(raf);clear();renderer.dispose();}
 return {show,view,snapshot,dispose};
}
