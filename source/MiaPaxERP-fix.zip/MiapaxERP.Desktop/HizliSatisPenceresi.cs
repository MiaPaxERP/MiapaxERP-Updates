using System.Collections.ObjectModel;
using System.Data;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ListBox = System.Windows.Controls.ListBox;
namespace MiapaxERP.Desktop;
public sealed class HizliSatisSatiri:System.ComponentModel.INotifyPropertyChanged
{
 decimal miktar,fiyat,kdv=20;
 public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
 void Degisti(string ad){PropertyChanged?.Invoke(this,new(ad));PropertyChanged?.Invoke(this,new(nameof(Toplam)));}
 public int Stok{get;set;}public string Urun{get;set;}="";public string Birim{get;set;}="";
 public decimal Miktar{get=>miktar;set{miktar=value<0?0:value;Degisti(nameof(Miktar));}}
 public decimal Fiyat{get=>fiyat;set{fiyat=value<0?0:value;Degisti(nameof(Fiyat));}}
 public decimal Kdv{get=>kdv;set{kdv=Math.Clamp(value,0,100);Degisti(nameof(Kdv));}}
 public decimal Toplam=>decimal.Round(Miktar*Fiyat,2)+decimal.Round(decimal.Round(Miktar*Fiyat,2)*Kdv/100,2);
}
public sealed class HizliSatisPenceresi:Window
{
 readonly bool normalSatis;readonly HizliSatisServisi service;readonly IsletmeServisi enterprise;readonly ObservableCollection<HizliSatisSatiri> rows=[];readonly DataGrid grid=new(){AutoGenerateColumns=false,CanUserAddRows=false,Height=310};readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap},total=new(){FontSize=22};readonly TextBox search=new(){MinWidth=300,MaxLength=100};readonly ComboBox customer=new(){DisplayMemberPath="Ad",SelectedValuePath="Id",MinWidth=300},account=new(){DisplayMemberPath="Ad",SelectedValuePath="Id",MinWidth=300};readonly CheckBox paid=new(){Content="Tamamı tahsil edildi"};Guid key=Guid.NewGuid();bool uncertain;SatisGirdisi? pending;
 public HizliSatisPenceresi(string connection,int user,bool normalSatis=false){
  FontSize=14;this.normalSatis=normalSatis;var sales=new SatisModuluServisi(connection,user);var buyer=new TextBox{MaxLength=160,MinHeight=32};
  service=new(connection,user);enterprise=new(connection,user);Title=normalSatis?"MiaPaxERP • SATIŞ":"MiaPaxERP • Hızlı satış";Width=1100;Height=880;WindowStartupLocation=WindowStartupLocation.CenterOwner;var root=new StackPanel{Margin=new Thickness(22)};Content=new ScrollViewer{Content=root};root.Children.Add(new TextBlock{Text="Barkodu okut, miktarı kontrol et, satışı tamamla",FontSize=23});var bar=new WrapPanel();root.Children.Add(bar);bar.Children.Add(search);Button scan=new Button{Content="Barkod / kod ekle",Margin=new Thickness(8)},find=new Button{Content="Ad ile ara",Margin=new Thickness(8)};bar.Children.Add(scan);bar.Children.Add(find);var results=new ListBox{Height=90,DisplayMemberPath="Ad"};root.Children.Add(results);
  async Task Search(bool barcode){try{string query=search.Text.Trim();var found=await Task.Run(()=>normalSatis?sales.UrunAra(query,barcode):service.UrunAra(query,barcode));if(barcode&&found.Length==1)Add(found[0]);else{results.ItemsSource=found;status.Text=found.Length+" ürün bulundu. Eklemek için çift tıklayın.";}}catch(Exception e){DestekIzleme.Bildir(e,"HIZLISATIS");status.Text=e.Message;}}
  scan.Click+=async(_,_)=>await Search(true);find.Click+=async(_,_)=>await Search(false);search.KeyDown+=async(_,e)=>{if(e.Key==Key.Enter){e.Handled=true;await Search(true);}};results.MouseDoubleClick+=(_,_)=>{if(results.SelectedItem is HizliUrun p)Add(p);};
  foreach(var (name,path,read) in new[]{("Ürün","Urun",true),("Birim","Birim",true),("Miktar","Miktar",false),("Birim fiyat · TRY","Fiyat",false),("KDV %","Kdv",false),("Toplam","Toplam",true)}){
   if(path=="Kdv"){grid.Columns.Add(KdvSutunu());continue;}
   // Tutarlar Türkçe binlik ayıracıyla gösterilir (4800 → 4.800,00); düzenlerken "4.800" veya "4800" yazılabilir.
   string? bicim=path switch{"Toplam"=>"#,##0.00","Fiyat"=>"#,##0.###","Miktar"=>"#,##0.###",_=>null};
   grid.Columns.Add(new DataGridTextColumn{Header=name,Binding=new System.Windows.Data.Binding(path){ConverterCulture=CultureInfo.GetCultureInfo("tr-TR"),StringFormat=bicim},IsReadOnly=read,MinWidth=name=="Ürün"?260:80,Width=name=="Ürün"?new DataGridLength(1,DataGridLengthUnitType.Star):120,ElementStyle=bicim is null?null:SagaDayali()});
  }
  grid.ItemsSource=rows;
  // Genel toplam her satır değişikliğinde (miktar, fiyat, KDV, ekleme, silme) hemen yenilenir; yalnız hücre düzenleme sonuna bağlı değildir.
  rows.CollectionChanged+=(_,e)=>{foreach(HizliSatisSatiri r in e.NewItems??Array.Empty<HizliSatisSatiri>())r.PropertyChanged+=SatirDegisti;foreach(HizliSatisSatiri r in e.OldItems??Array.Empty<HizliSatisSatiri>())r.PropertyChanged-=SatirDegisti;Update();};
  grid.CellEditEnding+=(_,_)=>Dispatcher.BeginInvoke(new Action(Update),System.Windows.Threading.DispatcherPriority.Background);
  grid.CurrentCellChanged+=(_,_)=>Update();root.Children.Add(grid);var remove=new Button{Content="Seçili satırı kaldır",HorizontalAlignment=System.Windows.HorizontalAlignment.Left};root.Children.Add(remove);remove.Click+=(_,_)=>{if(uncertain)return;if(grid.SelectedItem is HizliSatisSatiri r)rows.Remove(r);Update();};root.Children.Add(new TextBlock{Text="Cari müşteri"});root.Children.Add(customer);
  if(normalSatis){var retail=new Button{Content="Dışarıdan gelen müşteri · Perakende satış",Padding=new Thickness(10),Margin=new Thickness(0,8,0,8)};root.Children.Add(retail);root.Children.Add(new TextBlock{Text="Müşteri / teslim açıklaması · isteğe bağlı"});root.Children.Add(buyer);retail.Click+=async(_,_)=>{retail.IsEnabled=false;try{int id=await Task.Run(sales.PerakendeCari);customer.ItemsSource=(await Task.Run(()=>enterprise.Secimler("cari"))).DefaultView;customer.SelectedValue=id;paid.IsChecked=true;status.Text="Perakende müşteri seçildi. Tahsilat hesabını ve fiyatları kontrol edin.";}catch(Exception e){status.Text=e.Message;}finally{retail.IsEnabled=true;}};}
  root.Children.Add(paid);root.Children.Add(new TextBlock{Text="Tahsilat hesabı · TRY kasa veya banka"});root.Children.Add(account);root.Children.Add(total);Button save=new Button{Content="Satışı tamamla · stok ve muhasebeye işle",Padding=new Thickness(16,10,16,10)};root.Children.Add(save);root.Children.Add(new TextBlock{Text="Birim fiyatlar KDV hariçtir. KDV oranını kontrol edin. Parti maliyeti veya hesap kodu eksikse satışın tamamı geri alınır.",TextWrapping=TextWrapping.Wrap});root.Children.Add(status);
  Loaded+=async(_,_)=>{try{customer.ItemsSource=(await Task.Run(()=>enterprise.Secimler("cari"))).DefaultView;account.ItemsSource=(await Task.Run(()=>enterprise.Secimler("hesap"))).DefaultView;search.Focus();}catch(Exception e){DestekIzleme.Bildir(e,"HIZLISATIS");status.Text=e.Message;}};
  save.Click+=async(_,_)=>{save.IsEnabled=false;try{grid.CommitEdit(DataGridEditingUnit.Cell,true);grid.CommitEdit(DataGridEditingUnit.Row,true);if(pending is not null){var id=await Task.Run(()=>normalSatis?sales.Sonuc(key):service.Sonuc(key));if(id.HasValue){Done(id.Value);return;}}
   if(rows.Count==0||customer.SelectedValue is not int cid)throw new ArgumentException("Ürün ve cari müşteri seçin.");var lines=rows.Select(r=>new SatisKalemi(r.Stok,r.Miktar,r.Fiyat,r.Kdv)).ToArray();decimal sum=rows.Sum(x=>x.Toplam);int? aid=account.SelectedValue as int?;if(paid.IsChecked==true&&!aid.HasValue)throw new ArgumentException("Tahsilat hesabı seçin.");var g=pending??new SatisGirdisi(key,false,"HS-"+key.ToString("N"),cid,DateTime.Today,null,"TRY",1,0,normalSatis?"Satış · "+buyer.Text.Trim():"Hızlı satış",null,lines,paid.IsChecked==true?aid:null,paid.IsChecked==true?sum:0,1);pending=g;uncertain=true;grid.IsReadOnly=true;customer.IsEnabled=account.IsEnabled=paid.IsEnabled=search.IsEnabled=results.IsEnabled=remove.IsEnabled=false;long result=await Task.Run(()=>normalSatis?sales.Satis(g):service.Satis(g));Done(result);
  }catch(Exception e){DestekIzleme.Bildir(e,"HIZLISATIS");status.Text=e.Message+"\nİşlem kimliği: "+key+". Bağlantı kesildiyse tekrar basmak önce kayıt sonucunu kontrol eder.";uncertain=e is Microsoft.Data.SqlClient.SqlException||e.Message.StartsWith("Sunucuya ulaşılamadı",StringComparison.Ordinal);grid.IsReadOnly=uncertain;customer.IsEnabled=account.IsEnabled=paid.IsEnabled=!uncertain;if(!uncertain)pending=null;}finally{save.IsEnabled=true;if(!uncertain){grid.IsReadOnly=false;customer.IsEnabled=account.IsEnabled=paid.IsEnabled=search.IsEnabled=results.IsEnabled=remove.IsEnabled=true;}}};
 }
 internal static DataGridColumn KdvSutunu(){
  var view=new FrameworkElementFactory(typeof(TextBlock));view.SetBinding(TextBlock.TextProperty,new System.Windows.Data.Binding("Kdv"){StringFormat="{0:0.##} %"});
  var edit=new FrameworkElementFactory(typeof(ComboBox));edit.SetValue(ComboBox.ItemsSourceProperty,Enumerable.Range(0,21).ToArray());edit.SetValue(ComboBox.IsEditableProperty,true);edit.SetBinding(ComboBox.TextProperty,new System.Windows.Data.Binding("Kdv"){Mode=System.Windows.Data.BindingMode.TwoWay,UpdateSourceTrigger=System.Windows.Data.UpdateSourceTrigger.LostFocus,ConverterCulture=CultureInfo.GetCultureInfo("tr-TR"),ValidatesOnExceptions=true});
  return new DataGridTemplateColumn{Header="KDV % · seç / elle yaz",Width=160,CellTemplate=new DataTemplate{VisualTree=view},CellEditingTemplate=new DataTemplate{VisualTree=edit}};
 }
 void Done(long id){rows.Clear();key=Guid.NewGuid();pending=null;uncertain=false;customer.IsEnabled=account.IsEnabled=paid.IsEnabled=true;grid.IsReadOnly=false;status.Text="Satış #"+id+" kaydedildi. Stok, cari, muhasebe ve seçili tahsilat aynı işlemde işlendi.";Update();search.Focus();}
 void Add(HizliUrun p){if(uncertain){status.Text="Önce son işlemin sonucunu kontrol edin.";return;}if(p.Para!="TRY"||(!normalSatis&&p.Fiyat is null)){status.Text="Hızlı satış için TRY satış fiyatı tanımlayın. Dövizli satışta ticari satış ekranını kullanın.";return;}var row=rows.FirstOrDefault(x=>x.Stok==p.Id);if(row is null)rows.Add(new(){Stok=p.Id,Urun=p.Kod+" · "+p.Ad,Birim=p.Birim,Miktar=p.Carpan,Fiyat=p.Fiyat??0});else row.Miktar+=p.Carpan;search.Clear();Update();search.Focus();}
 void SatirDegisti(object? s,System.ComponentModel.PropertyChangedEventArgs e){if(e.PropertyName==nameof(HizliSatisSatiri.Toplam))Update();}
 static Style SagaDayali(){var s=new Style(typeof(TextBlock));s.Setters.Add(new Setter(TextBlock.TextAlignmentProperty,TextAlignment.Right));return s;}
 void Update(){
  if(!Dispatcher.CheckAccess()){Dispatcher.BeginInvoke(new Action(Update));return;}
  var tr=CultureInfo.GetCultureInfo("tr-TR");decimal net=rows.Sum(x=>decimal.Round(x.Miktar*x.Fiyat,2)),genel=rows.Sum(x=>x.Toplam);
  total.Text="Genel toplam: "+genel.ToString("N2",tr)+" TRY"+(rows.Count>0?"   (KDV hariç "+net.ToString("N2",tr)+" · KDV "+(genel-net).ToString("N2",tr)+")":"");
 }
}
