using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>Bir stoğun alış/satış fiyatları, KDV oranı ve fiyatların KDV dahil mi hariç mi girildiği.</summary>
public sealed record StokFiyatSatiri(int Id,string Kod,string Ad,string Birim,string Tip,bool Uretilen,decimal? Alis,bool AlisKdvDahil,decimal? Bayi,decimal? Perakende,bool SatisKdvDahil,decimal KdvOrani,string ParaBirimi,decimal? SonAlis,DateTime? SonAlisTarihi)
{
 public decimal? AlisKdvHaric=>Alis is { } a?StokFiyatKdvServisi.KdvHaric(a,AlisKdvDahil,KdvOrani):null;
 public decimal? PerakendeKdvDahil=>Perakende is { } p?StokFiyatKdvServisi.KdvDahil(p,SatisKdvDahil,KdvOrani):null;
 /// <summary>KDV hariç satış ile KDV hariç alış arasındaki brüt kâr oranı (%).</summary>
 public decimal? KarOrani=>Perakende is { } p&&Alis is { } a&&a>0?decimal.Round((StokFiyatKdvServisi.KdvHaric(p,SatisKdvDahil,KdvOrani)/StokFiyatKdvServisi.KdvHaric(a,AlisKdvDahil,KdvOrani)-1)*100,1):null;
}
public sealed record StokFiyatGirdisi(int Id,decimal? Alis,bool AlisKdvDahil,decimal? Bayi,decimal? Perakende,bool SatisKdvDahil,decimal KdvOrani,string ParaBirimi);

internal static class StokKdvSemasi
{
 internal const string Ddl="""
IF OBJECT_ID('dbo.MPXNext_StokKdv','U') IS NULL CREATE TABLE dbo.MPXNext_StokKdv(StokKartId int NOT NULL CONSTRAINT PK_MPXNext_StokKdv PRIMARY KEY REFERENCES dbo.StokKartlari(Id),KdvOrani decimal(5,2) NOT NULL CONSTRAINT CK_MPXNext_StokKdv_Oran CHECK(KdvOrani>=0 AND KdvOrani<=100),AlisKdvDahil bit NOT NULL DEFAULT 0,SatisKdvDahil bit NOT NULL DEFAULT 1,Guncelleyen int NOT NULL,Guncelleme datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
""";
 static readonly System.Collections.Concurrent.ConcurrentDictionary<string,bool> hazir=new(StringComparer.OrdinalIgnoreCase);
 internal static void Hazirla(SqlConnection c){
  string anahtar=c.DataSource+"|"+c.Database;if(hazir.ContainsKey(anahtar))return;
  using(var check=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.MPXNext_StokKdv','U') IS NULL OR OBJECT_ID('dbo.StokFiyatlari','U') IS NULL THEN 0 ELSE 1 END",c))if(Convert.ToInt32(check.ExecuteScalar())==1){hazir[anahtar]=true;return;}
  using var tx=c.BeginTransaction(IsolationLevel.Serializable);
  try{
   using(var gate=ErpModulServisi.Komut(c,tx,"DECLARE @r int;EXEC @r=sys.sp_getapplock @Resource='MiaPaxNextSchema',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;IF @r<0 THROW 51000,'Stok KDV kurulumu kilidi alinamadi',1"))gate.ExecuteNonQuery();
   using(var q=ErpModulServisi.Komut(c,tx,"IF OBJECT_ID('dbo.StokFiyatlari','U') IS NULL CREATE TABLE dbo.StokFiyatlari(StokKartId int NOT NULL PRIMARY KEY REFERENCES dbo.StokKartlari(Id),AlisMaliyeti decimal(18,4) NULL,BayiSatisFiyati decimal(18,4) NULL,PerakendeSatisFiyati decimal(18,4) NULL,ParaBirimi char(3) NOT NULL DEFAULT 'TRY',GuncellemeUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME());"+Ddl))q.ExecuteNonQuery();
   tx.Commit();hazir[anahtar]=true;
  }catch{tx.Rollback();throw;}
 }
}

/// <summary>
/// Mevcut ve üretilen stoklar için birim fiyat ve KDV yönetimi. Fiyatlar <c>StokFiyatlari</c> tablosunda kalır
/// (diğer modüller aynı alanları okumaya devam eder); KDV oranı ve dahil/hariç bilgisi <c>MPXNext_StokKdv</c> içindedir.
/// Diğer modüller <see cref="Fiyat"/>, <see cref="KdvHaric"/> ve <see cref="KdvDahil"/> ile aynı kuralı kullanır.
/// </summary>
public sealed class StokFiyatKdvServisi(string connection,int user)
{
 public static readonly decimal[] KdvOranlari=[0m,1m,10m,20m];
 public const decimal VarsayilanKdv=20m;
 readonly ErpModulServisi access=new(connection,user);
 readonly Action<SqlConnection,SqlTransaction?,string>? fixtureCheck;
 internal StokFiyatKdvServisi(string connection,int user,Action<SqlConnection,SqlTransaction?,string> check):this(connection,user){fixtureCheck=check;}
 void Yetki(SqlConnection c,SqlTransaction? t,string code){if(fixtureCheck is not null)fixtureCheck(c,t,code);else access.Yetki(c,t,code);}
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps)=>ErpModulServisi.Komut(c,t,sql,ps);
 SqlConnection Ac(){var c=access.Ac();try{StokKdvSemasi.Hazirla(c);StokBilesenSemasi.Hazirla(c);if(fixtureCheck is null)EkYetkiSemasi.Hazirla(c);return c;}catch{c.Dispose();throw;}}

 /// <summary>KDV dahil girilmiş fiyatı KDV hariç tutara çevirir (hariçse olduğu gibi döner).</summary>
 public static decimal KdvHaric(decimal fiyat,bool dahil,decimal oran)=>dahil?decimal.Round(fiyat/(1+oran/100m),4):fiyat;
 /// <summary>KDV hariç girilmiş fiyatı KDV dahil tutara çevirir (dahilse olduğu gibi döner).</summary>
 public static decimal KdvDahil(decimal fiyat,bool dahil,decimal oran)=>dahil?fiyat:decimal.Round(fiyat*(1+oran/100m),4);

 const string Secim="""
SELECT TOP(@n) s.Id,s.StokKodu,s.StokAdi,s.Birim,s.StokTipi,
 CAST(CASE WHEN EXISTS(SELECT 1 FROM dbo.UretimReceteleri r WHERE r.MamulStokId=s.Id) OR EXISTS(SELECT 1 FROM dbo.UretimEmirleri e WHERE e.MamulStokId=s.Id) OR EXISTS(SELECT 1 FROM dbo.MPXNext_StokBilesen b WHERE b.Ana=s.Id) THEN 1 ELSE 0 END AS bit) AS Uretilen,
 f.AlisMaliyeti AS Alis,CAST(ISNULL(k.AlisKdvDahil,0) AS bit) AS AlisKdvDahil,f.BayiSatisFiyati AS Bayi,f.PerakendeSatisFiyati AS Perakende,CAST(ISNULL(k.SatisKdvDahil,1) AS bit) AS SatisKdvDahil,CAST(ISNULL(k.KdvOrani,@v) AS decimal(5,2)) AS KdvOrani,CAST(ISNULL(f.ParaBirimi,'TRY') AS varchar(3)) AS ParaBirimi,
 a.BirimFiyat AS SonAlis,a.AlimTarihi AS SonAlisTarihi
FROM dbo.StokKartlari s
LEFT JOIN dbo.StokFiyatlari f ON f.StokKartId=s.Id
LEFT JOIN dbo.MPXNext_StokKdv k ON k.StokKartId=s.Id
OUTER APPLY(SELECT TOP(1) x.BirimFiyat,x.AlimTarihi FROM dbo.StokAlimKayitlari x WHERE x.StokKartId=s.Id AND (x.Aciklama IS NULL OR x.Aciklama NOT LIKE N'\[İPTAL\]%' ESCAPE '\') ORDER BY x.AlimTarihi DESC,x.Id DESC) a
""";
 static StokFiyatSatiri Satir(SqlDataReader r)=>new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetBoolean(5),
  r.IsDBNull(6)?null:r.GetDecimal(6),r.GetBoolean(7),r.IsDBNull(8)?null:r.GetDecimal(8),r.IsDBNull(9)?null:r.GetDecimal(9),r.GetBoolean(10),r.GetDecimal(11),r.GetString(12).Trim(),
  r.IsDBNull(13)?null:r.GetDecimal(13),r.IsDBNull(14)?null:r.GetDateTime(14));

 public StokFiyatSatiri[] Liste(string arama,bool sadeceUretilen){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<StokFiyatSatiri[]>(connection,"StokFiyatKdvServisi.Liste","",[arama,sadeceUretilen]);
  arama=(arama??"").Trim();if(arama.Length>100)throw new ArgumentException("Arama en fazla 100 karakter olmalı.");
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");Yetki(c,null,"STOCK.PRICE");
  string like="%"+arama.Replace("\\","\\\\").Replace("%","\\%").Replace("_","\\_").Replace("[","\\[")+"%";
  using var q=Q(c,null,"SELECT * FROM("+Secim+" WHERE s.Aktif=1 AND (@t=N'' OR s.StokKodu LIKE @l ESCAPE '\\' OR s.StokAdi LIKE @l ESCAPE '\\')) x WHERE (@u=0 OR x.Uretilen=1) ORDER BY x.StokKodu",
   ("@n",2000),("@v",VarsayilanKdv),("@t",arama),("@l",like),("@u",sadeceUretilen));
  using var r=q.ExecuteReader();var rows=new List<StokFiyatSatiri>();while(r.Read())rows.Add(Satir(r));return rows.ToArray();
 }

 /// <summary>Tek stoğun fiyat ve KDV bilgisi (satış, teklif, kroki, fatura gibi diğer modüller için).</summary>
 public StokFiyatSatiri? Fiyat(int stok){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<StokFiyatSatiri?>(connection,"StokFiyatKdvServisi.Fiyat","",[stok]);
  using var c=Ac();Yetki(c,null,"STOCK.VIEW");Yetki(c,null,"STOCK.PRICE");
  using var q=Q(c,null,Secim+" WHERE s.Id=@id",("@n",1),("@v",VarsayilanKdv),("@id",stok));using var r=q.ExecuteReader();return r.Read()?Satir(r):null;
 }

 /// <summary>Fiyat ve KDV satırlarını tek işlemde kaydeder; satırlardan biri hatalıysa hiçbiri yazılmaz.</summary>
 public int Kaydet(StokFiyatGirdisi[] satirlar){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<int>(connection,"StokFiyatKdvServisi.Kaydet","",[satirlar]);
  if(satirlar is null||satirlar.Length is 0 or >2000)throw new ArgumentException("Kaydedilecek 1–2000 satır gönderin.");
  foreach(var s in satirlar){
   foreach(var (v,ad) in new[]{(s.Alis,"Alış"),(s.Bayi,"Bayi"),(s.Perakende,"Satış")})if(v is { } x&&(x<0||x>99_999_999_999m||decimal.Round(x,4)!=x))throw new ArgumentException(ad+" fiyatı 0 veya pozitif, en fazla 4 ondalıklı olmalı (stok #"+s.Id+").");
   if(s.KdvOrani<0||s.KdvOrani>100||decimal.Round(s.KdvOrani,2)!=s.KdvOrani)throw new ArgumentException("KDV oranı 0–100 arasında olmalı (stok #"+s.Id+").");
   if(s.ParaBirimi is not ("TRY" or "USD" or "EUR" or "GBP"))throw new ArgumentException("Para birimi TRY, USD, EUR veya GBP olmalı.");
  }
  if(satirlar.Select(x=>x.Id).Distinct().Count()!=satirlar.Length)throw new ArgumentException("Aynı stok birden fazla kez gönderildi.");
  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);
  try{
   Yetki(c,t,"STOCK.VIEW");Yetki(c,t,"STOCK.PRICE");
   foreach(var s in satirlar){
    using(var e=Q(c,t,"SELECT COUNT(*) FROM dbo.StokKartlari WITH(HOLDLOCK) WHERE Id=@i",("@i",s.Id)))if(Convert.ToInt32(e.ExecuteScalar())!=1)throw new ArgumentException("Stok bulunamadı: #"+s.Id);
    using(var f=Q(c,t,"UPDATE dbo.StokFiyatlari WITH(UPDLOCK,HOLDLOCK) SET AlisMaliyeti=@a,BayiSatisFiyati=@b,PerakendeSatisFiyati=@p,ParaBirimi=@pb,GuncellemeUtc=SYSUTCDATETIME() WHERE StokKartId=@i;IF @@ROWCOUNT=0 INSERT dbo.StokFiyatlari(StokKartId,AlisMaliyeti,BayiSatisFiyati,PerakendeSatisFiyati,ParaBirimi) VALUES(@i,@a,@b,@p,@pb)",
     ("@i",s.Id),("@a",s.Alis),("@b",s.Bayi),("@p",s.Perakende),("@pb",s.ParaBirimi)))f.ExecuteNonQuery();
    using(var k=Q(c,t,"UPDATE dbo.MPXNext_StokKdv WITH(UPDLOCK,HOLDLOCK) SET KdvOrani=@k,AlisKdvDahil=@ad,SatisKdvDahil=@sd,Guncelleyen=@u,Guncelleme=SYSUTCDATETIME() WHERE StokKartId=@i;IF @@ROWCOUNT=0 INSERT dbo.MPXNext_StokKdv(StokKartId,KdvOrani,AlisKdvDahil,SatisKdvDahil,Guncelleyen) VALUES(@i,@k,@ad,@sd,@u)",
     ("@i",s.Id),("@k",s.KdvOrani),("@ad",s.AlisKdvDahil),("@sd",s.SatisKdvDahil),("@u",user)))k.ExecuteNonQuery();
   }
   t.Commit();return satirlar.Length;
  }catch{t.Rollback();throw;}
 }
}
