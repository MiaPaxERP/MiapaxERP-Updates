using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Interop;
using Microsoft.Web.WebView2.Core;
namespace MiapaxERP.Desktop;

/// <summary>
/// PDF'ten metin çıkarır. Programla gelen PDF.js, görünmez bir WebView2 denetleyicisinde çalışır (ağ erişimi yok, dosya sistemi yalnız
/// Assets/KrokiWeb). Taranmış (resim) PDF'lerde metin bulunmaz; çağıran bunu boş metin olarak görür.
/// </summary>
public static class PdfMetinOkuyucu
{
 public static async Task<string> MetinAsync(Window sahip,byte[] pdf,CancellationToken ct=default){
  if(pdf.Length<5||pdf.Length>20*1024*1024)throw new ArgumentException("PDF boyutu geçersiz.");
  var hwnd=new WindowInteropHelper(sahip).EnsureHandle();
  string profil=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","PdfMetin");
  var env=await CoreWebView2Environment.CreateAsync(null,profil);
  var controller=await env.CreateCoreWebView2ControllerAsync(hwnd);
  try{
   controller.IsVisible=false;var web=controller.CoreWebView2;
   web.Settings.AreDevToolsEnabled=false;web.Settings.IsScriptEnabled=true;web.Settings.AreDefaultContextMenusEnabled=false;
   web.SetVirtualHostNameToFolderMapping("kroki.boruerp.local",Path.Combine(AppContext.BaseDirectory,"Assets","KrokiWeb"),CoreWebView2HostResourceAccessKind.DenyCors);
   web.NavigationStarting+=(_,e)=>{if(!e.Uri.StartsWith("https://kroki.boruerp.local/",StringComparison.OrdinalIgnoreCase))e.Cancel=true;};
   web.NewWindowRequested+=(_,e)=>e.Handled=true;
   var ready=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
   var result=new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
   string id=Guid.NewGuid().ToString("N");
   web.WebMessageReceived+=(_,e)=>{
    try{
     using var doc=JsonDocument.Parse(e.WebMessageAsJson);var root=doc.RootElement;string action=root.GetProperty("action").GetString()??"";
     if(action=="pdfTextReady")ready.TrySetResult();
     else if(action=="pdfTextResult"&&root.TryGetProperty("id",out var rid)&&rid.GetString()==id){
      if(root.TryGetProperty("error",out var err)&&err.GetString() is {Length:>0} msg)result.TrySetException(new InvalidDataException("PDF okunamadı: "+msg));
      else result.TrySetResult(root.TryGetProperty("text",out var tx)?tx.GetString()??"":"");
     }
    }catch(Exception ex){result.TrySetException(ex);}
   };
   web.Navigate("https://kroki.boruerp.local/pdf-metin.html");
   using var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct);timeout.CancelAfter(TimeSpan.FromSeconds(45));
   using(timeout.Token.Register(()=>{ready.TrySetCanceled();result.TrySetCanceled();})){
    await ready.Task;
    web.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="pdfText",id,data=Convert.ToBase64String(pdf)}));
    return await result.Task;
   }
  }finally{controller.Close();}
 }
}
