using System.Text;
using System.Text.Json;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class MobilDisIpTestleri
{
    [Fact]public void DisIpYalnizInternetAdresiniKabulEder()
    {
        Assert.True(MobilYerelSunucu.DisIp("85.105.10.20"));
        foreach(var ip in new[]{"192.168.1.5","10.0.0.1","172.16.0.1","127.0.0.1","100.64.1.1","169.254.1.1","224.0.0.1","abc",""})Assert.False(MobilYerelSunucu.DisIp(ip));
        Assert.True(MobilYerelSunucu.DisPortGecerli(5189));Assert.False(MobilYerelSunucu.DisPortGecerli(3389));Assert.False(MobilYerelSunucu.DisPortGecerli(80));
    }
    [Fact]public void PaketDisIpVarkenIkiAdresTasir()
    {
        string pin=new('A',64),code=new('b',64);
        var yerel=MobilYerelSunucu.Paket(new MobilYerelTanim("https://192.168.1.5:5189",pin,DateTime.UtcNow.AddDays(30)),code);
        var dis=MobilYerelSunucu.Paket(new MobilYerelTanim("https://192.168.1.5:5189",pin,DateTime.UtcNow.AddDays(30),"https://85.105.10.20:5189"),code);
        static JsonElement Coz(string k){var b=k["BERP-LAN1:".Length..].Replace('-','+').Replace('_','/');b+=new string('=',(4-b.Length%4)%4);return JsonDocument.Parse(Encoding.UTF8.GetString(Convert.FromBase64String(b))).RootElement;}
        Assert.Equal(1,Coz(yerel).GetProperty("v").GetInt32());
        var j=Coz(dis);Assert.Equal(2,j.GetProperty("v").GetInt32());Assert.Equal("https://85.105.10.20:5189",j.GetProperty("alt").GetString());Assert.Equal("https://192.168.1.5:5189",j.GetProperty("address").GetString());
        Assert.Throws<ArgumentException>(()=>MobilYerelSunucu.Paket(new MobilYerelTanim("https://192.168.1.5:5189",pin,DateTime.UtcNow,"https://192.168.1.9:5189"),code));
    }
}
