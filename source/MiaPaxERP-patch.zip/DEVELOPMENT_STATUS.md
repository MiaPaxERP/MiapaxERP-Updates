# MiaPaxERP — geliştirme kaydı, 13 Kasım 2026

## 2.8.7 yayın hazırlığı — stok ve paket etiketleri

Stok kartındaki Barkodlar ekranından kayıtlı ürün barkodu/çarpanı ile etiket yazdırılır. Üretim emrindeki Paket barkod etiketi düğmesi kayıtlı paketleme partisini, paket içi adedi, özellikleri ve üretim emrini getirir. Ölçü mm olarak 100x100 gibi girilir; içerik ölçüye otomatik sığar. Kâğıt ölçüsü Windows yazıcı sürücüsüne gönderilir; sürücü ölçüyü değiştirirse veya yazdırılabilir kenar alanı uygun değilse işlem durur. Barkod fiziksel olarak fazla küçülüyorsa daha büyük etiket istenir; sessiz ölçekleme yapılmaz.

Paket kimliği MPXPK + paketleme kayıt kimliği + sıra numarasıdır; tekrar yazdırmada değişmez. Hızlı satış paketin kayıtlı iç adedini getirir; iptal üretim ve paket sıra sınırı dışı barkodlar reddedilir. Bu özellik fiziksel paketin bir kez satıldığını izleyen ayrı seri numarası satış defteri değildir. Yazdırmak stok veya üretim miktarını değiştirmez. STOCK.VIEW veya PRODUCTION.VIEW sunucu yetkisi zorunludur; yan bilgisayar veri için HTTPS, yazdırmak için kendi Windows yazıcısını kullanır.

Son yerel doğrulama: 62/62 ERP entegrasyon testi, 0 atlanan; tam Release derlemesi 0 uyarı/0 hata. 100x100 etiketler 203 DPI'da çizildi ve gerçek Code128 çözücüyle tekrar okundu. İzole SQL üzerinde paket içi miktar, sıra sınırı, iptal üretim ve yetkisiz okuma kontrol edildi. Fiziksel termal yazıcı bu çalışma ortamında denenmedi.

Android 2.8.7 yerelde derlendi; mevcut Android yayıncı sertifikasıyla v2/v3 imzası doğrulandı. Yeni anahtar oluşturulmadı. GitHub akışı imzalı APK'nin sertifikasını ve taze derlemenin DEX içeriğini ayrıca doğrular. Ana/Yan otomatik güncelleme bildirimi yalnız yayın dosyaları doğrulandıktan sonra mevcut Windows yayıncı anahtarıyla imzalanır. Aşağıdaki yayımlanmamış notları bu sürümün kapsamını açıklar; canlı lisans paneli kurulumu ayrıca gerekir.

## 16 Kasım 2026 — toplu güncelleme için yerel, yayımlanmamış çalışma

Bu bölüm aşağıdaki eski yayın notlarından daha yenidir. Kurulu 2.8.6, canlı müşteri veritabanı, çalışan HTTPS hizmeti, yerel lisans paneli ve internet lisans paneli değiştirilmedi. GitHub yayını ve otomatik güncelleme bildirimi oluşturulmadı.

- Her iki lisans panelinin görünür markası MiaPaxERP olarak düzenlendi. Cihaz donanımı her kalp atışında güncellenir; ERP bildirimi 1 dakika, açık destek penceresinin yenilenmesi 15 saniyedir. Yeni hata tekrarları çözülmüş kaydı yeniden açar. Eski istemcilerin alanları doldurması için istemci güncellemesi de gerekir.
- Modül bazında bitiş tarihleri lisans imzasına dahildir. Tarihler ana lisansın süresiyle ve modül bağımlılıklarıyla denetlenir. Son 7 günde Admin'in kişisel bildirim kutusuna tekilleştirilmiş uyarı düşer; süresi dolan modül kapanır. Eski lisanslar tarih alanı olmadan çalışır.
- Ana sayfada boru/sulama, Türkiye ve dünya RSS başlıkları dönüşümlü gösterilir. Haberler 60 saniyede yenilenir. İlk yüklemedeki eski başlıklar uyarılmaz; yeni ve yakın tarihli son dakika başlığı kullanıcı başına bir kere üst bantta görünür.
- Yerel ağda HTTPS ana sunucu keşfi eklenmiştir. Yan bilgisayar SQL'e doğrudan bağlanmaz. Keşif sonrası gerçek TLS kontrolü yapılır; yeni adres normal bağlantı düğmesiyle kabul edilir. Farklı kayıtlı sunucu sessizce değiştirilmez. Alan adı, güvenilir sertifika ve modem yönlendirmesi ana sunucuda bir defa kurulmalıdır; ISP dış IP hizmeti program tarafından değiştirilemez.
- Stok kartında birden fazla barkod ve miktar çarpanı bulunur. Hızlı satış mevcut atomik satış/stok/cari/muhasebe/tahsilat servisini kullanır; bağlantı tekrarında aynı işlem ikinci kez stoktan düşmez. TRY dışındaki satışlar mevcut ticari satış ekranındadır.
- Seçilen üretim emri ve paketleme kayıtları PDF olarak alınır. Ayrıntılı maliyet tablosu gerçek hammadde partisi, makine süresi, işçilik, elektrik, fire ve bağlı sevkiyat dayanaklarını gösterir. Eksik maliyet sıfır sayılmaz; kullanıcı navlun/genel gider paylarını belgeye dayalı düzenler. Düzenlemeler sürüm ve revizyon kaydıyla tutulur; analiz otomatik muhasebe fişi oluşturmaz. MRP mevcut reçete ve net ihtiyaç hesabını kullanır; genel çok seviyeli BOM planlayıcısı değildir.
- Günlük maliyet raporu aktif Admin ve yetkili muhasebe alıcılarına tekilleştirilerek gönderilir. Ana hizmet çalışırken veya yetkili ERP oturumu açıkken günlük görev yürür. Hizmet kapalıyken işletim sistemi zamanlayıcısı gibi çalıştığı iddiası yoktur.
- Departman/kişi bazında duyuru ve mesajlaşma eklendi. Alıcı ve departman üyeliği sunucuda denetlenir. HTTPS uzun bekleme bağlantısı yeni mesajı bildirir; pencere 2 saniyelik yedek yenileme kullanır. Oturum kapanınca özel pencereler kapatılır.

### Kurulum sırası ve yetkiler

1. Her iki lisans panelinde 0005_module_dates.sql geçişi uygulanmalı; güncel panel kaynakları kurulmalıdır. Eski kriptografik türetme sabitleri ve veri dizini adları uyumluluk için korunmuştur.
2. ERP ana sunucu ve yan bilgisayarlar aynı derlemeden güncellenmelidir. İlk Admin oturumunda ModullerNext.sql kontrollü ve işlem içinde uygulanır; USERS.MANAGE gerekir. Yeni izinler mevcut kullanıcılara kendiliğinden genişletilmez.
3. Kullanıcı ve Yetkiler'den QUICKSALE.VIEW + SALES.VIEW, COST.VIEW/EDIT/PUBLISH, CHAT.VIEW/SEND ve NOTIFICATION.PUBLISH uygun kişilere atanmalıdır. Maliyet bildirimlerinin muhasebe alıcısında COST.VIEW + ACCOUNTING.VIEW gerekir. Departman üyeleri Admin tarafından tanımlanır.
4. Yapay zekâ ekranı mevcut Ollama/MiaPax bağlantısını kullanır. Bu çalışmada model kurulmadı ve canlı model yanıtı test edilmedi. Otomatik aritmetik, net ihtiyaç hesabı, ağ keşfi ve yetki denetimi model olmadan çalışır. Müşteri verisi analize gönderilmeden kullanıcı onayı gerekir.

### Son doğrulama

- Tam Release çözüm derlemesi: 0 hata; NuGet güvenlik denetim adresine erişim nedeniyle 2 NU1900 uyarısı.
- ERP HTTPS entegrasyonu: 52 geçti, 0 başarısız, 0 atlanan. İzole SQL işlemleri, gerçek HTTP oturumu/uzun bekleme, 3 ardışık UDP keşfi, barkod, hızlı satış tekrar koruması, maliyet eksikleri ve revizyon, bildirim alıcı yetkileri dahildir.
- Yerel Node lisans paneli: 41 geçti. Web lisans paneli: 42 temel kontrol + destek/donanım/modül süresi + posta şifreleme kontrolü geçti; yerel Worker derlemesi ve artefakt doğrulaması geçti. Gerçek e-posta gönderilmedi.
- Tarayıcıda TEST müşteri cihaz/sorun penceresinin otomatik yenilenmesi gözlendi. ERP'nin kendi WPF bileşenleri sentetik verilerle çizdirildi; gerçek PDF yazıcısıyla üretim/paketleme PDF'leri oluşturulup görsel kontrol edildi. Kullanıcının açık uygulamalarında tam tıklama testi yapılamadı; gerçek müşteri verisiyle kabul testi yerine geçtiği iddiası yoktur.
- Çıktılar çalışma alanının outputs/next-native ve outputs/next-tests klasörlerindedir. Güncel kaynak arşivi ve durum kaydı ayrı saklanır; arşiv kurulum paketi değildir.

2.8.3 kaynak ve Windows x64 paket yayını. Ana dal yayını aynı SQL/TLS doğrulamasını tekrar çalıştırır ve başarılı olursa GitHub Releases paketini oluşturur. Otomatik güncelleme için masaüstü dosyaları ZIP kökünde paketlenir. Ana/Yan bildirimleri paket yüklemesinden sonra mevcut yayıncı anahtarıyla imzalanır. Uzak masaüstü kullanılmaz.

## Bu kopyadaki değişiklikler

- HTTPS oturumu, sunucuda kimlik/yetki denetimi ve imzaları açıkça tanımlanmış işlem kataloğu. Uzak masaüstü kullanılmaz.
- Eski stok, üretim, cari, finans, laboratuvar ve yardımcı ekran işlemlerinin sunucu servislerine taşınması; sabit sorgu kimlikleriyle salt okuma köprüsü.
- Satışın stok, cari, muhasebe ve girilmiş tahsilatla aynı işlemde kaydedilmesi; dövizli satış/tahsilat kur farkı.
- Sipariş–mal kabul–alış faturası miktar, fiyat ve KDV eşleştirme işlemleri.
- Depo/raf, parti, rezervasyon, transfer, sayım, üretimde hammadde–mamul parti bağlantıları.
- Dengeli muhasebe fişi, yevmiye, mizan ve aylık dönem kilidi. Kesin fiş değiştirilmez; ters fiş kullanılır. Resmî e-defter onayı iddiası yoktur.
- Sevkiyat/kantar ve boru basınç testi ekranları; fotoğraf/video arşivi, ayrı teknik inceleme, PDF raporu.
- Menü arama ve konum işareti; laboratuvar/kalibrasyon PDF arşivi.
- Makine kapasitesi, reçete/hedef KG üzerinden malzeme ihtiyaç hesabı ve fiilî maliyet kayıtları.
- Hızlı Bilişim, web sitesi, mağaza ve mobil hesap yönetimi için HTTPS sunucu adaptörleri. Sağlayıcı sonuçlarını istemcinin yazabildiği uçlar yayımlanmaz.

## Doğrulama ve kurulum sınırları

- GitHub Windows koşusu 43377312600: 20/20 test geçti, atlanan test yok; tam çözüm 0 uyarı / 0 hata.
- Gerçek TLS oturumu, güvenilmeyen sertifikanın ve yanlış alan adının reddi doğrulandı. Gerçek şifreli SQL bağlantısı geçti.
- İzole veritabanında satış/stok/cari/tahsilat, kısmi döviz ödeme yuvarlaması, geri alma, depo/rezervasyon/sayım değerlemesi, sipariş–kabul–fatura, parti izi, kapasite, fiilî maliyet, dönem kilidi ve bağımsız basınç onayı doğrulandı.
- 163 sabit okuma sorgusu ve kayıtlı HTTPS servis yolları denetlenir. Bu, bütün ekranların müşterinin verisiyle elle denenmiş olduğu iddiası değildir.
- Son mobil yan cihaz koruması, basınç tekrar kaydı ve paketleme de yayın öncesi aynı CI'da tekrar doğrulanır.
- İlk şifre/kurtarma, Excel ve yönetici sıfırlama sunucu akışları kodda mevcuttur; müşterinin gerçek hesap/verileriyle kabul denemesi gerekir.
- MRP boru üretiminin yüzdeli reçete/hedef KG yapısına dayanır; genel çok seviyeli BOM planlayıcısı değildir.
- Hızlı Bilişim hesabı/GİB gerçek gönderimi, mağaza sağlayıcıları ve müşterinin alan adı/modem bağlantısı bu testlerde kullanılmadı. Gerçek anahtarlar müşteri ana sunucusunda girilmelidir.
- Yeni Android APK imzalanmadı. Mevcut imzalı APK HTTPS adresi ve kişisel eşleme koduyla kullanılır; yeni bağlantı kodu desteği kaynakta bulunur.
- Canlı D: kurulumu ve müşteri veritabanı bu kaynak yayını tarafından değiştirilmedi.
- Basınç testi reddedilen parti güvenlik gereği serbest bırakılamaz. Yeniden işleme/teknik uygunsuzluk süreci işletilmeden geçmiş ret yok sayılmaz.

## Elle kurulum

Önce SQL veritabanını ve mevcut kurulum klasörünü yedekleyin. Windows x64 paketini ayrı klasöre açın. Ana bilgisayarda Kolay-Kurulum.cmd ile HTTPS sunucusunu yapılandırın; alan adı ve modem 443 yönlendirmesi ana sunucuya ait olmalıdır. Yan bilgisayarda Masaustu/MiapaxERP.Desktop.exe içindeki bağlantı ekranında HTTPS ana sunucu adresini seçin. SQL portunu internete açmayın. Mevcut lisans ve kullanıcı yetkileri geçerlidir. Yeni modüllerin kurulum işlemi MODULES.INSTALL yetkisi ister. Ana sunucu ve yan cihazların sürümü aynı olmalıdır.

## Derleme ve test

Windows ve .NET 10 SDK ile `MiapaxERP.slnx` çözümünü açın. Yeni test projesi `MiapaxERP.Tests.HTTPS.Integration` klasöründedir. Gerçek bağlantı testlerini çalıştırmadan önce ortamı hazırlayın; geliştirme kaydını üretim kurulumu olarak kullanmayın.

Sunucu anahtarları, şifreli hesap dosyaları, veritabanı dosyaları ve derleme çıktıları kaynak yayınına dahil edilmez.
Boyutu büyük tanıtım videoları, GeoJSON harita verileri ve places.json veri dosyaları bu hızlı kaynak yayınına eklenmedi; mevcut kurulumdaki bu varlıklar kaynak yayınından bağımsızdır.

## 2.8.3 arayüz ve güncelleme düzeltmeleri

Yeni sekiz modül ana ekran içinde açılır; mevcut menü stilini ve seçili temayı kullanır. Depo raf ağacı, muhasebe dönem/mizanı, satın alma satır eşleştirmesi, basınç ölçümleri, sevkiyat rotası, dövizli tahsilat özeti, makine planları ve MRP/maliyet ayrı çalışma alanlarıdır.
Girişteki MiaPaxERP logosu korunur. Stok–üretim–sevkiyat–finans akışını gösteren sessiz çizim animasyonu eklenir; pencere gizlendiğinde durur ve Windows hareket azaltma ayarına uyar.
Bilinen eski BoruERP güncelleme adresi mevcut MiaPaxERP kanalına taşınır; özel sunucu adresleri korunur. Yeni sürüm dosya sürümü 2.8.3.0'dır. Güncelleme paketi mevcut RSA-PSS anahtarıyla doğrulanır; anahtar değiştirilmez.

## 2.8.4 müşteri destek bilgileri
Cihaz sayısı, ana/yan PC Windows, işlemci, RAM ve sabit disk bilgileri ile sınıflandırılmış hata kayıtları lisans sunucusuna bildirilir. Parola, lisans anahtarı, SQL metni ve müşteri belge içeriği hata kayıtlarına eklenmez. Eski istemcilerden henüz bilgi gelmeyen alanlar boş gösterilir. Yan PC bildirimleri yetkili HTTPS oturumuyla ana sunucu üzerinden iletilir. İlgili lisans sunucusu da destek güncellemesini almalıdır.

## 2.8.5 kroki ve güncelleme
Parsel PDF sayfaları yerel PDF.js ile zemin olarak açılır; iki noktadan ölçeklenir. PDF koordinat veya kadastro sınırı olarak otomatik yorumlanmaz; sınır çizimi ve harita referansı kullanıcı tarafından doğrulanır. Sulama hatları ve başlıklar seçilen yön/aralıkta hizalanır; sınır dışına taşacak parçalar korunur. Kaynak noktası ve debi/basınç alanları mevcut akışla kullanılır. Google uydu ve 3D arazi için kullanıcının Google Cloud Maps anahtarı, faturalandırma ve koordinat referansı gerekir. Anahtar girilmediği için Google canlı harita kabul testi yapılmadı.
Ana/Yan güncelleme ZIP dosyaları ayrıdır; eski güncelleyicinin reddettiği Lisans.Core.pdb ve kullanıcı ayar dosyaları paketlere alınmaz. Son kullanıcıda açık olan Debug kopyası otomatik güncellenmez; Release kurulumu kullanılmalıdır. Mobil ZIP içindeki APK imzasızdır; mevcut Android anahtarıyla normal Windows oturumunda Imzala.ps1 çalıştırılmadan müşteriye dağıtılamaz. Ana HTTPS Windows hizmeti ayrı tam Ana-Kurulum paketinden güncellenir; masaüstü otomatik güncelleme çalışan hizmet dosyalarını değiştirmez.

## 2.8.6 anahtarsız harita saha sayaçları ve menü yetkileri
Kroki anahtarsız OpenStreetMap internet haritasını varsayılan açar; sulama hatları aynı koordinat dönüşümüyle haritada gösterilir. Saha Türkiye haritasında her il için kayıtlı kişi kartı sayısı görünür; tekrar görüşmeler sayıyı artırmaz. İl seçimi solda görüşme notu olmayan kartlar dahil tüm kayıtları sayfalı ve kaydırarak gösterir; mevcut mobil sahiplik kapsamı korunur. Menü modülleri oturum kullanıcısının etkin izinleri ve lisansı birlikte değerlendirilerek gizlenir; tema ve lisans yenilemesi görünürlüğü geri açmaz. Kullanıcı yönetiminde KROKI.VIEW ayrı atanabilir. Üretim stok tüketimi emrin ilk kaydında değil üretim tamamlanıp stok işleme aşamasında gerçekleşen miktar ve fire üzerinden yapılır; bu zamanlama değiştirilmedi.
