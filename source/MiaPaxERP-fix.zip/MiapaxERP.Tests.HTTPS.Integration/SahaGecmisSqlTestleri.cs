using System.Text.Json;
using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;

/// <summary>Saha müşterisi: güncelleme değişiklik geçmişine tarihle yazılır, il listesi ve rapora girer; müşteri silinebilir.</summary>
public class SahaGecmisSqlTestleri
{
 static void Sql(SqlConnection c,string s){using var q=new SqlCommand(s,c);q.ExecuteNonQuery();}
 [Fact]public void GuncellemeGecmiseYazilirVeMusteriSilinir(){
  string name="MiapaxSahaGecmis_"+Guid.NewGuid().ToString("N");using var master=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=5");master.Open();Sql(master,"CREATE DATABASE ["+name+"]");
  try{string cs=new SqlConnectionStringBuilder(master.ConnectionString){InitialCatalog=name}.ConnectionString;using var c=new SqlConnection(cs);c.Open();Sql(c,"""
   CREATE TABLE dbo.BERP210_SahaMusteri(Id uniqueidentifier PRIMARY KEY,IlId nvarchar(30) NOT NULL,IlceId nvarchar(40) NOT NULL,Koy nvarchar(160) NOT NULL,Ad nvarchar(160) NOT NULL,Telefon nvarchar(30) NOT NULL,Veri nvarchar(max) NOT NULL CHECK(ISJSON(Veri)=1),Olusturan int NOT NULL,Olusturma datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),Guncelleme datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),Surum rowversion);
   CREATE TABLE dbo.BERP210_Gorusme(Id uniqueidentifier PRIMARY KEY,MusteriId uniqueidentifier NOT NULL REFERENCES dbo.BERP210_SahaMusteri(Id),Tarih datetime2 NOT NULL,Sonuc nvarchar(2000) NOT NULL,KullaniciId int NOT NULL,KayitZamani datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
   CREATE TABLE dbo.Kullanicilar(Id int PRIMARY KEY,KullaniciAdi nvarchar(60),AdSoyad nvarchar(120),Aktif bit);INSERT dbo.Kullanicilar VALUES(2,N'ali',N'Ali Saha',1);
   """);
   var s=new SahaServisi(cs,2,(_,_,_)=>{});var id=Guid.NewGuid();
   var m=new SahaMusterisi(id,"38","1",N("Sindelhöyük"),"Ahmet Yılmaz","05551112233",10,"dekar","mısır",null,"m³/saat",null,"Bilinmiyor","Kuyu","");
   string v1=s.Kaydet(m,null,Guid.NewGuid(),DateTimeOffset.UtcNow,"İlk görüşme");
   // Görüşme yazmadan yalnız kartı güncelle: değişiklik tarihle geçmişe girmeli.
   string v2=s.Kaydet(m with{Alan=12,Telefon="05559998877"},v1,Guid.NewGuid(),DateTimeOffset.UtcNow,"");
   var loaded=JsonSerializer.SerializeToElement(s.Oku(id),SahaServisi.Json);var visits=loaded.GetProperty("visits").EnumerateArray().ToArray();
   Assert.Equal(2,visits.Length);
   var change=visits.Single(x=>x.GetProperty("tur").GetString()=="degisiklik");
   Assert.Contains("10 dekar → 12 dekar",change.GetProperty("sonuc").GetString());Assert.Contains("05551112233 → 05559998877",change.GetProperty("sonuc").GetString());
   Assert.Equal("Ali Saha",change.GetProperty("kullaniciAdi").GetString());
   // İl listesi son işlemi güncelleme olarak gösterir.
   var row=Assert.Single(s.IlGorusmeleri("38").Rows);Assert.StartsWith("✎ Kart güncellendi",row.Sonuc);Assert.NotNull(row.SonGorusme);
   // Değişmeyen kayıtla tekrar kaydetmek geçmişe satır eklemez.
   string v3=s.Kaydet(m with{Alan=12,Telefon="05559998877"},v2,Guid.NewGuid(),DateTimeOffset.UtcNow,"");
   Assert.Equal(2,JsonSerializer.SerializeToElement(s.Oku(id),SahaServisi.Json).GetProperty("visits").GetArrayLength());
   // Eski sürümle silme reddedilir; güncel sürümle müşteri, görüşmeler ve geçmiş silinir.
   Assert.Throws<InvalidOperationException>(()=>s.Sil(id,v1));
   s.Sil(id,v3);
   using var q=new SqlCommand("SELECT (SELECT COUNT(*) FROM dbo.BERP210_SahaMusteri)+(SELECT COUNT(*) FROM dbo.BERP210_Gorusme)+(SELECT COUNT(*) FROM dbo.BERP299_SahaGecmis)",c);
   Assert.Equal(0,Convert.ToInt32(q.ExecuteScalar()));
  }finally{if(!System.Text.RegularExpressions.Regex.IsMatch(name,"^MiapaxSahaGecmis_[a-f0-9]{32}$"))throw new InvalidOperationException();Sql(master,"ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]");}
 }
 static string N(string s)=>s;
}
