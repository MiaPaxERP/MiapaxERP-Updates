using System.Data;
using System.IO;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
internal static class IsbirligiSemasi
{
 // Schema is application installation work, not a grant of user permissions.
 // Any authenticated active user may trigger the same fixed, idempotent migration.
 internal static void Hazirla(SqlConnection c){
  using(var check=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.MPXNext_Departman','U') IS NOT NULL AND OBJECT_ID('dbo.MPXNext_DepartmanUye','U') IS NOT NULL AND OBJECT_ID('dbo.MPXNext_Duyuru','U') IS NOT NULL AND OBJECT_ID('dbo.MPXNext_DuyuruAlici','U') IS NOT NULL AND OBJECT_ID('dbo.MPXNext_Mesaj','U') IS NOT NULL AND OBJECT_ID('dbo.MPXNext_Barkod','U') IS NOT NULL AND OBJECT_ID('dbo.MPXNext_Maliyet','U') IS NOT NULL AND OBJECT_ID('dbo.MPXNext_Gunluk','U') IS NOT NULL AND EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu='CHAT.VIEW') AND EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu='DASHBOARD.VIEW') AND EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu='MOBILE.ACCESS') THEN 1 ELSE 0 END",c))if(Convert.ToInt32(check.ExecuteScalar())==1)return;
  using var tx=c.BeginTransaction(IsolationLevel.Serializable);
  try{using(var gate=ErpModulServisi.Komut(c,tx,"DECLARE @r int;EXEC @r=sys.sp_getapplock @Resource='MiaPaxNextSchema',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;IF @r<0 THROW 51000,'Iletisim kurulumu kilidi alinamadi',1"))gate.ExecuteNonQuery();using(var q=ErpModulServisi.Komut(c,tx,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"ModullerNext.sql"))))q.ExecuteNonQuery();tx.Commit();}
  catch{tx.Rollback();throw;}
 }
}
