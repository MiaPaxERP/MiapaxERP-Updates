using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
namespace MiapaxERP.Desktop;

/// <summary>
/// Üst çubukta, bildirimin yanında "💡 Öneriler": program üretim, stok, masraf, muhasebe, finans ve cari kayıtlarını
/// arka planda düzenli inceler; eksik/fazla/yanlış veya iyileştirilebilir konuları hatırlatır. Yapay zekâ bağlantısı
/// tanımlıysa bulguları yorumlatıp kendi fikirlerini de ekler.
/// </summary>
public partial class MainWindow
{
 sealed class AkilliAyar{public HashSet<string> Gizlenen{get;set;}=[];public bool YapayZeka{get;set;}=true;public DateTime SonYapayZeka{get;set;}}
 Button? btnOneriler;Popup? oneriPopup;StackPanel? oneriListesi;TextBlock? oneriDurum;System.Windows.Controls.CheckBox? oneriYz;
 readonly DispatcherTimer oneriSaat=new(){Interval=TimeSpan.FromMinutes(10)};
 List<AkilliOneri> oneriler=[];List<AkilliOneri> yzOnerileri=[];bool oneriMesgul;int oneriKullanici;AkilliAyar oneriAyar=new();HashSet<string> oneriGosterilenKritik=[];
 static readonly TimeSpan YapayZekaAraligi=TimeSpan.FromHours(6);
 string OneriAyarYolu=>Path.Combine(GorunumDeposu.Klasor(baglantiAdresi,aktifKullanici?.KullaniciId??0),"akilli-oneriler.json");

 void AkilliOnerileriBagla(){
  if(BtnBildirimler.Parent is not Panel bar)return;
  btnOneriler=new Button{Content="💡 Öneriler",Padding=new Thickness(8,7,8,7),Margin=new Thickness(0,0,8,0),BorderThickness=new Thickness(0),Background=new SolidColorBrush(Color.FromRgb(0xFE,0xF9,0xC3)),Foreground=new SolidColorBrush(Color.FromRgb(0x85,0x4D,0x0E)),Cursor=System.Windows.Input.Cursors.Hand,FontSize=11,ToolTip="Akıllı denetim: eksik, fazla, yanlış veya iyileştirilebilir konular",Visibility=Visibility.Collapsed};
  bar.Children.Insert(bar.Children.IndexOf(BtnBildirimler)+1,btnOneriler);
  oneriListesi=new StackPanel();oneriDurum=new TextBlock{TextWrapping=TextWrapping.Wrap,FontSize=11,Foreground=Brushes.SlateGray,Margin=new Thickness(0,6,0,0)};
  oneriYz=new System.Windows.Controls.CheckBox{Content="Yapay zekâ da incelesin ve fikir versin",Margin=new Thickness(0,8,0,0),FontSize=11};
  var yenile=new Button{Content="Şimdi incele",Padding=new Thickness(10,5,10,5),Margin=new Thickness(0,0,8,0)};var yz=new Button{Content="Yapay zekâya yorumlat",Padding=new Thickness(10,5,10,5)};
  var buttons=new WrapPanel{Margin=new Thickness(0,8,0,0)};buttons.Children.Add(yenile);buttons.Children.Add(yz);
  var root=new DockPanel();var head=new StackPanel();DockPanel.SetDock(head,Dock.Top);root.Children.Add(head);
  head.Children.Add(new TextBlock{Text="💡 Akıllı öneriler",FontSize=17,FontWeight=FontWeights.Bold});
  head.Children.Add(new TextBlock{Text="Program kayıtlarınızı düzenli inceler ve dikkat isteyen konuları burada hatırlatır. Kayıtlar değiştirilmez.",TextWrapping=TextWrapping.Wrap,FontSize=11,Foreground=Brushes.SlateGray,Margin=new Thickness(0,2,0,8)});
  var foot=new StackPanel();DockPanel.SetDock(foot,Dock.Bottom);root.Children.Add(foot);foot.Children.Add(oneriYz);foot.Children.Add(buttons);foot.Children.Add(oneriDurum);
  root.Children.Add(new ScrollViewer{Content=oneriListesi,VerticalScrollBarVisibility=ScrollBarVisibility.Auto});
  oneriPopup=new Popup{PlacementTarget=btnOneriler,Placement=PlacementMode.Bottom,StaysOpen=false,AllowsTransparency=true,PopupAnimation=PopupAnimation.Fade,
   Child=new Border{Width=440,Height=520,BorderBrush=Brushes.LightGray,BorderThickness=new Thickness(1),Background=Brushes.White,CornerRadius=new CornerRadius(10),Padding=new Thickness(12),Child=root}};
  btnOneriler.Click+=(_,_)=>{OnerileriCiz();oneriPopup.IsOpen=!oneriPopup.IsOpen;};
  yenile.Click+=async(_,_)=>await OnerileriYenile(true);
  yz.Click+=async(_,_)=>await YapayZekaYorumu(true);
  oneriYz.Checked+=(_,_)=>{oneriAyar.YapayZeka=true;OneriAyarKaydet();};oneriYz.Unchecked+=(_,_)=>{oneriAyar.YapayZeka=false;OneriAyarKaydet();};
  oneriSaat.Tick+=async(_,_)=>await OnerileriYenile(false);
  Loaded+=(_,_)=>{oneriSaat.Start();_=GecikmeliIlkInceleme();};
  Closed+=(_,_)=>oneriSaat.Stop();
 }
 async Task GecikmeliIlkInceleme(){await Task.Delay(TimeSpan.FromSeconds(20));await OnerileriYenile(false);}

 void OneriAyarOku(){try{oneriAyar=File.Exists(OneriAyarYolu)?JsonSerializer.Deserialize<AkilliAyar>(File.ReadAllText(OneriAyarYolu))??new():new();}catch(Exception e)when(e is IOException or JsonException or UnauthorizedAccessException){oneriAyar=new();}if(oneriYz is not null)oneriYz.IsChecked=oneriAyar.YapayZeka;}
 void OneriAyarKaydet(){try{Directory.CreateDirectory(Path.GetDirectoryName(OneriAyarYolu)!);var tmp=OneriAyarYolu+".tmp";File.WriteAllText(tmp,JsonSerializer.Serialize(oneriAyar));File.Move(tmp,OneriAyarYolu,true);}catch(Exception e)when(e is IOException or UnauthorizedAccessException){}}

 async Task OnerileriYenile(bool elle){
  if(btnOneriler is null||oneriMesgul)return;
  if(aktifKullanici is null||DemoModu){btnOneriler.Visibility=Visibility.Collapsed;return;}
  int user=aktifKullanici.KullaniciId;oneriMesgul=true;
  try{
   if(oneriKullanici!=user){oneriKullanici=user;OneriAyarOku();oneriler=[];yzOnerileri=[];oneriGosterilenKritik=[];}
   if(elle&&oneriDurum is not null)oneriDurum.Text="İnceleniyor…";
   var bulunan=await Task.Run(()=>new AkilliDenetimServisi(baglantiAdresi,user).Incele());
   if(aktifKullanici?.KullaniciId!=user)return;
   oneriler=bulunan.ToList();btnOneriler.Visibility=Visibility.Visible;
   if(oneriDurum is not null)oneriDurum.Text="Son inceleme: "+DateTime.Now.ToString("HH:mm")+" · her 10 dakikada yenilenir.";
   OneriDugmesiniGuncelle();OnerileriCiz();
   var yeniKritik=Gorunen().Where(x=>x.Onem=="Kritik"&&oneriGosterilenKritik.Add(x.Anahtar)).ToList();
   if(yeniKritik.Count>0&&!elle&&oneriPopup is not null&&IsActive)oneriPopup.IsOpen=true;
   if(oneriAyar.YapayZeka&&DateTime.UtcNow-oneriAyar.SonYapayZeka>YapayZekaAraligi)await YapayZekaYorumu(false);
  }
  catch(Exception e){if(oneriDurum is not null)oneriDurum.Text="İnceleme yapılamadı: "+e.Message;if(elle)DestekIzleme.Bildir(e,"ASISTAN");}
  finally{oneriMesgul=false;}
 }

 IEnumerable<AkilliOneri> Gorunen()=>oneriler.Concat(yzOnerileri).Where(x=>!oneriAyar.Gizlenen.Contains(x.Anahtar));
 void OneriDugmesiniGuncelle(){
  if(btnOneriler is null)return;var g=Gorunen().ToList();int kritik=g.Count(x=>x.Onem=="Kritik");
  btnOneriler.Content="💡 Öneriler ("+g.Count+")";
  btnOneriler.Background=new SolidColorBrush(kritik>0?Color.FromRgb(0xFE,0xE2,0xE2):Color.FromRgb(0xFE,0xF9,0xC3));
  btnOneriler.Foreground=new SolidColorBrush(kritik>0?Color.FromRgb(0x99,0x1B,0x1B):Color.FromRgb(0x85,0x4D,0x0E));
  btnOneriler.ToolTip=g.Count==0?"Şu an dikkat isteyen konu bulunmadı.":string.Join("\n",g.Take(6).Select(x=>"• "+x.Baslik));
 }
 void OnerileriCiz(){
  if(oneriListesi is null)return;oneriListesi.Children.Clear();var g=Gorunen().ToList();
  if(g.Count==0){oneriListesi.Children.Add(new TextBlock{Text="✓ Şu an dikkat isteyen konu yok.",Margin=new Thickness(0,10,0,0)});return;}
  foreach(var x in g){
   var renk=x.Onem switch{"Kritik"=>Color.FromRgb(0xDC,0x26,0x26),"Uyarı"=>Color.FromRgb(0xD9,0x77,0x06),_=>Color.FromRgb(0x25,0x63,0xEB)};
   var p=new StackPanel();
   p.Children.Add(new TextBlock{Text=x.Onem+" · "+x.Alan,FontSize=10,FontWeight=FontWeights.SemiBold,Foreground=new SolidColorBrush(renk)});
   p.Children.Add(new TextBlock{Text=x.Baslik,FontWeight=FontWeights.SemiBold,TextWrapping=TextWrapping.Wrap});
   if(x.Aciklama.Length>0)p.Children.Add(new TextBlock{Text=x.Aciklama,TextWrapping=TextWrapping.Wrap,FontSize=11,Margin=new Thickness(0,2,0,0)});
   if(x.Oneri.Length>0)p.Children.Add(new TextBlock{Text="Öneri: "+x.Oneri,TextWrapping=TextWrapping.Wrap,FontSize=11,FontStyle=FontStyles.Italic,Margin=new Thickness(0,2,0,0)});
   var gizle=new Button{Content="Tamam, gizle",FontSize=10,Padding=new Thickness(6,2,6,2),HorizontalAlignment=System.Windows.HorizontalAlignment.Right,Margin=new Thickness(0,4,0,0)};
   var key=x.Anahtar;gizle.Click+=(_,_)=>{oneriAyar.Gizlenen.Add(key);if(oneriAyar.Gizlenen.Count>500)oneriAyar.Gizlenen=oneriAyar.Gizlenen.Skip(oneriAyar.Gizlenen.Count-500).ToHashSet();OneriAyarKaydet();OneriDugmesiniGuncelle();OnerileriCiz();};
   p.Children.Add(gizle);
   oneriListesi.Children.Add(new Border{Child=p,BorderBrush=new SolidColorBrush(renk),BorderThickness=new Thickness(3,0,0,0),Padding=new Thickness(8,6,6,6),Margin=new Thickness(0,0,0,8),Background=new SolidColorBrush(Color.FromRgb(0xF8,0xFA,0xFC))});
  }
 }

 /// <summary>Yapılandırılmış yapay zekâdan bulguları yorumlamasını ve en fazla 5 yeni fikir vermesini ister.</summary>
 async Task YapayZekaYorumu(bool elle){
  if(aktifKullanici is null)return;
  AsistanAyari ayar;try{ayar=AsistanAyari.Oku(AsistanAyarYolu);}catch(Exception){return;}
  if(ayar.Tur=="Yerleşik rehber"){if(elle&&oneriDurum is not null)oneriDurum.Text="Yapay zekâ bağlantısı tanımlı değil. Yardım panelinden (Yapay zekâ bağlantısı) Ollama veya MiapaxERP sunucusu bağlayın; kural tabanlı inceleme bağlantısız da çalışır.";return;}
  if(!elle&&!oneriAyar.YapayZeka)return;
  string ozet=string.Join("\n",oneriler.Take(25).Select(x=>"- ["+x.Onem+"/"+x.Alan+"] "+x.Baslik+": "+x.Aciklama));
  if(ozet.Length==0)ozet="(kural tabanlı incelemede bulgu yok)";
  if(ozet.Length>6000)ozet=ozet[..6000];
  string sektor=LisansOturumu.SektorKodu is { } s?MiapaxERP.Lisans.Core.UrunKatalogu.SektorBul(s)?.Ad??s:"Genel";
  string soru="Sen bir "+sektor+" işletmesinin ERP danışmanısın. Aşağıda programın otomatik denetim bulguları var. Bunlara dayanarak işletmeye en fazla 5 kısa, uygulanabilir fikir ver (üretim verimi, stok, harcama, muhasebe düzeni, nakit). "+
   "Her fikri ayrı satırda 'BAŞLIK | AÇIKLAMA' biçiminde yaz; başka metin yazma. Veri uydurma, yalnız verilen bulgulara ve genel iyi uygulamaya dayan. Güvenlik denetimini kapatmayı veya SQL'i internete açmayı önerme.\nBulgular:\n"+ozet;
  if(oneriDurum is not null)oneriDurum.Text="Yapay zekâ fikirleri hazırlanıyor…";
  try{
   using var cts=new CancellationTokenSource(TimeSpan.FromSeconds(90));
   var yanit=await new AsistanIstemcisi().SorAsync(ayar,soru,"Akıllı öneriler",[],cts.Token);
   oneriAyar.SonYapayZeka=DateTime.UtcNow;OneriAyarKaydet();
   var yeni=new List<AkilliOneri>();
   foreach(var line in (yanit.Metin??"").Split('\n').Select(l=>l.Trim().TrimStart('-','•','*',' ').Trim()).Where(l=>l.Length>3)){
    var parts=line.Split('|',2);string baslik=parts[0].Trim(),aciklama=parts.Length>1?parts[1].Trim():"";
    if(baslik.Length>140)baslik=baslik[..140];if(aciklama.Length>600)aciklama=aciklama[..600];
    string key="yz-"+Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(baslik.ToLowerInvariant())))[..16];
    yeni.Add(new(key,"Yapay zekâ","Öneri",baslik,aciklama,""));if(yeni.Count==5)break;
   }
   yzOnerileri=yeni;OneriDugmesiniGuncelle();OnerileriCiz();
   if(oneriDurum is not null)oneriDurum.Text=yeni.Count>0?"Yapay zekâ "+yeni.Count+" fikir ekledi ("+DateTime.Now.ToString("HH:mm")+"). Bulgular yalnız ayarlı yapay zekâ adresine gönderildi: "+ayar.Adres:(yanit.Durum.Length>0?yanit.Durum:"Yapay zekâ yeni fikir vermedi.");
  }
  catch(Exception e)when(e is OperationCanceledException or System.Net.Http.HttpRequestException or ArgumentException or JsonException or IOException){if(oneriDurum is not null)oneriDurum.Text="Yapay zekâya ulaşılamadı: "+e.Message;}
 }
}
