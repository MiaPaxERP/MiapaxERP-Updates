using System.Data;
using System.Net;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>Makineden okunacak bir değer. Kaynak biçimi protokole göre değişir:
/// OPC UA "ns=2;s=Hat1.Hiz", Modbus "HR:40001[:F32]", MQTT "fabrika/hat1/hiz[#json.yol]", HTTP "veri.hiz".</summary>
/// <param name="Rol">Durum, Hiz, Sayac, Hedef, Sicaklik, Basinc, Enerji veya Diger.</param>
/// <param name="Esleme">Durum için sayı→metin eşlemesi, ör. "0=Durdu;1=Çalışıyor;2=Arıza".</param>
public sealed record MakineAlani(string Ad,string Kaynak,string Birim,double Carpan,string Rol,string Esleme);
public sealed record MakineTanimi(int Id,string Ad,string Marka,string Model,string SeriNo,string Bolum,string Protokol,string Adres,int? Port,int BirimNo,int OkumaSaniye,MakineAlani[] Alanlar,bool Aktif)
{
 public string Ozet=>Ad+(Marka.Length+Model.Length>0?" · "+(Marka+" "+Model).Trim():"")+(Bolum.Length>0?" · "+Bolum:"");
}

internal static class MakineSemasi
{
 internal const string Ddl="""
IF OBJECT_ID('dbo.MPXNext_Makine','U') IS NULL CREATE TABLE dbo.MPXNext_Makine(Id int IDENTITY CONSTRAINT PK_MPXNext_Makine PRIMARY KEY,Ad nvarchar(120) NOT NULL CONSTRAINT UX_MPXNext_Makine_Ad UNIQUE,Marka nvarchar(80) NOT NULL DEFAULT N'',Model nvarchar(80) NOT NULL DEFAULT N'',SeriNo nvarchar(80) NOT NULL DEFAULT N'',Bolum nvarchar(80) NOT NULL DEFAULT N'',Protokol varchar(10) NOT NULL CONSTRAINT CK_MPXNext_Makine_Protokol CHECK(Protokol IN('OPCUA','MODBUS','MQTT','HTTP')),Adres nvarchar(300) NOT NULL,Port int NULL CONSTRAINT CK_MPXNext_Makine_Port CHECK(Port BETWEEN 1 AND 65535),Ayar nvarchar(max) NOT NULL CONSTRAINT CK_MPXNext_Makine_Ayar CHECK(ISJSON(Ayar)=1),Aktif bit NOT NULL DEFAULT 1,Olusturan int NOT NULL,Guncelleme datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID('dbo.Yetkiler','U') IS NOT NULL
 INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
 SELECT x.Kod,N'Makine yönetimi',x.Islem,x.Aciklama,1 FROM (VALUES('MACHINE.VIEW',N'Canlı makine paneli',N'Makinelerin anlık üretim, hız ve durum bilgilerini görür'),('MACHINE.MANAGE',N'Makine bağlantıları',N'Makine ekler, bağlantı ve veri alanlarını düzenler')) x(Kod,Islem,Aciklama)
 WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=x.Kod);
""";
 static readonly System.Collections.Concurrent.ConcurrentDictionary<string,bool> hazir=new(StringComparer.OrdinalIgnoreCase);
 internal static void Hazirla(SqlConnection c){
  string anahtar=c.DataSource+"|"+c.Database;if(hazir.ContainsKey(anahtar))return;
  using(var check=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.MPXNext_Makine','U') IS NOT NULL AND (OBJECT_ID('dbo.Yetkiler','U') IS NULL OR EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu='MACHINE.MANAGE')) THEN 1 ELSE 0 END",c))if(Convert.ToInt32(check.ExecuteScalar())==1){hazir[anahtar]=true;return;}
  using var tx=c.BeginTransaction(IsolationLevel.Serializable);
  try{
   using(var gate=ErpModulServisi.Komut(c,tx,"DECLARE @r int;EXEC @r=sys.sp_getapplock @Resource='MiaPaxNextSchema',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;IF @r<0 THROW 51000,'Makine kurulumu kilidi alinamadi',1"))gate.ExecuteNonQuery();
   using(var q=ErpModulServisi.Komut(c,tx,Ddl))q.ExecuteNonQuery();
   tx.Commit();hazir[anahtar]=true;
  }catch{tx.Rollback();throw;}
 }
}

/// <summary>Makine bağlantı tanımlarını saklar. Canlı okuma, makinelerle aynı ağdaki bilgisayarda <see cref="MakineOkuyucu"/> ile yapılır;
/// makine verisi veritabanına yazılmaz, SQL internete açılmaz.</summary>
public sealed class MakineServisi(string connection,int user)
{
 public static readonly string[] Protokoller=["OPCUA","MODBUS","MQTT","HTTP"];
 public static readonly string[] Roller=["Durum","Hiz","Sayac","Hedef","Sicaklik","Basinc","Enerji","Diger"];
 static readonly JsonSerializerOptions json=new(){PropertyNamingPolicy=null};
 readonly ErpModulServisi access=new(connection,user);
 readonly Action<SqlConnection,SqlTransaction?,string>? fixtureCheck;
 internal MakineServisi(string connection,int user,Action<SqlConnection,SqlTransaction?,string> check):this(connection,user){fixtureCheck=check;}
 void Yetki(SqlConnection c,SqlTransaction? t,string code){if(fixtureCheck is not null)fixtureCheck(c,t,code);else access.Yetki(c,t,code);}
 SqlConnection Ac(){var c=access.Ac();try{MakineSemasi.Hazirla(c);return c;}catch{c.Dispose();throw;}}
 sealed record Ayar(int BirimNo,int OkumaSaniye,MakineAlani[] Alanlar);

 public MakineTanimi[] Liste(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<MakineTanimi[]>(connection,"MakineServisi.Liste","",[]);
  using var c=Ac();Yetki(c,null,"MACHINE.VIEW");
  using var q=ErpModulServisi.Komut(c,null,"SELECT Id,Ad,Marka,Model,SeriNo,Bolum,Protokol,Adres,Port,Ayar,Aktif FROM dbo.MPXNext_Makine ORDER BY Bolum,Ad");
  using var r=q.ExecuteReader();var list=new List<MakineTanimi>();
  while(r.Read()){var a=JsonSerializer.Deserialize<Ayar>(r.GetString(9),json)??new(1,2,[]);list.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetString(5),r.GetString(6),r.GetString(7),r.IsDBNull(8)?null:r.GetInt32(8),a.BirimNo,a.OkumaSaniye,a.Alanlar??[],r.GetBoolean(10)));}
  return list.ToArray();
 }

 /// <summary>Makineyi ekler (Id=0) veya günceller; makine kimliğini döndürür.</summary>
 public int Kaydet(MakineTanimi m){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<int>(connection,"MakineServisi.Kaydet","",[m]);
  m=Dogrula(m);string ayar=JsonSerializer.Serialize(new Ayar(m.BirimNo,m.OkumaSaniye,m.Alanlar),json);
  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);
  try{
   Yetki(c,t,"MACHINE.VIEW");Yetki(c,t,"MACHINE.MANAGE");
   using(var dup=ErpModulServisi.Komut(c,t,"SELECT COUNT(*) FROM dbo.MPXNext_Makine WITH(UPDLOCK,HOLDLOCK) WHERE Ad=@a AND Id<>@i",("@a",m.Ad),("@i",m.Id)))if(Convert.ToInt32(dup.ExecuteScalar())>0)throw new ArgumentException("Bu adla başka bir makine var.");
   int id;
   if(m.Id==0){using var q=ErpModulServisi.Komut(c,t,"INSERT dbo.MPXNext_Makine(Ad,Marka,Model,SeriNo,Bolum,Protokol,Adres,Port,Ayar,Aktif,Olusturan) OUTPUT INSERTED.Id VALUES(@a,@ma,@mo,@s,@b,@p,@ad,@po,@ay,@ak,@u)",P(m,ayar));id=Convert.ToInt32(q.ExecuteScalar());}
   else{using var q=ErpModulServisi.Komut(c,t,"UPDATE dbo.MPXNext_Makine SET Ad=@a,Marka=@ma,Model=@mo,SeriNo=@s,Bolum=@b,Protokol=@p,Adres=@ad,Port=@po,Ayar=@ay,Aktif=@ak,Guncelleme=SYSUTCDATETIME() WHERE Id=@i",[..P(m,ayar),("@i",m.Id)]);if(q.ExecuteNonQuery()!=1)throw new ArgumentException("Makine bulunamadı.");id=m.Id;}
   t.Commit();return id;
  }catch{t.Rollback();throw;}
  (string,object?)[] P(MakineTanimi x,string a)=>[("@a",x.Ad),("@ma",x.Marka),("@mo",x.Model),("@s",x.SeriNo),("@b",x.Bolum),("@p",x.Protokol),("@ad",x.Adres),("@po",x.Port),("@ay",a),("@ak",x.Aktif),("@u",user)];
 }

 public void Sil(int id){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"MakineServisi.Sil","",[id]);return;}
  using var c=Ac();Yetki(c,null,"MACHINE.VIEW");Yetki(c,null,"MACHINE.MANAGE");
  using var q=ErpModulServisi.Komut(c,null,"DELETE dbo.MPXNext_Makine WHERE Id=@i",("@i",id));q.ExecuteNonQuery();
 }

 static string T(string? v,int max,string ad,bool zorunlu=false){v=(v??"").Trim();if(zorunlu&&v.Length==0)throw new ArgumentException(ad+" girin.");if(v.Length>max||v.Any(char.IsControl))throw new ArgumentException(ad+" en fazla "+max+" karakter olmalı.");return v;}
 /// <summary>Tanımı doğrular ve temizlenmiş kopyasını döndürür.</summary>
 public static MakineTanimi Dogrula(MakineTanimi m){
  if(m is null)throw new ArgumentException("Makine bilgisi eksik.");
  string p=(m.Protokol??"").Trim().ToUpperInvariant();if(!Protokoller.Contains(p))throw new ArgumentException("Bağlantı türü OPC UA, Modbus TCP, MQTT veya HTTP olmalı.");
  string adres=T(m.Adres,300,"Makine adresi",true);
  if(p=="HTTP"){if(!Uri.TryCreate(adres,UriKind.Absolute,out var u)||u.Scheme is not ("http" or "https")||u.UserInfo.Length>0)throw new ArgumentException("HTTP makine adresi http(s)://… ile başlamalı ve kullanıcı bilgisi içermemeli.");}
  else if(p=="OPCUA"){if(!Uri.TryCreate(adres,UriKind.Absolute,out var u)||u.Scheme!="opc.tcp")throw new ArgumentException("OPC UA adresi opc.tcp://ip:4840 biçiminde olmalı.");}
  else if(Uri.CheckHostName(adres)==UriHostNameType.Unknown)throw new ArgumentException("Makine adresi IP veya ağ adı olmalı (ör. 192.168.1.50).");
  if(m.Port is { } port&&(port<1||port>65535))throw new ArgumentException("Port 1–65535 olmalı.");
  if(m.BirimNo is <0 or >255)throw new ArgumentException("Modbus birim (slave) numarası 0–255 olmalı.");
  if(m.OkumaSaniye is <1 or >300)throw new ArgumentException("Okuma aralığı 1–300 saniye olmalı.");
  var alanlar=m.Alanlar??[];if(alanlar.Length is 0 or >40)throw new ArgumentException("1–40 veri alanı tanımlayın.");
  var temiz=alanlar.Select(a=>{
   string rol=Roller.FirstOrDefault(r=>string.Equals(r,a.Rol?.Trim(),StringComparison.OrdinalIgnoreCase))??throw new ArgumentException("Alan rolü geçersiz: "+a.Rol);
   string kaynak=T(a.Kaynak,300,"Veri adresi",true);
   if(p=="MODBUS")_=MakineOkuyucu.ModbusAdres(kaynak);else if(p=="OPCUA")_=OpcUaBaglanti.DugumKodla(kaynak);
   if(double.IsNaN(a.Carpan)||double.IsInfinity(a.Carpan)||a.Carpan==0)throw new ArgumentException("Çarpan 0 olamaz: "+a.Ad);
   return new MakineAlani(T(a.Ad,60,"Alan adı",true),kaynak,T(a.Birim,20,"Birim"),a.Carpan,rol,T(a.Esleme,300,"Durum eşlemesi"));
  }).ToArray();
  if(temiz.Select(x=>x.Ad).Distinct(StringComparer.CurrentCultureIgnoreCase).Count()!=temiz.Length)throw new ArgumentException("Alan adları benzersiz olmalı.");
  return m with{Ad=T(m.Ad,120,"Makine adı",true),Marka=T(m.Marka,80,"Marka"),Model=T(m.Model,80,"Model"),SeriNo=T(m.SeriNo,80,"Seri no"),Bolum=T(m.Bolum,80,"Bölüm"),Protokol=p,Adres=adres,Alanlar=temiz};
 }
}
