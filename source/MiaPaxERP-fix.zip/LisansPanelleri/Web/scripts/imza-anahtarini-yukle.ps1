﻿# Yerel paneldeki (DPAPI ile korunan) mevcut lisans imza anahtarını diske yazmadan
# kendi Cloudflare Worker'ınıza gizli değer olarak yükler. Anahtar değiştirilmez/yeniden üretilmez.
# Kullanım (InternetPaneli klasöründe, "npx wrangler login" yapıldıktan sonra):
#   powershell -ExecutionPolicy Bypass -File scripts\imza-anahtarini-yukle.ps1 -YerelPanel "C:\...\BoruERP-BayiPaneli-3.0"
param([Parameter(Mandatory=$true)][string]$YerelPanel)
$ErrorActionPreference='Stop'
$privateFolder=Join-Path $env:USERPROFILE 'BoruERP_GizliAnahtarlar\BayiPaneli30'
$env:PORTAL_SECRET_FILE=Join-Path $privateFolder 'secrets.dpapi'
if(-not (Test-Path -LiteralPath $env:PORTAL_SECRET_FILE)) { throw "Gizli ayar dosyası bulunamadı: $($env:PORTAL_SECRET_FILE)" }
$config=(Resolve-Path (Join-Path $YerelPanel 'src\config.js')).Path.Replace('\','/')
$key=& node --input-type=module -e "import {loadConfig} from 'file:///$config';const k=loadConfig().LICENSE_PRIVATE_PKCS8;if(!k)process.exit(3);process.stdout.write(k);"
if($LASTEXITCODE -ne 0 -or -not $key) { throw 'LICENSE_PRIVATE_PKCS8 yerel panel ayarlarında bulunamadı.' }
try { $key | npx wrangler secret put LICENSE_PRIVATE_PKCS8 } finally { $key=$null; [GC]::Collect() }
Write-Host 'İmza anahtarı Cloudflare gizli değeri olarak yüklendi (diske yazılmadı).'
