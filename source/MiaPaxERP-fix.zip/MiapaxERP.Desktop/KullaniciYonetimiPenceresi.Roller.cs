using System.Windows;
using System.Windows.Controls;
using ListBox = System.Windows.Controls.ListBox;
using Orientation = System.Windows.Controls.Orientation;

namespace MiapaxERP.Desktop
{
    /// <summary>Rol ekleme ve rol yetkilerini işaretleyerek düzenleme (yalnız ana sunucuda).</summary>
    public partial class KullaniciYonetimiPenceresi
    {
        bool RolIslemiYapilabilir()
        {
            if (!HttpsOturumu.Uzak(baglantiAdresi)) return true;
            MessageBox.Show(this, "Rol ekleme ve rol yetkileri ana sunucu bilgisayarında düzenlenir.", "Roller", MessageBoxButton.OK, MessageBoxImage.Information);
            return false;
        }

        static string? Sor(Window owner, string baslik, string etiket)
        {
            var kutu = new TextBox { MinWidth = 320, MaxLength = 60, Margin = new Thickness(0, 6, 0, 10) };
            var aciklama = new TextBox { MinWidth = 320, MaxLength = 250, Margin = new Thickness(0, 6, 0, 10) };
            var tamam = new Button { Content = "Ekle", IsDefault = true, MinWidth = 90, Margin = new Thickness(0, 0, 8, 0) };
            var iptal = new Button { Content = "Vazgeç", IsCancel = true, MinWidth = 90 };
            var p = new StackPanel { Margin = new Thickness(18) };
            p.Children.Add(new TextBlock { Text = etiket });p.Children.Add(kutu);
            p.Children.Add(new TextBlock { Text = "Açıklama (isteğe bağlı)" });p.Children.Add(aciklama);
            var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };bar.Children.Add(tamam);bar.Children.Add(iptal);p.Children.Add(bar);
            var w = new Window { Title = baslik, Owner = owner, SizeToContent = SizeToContent.WidthAndHeight, ResizeMode = ResizeMode.NoResize, WindowStartupLocation = WindowStartupLocation.CenterOwner, Content = p };
            tamam.Click += (_, _) => w.DialogResult = true;kutu.Focus();
            return w.ShowDialog() == true ? kutu.Text.Trim() + "\u0001" + aciklama.Text.Trim() : null;
        }

        private void YeniRol_Click(object sender, RoutedEventArgs e)
        {
            if (!RolIslemiYapilabilir()) return;
            var yanit = Sor(this, "Yeni rol", "Rol adı (ör. Sevkiyat, Kalite Kontrol)");
            if (yanit is null) return;
            var parca = yanit.Split('\u0001');
            try
            {
                using var c = new Microsoft.Data.SqlClient.SqlConnection(baglantiAdresi);c.Open();
                using (var yetkiBaglanti = new ErpSqlConnection(baglantiAdresi)) { yetkiBaglanti.Open(); if (!AdminYetkisiniKontrolEt(yetkiBaglanti)) return; }
                int id = RolSemasi.Ekle(c, parca[0], parca.Length > 1 ? parca[1] : "");
                RolleriYukle();CmbYRol.SelectedValue = id;
                if (MessageBox.Show(this, "Rol eklendi. Şimdi bu rolün yetkilerini işaretlemek ister misiniz?", "Roller", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    RolYetkileriniDuzenle(id, parca[0]);
            }
            catch (Exception ex) when (ex is ArgumentException or Microsoft.Data.SqlClient.SqlException or InvalidOperationException)
            {
                MessageBox.Show(this, "Rol eklenemedi: " + ex.Message, "Roller", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void RolYetkileri_Click(object sender, RoutedEventArgs e)
        {
            if (!RolIslemiYapilabilir()) return;
            if (CmbYRol.SelectedValue is not int id || CmbYRol.SelectedItem is not System.Data.DataRowView satir)
            { MessageBox.Show(this, "Önce Rol listesinden bir rol seçin.", "Roller", MessageBoxButton.OK, MessageBoxImage.Information); return; }
            RolYetkileriniDuzenle(id, satir["RolAdi"]?.ToString() ?? "");
        }

        void RolYetkileriniDuzenle(int rol, string ad)
        {
            try
            {
                using var c = new Microsoft.Data.SqlClient.SqlConnection(baglantiAdresi);c.Open();
                using (var yetkiBaglanti = new ErpSqlConnection(baglantiAdresi)) { yetkiBaglanti.Open(); if (!AdminYetkisiniKontrolEt(yetkiBaglanti)) return; }
                if (ad == "Yönetici") { MessageBox.Show(this, "Yönetici rolü tüm yetkilere sahiptir; değiştirilemez.", "Roller", MessageBoxButton.OK, MessageBoxImage.Information); return; }
                var yetkiler = RolSemasi.Yetkiler(c, rol);
                var kutular = yetkiler.Select(y => new CheckBox { Content = y.Ad + "  (" + y.Kod + ")", IsChecked = y.Var, Tag = y.Id, Margin = new Thickness(2) }).ToList();
                var ara = new TextBox { Margin = new Thickness(0, 0, 0, 6), ToolTip = "Yetki ara" };
                var liste = new ListBox { Height = 460, ItemsSource = kutular };
                ara.TextChanged += (_, _) => { string t = ara.Text.Trim(); liste.ItemsSource = t.Length == 0 ? kutular : kutular.Where(k => k.Content?.ToString()?.Contains(t, StringComparison.CurrentCultureIgnoreCase) == true).ToList(); };
                var kaydet = new Button { Content = "Kaydet", IsDefault = true, MinWidth = 100, Margin = new Thickness(0, 8, 8, 0) };
                var kapat = new Button { Content = "Vazgeç", IsCancel = true, MinWidth = 100, Margin = new Thickness(0, 8, 0, 0) };
                var p = new StackPanel { Margin = new Thickness(16) };
                p.Children.Add(new TextBlock { Text = "“" + ad + "” rolünün yetkileri — işaretli olanlar bu roldeki herkese verilir.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 8) });
                p.Children.Add(new TextBlock { Text = "Ara:" });p.Children.Add(ara);p.Children.Add(liste);
                var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };bar.Children.Add(kaydet);bar.Children.Add(kapat);p.Children.Add(bar);
                var w = new Window { Title = "Rol yetkileri · " + ad, Owner = this, Width = 620, SizeToContent = SizeToContent.Height, WindowStartupLocation = WindowStartupLocation.CenterOwner, Content = p };
                kaydet.Click += (_, _) =>
                {
                    try
                    {
                        using var k = new Microsoft.Data.SqlClient.SqlConnection(baglantiAdresi);k.Open();
                        RolSemasi.YetkileriKaydet(k, rol, kutular.Where(x => x.IsChecked == true).Select(x => (int)x.Tag));
                        w.DialogResult = true;
                    }
                    catch (Exception ex) when (ex is ArgumentException or InvalidOperationException or Microsoft.Data.SqlClient.SqlException)
                    { MessageBox.Show(w, "Kaydedilemedi: " + ex.Message, "Roller", MessageBoxButton.OK, MessageBoxImage.Warning); }
                };
                if (w.ShowDialog() == true) MessageBox.Show(this, "Rol yetkileri kaydedildi. Bu roldeki kullanıcılar yeniden giriş yapınca yeni yetkileri görür.", "Roller", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex) when (ex is Microsoft.Data.SqlClient.SqlException or InvalidOperationException)
            { MessageBox.Show(this, "Rol yetkileri açılamadı: " + ex.Message, "Roller", MessageBoxButton.OK, MessageBoxImage.Warning); }
        }
    }
}
