CREATE TABLE portal_announcements (
 seq INTEGER PRIMARY KEY AUTOINCREMENT,
 id TEXT NOT NULL UNIQUE,
 title TEXT NOT NULL,
 body TEXT NOT NULL,
 audience TEXT NOT NULL CHECK(audience IN ('ALL','CUSTOMER')),
 customer_id TEXT REFERENCES customers(id),
 actor TEXT NOT NULL,
 created_at TEXT NOT NULL,
 CHECK((audience='ALL' AND customer_id IS NULL) OR (audience='CUSTOMER' AND customer_id IS NOT NULL))
);
CREATE TABLE portal_announcement_recipients (
 announcement_id TEXT NOT NULL REFERENCES portal_announcements(id),
 customer_id TEXT NOT NULL REFERENCES customers(id),
 PRIMARY KEY(announcement_id,customer_id)
);
CREATE INDEX portal_announcements_customer ON portal_announcement_recipients(customer_id,announcement_id);
