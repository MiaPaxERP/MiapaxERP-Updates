using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record ErpKullaniciSecimi(int Id,string Ad){public override string ToString()=>Ad+" (No "+Id+")";}

/// <summary>Mobil hesap için çalışan seçimi, bağlanamama nedenini bulma ve Mobil erişim yetkisini tek tıkla verme.</summary>
public sealed partial class MobilHesapServisi
{
 static void YalnizAna(string cs){if(HttpsOturumu.Uzak(cs))throw new InvalidOperationException("Bu işlem ana sunucu bilgisayarında yapılır.");}

 public ErpKullaniciSecimi[] ErpKullanicilari(int admin){
  YalnizAna(Baglanti);using var c=new SqlConnection(Baglanti);c.Open();Yonetici(c,null,admin);
  using var q=ErpModulServisi.Komut(c,null,"SELECT Id,COALESCE(NULLIF(AdSoyad,N''),KullaniciAdi) FROM dbo.Kullanicilar WHERE Aktif=1 ORDER BY 2");
  using var r=q.ExecuteReader();var list=new List<ErpKullaniciSecimi>();while(r.Read())list.Add(new(r.GetInt32(0),r.GetString(1)));return list.ToArray();
 }

 /// <summary>Seçili hesabın telefonla neden bağlanamayacağını madde madde yazar (✔ / ✖).</summary>
 public string Teshis(int admin,Guid id){
  YalnizAna(Baglanti);using var c=new SqlConnection(Baglanti);c.Open();Yonetici(c,null,admin);
  var s=new System.Text.StringBuilder();void S(bool ok,string m)=>s.AppendLine((ok?"✔ ":"✖ ")+m);
  int user;string ad;bool aktif;int cihaz;
  using(var q=ErpModulServisi.Komut(c,null,"SELECT h.KullaniciId,h.Ad,h.Aktif,(SELECT COUNT(*) FROM dbo.BERP220_Cihaz d WHERE d.HesapId=h.Id AND d.Iptal=0) FROM dbo.BERP220_Hesap h WHERE h.Id=@id",("@id",id))){using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Hesap bulunamadı.");user=r.GetInt32(0);ad=r.GetString(1);aktif=r.GetBoolean(2);cihaz=r.GetInt32(3);}
  S(aktif,aktif?$"Mobil hesap etkin: {ad} (ERP kullanıcı No {user}), bağlı telefon: {cihaz}":"Mobil hesap kapalı (iptal edilmiş). 'Çalışanı ekle' ile yeniden etkinleştirin.");
  using(var q=ErpModulServisi.Komut(c,null,"SELECT COUNT(*) FROM dbo.Kullanicilar WHERE Id=@u AND Aktif=1",("@u",user)))S(Convert.ToInt32(q.ExecuteScalar())==1,"ERP kullanıcısı etkin");
  bool lisans=LisansOturumu.ModulVar("MOBIL");S(lisans,lisans?"Lisansta MOBIL modülü açık":"Lisansta MOBIL modülü kapalı → lisans yöneticisinden açtırın");
  var yetki=new MenuYetkiServisi(Baglanti,user).Yetkiler().ToHashSet(StringComparer.Ordinal);
  S(yetki.Contains("MOBILE.ACCESS"),yetki.Contains("MOBILE.ACCESS")?"Mobil erişim yetkisi var":"Mobil erişim (MOBILE.ACCESS) yetkisi YOK → 'Mobil erişimi ver' düğmesine basın. Telefonun bağlanamamasının nedeni budur.");
  var bolumler=MobilDepartmanKurallari.Bolumler.Where(b=>yetki.Contains(b.Mobil)&&yetki.Contains(b.Erp)).Select(b=>b.Ad).ToArray();
  S(bolumler.Length>0,bolumler.Length>0?"Telefonda açılacak bölümler: "+string.Join(", ",bolumler):"Telefonda açılacak bölüm yok: Kullanıcı ve Yetkiler'den Mobil saha/stok/mesaj vb. yetkilerini verin (bağlanır ama boş görünür).");
  if(LisansOturumu.MobilCihazSiniri is int sinir){using var q=ErpModulServisi.Komut(c,null,"SELECT COUNT(*) FROM dbo.BERP220_Cihaz d JOIN dbo.BERP220_Hesap h ON h.Id=d.HesapId WHERE d.Iptal=0 AND h.Aktif=1");int k=Convert.ToInt32(q.ExecuteScalar());S(k<sinir,$"Mobil cihaz lisansı: {k} / {sinir}"+(k<sinir?"":" → DOLU, kullanılmayan cihazları iptal edin"));}
  else S(true,"Mobil cihaz sınırı yok");
  s.AppendLine("• Telefon kodu 15 dakika geçerli ve tek kullanımlıktır; her denemede yeni kod üretin.");
  return s.ToString();
 }

 /// <summary>Hesabın ERP kullanıcısına Mobil erişim (MOBILE.ACCESS) ve Mobil mesajlaşma (MOBILE.CHAT) yetkisini verir.</summary>
 public void ErisimVer(int admin,Guid id){
  YalnizAna(Baglanti);using var c=new SqlConnection(Baglanti);c.Open();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yonetici(c,tx,admin);
  using var q=ErpModulServisi.Komut(c,tx,"""
DECLARE @u int=(SELECT KullaniciId FROM dbo.BERP220_Hesap WHERE Id=@id);
IF @u IS NULL THROW 51000,N'Hesap bulunamadı.',1;
MERGE dbo.KullaniciYetkileri WITH(HOLDLOCK) AS t
USING (SELECT @u AS KullaniciId,y.Id AS YetkiId FROM dbo.Yetkiler y WHERE y.Aktif=1 AND y.YetkiKodu IN (N'MOBILE.ACCESS',N'MOBILE.CHAT')) AS s
ON t.KullaniciId=s.KullaniciId AND t.YetkiId=s.YetkiId
WHEN MATCHED THEN UPDATE SET IzinVerildi=1,GuncellemeTarihiUtc=SYSUTCDATETIME(),GuncelleyenKullaniciId=@a
WHEN NOT MATCHED THEN INSERT(KullaniciId,YetkiId,IzinVerildi,GuncellemeTarihiUtc,GuncelleyenKullaniciId) VALUES(s.KullaniciId,s.YetkiId,1,SYSUTCDATETIME(),@a);
""",("@id",id),("@a",admin));q.ExecuteNonQuery();tx.Commit();
 }
}
