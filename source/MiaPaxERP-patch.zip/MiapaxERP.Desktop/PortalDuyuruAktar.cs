using System.Data;
using Microsoft.Data.SqlClient;
using MiapaxERP.Lisans.Core;
namespace MiapaxERP.Desktop;
internal static class PortalDuyuruAktar
{
 // Called only after the RSA-PSS license is verified for this machine/database.
 internal static long Kaydet(string connection,string provider,LisansIcerigi verified){
  if(verified.PortalNotices is not {Length:>0} notices)return 0;
  if(!Uri.TryCreate(provider,UriKind.Absolute,out var uri)||uri.Scheme!="https"&&!(uri.Scheme=="http"&&uri.IsLoopback))throw new ArgumentException("Lisans sağlayıcı adresi geçersiz.");
  using var c=new SqlConnection(connection);c.Open();IsbirligiSemasi.Hazirla(c);using var tx=c.BeginTransaction(IsolationLevel.Serializable);
  foreach(var n in notices){string source="PORTAL:"+LisansKripto.Ozet(uri.GetLeftPart(UriPartial.Authority).ToLowerInvariant())+":"+verified.CustomerId+":"+n.Id;string title="MiaPaxERP · "+n.Title;
   using(var prior=ErpModulServisi.Komut(c,tx,"SELECT Baslik,Metin FROM dbo.MPXNext_Duyuru WITH(UPDLOCK,HOLDLOCK) WHERE Kaynak=@s",("@s",source))){using var r=prior.ExecuteReader();if(r.Read()&&(r.GetString(0)!=title||r.GetString(1)!=n.Body))throw new InvalidOperationException("Duyuru kimliği farklı içerikle tekrar kullanılamaz.");}
   long id=IsbirligiServisi.Insert(c,tx,Guid.NewGuid(),source,0,title,n.Body,null,null);
   using var date=ErpModulServisi.Komut(c,tx,"UPDATE dbo.MPXNext_Duyuru SET Tarih=@t WHERE Id=@id",("@t",n.CreatedAt.UtcDateTime),("@id",id));date.ExecuteNonQuery();
  }tx.Commit();return notices.Max(x=>x.Sequence);
 }
}
