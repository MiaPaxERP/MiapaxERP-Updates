using System.Data;
using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed record TamSifirlamaSonucu(string Yedek,int TabloSayisi);
public sealed partial class YardimciEkranServisi
{
 readonly Action<SqlConnection,SqlTransaction?>? fixtureAdmin;
 internal YardimciEkranServisi(string connection,int user,Action<SqlConnection,SqlTransaction?> check):this(connection,user){fixtureAdmin=check;}
 void TamSifirlamaYetkisi(SqlConnection c,SqlTransaction? t){if(fixtureAdmin is not null)fixtureAdmin(c,t);else Yonetici(c,t);}
 internal static HashSet<string> UygulamaTablolari()=>Regex.Matches(IlkKurulumServisi.Kaynak("Sema.sql"),@"CREATE TABLE \[dbo\]\.\[([^\]]+)\]",RegexOptions.IgnoreCase).Select(x=>x.Groups[1].Value).ToHashSet(StringComparer.OrdinalIgnoreCase);
 public TamSifirlamaSonucu TumVerileriSifirla(string veritabani,string onay,string yoneticiSifresi,bool kabul){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<TamSifirlamaSonucu>(connection,"YardimciEkranServisi.TumVerileriSifirla","",[veritabani,onay,yoneticiSifresi,kabul]);
  if(!kabul||onay!="TUM VERILERI SIFIRLA")throw new ArgumentException("Tam sıfırlama onayı gerekli.");
  IlkKurulumServisi.Veritabani(veritabani);using var c=access.Ac();TamSifirlamaYetkisi(c,null);if(c.Database!=veritabani)throw new ArgumentException("Veritabanı adı uyuşmuyor.");
  using(var auth=Q(c,null,"SELECT SifreOzeti FROM dbo.Kullanicilar WHERE Id=@u AND Aktif=1",("@u",user)))if(auth.ExecuteScalar() is not string hash||!GirisPenceresi.SifreDogrula(yoneticiSifresi,hash))throw new UnauthorizedAccessException("Yönetici şifresi doğrulanamadı.");
  using var gate=Q(c,null,"DECLARE @r int;EXEC @r=sys.sp_getapplock @Resource='MiaPaxERP.FactoryReset',@LockMode='Exclusive',@LockOwner='Session',@LockTimeout=10000;IF @r<0 THROW 51000,N'Sıfırlama işlemi sürüyor.',1;");gate.ExecuteNonQuery();
  try{
   string backupFolder;using(var folder=Q(c,null,"SELECT CONVERT(nvarchar(512),SERVERPROPERTY('InstanceDefaultBackupPath'))"))backupFolder=Convert.ToString(folder.ExecuteScalar())??"";
   if(string.IsNullOrWhiteSpace(backupFolder)){using var data=Q(c,null,"SELECT physical_name FROM sys.database_files WHERE file_id=1");string path=Convert.ToString(data.ExecuteScalar())??"";int separator=Math.Max(path.LastIndexOf('/'),path.LastIndexOf('\\'));if(separator>0)backupFolder=path[..separator];}
   if(string.IsNullOrWhiteSpace(backupFolder))throw new InvalidOperationException("SQL Server yedek klasörü belirlenemedi. Sıfırlama yapılmadı.");
   string backup=backupFolder.TrimEnd('\\','/')+"/MiaPaxERP-"+Regex.Replace(veritabani,"[^A-Za-z0-9_-]","_")+"-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N")+".bak";
   using(var save=Q(c,null,"BACKUP DATABASE "+IlkKurulumServisi.Tanim(veritabani)+" TO DISK=@p WITH COPY_ONLY,CHECKSUM;RESTORE VERIFYONLY FROM DISK=@p WITH CHECKSUM;",("@p",backup))){save.CommandTimeout=600;save.ExecuteNonQuery();}
   using var tx=c.BeginTransaction(IsolationLevel.Serializable);
   try{
    TamSifirlamaYetkisi(c,tx);var allowed=UygulamaTablolari();allowed.Remove("BERP_Sema");
    var tables=new List<string>();using(var q=Q(c,tx,"SELECT name FROM sys.tables WHERE schema_id=SCHEMA_ID('dbo') AND is_ms_shipped=0"))using(var r=q.ExecuteReader())while(r.Read())if(allowed.Contains(r.GetString(0)))tables.Add(r.GetString(0));
    var foreign=new List<(string Table,string Name,bool Disabled,bool Untrusted)>();using(var q=Q(c,tx,"SELECT OBJECT_NAME(parent_object_id),name,is_disabled,is_not_trusted,OBJECT_NAME(referenced_object_id) FROM sys.foreign_keys"))using(var r=q.ExecuteReader())while(r.Read()){string child=r.GetString(0),parent=r.GetString(4);if(tables.Contains(parent)&&!tables.Contains(child))throw new InvalidOperationException("ERP dışındaki tablo bağımlı: "+child+". Sıfırlama iptal edildi.");if(tables.Contains(child))foreign.Add((child,r.GetString(1),r.GetBoolean(2),r.GetBoolean(3)));}
    var triggers=new List<(string Table,string Name,bool Disabled)>();using(var q=Q(c,tx,"SELECT OBJECT_NAME(parent_id),name,is_disabled FROM sys.triggers WHERE parent_class=1"))using(var r=q.ExecuteReader())while(r.Read())if(tables.Contains(r.GetString(0)))triggers.Add((r.GetString(0),r.GetString(1),r.GetBoolean(2)));
    foreach(var table in tables){using var q=Q(c,tx,"ALTER TABLE dbo."+IlkKurulumServisi.Tanim(table)+" NOCHECK CONSTRAINT ALL;DISABLE TRIGGER ALL ON dbo."+IlkKurulumServisi.Tanim(table)+";");q.ExecuteNonQuery();}
    foreach(var table in tables){using var q=Q(c,tx,"DELETE FROM dbo."+IlkKurulumServisi.Tanim(table)+" WITH(TABLOCKX);");q.CommandTimeout=180;q.ExecuteNonQuery();}
    using(var seed=Q(c,tx,IlkKurulumServisi.Kaynak("Tohum.sql")))seed.ExecuteNonQuery();
    using(var admin=Q(c,tx,"INSERT dbo.Kullanicilar(KullaniciAdi,AdSoyad,SifreOzeti,Aktif,SifreDegistirmeli) VALUES(N'Admin',N'İlk Yönetici',@s,1,1);DECLARE @i int=SCOPE_IDENTITY();INSERT dbo.KullaniciRolAtamalari(KullaniciId,RolId) SELECT @i,Id FROM dbo.KullaniciRolleri WHERE RolAdi=N'Yönetici' AND Aktif=1;INSERT dbo.BoruERP_IlkKurulum(Id) VALUES(1);",("@s",GirisPenceresi.SifreOzetiOlustur("1234"))))admin.ExecuteNonQuery();
    foreach(var file in new[]{"Isletme310.sql","ModullerNext.sql"}){using var q=Q(c,tx,System.IO.File.ReadAllText(System.IO.Path.Combine(AppContext.BaseDirectory,file)));q.CommandTimeout=120;q.ExecuteNonQuery();}
    foreach(var fk in foreign){using var q=Q(c,tx,"ALTER TABLE dbo."+IlkKurulumServisi.Tanim(fk.Table)+(fk.Disabled?" NOCHECK CONSTRAINT ":fk.Untrusted?" WITH NOCHECK CHECK CONSTRAINT ":" WITH CHECK CHECK CONSTRAINT ")+IlkKurulumServisi.Tanim(fk.Name));q.ExecuteNonQuery();}
    foreach(var trigger in triggers){using var q=Q(c,tx,(trigger.Disabled?"DISABLE":"ENABLE")+" TRIGGER "+IlkKurulumServisi.Tanim(trigger.Name)+" ON dbo."+IlkKurulumServisi.Tanim(trigger.Table));q.ExecuteNonQuery();}
    using(var audit=Q(c,tx,"IF OBJECT_ID('dbo.MiaPaxFactoryResetHistory','U') IS NULL CREATE TABLE dbo.MiaPaxFactoryResetHistory(Id uniqueidentifier PRIMARY KEY,AtUtc datetime2 NOT NULL,Actor int NOT NULL,BackupPath nvarchar(1000) NOT NULL);INSERT dbo.MiaPaxFactoryResetHistory VALUES(NEWID(),SYSUTCDATETIME(),@u,@p);",("@u",user),("@p",backup)))audit.ExecuteNonQuery();
    tx.Commit();return new(backup,tables.Count);
   }catch{if(tx.Connection is not null)tx.Rollback();throw;}
  }finally{using var release=Q(c,null,"EXEC sys.sp_releaseapplock @Resource='MiaPaxERP.FactoryReset',@LockOwner='Session'");release.ExecuteNonQuery();}
 }
}
