// MiapaxERP Arazi Stüdyosu · 3D uydu görünümü.
// Esri World Imagery uydu dokusu gerçek arazi yüksekliğine (AWS Terrain Tiles / Mapzen terrarium) giydirilir;
// tarla sınırı, borular, başlıklar, su kaynağı ve ek parçalar arazinin üzerinde çizilir.
import * as THREE from '/lib/three/three.module.js';
import {OrbitControls} from '/lib/three/OrbitControls.js';
import {toLatLng,bbox,polyLength,TYPES} from './arazi-model.mjs?v=arazi1';

export const imageryCredit='Uydu: Esri World Imagery (Esri, Maxar, Earthstar Geographics, GIS User Community)';
export const terrainCredit='Yükseklik: AWS Terrain Tiles (Mapzen; SRTM/USGS, Copernicus EU-DEM)';
const tileUrl=(z,x,y)=>`https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`;
const demUrl=(z,x,y)=>`https://elevation-tiles-prod.s3.amazonaws.com/terrarium/${z}/${x}/${y}.png`;
function merc(ll,z){const n=2**z,lat=Math.max(-85,Math.min(85,ll.lat))*Math.PI/180;return {x:(ll.lng+180)/360*n,y:(1-Math.asinh(Math.tan(lat))/Math.PI)/2*n};}
function img(url,ms=18000){return new Promise((res,rej)=>{const i=new Image();i.crossOrigin='anonymous';const t=setTimeout(()=>{i.src='';rej(Error('Görüntü zaman aşımı'));},ms);i.onload=()=>{clearTimeout(t);res(i);};i.onerror=()=>{clearTimeout(t);rej(Error('Görüntü yüklenemedi'));};i.src=url;});}

/** Alanı kapsayan uydu karoları (en fazla 36) tek tuvale çizilir. */
async function satellite(llMin,llMax){
 let z=19,r;do{const a=merc({lat:llMax.lat,lng:llMin.lng},z),b=merc({lat:llMin.lat,lng:llMax.lng},z);r={z,x0:Math.floor(a.x),y0:Math.floor(a.y),x1:Math.floor(b.x),y1:Math.floor(b.y)};if((r.x1-r.x0+1)*(r.y1-r.y0+1)<=36)break;z--;}while(z>3);
 const cv=document.createElement('canvas');cv.width=(r.x1-r.x0+1)*256;cv.height=(r.y1-r.y0+1)*256;const ctx=cv.getContext('2d');ctx.fillStyle='#8a9a6a';ctx.fillRect(0,0,cv.width,cv.height);
 const jobs=[];for(let y=r.y0;y<=r.y1;y++)for(let x=r.x0;x<=r.x1;x++)jobs.push(img(tileUrl(r.z,x,y)).then(i=>ctx.drawImage(i,(x-r.x0)*256,(y-r.y0)*256)).catch(()=>{}));
 await Promise.all(jobs);
 return {canvas:cv,uv:ll=>{const m=merc(ll,r.z);return {u:(m.x-r.x0)/(r.x1-r.x0+1),v:1-(m.y-r.y0)/(r.y1-r.y0+1)};}};
}
/** Terrarium yükseklik karoları; çift doğrusal örnekleme. Alınamazsa düz zemin. */
async function elevation(llMin,llMax,zMax){
 let z=Math.min(14,zMax),r;do{const a=merc({lat:llMax.lat,lng:llMin.lng},z),b=merc({lat:llMin.lat,lng:llMax.lng},z);r={x0:Math.floor(a.x),y0:Math.floor(a.y),x1:Math.floor(b.x),y1:Math.floor(b.y)};if((r.x1-r.x0+1)*(r.y1-r.y0+1)<=16)break;z--;}while(z>5);
 const tiles=new Map();const jobs=[];
 for(let y=r.y0;y<=r.y1;y++)for(let x=r.x0;x<=r.x1;x++)jobs.push(img(demUrl(z,x,y),12000).then(i=>{const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d',{willReadFrequently:true});g.drawImage(i,0,0);tiles.set(x+','+y,g.getImageData(0,0,256,256).data);}).catch(()=>{}));
 await Promise.all(jobs);
 if(!tiles.size)return {ok:false,at:()=>0};
 const dec=(d,n)=>d[n]*256+d[n+1]+d[n+2]/256-32768;
 const at=ll=>{const m=merc(ll,z),tx=Math.floor(m.x),ty=Math.floor(m.y),d=tiles.get(tx+','+ty);if(!d)return 0;const fx=Math.min(254.999,(m.x-tx)*256),fy=Math.min(254.999,(m.y-ty)*256),ix=Math.floor(fx),iy=Math.floor(fy),dx=fx-ix,dy=fy-iy,g=(a,b)=>dec(d,(b*256+a)*4);
  return g(ix,iy)*(1-dx)*(1-dy)+g(ix+1,iy)*dx*(1-dy)+g(ix,iy+1)*(1-dx)*dy+g(ix+1,iy+1)*dx*dy;};
 return {ok:true,at};
}

export function createStudio3D(host){
 const scene=new THREE.Scene();scene.background=new THREE.Color('#bcd7e6');scene.fog=new THREE.Fog('#bcd7e6',2000,9000);
 const camera=new THREE.PerspectiveCamera(45,1,0.5,40000);
 const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));renderer.outputColorSpace=THREE.SRGBColorSpace;host.append(renderer.domElement);
 const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.maxPolarAngle=Math.PI/2-0.03;
 scene.add(new THREE.HemisphereLight('#ffffff','#6b7a4a',1.2));const sun=new THREE.DirectionalLight('#ffffff',1.3);sun.position.set(-1,2,1);scene.add(sun);
 const world=new THREE.Group(),overlay=new THREE.Group();scene.add(world,overlay);
 let raf=0,height=()=>0,focus=new THREE.Box3(),geo=null,exaggeration=1.5,lastKey='';
 const resize=()=>{const w=host.clientWidth||800,h=host.clientHeight||500;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();};
 new ResizeObserver(resize).observe(host);resize();
 const loop=()=>{raf=requestAnimationFrame(loop);controls.update();renderer.render(scene,camera);};loop();
 const disposeGroup=g=>{g.traverse(o=>{o.geometry?.dispose?.();for(const m of [].concat(o.material||[])){m.map?.dispose?.();m.dispose?.();}});g.clear();};
 const V=(p,h)=>new THREE.Vector3(p.x,h,-p.y);// yerel (x doğu, y kuzey) → sahne (x, y yukarı, z güney)
 const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.6});
 function label(text,pos,s){const c=document.createElement('canvas');c.width=512;c.height=112;const x=c.getContext('2d');x.fillStyle='rgba(255,255,255,.93)';x.beginPath();x.roundRect(4,4,504,104,22);x.fill();x.fillStyle='#123b31';x.font='bold 44px Segoe UI, Arial';x.textAlign='center';x.textBaseline='middle';x.fillText(text,256,58);
  const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),depthTest:false}));sp.scale.set(s*4.6,s,1);sp.position.copy(pos);sp.renderOrder=10;return sp;}
 function tube(pts,r,color,lift){const g=new THREE.Group();const dense=[];
  for(let i=1;i<pts.length;i++){const a=pts[i-1],b=pts[i],n=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/4));for(let k=i===1?0:1;k<=n;k++){const t=k/n,p={x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t};dense.push(V(p,height(p)+lift));}}
  if(dense.length<2)return g;const curve=new THREE.CatmullRomCurve3(dense,false,'catmullrom',0.01);
  g.add(new THREE.Mesh(new THREE.TubeGeometry(curve,Math.min(2000,dense.length*2),r,8,false),mat(color)));return g;}

 /** Zemin (uydu + yükseklik) yalnız konum/sınır değişince yeniden yüklenir. */
 async function ground(state){
  const pts=[...state.boundary,...state.items.flatMap(i=>i.points||[i.p])].filter(Boolean);
  if(!state.geo||!pts.length)throw Error('3D için önce konumu seçip tarla sınırını çizin.');
  const b=bbox(pts),span=Math.max(b.maxX-b.minX,b.maxY-b.minY,40),pad=span*0.45+20;
  const ext={minX:b.minX-pad,maxX:b.maxX+pad,minY:b.minY-pad,maxY:b.maxY+pad};
  const key=JSON.stringify([state.geo,ext.minX|0,ext.maxX|0,ext.minY|0,ext.maxY|0,exaggeration]);
  if(key===lastKey)return ext;lastKey=key;geo=state.geo;disposeGroup(world);
  const llMin=toLatLng({x:ext.minX,y:ext.minY},geo),llMax=toLatLng({x:ext.maxX,y:ext.maxY},geo);
  const [sat,dem]=await Promise.all([satellite(llMin,llMax),elevation(llMin,llMax,17)]);
  const c=toLatLng({x:(b.minX+b.maxX)/2,y:(b.minY+b.maxY)/2},geo),base=dem.at(c);
  height=p=>(dem.at(toLatLng(p,geo))-base)*exaggeration;
  const W=ext.maxX-ext.minX,H=ext.maxY-ext.minY,seg=110;
  const g=new THREE.PlaneGeometry(W,H,seg,seg);g.rotateX(-Math.PI/2);
  const pos=g.attributes.position,uv=g.attributes.uv;
  for(let i=0;i<pos.count;i++){const x=pos.getX(i)+ext.minX+W/2,y=-pos.getZ(i)+ext.minY+H/2;const p={x,y};pos.setXYZ(i,x,height(p),-y);const t=sat.uv(toLatLng(p,geo));uv.setXY(i,t.u,t.v);}
  g.computeVertexNormals();const tex=new THREE.CanvasTexture(sat.canvas);tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=8;
  world.add(new THREE.Mesh(g,new THREE.MeshStandardMaterial({map:tex,roughness:1})));
  focus.makeEmpty();focus.expandByPoint(V({x:b.minX,y:b.minY},-5));focus.expandByPoint(V({x:b.maxX,y:b.maxY},10));
  return ext;
 }
 /** Çizim katmanı her değişiklikte hızlıca yeniden kurulur. */
 function draw(state){
  disposeGroup(overlay);const b=state.boundary;const all=[...b,...state.items.flatMap(i=>i.points||[i.p])];if(!all.length)return;
  const bb=bbox(all),size=Math.max(bb.maxX-bb.minX,bb.maxY-bb.minY,30),vis=Math.max(0.12,size/700);
  if(b.length>2){const ring=[...b,b[0]],pts=[];for(let i=1;i<ring.length;i++){const a=ring[i-1],c=ring[i],n=Math.max(1,Math.ceil(Math.hypot(c.x-a.x,c.y-a.y)/3));for(let k=0;k<=n;k++){const p={x:a.x+(c.x-a.x)*k/n,y:a.y+(c.y-a.y)*k/n};pts.push(V(p,height(p)+0.4));}}
   overlay.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:'#ffe066'})));
   const t=tube([...b,b[0]],Math.max(0.2,size/260),'#ffd43b',0.3);overlay.add(t);}
  // Borular uzaktan da seçilebilsin diye gerçek çaptan kalın, sembolik çizilir; renkler 2D ile aynıdır.
  const latSay=state.items.filter(i=>i.type==='lateral').length,latKalin=latSay>120?0.6:1;
  for(const i of state.items){
   if(i.points){const r=i.type==='main'?Math.max(0.25,size/240):i.type==='manifold'?Math.max(0.2,size/300):Math.max(0.06,Math.min(size/900,0.45))*latKalin;
    const renk=i.type==='main'?'#1e88ff':i.type==='manifold'?'#22c55e':i.drip?'#111111':'#2a6bb0';
    overlay.add(tube(i.points,r,renk,0.15+r));}
   else{const p=i.p,h=height(p),k=Math.max(1,vis*5);
    if(i.type==='source'){const kind=i.kind||'well';
     if(kind==='tank'){const m=new THREE.Mesh(new THREE.CylinderGeometry(k*1.4,k*1.4,k*2.2,28),mat('#dfe6e9'));m.position.copy(V(p,h+k*1.1));overlay.add(m);}
     else if(kind==='canal'){const m=new THREE.Mesh(new THREE.BoxGeometry(k*10,0.3,k*2),mat('#2e86de'));m.position.copy(V(p,h+0.15));overlay.add(m);}
     else{const m=new THREE.Mesh(new THREE.CylinderGeometry(k,k,k*0.9,28),mat('#7f8c8d'));m.position.copy(V(p,h+k*0.45));overlay.add(m);const w=new THREE.Mesh(new THREE.CircleGeometry(k*0.82,28),mat('#2e86de'));w.rotation.x=-Math.PI/2;w.position.copy(V(p,h+k*0.92));overlay.add(w);}
     overlay.add(label('💧 '+({well:'Kuyu',tank:'Depo',canal:'Kanal',network:'Şebeke'}[kind]||'Su kaynağı')+(i.depth?` · ${i.depth} m`:''),V(p,h+k*2.6+vis*6),Math.max(2,vis*7)));}
    else if(i.type==='head'){const m=new THREE.Mesh(new THREE.CylinderGeometry(Math.max(0.06,vis*0.25),Math.max(0.06,vis*0.25),Math.max(0.8,vis*4),8),mat('#f2b134'));m.position.copy(V(p,h+Math.max(0.4,vis*2)));overlay.add(m);
     const ring=new THREE.Mesh(new THREE.RingGeometry(Math.max(0.5,i.range-0.25),i.range,40),new THREE.MeshBasicMaterial({color:'#4fc3f7',transparent:true,opacity:.35,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.copy(V(p,h+0.25));overlay.add(ring);}
    else if(i.type==='fitting'){const col={valve:'#c0392b',pump:'#16a085',filter:'#e67e22',tee:'#8e44ad',elbow:'#8e44ad',cap:'#34495e',reducer:'#8e44ad',airValve:'#2980b9',manometer:'#f1c40f',regulator:'#d35400',meter:'#1abc9c',fertilizer:'#27ae60',solenoid:'#c0392b',coupling:'#7f8c8d'}[i.kind]||'#c0392b';
     const s=Math.max(0.5,vis*2.2);const m=new THREE.Mesh(i.kind==='pump'?new THREE.BoxGeometry(s*2,s*1.4,s*1.2):i.kind==='filter'?new THREE.CylinderGeometry(s*0.6,s*0.6,s*2,16):new THREE.BoxGeometry(s,s,s),mat(col));m.position.copy(V(p,h+s));overlay.add(m);}
   }
  }
 }
 function view(kind){
  const box=focus.isEmpty()?new THREE.Box3().setFromObject(overlay):focus;const c=box.getCenter(new THREE.Vector3()),sz=box.getSize(new THREE.Vector3()),d=Math.max(30,sz.length());
  controls.target.copy(c);
  // Yukarıdan: tarlanın tamamı pencereye sığacak yükseklik (en-boy oranı dikkate alınır).
  const fit=Math.max(sz.x/Math.max(.3,camera.aspect),sz.z)/2/Math.tan(camera.fov*Math.PI/360)*1.18;
  if(kind==='above')camera.position.set(c.x,c.y+Math.max(20,fit),c.z+0.01);
  else if(kind==='ground')camera.position.set(c.x-d*0.5,Math.max(3,d*0.06)+c.y,c.z+d*0.55);
  else camera.position.set(c.x+d*0.45,d*0.55+c.y,c.z+d*0.75);
  camera.near=Math.max(0.2,d/4000);camera.far=d*30;camera.updateProjectionMatrix();controls.update();
 }
 async function show(state,{fit=false}={}){await ground(state);draw(state);if(fit)view('angle');}
 /** PDF için görüntü: 'above' (yukarıdan) veya 'angle' (3D). Kamera eski hâline döner. */
 function snapshot(kind){const p=camera.position.clone(),t=controls.target.clone();view(kind);controls.update();renderer.render(scene,camera);const url=renderer.domElement.toDataURL('image/jpeg',0.9);camera.position.copy(p);controls.target.copy(t);controls.update();return url;}
 function setExaggeration(x){exaggeration=x;lastKey='';}
 function dispose(){cancelAnimationFrame(raf);disposeGroup(world);disposeGroup(overlay);renderer.dispose();}
 return {show,draw,view,snapshot,setExaggeration,dispose,heightAt:p=>height(p)};
}
