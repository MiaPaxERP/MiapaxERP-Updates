using System.Data;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
public sealed class SatisPaneli:UserControl
{
 public SatisPaneli(MainWindow owner,string connection,int user,bool mamul=false){
  var service=new SatisModuluServisi(connection,user);var root=new DockPanel{Margin=new Thickness(22)};Content=root;var top=new StackPanel();DockPanel.SetDock(top,Dock.Top);root.Children.Add(top);top.Children.Add(new TextBlock{Text=mamul?"ÜRETİLEN ÜRÜNLER STOKU":"SATIŞ",FontSize=25,FontWeight=FontWeights.SemiBold});top.Children.Add(new TextBlock{Text=mamul?"Üretimden oluşan mevcut, serbest ve bloke miktarlar aynı stok defterinden izlenir. Satışla birlikte azalır.":"Cari veya perakende satış • Normal stok ve üretilen ürünler • Stok, cari ve muhasebe entegrasyonu",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,14)});
  var bar=new WrapPanel();top.Children.Add(bar);var find=new TextBox{MinWidth=260,MaxLength=100,Margin=new Thickness(0,0,8,8)};bar.Children.Add(find);var type=new ComboBox{ItemsSource=new[]{"Tüm stoklar","Yalnız üretilen ürünler"},SelectedIndex=mamul?1:0,MinWidth=220,Margin=new Thickness(0,0,8,8)};bar.Children.Add(type);Button refresh=new Button{Content="Yenile",Padding=new Thickness(12,6,12,6)},sell=new Button{Content="Yeni satış · Cari / perakende",Padding=new Thickness(12,6,12,6),Margin=new Thickness(8,0,0,8)};bar.Children.Add(refresh);if(!mamul)bar.Children.Add(sell);
  var status=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,10)};top.Children.Add(status);var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,CanUserAddRows=false};root.Children.Add(grid);
  grid.AutoGeneratingColumn+=(_,e)=>{var names=new Dictionary<string,string>{{"StokKodu","Stok kodu"},{"StokAdi","Ürün / malzeme"},{"StokTipi","Ürün türü"},{"ToplamStok","Toplam stok"},{"UretilmisMevcut","Üretilen mevcut"},{"UretilmisSatilabilir","Üretilen satılabilir"},{"UretilmisBloke","Üretilen bloke"},{"Satilabilir","Toplam satılabilir"},{"SatisFiyati","Satış fiyatı"},{"ParaBirimi","Döviz"}};if(e.PropertyName=="Id"){e.Cancel=true;return;}if(names.TryGetValue(e.PropertyName,out var label))e.Column.Header=label;if(e.PropertyName=="StokAdi")e.Column.MinWidth=200;};
  async Task Load(){refresh.IsEnabled=false;try{bool produced=type.SelectedIndex==1;string query=find.Text;grid.ItemsSource=(await Task.Run(()=>service.Stoklar(produced,query))).DefaultView;status.Text="Toplam stok tüm stoğu; üretilen mevcut bunun üretimden kalan bölümünü gösterir. Bu iki miktar birbirine eklenmez. Bloke ve rezerve miktar satılamaz.";}catch(Exception e){status.Text=e.Message;}finally{refresh.IsEnabled=true;}}
  refresh.Click+=async(_,_)=>await Load();type.SelectionChanged+=async(_,_)=>await Load();Loaded+=async(_,_)=>await Load();sell.Click+=(_,_)=>{var w=new HizliSatisPenceresi(connection,user,true){Owner=owner};w.Closed+=async(_,_)=>await Load();w.Show();};
 }
}
