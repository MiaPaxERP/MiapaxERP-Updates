import test from 'node:test';
import assert from 'node:assert/strict';
import {openDatabase} from '../src/database.js';
import {syncAll} from '../src/sync-all.js';
test('sync-all sends every license to configured own origin',async()=>{
 const db=openDatabase(':memory:');const now=new Date().toISOString();
 const pair=await crypto.subtle.generateKey({name:'RSA-PSS',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
 const env={LICENSE_PRIVATE_PKCS8:Buffer.from(await crypto.subtle.exportKey('pkcs8',pair.privateKey)).toString('base64'),LICENSE_CLOUD_ORIGIN:'https://lisans.firma.com'};
 const cid=crypto.randomUUID();db.prepare('INSERT INTO customers(id,name,sector,contact,notes,active,revision,created_at,tax_info,email) VALUES(?,?,?,?,?,?,?,?,?,?)').run(cid,'Firma','KAFE','','',1,1,now,'{}','a@b.com');
 for(let i=0;i<2;i++)db.prepare('INSERT INTO licenses(id,customer_id,key_hash,label,modules,max_devices,starts_at,expires_at,active,revision,created_at,mail_status,module_expires) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').run(crypto.randomUUID(),cid,'a'.repeat(63)+i,'L'+i,'["STOK"]',1,now,null,1,1,now,'not_sent','{}');
 const urls=[];const r=await syncAll(db,env,async(url)=>{urls.push(url);return Response.json({ok:true});});
 assert.equal(r.total,2);assert.equal(r.ok,2);assert.ok(urls.every(u=>u==='https://lisans.firma.com/api/license-sync'));
});
