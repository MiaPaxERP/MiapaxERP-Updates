using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed record UrunEtiketBilgisi(int Stok,string Kod,string Ad,string Birim,string Ozellikler,int? PaketId,int PaketIciAdet,int PaketSayisi,string Emir){public string Baslik=>PaketId.HasValue?$"{Ad} · Kayıt #{PaketId} · {PaketIciAdet} {Birim}/paket × {PaketSayisi} paket":Ad;}
public sealed class UrunEtiketServisi(string connection,int user)
{
 readonly Action<SqlConnection,SqlTransaction?,string>? fixtureCheck;
 internal UrunEtiketServisi(string connection,int user,Action<SqlConnection,SqlTransaction?,string> check):this(connection,user){fixtureCheck=check;}
 public UrunEtiketBilgisi[] Bilgiler(int id,bool paket){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<UrunEtiketBilgisi[]>(connection,"UrunEtiketServisi.Bilgiler","",[id,paket]);
  var access=new ErpModulServisi(connection,user);using var c=access.Ac();if(fixtureCheck is null)access.Yetki(c,null,paket?"PRODUCTION.VIEW":"STOCK.VIEW");else fixtureCheck(c,null,paket?"PRODUCTION.VIEW":"STOCK.VIEW");
  using var q=ErpModulServisi.Komut(c,null,paket?"SELECT s.*,p.Id EtiketPaketId,p.PaketIciAdet EtiketAdet,p.PaketSayisi EtiketSayisi,u.UretimEmriNo EtiketEmir FROM dbo.UretimPaketlemeKayitlari p JOIN dbo.UretimEmirleri u ON u.Id=p.UretimEmriId JOIN dbo.StokKartlari s ON s.Id=u.MamulStokId WHERE u.Id=@id AND u.Durum IN(N'Üretimde',N'Tamamlandı') AND p.PaketIciAdet>0 AND p.PaketSayisi>0 ORDER BY p.Id":"SELECT * FROM dbo.StokKartlari WHERE Id=@id AND Aktif=1",("@id",id));
  using var r=q.ExecuteReader();var fields=Enumerable.Range(0,r.FieldCount).ToDictionary(r.GetName,StringComparer.OrdinalIgnoreCase);var rows=new List<UrunEtiketBilgisi>();
  while(r.Read()){
   string V(string name)=>fields.TryGetValue(name,out int i)&&!r.IsDBNull(i)?Convert.ToString(r.GetValue(i),CultureInfo.GetCultureInfo("tr-TR"))??"":"";
   string[] names=["CapMm","BasincSinifi","UzunlukMetre","EtKalinligiMm","Renk","HammaddeTuru","AgirlikKg","Aciklama"];
   string[] labels=["Çap (mm)","Basınç","Boy (m)","Et (mm)","Renk","Malzeme","Ağırlık (kg)","Açıklama"];
   string info=string.Join(" · ",names.Select((n,i)=>V(n) is {Length:>0} v?labels[i]+": "+v:"").Where(x=>x.Length>0));
   rows.Add(new(Convert.ToInt32(r["Id"]),V("StokKodu"),V("StokAdi"),V("Birim"),info,paket?Convert.ToInt32(r["EtiketPaketId"]):null,paket?Convert.ToInt32(r["EtiketAdet"]):1,paket?Convert.ToInt32(r["EtiketSayisi"]):1,paket?V("EtiketEmir"):""));
  }return rows.ToArray();
 }
 public static string PaketBarkodu(int paket,int sira){if(paket<1||sira<1)throw new ArgumentException("Geçerli paket ve sıra girin.");return $"MPXPK{paket:D9}-{sira:D6}";}
 public static bool PaketCoz(string text,out int paket,out int sira){paket=sira=0;if(text is null||!text.StartsWith("MPXPK",StringComparison.Ordinal))return false;var p=text[5..].Split('-');return p.Length==2&&int.TryParse(p[0],NumberStyles.None,CultureInfo.InvariantCulture,out paket)&&int.TryParse(p[1],NumberStyles.None,CultureInfo.InvariantCulture,out sira)&&paket>0&&sira>0&&PaketBarkodu(paket,sira)==text;}
}
