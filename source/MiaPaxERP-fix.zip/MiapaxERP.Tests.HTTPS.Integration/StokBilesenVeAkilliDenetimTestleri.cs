using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;

public class StokBilesenVeAkilliDenetimTestleri
{
 static void Sql(SqlConnection c,string sql){using var q=new SqlCommand(sql,c);q.ExecuteNonQuery();}

 [Fact]public void Ean13KontrolHanesiDogruHesaplanir(){
  Assert.Equal("4006381333931",StokBilesenServisi.Ean13("400638133393"));
  Assert.Equal("2900000000001",StokBilesenServisi.Ean13("290000000000"));
  Assert.Throws<ArgumentException>(()=>StokBilesenServisi.Ean13("12345"));
  Assert.Equal("96385074",StokBilesenServisi.Ean8("9638507"));Assert.Equal("20000004",StokBilesenServisi.Ean8("2000000"));
 }

 [Fact]public void StokIcindeStokAgaciDongusuzVeBarkodluCalisir(){
  string name="MiapaxParca_"+Guid.NewGuid().ToString("N");
  using var master=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=5");master.Open();Sql(master,"CREATE DATABASE ["+name+"]");
  try{
   string cs=new SqlConnectionStringBuilder(master.ConnectionString){InitialCatalog=name}.ConnectionString;using var c=new SqlConnection(cs);c.Open();
   Sql(c,"""
    CREATE TABLE dbo.Kullanicilar(Id int PRIMARY KEY,Aktif bit,AdSoyad nvarchar(100),KullaniciAdi nvarchar(50));INSERT dbo.Kullanicilar VALUES(1,1,'Admin','admin'),(3,1,'Stok','stok'),(4,1,'Bakan','bakan');
    CREATE TABLE dbo.KullaniciRolleri(Id int PRIMARY KEY,RolAdi nvarchar(80),Aktif bit);INSERT dbo.KullaniciRolleri VALUES(1,N'Yönetici',1);
    CREATE TABLE dbo.KullaniciRolAtamalari(KullaniciId int,RolId int);INSERT dbo.KullaniciRolAtamalari VALUES(1,1);
    CREATE TABLE dbo.TestYetki(KullaniciId int,YetkiKodu varchar(80),Yetkili bit);INSERT dbo.TestYetki VALUES(3,'STOCK.VIEW',1),(3,'STOCK.EDIT',1),(4,'STOCK.VIEW',1);
    CREATE TABLE dbo.StokTipleri(Id int PRIMARY KEY,Ad nvarchar(50),Aktif bit);INSERT dbo.StokTipleri VALUES(7,N'Mamul',1);
    CREATE TABLE dbo.StokKartlari(Id int PRIMARY KEY,StokKodu nvarchar(50) UNIQUE,StokAdi nvarchar(200),StokTipi nvarchar(30),Birim nvarchar(20),Aktif bit,MinimumStokMiktari decimal(18,3) NULL);
    INSERT dbo.StokKartlari VALUES(1,'POMPA',N'Pompa',N'Mamul','Adet',1,NULL),(2,'MOTOR',N'Motor',N'Mamul','Adet',1,NULL),(3,'VIDA',N'Vida',N'Mamul','Adet',1,NULL),(4,'ESKI',N'Eski parça',N'Mamul','Adet',0,NULL);
    CREATE TABLE dbo.MPXNext_Barkod(Barkod varchar(100) COLLATE Latin1_General_100_BIN2 PRIMARY KEY,Stok int NOT NULL REFERENCES dbo.StokKartlari(Id),Carpan decimal(18,3) NOT NULL DEFAULT 1,Olusturan int NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
    INSERT dbo.MPXNext_Barkod(Barkod,Stok,Olusturan) VALUES('2900000000008',3,1);
    CREATE TABLE dbo.StokBakiyeleri(StokKartId int,Birim nvarchar(20),Miktar decimal(18,3),SonGuncelleme datetime2);INSERT dbo.StokBakiyeleri VALUES(2,'Adet',-5,SYSUTCDATETIME());
    """);
   Sql(c,"CREATE VIEW dbo.vw_KullaniciEtkinYetkileri AS SELECT * FROM dbo.TestYetki");
   bool Has(int u,string code){if(u==1)return true;using var q=new SqlCommand("SELECT COUNT(*) FROM dbo.TestYetki WHERE KullaniciId=@u AND YetkiKodu=@p AND Yetkili=1",c);q.Parameters.AddWithValue("@u",u);q.Parameters.AddWithValue("@p",code);return Convert.ToInt32(q.ExecuteScalar())>0;}
   Action<SqlConnection,SqlTransaction?,string> Gate(int u)=>(_,_,code)=>{if(!Has(u,code))throw new UnauthorizedAccessException(code);};
   var s=new StokBilesenServisi(cs,3,Gate(3));
   s.Kaydet(1,2,1,"ana motor");s.Kaydet(2,3,4,"");
   var direct=s.Bilesenler(1);Assert.Single(direct);Assert.Equal("MOTOR",direct[0].Kod);Assert.Equal(1,direct[0].AltParcaSayisi);
   var tree=s.Agac(1);Assert.Equal(2,tree.Length);Assert.Equal(2,tree[1].Seviye);Assert.Equal(4m,tree[1].Toplam);Assert.Equal("2900000000008",tree[1].Barkodlar);
   s.Kaydet(1,2,2,"");Assert.Equal(2m,s.Bilesenler(1)[0].Miktar);
   Assert.Throws<InvalidOperationException>(()=>s.Kaydet(3,1,1,""));
   Assert.Throws<ArgumentException>(()=>s.Kaydet(1,1,1,""));
   Assert.Throws<ArgumentException>(()=>s.Kaydet(1,4,1,""));
   Assert.Throws<ArgumentException>(()=>s.Kaydet(1,3,0,""));
   Assert.Throws<UnauthorizedAccessException>(()=>new StokBilesenServisi(cs,4,Gate(4)).Kaydet(1,3,1,""));
   Assert.Contains(s.Ara("2900000000008"),x=>x.Id==3);Assert.Contains(s.Ara("mot"),x=>x.Id==2);
   Assert.Equal(7,s.AnaTipi(1));Assert.Equal("POMPA-P01",s.SonrakiParcaKodu(1));Assert.Equal(2,s.IdBul("MOTOR"));
   string barkod=s.YeniBarkod();Assert.Matches("^2[0-9]{7}$",barkod);Assert.Equal(barkod,StokBilesenServisi.Ean8(barkod[..7]));
   // Akıllı denetim: eksik tablolar atlanır, yalnız yetkili alanda bulgu üretilir, kayıt değiştirilmez.
   var bulgular=new AkilliDenetimServisi(cs,1,code=>Has(1,code)).Incele();
   Assert.Contains(bulgular,x=>x.Alan=="Stok"&&x.Onem=="Kritik"&&x.Aciklama.Contains("Motor"));
   Assert.Contains(bulgular,x=>x.Anahtar.StartsWith("parca-barkod-",StringComparison.Ordinal)&&x.Aciklama.Contains("Motor"));
   Assert.DoesNotContain(bulgular,x=>x.Alan=="Muhasebe");
   Assert.Equal(-5m,Convert.ToDecimal(new SqlCommand("SELECT Miktar FROM dbo.StokBakiyeleri WHERE StokKartId=2",c).ExecuteScalar()));
   Assert.DoesNotContain(new AkilliDenetimServisi(cs,4,code=>Has(4,code)).Incele(),x=>x.Alan!="Stok");
   s.Sil(1,2);Assert.Empty(s.Bilesenler(1));
  }
  finally{SqlConnection.ClearAllPools();Sql(master,"ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]");}
 }
}
