using System.Globalization;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Linq;
namespace MiapaxERP.Desktop;
public sealed record GuncelHaber(string Id,string Baslik,string Url,string Kategori,DateTimeOffset Yayin,bool SonDakika);
public static class HaberAkisi
{
 static readonly HttpClient http=new(new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(15),MaxResponseContentBufferSize=2*1024*1024};
 public static readonly (string Url,string Category,bool Breaking)[] Kaynaklar=[("https://www.trthaber.com/turkiye_articles.rss","Türkiye",false),("https://www.trthaber.com/dunya_articles.rss","Dünya",false),("https://www.trthaber.com/sondakika.rss","Son dakika · TRT Haber",true),("https://news.google.com/rss/search?q=boru%20sulama%20PE100%20when%3A7d&hl=tr&gl=TR&ceid=TR%3Atr","Boru ve sulama",false)];
 public static GuncelHaber[] Coz(string xml,string category,bool breaking,DateTimeOffset now){
  using var reader=XmlReader.Create(new System.IO.StringReader(xml),new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null,MaxCharactersInDocument=2*1024*1024});var doc=XDocument.Load(reader);var rows=new List<GuncelHaber>();
  foreach(var item in doc.Descendants("item").Take(100)){string title=((string?)item.Element("title")??"").Trim(),link=((string?)item.Element("link")??"").Trim();if(title.Length<5||title.Length>500||!Uri.TryCreate(link,UriKind.Absolute,out var uri)||uri.Scheme!="https"||!string.IsNullOrEmpty(uri.UserInfo))continue;if(!DateTimeOffset.TryParse((string?)item.Element("pubDate"),CultureInfo.InvariantCulture,DateTimeStyles.AssumeUniversal,out var date)||date>now.AddMinutes(5)||date<now.AddDays(-7))continue;string id=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(link)));rows.Add(new(id,title,link,category,date,breaking));}return rows.ToArray();
 }
 public static async Task<GuncelHaber[]> Getir(CancellationToken ct=default){var all=await Task.WhenAll(Kaynaklar.Select(async source=>{try{var xml=await http.GetStringAsync(source.Url,ct);return Coz(xml,source.Category,source.Breaking,DateTimeOffset.UtcNow);}catch(Exception e)when(e is HttpRequestException or TaskCanceledException or XmlException){return Array.Empty<GuncelHaber>();}}));return all.SelectMany(x=>x).GroupBy(x=>x.Id).Select(g=>g.First() with{SonDakika=g.Any(x=>x.SonDakika)}).OrderByDescending(x=>x.Yayin).ToArray();}
}
