// MiapaxERP · PDF'ten metin çıkarma (Firma bilgileri otomatik doldurma). Sayfa görünmez; masaüstü PDF baytlarını gönderir, metni geri alır.
// Ağ erişimi yoktur; yalnız paketle gelen PDF.js kullanılır.
const pdfjs=await import('../lib/pdfjs/build/pdf.mjs');
pdfjs.GlobalWorkerOptions.workerSrc=new URL('../lib/pdfjs/build/pdf.worker.mjs',import.meta.url).href;
const MAX_PAGES=15;
async function extract(base64){
 const bin=atob(base64),data=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)data[i]=bin.charCodeAt(i);
 const doc=await pdfjs.getDocument({data,isEvalSupported:false,enableXfa:false,cMapUrl:new URL('../lib/pdfjs/cmaps/',import.meta.url).href,cMapPacked:true,standardFontDataUrl:new URL('../lib/pdfjs/standard_fonts/',import.meta.url).href,wasmUrl:new URL('../lib/pdfjs/wasm/',import.meta.url).href}).promise;
 const pages=[];
 for(let n=1;n<=Math.min(doc.numPages,MAX_PAGES);n++){
  const page=await doc.getPage(n),content=await page.getTextContent();let line='',lastY=null;const lines=[];
  for(const item of content.items){
   if(!('str' in item))continue;const y=Math.round(item.transform[5]);
   if(lastY!==null&&Math.abs(y-lastY)>2){lines.push(line);line='';}
   line+=(line&&!line.endsWith(' ')&&item.str&&!item.str.startsWith(' ')?' ':'')+item.str;lastY=y;if(item.hasEOL){lines.push(line);line='';lastY=null;}
  }
  if(line)lines.push(line);pages.push(lines.map(l=>l.replace(/\s+/g,' ').trim()).filter(Boolean).join('\n'));
 }
 return {text:pages.join('\n\f\n'),pages:doc.numPages};
}
window.chrome?.webview?.addEventListener('message',async e=>{
 const d=e.data||{};if(d.action!=='pdfText')return;
 try{const r=await extract(String(d.data||''));window.chrome.webview.postMessage({action:'pdfTextResult',id:d.id,text:r.text,pages:r.pages});}
 catch(err){window.chrome.webview.postMessage({action:'pdfTextResult',id:d.id,error:String(err?.message||err)});}
});
window.chrome?.webview?.postMessage({action:'pdfTextReady'});
