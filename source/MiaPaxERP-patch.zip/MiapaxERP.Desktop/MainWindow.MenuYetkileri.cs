using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
 readonly HashSet<string> menuYetkileri=new(StringComparer.OrdinalIgnoreCase);
 int menuYetkiKullanici,menuYetkiIstegi;DispatcherTimer? menuYetkiSaat;
 void MenuYetkiIzlemesiniBagla(){
  MenuYetkiGorunumunuUygula();
  Loaded+=(_,_)=>{menuYetkiSaat=new(){Interval=TimeSpan.FromSeconds(30)};menuYetkiSaat.Tick+=(_,_)=>{if(IsActive)_=MenuYetkileriniYenileAsync();};menuYetkiSaat.Start();};
  Closed+=(_,_)=>{menuYetkiSaat?.Stop();menuYetkiIstegi++;};
 }
 async Task MenuYetkileriniYenileAsync(){
  int user=aktifKullanici?.KullaniciId??0,request=++menuYetkiIstegi;
  if(menuYetkiKullanici!=user){menuYetkileri.Clear();menuYetkiKullanici=user;MenuYetkiGorunumunuUygula();}
  if(DemoModu||user==0){MenuYetkiGorunumunuUygula();return;}
  try{if(HttpsOturumu.Istemci is {} remote)await remote.ProfiliYenile();var codes=await Task.Run(()=>new MenuYetkiServisi(baglantiAdresi,user).Yetkiler());if(request!=menuYetkiIstegi||aktifKullanici?.KullaniciId!=user)return;menuYetkileri.Clear();menuYetkileri.UnionWith(codes);}
  catch{if(request!=menuYetkiIstegi)return;menuYetkileri.Clear();}
  MenuYetkiGorunumunuUygula();
 }
 void MenuYetkiGorunumunuUygula(){
  if(TemaMenuOgeleri is null)return;
  if(menuYetkiKullanici!=(aktifKullanici?.KullaniciId??0))menuYetkileri.Clear();
  foreach(var b in TemaMenuOgeleri.Children.OfType<Button>()){
   bool allowed=DemoModu||aktifKullanici is not null&&MenuYetkiKurallari.Gorunur(b.Name,b.Tag as string,menuYetkileri,LisansOturumu.ModulVar,LisansOturumu.SektorKodu);
   b.Visibility=allowed?Visibility.Visible:Visibility.Collapsed;
  }
  if(sonMenuHedefi is {Visibility:not Visibility.Visible}){sonMenuHedefi=null;TumIcerikleriGizle();AnaSayfaIcerik.Visibility=Visibility.Visible;SayfaBasligi.Text="Ana Sayfa";}
 }
}
