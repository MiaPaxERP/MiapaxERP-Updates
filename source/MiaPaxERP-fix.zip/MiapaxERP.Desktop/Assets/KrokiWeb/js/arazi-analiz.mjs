// MiapaxERP Arazi Stüdyosu · toprak, meteoroloji ve arazi eğimi analizi.
// Kaynaklar (anahtar gerektirmez): ISRIC SoilGrids 2.0 (CC BY 4.0), Open-Meteo (CC BY 4.0) hava, iklim arşivi ve yükseklik.
// Sonuçlar ön değerlendirmedir; laboratuvar toprak analizi ve yerel istasyon verisinin yerine geçmez.
import {texture,soilWater,phNote,omNote,irrigationAdvice,toLatLng,bbox,inside,r1,r2} from './arazi-model.mjs?v=arazi1';

const zaman=(ms,p)=>Promise.race([p,new Promise((_,rej)=>setTimeout(()=>rej(Error('Zaman aşımı')),ms))]);
async function json(url,ms=25000){const r=await zaman(ms,fetch(url,{headers:{Accept:'application/json'}}));if(!r.ok)throw Error(`Servis yanıtı ${r.status}`);return r.json();}
const iso=d=>d.toISOString().slice(0,10);

/** SoilGrids 0–30 cm ağırlıklı ortalama değerler ve WRB toprak sınıfı. */
export async function soil(lat,lng){
 const props=['bdod','cec','clay','nitrogen','phh2o','sand','silt','soc'];
 const u=`https://rest.isric.org/soilgrids/v2.0/properties/query?lon=${lng.toFixed(5)}&lat=${lat.toFixed(5)}&${props.map(p=>'property='+p).join('&')}&depth=0-5cm&depth=5-15cm&depth=15-30cm&value=mean`;
 let j;try{j=await json(u,60000);}catch(e){throw Error(e.message==='Zaman aşımı'?'Toprak servisi (SoilGrids) yavaş yanıt verdi; biraz sonra "Analizi yenile" ile tekrar deneyin.':e.message);}const w={'0-5cm':5,'5-15cm':10,'15-30cm':15},out={};
 for(const layer of j?.properties?.layers??[]){const d=layer.unit_measure?.d_factor||1;let s=0,t=0;
  for(const dep of layer.depths??[]){const v=dep.values?.mean;if(v==null)continue;const k=w[dep.label]||0;s+=v/d*k;t+=k;}
  out[layer.name]=t?s/t:null;}
 if(out.clay==null&&out.sand==null)throw Error('Bu konum için toprak verisi yok (su, yerleşim alanı veya kayalık olabilir).');
 const clay=out.clay/10,sand=out.sand/10,silt=out.silt/10;// g/kg → %
 const tex=texture(sand,clay,silt);const water=soilWater(tex);const om=omNote(out.soc??0);
 let wrb=null;try{const c=await json(`https://rest.isric.org/soilgrids/v2.0/classification/query?lon=${lng.toFixed(5)}&lat=${lat.toFixed(5)}&number_classes=3`,20000);wrb={name:c.wrb_class_name,classes:(c.wrb_class_probability||[]).map(([n,p])=>({name:n,p}))};}catch{/* sınıf isteğe bağlı */}
 return {source:'ISRIC SoilGrids 2.0 (250 m çözünürlüklü tahmin, 0–30 cm)',ph:r2(out.phh2o??0),phNote:phNote(out.phh2o??7),clay:r1(clay),sand:r1(sand),silt:r1(silt),texture:tex,
  soc:r1(out.soc??0),organicMatter:om.om,omNote:om.note,nitrogen:r2(out.nitrogen??0),cec:r1(out.cec??0),bulkDensity:r2(out.bdod??0),infiltration:water.infiltration,availableWater:water.available,waterNote:water.note,wrb,
  advice:soilAdvice({ph:out.phh2o,clay,sand,om:om.om,cec:out.cec,n:out.nitrogen})};
}
function soilAdvice({ph,clay,sand,om,cec,n}){const a=[];
 if(ph>7.8)a.push('Alkali toprakta asit karakterli (amonyum sülfat, fosforik asit) gübreler ve şelatlı demir tercih edin.');
 if(ph<5.8)a.push('Asidik toprakta kireçleme ile pH 6–7 aralığına çekilmesi verimi artırır.');
 if(om<2)a.push('Organik madde düşük: hayvan gübresi, kompost veya yeşil gübreleme önerilir.');
 if(clay>40)a.push('Kil oranı yüksek: derin sürüm/dip kazan ve drenaj, yağmurlamada düşük yağış hızı.');
 if(sand>65)a.push('Kumlu toprak: sık ve az sulama, gübreyi parça parça (fertigasyon) verin.');
 if(cec!=null&&cec<10)a.push('Katyon değişim kapasitesi düşük: besin tutma zayıf, fertigasyon uygun.');
 if(n!=null&&n<1)a.push('Toplam azot düşük: ekim öncesi taban azotlu gübreleme planlayın.');
 if(!a.length)a.push('Toprak özellikleri genel olarak dengeli görünüyor; ekim öncesi laboratuvar analiziyle doğrulayın.');return a;}

/** 7 günlük tahmin + son 12 ayın iklim özeti. */
export async function weather(lat,lng){
 const f=await json(`https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,et0_fao_evapotranspiration,wind_speed_10m_max&timezone=auto&forecast_days=7`);
 const d=f.daily||{};const days=(d.time||[]).map((t,i)=>({date:t,max:d.temperature_2m_max?.[i],min:d.temperature_2m_min?.[i],rain:d.precipitation_sum?.[i]??0,prob:d.precipitation_probability_max?.[i],et0:d.et0_fao_evapotranspiration?.[i]??0,wind:d.wind_speed_10m_max?.[i]}));
 const end=new Date();end.setDate(end.getDate()-6);const start=new Date(end);start.setFullYear(start.getFullYear()-1);start.setDate(start.getDate()+1);
 let climate=null;
 try{
  const a=await json(`https://archive-api.open-meteo.com/v1/archive?latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}&start_date=${iso(start)}&end_date=${iso(end)}&daily=precipitation_sum,et0_fao_evapotranspiration,temperature_2m_max,temperature_2m_min&timezone=auto`,35000);
  const ad=a.daily||{},months=new Map();let rain=0,et0=0,gdd=0,frost=0,lastFrost=null,hot=0;
  (ad.time||[]).forEach((t,i)=>{const p=ad.precipitation_sum?.[i]??0,e=ad.et0_fao_evapotranspiration?.[i]??0,mx=ad.temperature_2m_max?.[i],mn=ad.temperature_2m_min?.[i];rain+=p;et0+=e;
   if(mx!=null&&mn!=null){gdd+=Math.max(0,(mx+mn)/2-10);if(mn<0){frost++;const dt=new Date(t);if(dt.getMonth()<6)lastFrost=t;}if(mx>35)hot++;}
   const k=t.slice(0,7);const m=months.get(k)||{month:k,rain:0,et0:0};m.rain+=p;m.et0+=e;months.set(k,m);});
  climate={period:`${iso(start)} – ${iso(end)}`,rain:Math.round(rain),et0:Math.round(et0),deficit:Math.round(et0-rain),gdd:Math.round(gdd),frostDays:frost,lastSpringFrost:lastFrost,hotDays:hot,months:[...months.values()].map(m=>({month:m.month,rain:Math.round(m.rain),et0:Math.round(m.et0)}))};
 }catch{/* arşiv isteğe bağlı */}
 const c=f.current||{};
 return {source:'Open-Meteo (tahmin ve ERA5 tabanlı iklim arşivi)',timezone:f.timezone,current:{temp:c.temperature_2m,humidity:c.relative_humidity_2m,wind:c.wind_speed_10m,code:c.weather_code},days,
  avgEt0:r2(days.reduce((s,x)=>s+(x.et0||0),0)/Math.max(1,days.length)),avgRain:r2(days.reduce((s,x)=>s+(x.rain||0),0)/Math.max(1,days.length)),weekRain:r1(days.reduce((s,x)=>s+(x.rain||0),0)),climate,
  alerts:weatherAlerts(days)};
}
function weatherAlerts(days){const a=[];
 const frost=days.filter(x=>x.min!=null&&x.min<=0);if(frost.length)a.push(`Don riski: ${frost.map(x=>x.date.slice(5)).join(', ')} (en düşük ${Math.min(...frost.map(x=>x.min))} °C). Hassas ürünleri koruyun; donlu gecede yağmurlama ile koruma yapılabilir.`);
 const wind=days.filter(x=>x.wind>=35);if(wind.length)a.push(`Kuvvetli rüzgâr (≥35 km/sa): ${wind.map(x=>x.date.slice(5)).join(', ')}. Bu günlerde yağmurlama yerine gece sulayın veya damla kullanın.`);
 const heavy=days.filter(x=>x.rain>=15);if(heavy.length)a.push(`Yoğun yağış bekleniyor: ${heavy.map(x=>x.date.slice(5)+' '+x.rain+' mm').join(', ')}. Sulamayı erteleyin, drenajı kontrol edin.`);
 const hot=days.filter(x=>x.max>=35);if(hot.length)a.push(`Sıcak günler (≥35 °C): ${hot.map(x=>x.date.slice(5)).join(', ')}. Sulamayı sabah erken veya akşam yapın.`);
 if(!a.length)a.push('Önümüzdeki 7 günde olağan dışı hava olayı görünmüyor.');return a;}

/** Tarla içinden örnek noktalarla yükseklik, eğim ve bakı (Open-Meteo yükseklik, 90 m DEM). */
export async function terrain(boundary,geo){
 if(boundary.length<3)throw Error('Tarla sınırı yok.');const b=bbox(boundary),pts=[];
 const n=6;for(let i=0;i<=n;i++)for(let k=0;k<=n;k++){const p={x:b.minX+(b.maxX-b.minX)*i/n,y:b.minY+(b.maxY-b.minY)*k/n};if(inside(p,boundary)||i===0||k===0||i===n||k===n)pts.push(p);}
 const sample=pts.slice(0,100),ll=sample.map(p=>toLatLng(p,geo));
 const j=await json(`https://api.open-meteo.com/v1/elevation?latitude=${ll.map(x=>x.lat.toFixed(5)).join(',')}&longitude=${ll.map(x=>x.lng.toFixed(5)).join(',')}`);
 const e=j.elevation||[];if(!e.length)throw Error('Yükseklik alınamadı.');
 let hi=-1e9,lo=1e9,ph=null,pl=null;e.forEach((v,i)=>{if(v>hi){hi=v;ph=sample[i];}if(v<lo){lo=v;pl=sample[i];}});
 const run=Math.max(1,Math.hypot(ph.x-pl.x,ph.y-pl.y));const slope=r2((hi-lo)/run*100);
 const ang=Math.atan2(pl.x-ph.x,pl.y-ph.y)*180/Math.PI;const yon=['Kuzey','Kuzeydoğu','Doğu','Güneydoğu','Güney','Güneybatı','Batı','Kuzeybatı'][Math.round(((ang+360)%360)/45)%8];
 return {source:'Open-Meteo yükseklik (Copernicus DEM 90 m)',min:Math.round(lo),max:Math.round(hi),diff:r1(hi-lo),slope,aspect:yon,highPoint:ph,lowPoint:pl,
  note:slope<2?'Arazi düz; tek yönlü hatlar sorunsuz.':slope<5?'Hafif eğimli; hatları eğime dik (eş yükselti boyunca) döşeyin.':slope<10?'Orta eğim; basınç ayarlı (PC) damlatıcı ve bölüm vanası başına basınç düzenleyici önerilir.':'Dik eğim; teraslama veya eş yükselti hatları ve PC damlatıcı gerekli, yağmurlamada yüzey akışına dikkat.'};
}

/** Tüm analizler; her biri bağımsız hata verebilir. */
export async function analyse(state){
 if(!state.geo)throw Error('Önce haritada konumu belirleyin.');
 const c=state.boundary.length>2?(()=>{const b=bbox(state.boundary);return toLatLng({x:(b.minX+b.maxX)/2,y:(b.minY+b.maxY)/2},state.geo);})():state.geo;
 // Merkez yerleşim/su alanına düşerse tarla içindeki çeyrek noktalar denenir.
 const soilAny=async()=>{let first;const b=state.boundary.length>2?bbox(state.boundary):null;
  const cand=[c,...(b?[[.25,.25],[.75,.75],[.25,.75],[.75,.25]].map(([u,v])=>({x:b.minX+(b.maxX-b.minX)*u,y:b.minY+(b.maxY-b.minY)*v})).filter(p=>inside(p,state.boundary)).map(p=>toLatLng(p,state.geo)):[])];
  for(const p of cand.slice(0,3)){try{return await soil(p.lat,p.lng);}catch(e){first??=e;if(/yavaş/.test(e.message))throw e;}}throw first;};
 const [s,w,t]=await Promise.allSettled([soilAny(),weather(c.lat,c.lng),state.boundary.length>2?terrain(state.boundary,state.geo):Promise.reject(Error('Tarla sınırı yok'))]);
 const out={at:new Date().toISOString(),point:c,soil:s.status==='fulfilled'?s.value:{error:s.reason?.message||'Toprak verisi alınamadı'},weather:w.status==='fulfilled'?w.value:{error:w.reason?.message||'Hava verisi alınamadı'},terrain:t.status==='fulfilled'?t.value:{error:t.reason?.message||'Eğim hesaplanamadı'}};
 const area=state.boundary.length>2?Math.abs(state.boundary.reduce((s2,a,i)=>{const b=state.boundary[(i+1)%state.boundary.length];return s2+a.x*b.y-b.x*a.y;},0)/2):1000;
 if(!out.weather.error){
  out.irrigation=irrigationAdvice({et0:out.weather.avgEt0,rain:out.weather.avgRain,cropName:state.crop,areaM2:area,texture:out.soil.texture,method:state.method});
  // Tasarım (en sıcak ay) ihtiyacı: pompa ve bölüm sayısı bu değere göre seçilmelidir.
  const ms=out.weather.climate?.months||[];if(ms.length){const pk=ms.reduce((a,m)=>(m.et0-m.rain)>(a.et0-a.rain)?m:a,ms[0]);const gun=new Date(Number(pk.month.slice(0,4)),Number(pk.month.slice(5,7)),0).getDate();
   const p=irrigationAdvice({et0:pk.et0/gun,rain:pk.rain/gun,cropName:state.crop,areaM2:area,texture:out.soil.texture,method:state.method});
   out.irrigation.peak={month:pk.month,etc:p.etc,need:p.need,dailyM3:p.dailyM3,interval:p.interval,dose:p.dose,text:`En yoğun ay (${new Date(pk.month+'-01').toLocaleDateString('tr-TR',{month:'long'})}): ${p.text}`};}
 }
 return out;
}
