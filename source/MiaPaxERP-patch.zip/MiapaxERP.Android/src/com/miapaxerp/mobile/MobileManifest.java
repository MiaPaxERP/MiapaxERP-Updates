package com.miapaxerp.mobile;
import java.security.*;import java.security.spec.*;import java.nio.charset.StandardCharsets;import java.util.Base64;
public final class MobileManifest{
 public static int compare(String a,String b){String[] x=a.split("\\."),y=b.split("\\.");for(int i=0;i<Math.max(x.length,y.length);i++){int d=Integer.compare(i<x.length?Integer.parseInt(x[i]):0,i<y.length?Integer.parseInt(y[i]):0);if(d!=0)return d;}return 0;}
 public static void verify(PublicKey key,String version,String url,String sha,String signature)throws GeneralSecurityException{
  if(!version.matches("[0-9]{1,5}(\\.[0-9]{1,5}){2,3}")||!sha.matches("[a-f0-9]{64}")||!url.equals("https://github.com/MiaPaxERP/MiapaxERP-Updates/releases/download/v"+version+"/MiaPaxERP-Mobil-v"+version+".apk"))throw new GeneralSecurityException("Mobil güncelleme adresi geçersiz.");
  Signature sig;try{sig=Signature.getInstance("RSASSA-PSS");}catch(GeneralSecurityException e){sig=Signature.getInstance("SHA256withRSA/PSS");}sig.initVerify(key);sig.setParameter(new PSSParameterSpec("SHA-256","MGF1",MGF1ParameterSpec.SHA256,32,1));sig.update((version+"\nMobil\n"+url+"\n"+sha+"\n").getBytes(StandardCharsets.UTF_8));try{if(!sig.verify(Base64.getDecoder().decode(signature)))throw new GeneralSecurityException("Mobil güncelleme imzası geçersiz.");}catch(IllegalArgumentException e){throw new GeneralSecurityException(e);}
 }
}
