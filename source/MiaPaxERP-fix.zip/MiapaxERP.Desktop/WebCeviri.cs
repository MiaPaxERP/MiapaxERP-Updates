using System.Text.Json;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
namespace MiapaxERP.Desktop;

/// <summary>
/// Program içindeki web sayfalarını (Arazi Stüdyosu, saha pazarlama, laboratuvar ve PDF raporları) programın
/// seçili diline çevirir. Sayfadaki metin düğümleri ile placeholder/title öznitelikleri toplanır, masaüstündeki
/// sözlükle (<see cref="Dil.Cevir(string?)"/>) çevrilir ve yerine yazılır. Türkçe asıl öğede saklanır; dil Türkçeye
/// dönünce geri yazılır. Giriş kutularının değerleri, betik ve stil içerikleri değiştirilmez; sözlükte tam karşılığı
/// olmayan metin (müşteri adı vb. veri) olduğu gibi kalır. Sayfaya ağdan bir şey gönderilmez.
/// </summary>
public static class WebCeviri
{
    const string Topla = """
(()=>{const out=new Set(),skip=/^(SCRIPT|STYLE|TEXTAREA|INPUT|SELECT|OPTION|CODE|PRE|NOSCRIPT)$/;
 const w=document.createTreeWalker(document.body||document.documentElement,NodeFilter.SHOW_TEXT,{acceptNode:n=>{const p=n.parentElement;if(!p||skip.test(p.tagName)||p.closest('[contenteditable],[data-ceviri-yok]'))return NodeFilter.FILTER_REJECT;return /\p{L}{2}/u.test(n.nodeValue)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;}});
 let n;while((n=w.nextNode())){const a=n.__mpxAsil??n.nodeValue;if(a.trim().length<=400)out.add(a.trim());if(out.size>3000)break;}
 for(const e of document.querySelectorAll('[placeholder],[title],[aria-label],button[value]'))for(const k of ['placeholder','title','aria-label']){const v=e.__mpxAsil?.[k]??e.getAttribute(k);if(v&&/\p{L}{2}/u.test(v)&&v.length<=400)out.add(v.trim());}
 if(document.title)out.add((document.__mpxBaslik??document.title).trim());
 return [...out];})()
""";
    const string Uygula = """
((m)=>{const skip=/^(SCRIPT|STYLE|TEXTAREA|INPUT|SELECT|OPTION|CODE|PRE|NOSCRIPT)$/;
 const ceviri=s=>{const t=s.trim();const c=m[t];if(c===undefined)return s;const i=s.indexOf(t);return s.slice(0,i)+c+s.slice(i+t.length);};
 const w=document.createTreeWalker(document.body||document.documentElement,NodeFilter.SHOW_TEXT,{acceptNode:n=>{const p=n.parentElement;return !p||skip.test(p.tagName)||p.closest('[contenteditable],[data-ceviri-yok]')?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT;}});
 let n,say=0;while((n=w.nextNode())){
  // Sayfa metni kendisi değiştirdiyse (ör. durum yazısı) yeni metin asıl kabul edilir.
  if(n.__mpxAsil!==undefined&&n.nodeValue!==n.__mpxSon)n.__mpxAsil=undefined;
  const asil=n.__mpxAsil??n.nodeValue,yeni=ceviri(asil);
  if(yeni!==n.nodeValue){n.__mpxAsil=asil;n.nodeValue=yeni;n.__mpxSon=yeni;say++;}}
 for(const e of document.querySelectorAll('[placeholder],[title],[aria-label]'))for(const k of ['placeholder','title','aria-label']){if(!e.hasAttribute(k))continue;e.__mpxAsil??={};const cur=e.getAttribute(k);if(e.__mpxAsil[k]!==undefined&&cur!==e.__mpxAsil[k+'#'])delete e.__mpxAsil[k];const asil=e.__mpxAsil[k]??cur,yeni=ceviri(asil);if(yeni!==cur){e.__mpxAsil[k]=asil;e.setAttribute(k,yeni);e.__mpxAsil[k+'#']=yeni;}}
 if(document.title){document.__mpxBaslik??=document.title;document.title=ceviri(document.__mpxBaslik);}
 document.documentElement.lang=m['__dil']||document.documentElement.lang;document.documentElement.dir=m['__yon']||'ltr';
 return say;})
""";

    static readonly System.Text.RegularExpressions.Regex metinDugumu=new(@"(<(script|style)\b[\s\S]*?</\2>)|>([^<>]+)<",System.Text.RegularExpressions.RegexOptions.IgnoreCase|System.Text.RegularExpressions.RegexOptions.Compiled);
    /// <summary>
    /// Betik çalıştırılmayan rapor sayfaları (laboratuvar, basınç testi, tablo PDF'leri) için: HTML'deki etiketler arası
    /// metinleri sözlükle çevirir. HTML kodlaması korunur; script/style blokları atlanır; sözlükte olmayan veri değişmez.
    /// </summary>
    public static string Html(string html)
    {
        if(Dil.Turkce||string.IsNullOrEmpty(html))return html;
        string sonuc=metinDugumu.Replace(html,m=>{
            if(m.Groups[1].Success)return m.Value;
            string ham=m.Groups[3].Value;if(!ham.Any(char.IsLetter))return m.Value;
            string metin=System.Net.WebUtility.HtmlDecode(ham);
            string cevrilen=Dil.CevirKayitsiz(metin);
            return ReferenceEquals(cevrilen,metin)||cevrilen==metin?m.Value:">"+System.Net.WebUtility.HtmlEncode(cevrilen)+"<";
        });
        return sonuc.Replace("<html lang='tr'>","<html lang='"+Dil.Mevcut+"'"+(Dil.SagdanSola?" dir='rtl'":"")+">");
    }

    /// <summary>Sayfayı bir kez çevirir (PDF yazdırmadan önce de çağrılır). Türkçede asıllar geri yazılır.</summary>
    public static async Task CevirAsync(CoreWebView2? web)
    {
        if(web is null)return;
        try
        {
            string json=await web.ExecuteScriptAsync(Topla);
            var metinler=JsonSerializer.Deserialize<string[]>(json)??[];
            var harita=new Dictionary<string,string>(StringComparer.Ordinal);
            foreach(var t in metinler){var c=Dil.Turkce?t:Dil.CevirKayitsiz(t);harita[t]=c;}
            harita["__dil"]=Dil.Mevcut;harita["__yon"]=Dil.SagdanSola?"rtl":"ltr";
            await web.ExecuteScriptAsync("("+Uygula+")("+JsonSerializer.Serialize(harita)+")");
        }
        catch(Exception e) when(e is InvalidOperationException or JsonException or System.Runtime.InteropServices.COMException or ObjectDisposedException){}
    }

    /// <summary>
    /// WebView'i program diline bağlar: sayfa yüklenince ve 3 sn'de bir (sayfa sonradan metin ekleyebildiği için) çevirir;
    /// dil değişince hemen yeniler. Türkçede ve görünmeyen pencerede çalışmaz.
    /// </summary>
    public static void Bagla(WebView2 web)
    {
        bool kullanildi=!Dil.Turkce;
        void Hazir(){
            if(web.CoreWebView2 is null)return;
            web.CoreWebView2.NavigationCompleted+=async(_,_)=>{if(kullanildi||!Dil.Turkce)await CevirAsync(web.CoreWebView2);};
        }
        if(web.CoreWebView2 is not null)Hazir();else web.CoreWebView2InitializationCompleted+=(_,e)=>{if(e.IsSuccess)Hazir();};
        var zaman=new System.Windows.Threading.DispatcherTimer(System.Windows.Threading.DispatcherPriority.Background){Interval=TimeSpan.FromSeconds(3)};
        bool calisiyor=false;
        zaman.Tick+=async(_,_)=>{
            if(calisiyor||Dil.Turkce||web.CoreWebView2 is null||!web.IsVisible)return;
            calisiyor=true;try{kullanildi=true;await CevirAsync(web.CoreWebView2);}finally{calisiyor=false;}
        };
        Action degisti=()=>web.Dispatcher.BeginInvoke(async()=>{kullanildi=true;await CevirAsync(web.CoreWebView2);});
        Dil.Degisti+=degisti;
        web.Loaded+=(_,_)=>zaman.Start();
        web.Unloaded+=(_,_)=>zaman.Stop();
        if(web.IsLoaded)zaman.Start();
        // WebView kapanınca olay aboneliği bırakılır.
        void Birak(){zaman.Stop();Dil.Degisti-=degisti;}
        web.Unloaded+=(_,_)=>{if(System.Windows.Window.GetWindow(web) is null)Birak();};
    }
}
