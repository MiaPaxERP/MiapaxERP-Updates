using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MiapaxERP.Desktop;
using Xunit;
using ZXing;
namespace MiapaxERP.Tests.HTTPS.Integration;
[Collection("WpfArayuz")]
public class UrunEtiketTestleri
{
 [Theory][InlineData("100x100",100,100)][InlineData("70 × 40 mm",70,40)][InlineData("50,5x30",50.5,30)]public void OlcuMmOlarakCozulur(string input,double w,double h){Assert.Equal((w,h),UrunEtiketYazici.Olcu(input));}
 [Theory][InlineData("0x100")][InlineData("100xNaN")][InlineData("900x20")][InlineData("100")][InlineData("-50x100")]public void GecersizOlcuReddedilir(string input)=>Assert.Throws<ArgumentException>(()=>UrunEtiketYazici.Olcu(input));
 [Fact]public void PaketKimligiVeSiraTekrarlanabilirVeSikiDogrulanir(){var code=UrunEtiketServisi.PaketBarkodu(123,2);Assert.Equal("MPXPK000000123-000002",code);Assert.True(UrunEtiketServisi.PaketCoz(code,out int p,out int n));Assert.Equal(123,p);Assert.Equal(2,n);foreach(string bad in new[]{"MPXPK123-2","MPXPK000000123-000000","MPXPK000000123-000002-1","MPXPK+00000123-000002"})Assert.False(UrunEtiketServisi.PaketCoz(bad,out _,out _));Assert.Contains("UrunEtiketServisi.Bilgiler",HttpsIslemKatalogu.Adlar);}
 [Fact]public async Task GercekEtiket100mmVeTermalCozunurlukteBarkodOkunur(){
  var done=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);var thread=new Thread(()=>{try{
   var data=new UrunEtiketBilgisi(1,"PIPE-75","TEST PE100 sulama borusu","Adet","Çap: 75 mm · Basınç: PN10 · Boy: 5 m · Renk: Siyah",123,10,30,"TEST-UE-001");string folder=Path.Combine(AppContext.BaseDirectory,"TestResults","Etiket287");Directory.CreateDirectory(folder);
   foreach(var pair in new[]{("paket",UrunEtiketServisi.PaketBarkodu(123,2)),("stok","0001234567890")}){
    var el=UrunEtiketYazici.Etiket(data,pair.Item2,10,100,100,2);double dip=100*96/25.4;Assert.Equal(dip,el.Width,6);el.Measure(new Size(dip,dip));el.Arrange(new Rect(0,0,dip,dip));el.UpdateLayout();int pixels=(int)Math.Ceiling(100*203/25.4);var bm=new RenderTargetBitmap(pixels,pixels,203,203,PixelFormats.Pbgra32);bm.Render(el);byte[] bytes=new byte[pixels*pixels*4];bm.CopyPixels(bytes,pixels*4,0);var source=new RGBLuminanceSource(bytes,pixels,pixels,RGBLuminanceSource.BitmapFormat.BGRA32);var decoded=new BarcodeReaderGeneric{Options=new ZXing.Common.DecodingOptions{TryHarder=true,PossibleFormats=[BarcodeFormat.CODE_128]}}.Decode(source);Assert.NotNull(decoded);Assert.Equal(pair.Item2,decoded.Text);var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(bm));using var file=File.Create(Path.Combine(folder,pair.Item1+"-100x100.png"));png.Save(file);
   }
   Assert.Throws<ArgumentException>(()=>UrunEtiketYazici.Etiket(data,new string('W',100),10,25,20));done.SetResult();
  }catch(Exception e){done.SetException(e);}});thread.SetApartmentState(ApartmentState.STA);thread.Start();await done.Task.WaitAsync(TimeSpan.FromSeconds(30));
 }
}
