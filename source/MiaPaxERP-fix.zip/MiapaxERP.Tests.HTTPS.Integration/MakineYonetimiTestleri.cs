using System.Buffers.Binary;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;

public class MakineYonetimiTestleri
{
 static MakineTanimi Modbus(int port,params MakineAlani[] a)=>new(0,"Ekstruder 1","Firma","X-90","S1","Hat 1","MODBUS","127.0.0.1",port,1,1,a,true);

 [Fact]public void ModbusAdresleriCozulurVeHatalilarReddedilir(){
  Assert.Equal(new ModbusAdresi(ModbusTablo.HR,0,ModbusTip.U16,false),MakineOkuyucu.ModbusAdres("HR:40001"));
  Assert.Equal(new ModbusAdresi(ModbusTablo.IR,4,ModbusTip.F32,true),MakineOkuyucu.ModbusAdres("ir:30005:f32:sw"));
  Assert.Equal(new ModbusAdresi(ModbusTablo.HR,100,ModbusTip.U16,false),MakineOkuyucu.ModbusAdres("HR:100"));
  Assert.Equal(new ModbusAdresi(ModbusTablo.COIL,0,ModbusTip.U16,false),MakineOkuyucu.ModbusAdres("COIL:1"));
  foreach(var bad in new[]{"","HR","XX:1","HR:abc","HR:70000","HR:1:F64","COIL:1:F32","0:1","HR:1:5"})Assert.Throws<ArgumentException>(()=>MakineOkuyucu.ModbusAdres(bad));
 }

 [Fact]public void ModbusDegerleriTipVeKelimeSirasinaGoreCozulur(){
  var f=new byte[4];BinaryPrimitives.WriteSingleBigEndian(f,12.5f);
  Assert.Equal(12.5,MakineOkuyucu.ModbusCoz(f,MakineOkuyucu.ModbusAdres("HR:1:F32")));
  Assert.Equal(12.5,MakineOkuyucu.ModbusCoz([f[2],f[3],f[0],f[1]],MakineOkuyucu.ModbusAdres("HR:1:F32:SW")));
  Assert.Equal(-2,MakineOkuyucu.ModbusCoz([0xFF,0xFE],MakineOkuyucu.ModbusAdres("HR:1:S16")));
  Assert.Equal(65538,MakineOkuyucu.ModbusCoz([0,1,0,2],MakineOkuyucu.ModbusAdres("HR:1:U32")));
  Assert.Equal(1,MakineOkuyucu.ModbusCoz([1],MakineOkuyucu.ModbusAdres("DI:1")));
 }

 [Fact]public void JsonVeMqttYollariOkunur(){
  using var doc=JsonDocument.Parse("""{"veri":{"hiz":"12.5","hatlar":[{"sayac":40}],"calisiyor":true}}""");
  Assert.Equal(12.5,MakineOkuyucu.JsonDeger(doc.RootElement,"veri.hiz"));
  Assert.Equal(40,MakineOkuyucu.JsonDeger(doc.RootElement,"veri.hatlar.0.sayac"));
  Assert.Equal(1,MakineOkuyucu.JsonDeger(doc.RootElement,"veri.calisiyor"));
  Assert.Null(MakineOkuyucu.JsonDeger(doc.RootElement,"veri.yok"));
  Assert.Equal(7.25,MakineOkuyucu.MqttDeger(" 7.25 ",null));
  Assert.Equal(3,MakineOkuyucu.MqttDeger("""{"a":{"b":3}}""","a.b"));
  Assert.Equal(1,MakineOkuyucu.MqttDeger("ON",null));
  Assert.Null(MakineOkuyucu.MqttDeger("bozuk",null));
 }

 [Fact]public void DurumEslemesiVeRenkleriDogru(){
  Assert.Equal("Bakım",MakinePaneli.DurumMetni("0=Durdu;1=Çalışıyor;3=Bakım",3));
  Assert.Equal("Çalışıyor",MakinePaneli.DurumMetni("",1));
  Assert.StartsWith("Arıza",MakinePaneli.DurumMetni("",5));
  var m=Modbus(502,new MakineAlani("Durum","HR:40001","",1,"Durum","0=Durdu;1=Çalışıyor;2=Arıza"));
  Assert.Equal("Arıza",MakinePaneli.Durum(m,new(true,new Dictionary<string,double?>{["Durum"]=2},null,DateTimeOffset.Now)).Metin);
  Assert.Equal("Bağlantı yok",MakinePaneli.Durum(m,MakineOkumaSonucu.HataIle("x")).Metin);
 }

 [Fact]public void TanimDogrulamasiHataliGirdiyiReddeder(){
  var ok=MakineServisi.Dogrula(Modbus(502,new MakineAlani("Hız","HR:40002","m/dk",0.1,"hiz","")));
  Assert.Equal("MODBUS",ok.Protokol);Assert.Equal("Hiz",ok.Alanlar[0].Rol);
  Assert.ThrowsAny<ArgumentException>(()=>MakineServisi.Dogrula(Modbus(502,new MakineAlani("Hız","HR:abc","",1,"Hiz",""))));
  Assert.ThrowsAny<ArgumentException>(()=>MakineServisi.Dogrula(Modbus(502)));
  Assert.ThrowsAny<ArgumentException>(()=>MakineServisi.Dogrula(Modbus(502,new MakineAlani("Hız","HR:1","",1,"Uydurma",""))));
  Assert.ThrowsAny<ArgumentException>(()=>MakineServisi.Dogrula(Modbus(502,new MakineAlani("Hız","HR:1","",1,"Hiz",""))with{Protokol="SNMP"}));
  Assert.ThrowsAny<ArgumentException>(()=>MakineServisi.Dogrula(Modbus(502,new MakineAlani("Hız","HR:1","",1,"Hiz",""))with{Ad=" "}));
 }

 /// <summary>Gerçek soket üzerinden FC3/FC4/FC1 isteklerine yanıt veren küçük Modbus TCP sunucusu.</summary>
 [Fact]public async Task ModbusTcpMakinesindenCanliDegerOkunur(){
  var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;
  ushort[] holding=new ushort[16];holding[0]=1;holding[1]=255;holding[2]=0;holding[3]=1234;
  ushort[] input=new ushort[16];var f=new byte[4];BinaryPrimitives.WriteSingleBigEndian(f,182.5f);input[4]=BinaryPrimitives.ReadUInt16BigEndian(f);input[5]=BinaryPrimitives.ReadUInt16BigEndian(f.AsSpan(2));
  using var stop=new CancellationTokenSource(TimeSpan.FromSeconds(20));
  var server=Task.Run(async()=>{
   using var client=await listener.AcceptTcpClientAsync(stop.Token);var s=client.GetStream();
   while(!stop.IsCancellationRequested){
    var head=new byte[7];try{await s.ReadExactlyAsync(head,stop.Token);}catch(EndOfStreamException){break;}
    var body=new byte[BinaryPrimitives.ReadUInt16BigEndian(head.AsSpan(4))-1];await s.ReadExactlyAsync(body,stop.Token);
    byte fn=body[0];int adr=BinaryPrimitives.ReadUInt16BigEndian(body.AsSpan(1)),n=BinaryPrimitives.ReadUInt16BigEndian(body.AsSpan(3));
    byte[] data;
    if(fn is 3 or 4){var src=fn==3?holding:input;data=new byte[n*2];for(int i=0;i<n;i++)BinaryPrimitives.WriteUInt16BigEndian(data.AsSpan(i*2),src[adr+i]);}
    else data=[1];
    var res=new byte[9+data.Length];head.AsSpan(0,4).CopyTo(res);BinaryPrimitives.WriteUInt16BigEndian(res.AsSpan(4),(ushort)(3+data.Length));res[6]=head[6];res[7]=fn;res[8]=(byte)data.Length;data.CopyTo(res,9);
    await s.WriteAsync(res,stop.Token);
   }
  });
  try{
   var m=MakineServisi.Dogrula(Modbus(port,
    new("Durum","HR:40001","",1,"Durum",""),new("Hız","HR:40002","m/dk",0.1,"Hiz",""),new("Üretilen","HR:40003:U32","adet",1,"Sayac",""),
    new("Sıcaklık","IR:30005:F32","°C",1,"Sicaklik",""),new("Kapı","COIL:1","",1,"Diger","")));
   await using var r=new MakineOkuyucu(m);
   var first=await r.OkuAsync(stop.Token);
   Assert.True(first.Basarili,first.Hata);
   Assert.Equal(1,first.Degerler["Durum"]);Assert.Equal(25.5,first.Degerler["Hız"]!.Value,6);Assert.Equal(1234,first.Degerler["Üretilen"]);
   Assert.Equal(182.5,first.Degerler["Sıcaklık"]);Assert.Equal(1,first.Degerler["Kapı"]);
   holding[3]=1300;var second=await r.OkuAsync(stop.Token);
   Assert.Equal(1300,second.Degerler["Üretilen"]);
   Assert.Equal("Çalışıyor",MakinePaneli.Durum(m,second).Metin);
  }finally{stop.Cancel();listener.Stop();try{await server;}catch(Exception){}}
 }

 [Fact]public async Task KapaliMakineHataMesajiDondururCokmez(){
  var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();
  await using var r=new MakineOkuyucu(MakineServisi.Dogrula(Modbus(port,new MakineAlani("Hız","HR:1","",1,"Hiz",""))));
  var res=await r.OkuAsync(CancellationToken.None);
  Assert.False(res.Basarili);Assert.False(string.IsNullOrWhiteSpace(res.Hata));
 }

 /// <summary>CONNECT/SUBSCRIBE kabul edip abone olunan konulara PUBLISH gönderen küçük MQTT broker.</summary>
 [Fact]public async Task MqttKonusundanCanliDegerOkunur(){
  var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;
  using var stop=new CancellationTokenSource(TimeSpan.FromSeconds(20));
  var subscribed=new List<string>();
  var broker=Task.Run(async()=>{
   using var client=await listener.AcceptTcpClientAsync(stop.Token);var s=client.GetStream();
   async Task<(int,byte[])> Read(){var one=new byte[1];await s.ReadExactlyAsync(one,stop.Token);int t=one[0]>>4;int len=0,mul=1;while(true){await s.ReadExactlyAsync(one,stop.Token);len+=(one[0]&127)*mul;if((one[0]&128)==0)break;mul*=128;}var b=new byte[len];if(len>0)await s.ReadExactlyAsync(b,stop.Token);return (t,b);}
   async Task Send(byte h,byte[] b){var p=new List<byte>{h,(byte)b.Length};p.AddRange(b);await s.WriteAsync(p.ToArray(),stop.Token);}
   var (t1,_)=await Read();Assert.Equal(1,t1);await Send(0x20,[0,0]);
   var (t2,sub)=await Read();Assert.Equal(8,t2);
   for(int i=2;i<sub.Length;){int l=(sub[i]<<8)|sub[i+1];subscribed.Add(Encoding.UTF8.GetString(sub,i+2,l));i+=3+l;}
   await Send(0x90,[sub[0],sub[1],0,0]);
   byte[] Pub(string topic,string payload){var t=Encoding.UTF8.GetBytes(topic);var p=new List<byte>{(byte)(t.Length>>8),(byte)t.Length};p.AddRange(t);p.AddRange(Encoding.UTF8.GetBytes(payload));return p.ToArray();}
   await Send(0x30,Pub("fabrika/hat1/hiz","42.5"));
   await Send(0x30,Pub("fabrika/hat1/durum","""{"kod":1,"sayac":980}"""));
   try{while(!stop.IsCancellationRequested)await Read();}catch(Exception){}
  });
  try{
   var m=MakineServisi.Dogrula(new(0,"Hat 1","","","","","MQTT","127.0.0.1",port,1,1,[
    new("Hız","fabrika/hat1/hiz","m/dk",1,"Hiz",""),new("Durum","fabrika/hat1/durum#kod","",1,"Durum",""),new("Üretilen","fabrika/hat1/durum#sayac","adet",1,"Sayac","")],true));
   var res=await MakineOkuyucu.TekSeferAsync(m,stop.Token);
   Assert.True(res.Basarili,res.Hata);
   Assert.Equal(["fabrika/hat1/hiz","fabrika/hat1/durum"],subscribed);
   Assert.Equal(42.5,res.Degerler["Hız"]);Assert.Equal(1,res.Degerler["Durum"]);Assert.Equal(980,res.Degerler["Üretilen"]);
  }finally{stop.Cancel();listener.Stop();try{await broker;}catch(Exception){}}
 }

 [Fact]public void OpcUaDugumKimlikleriKodlanir(){
  Assert.Equal(new byte[]{0,85},OpcUaBaglanti.DugumKodla("i=85"));
  Assert.Equal(new byte[]{1,2,0xE9,0x03},OpcUaBaglanti.DugumKodla("ns=2;i=1001"));
  Assert.Equal(new byte[]{3,2,0,4,0,0,0,(byte)'H',(byte)'1',(byte)'.',(byte)'V'},OpcUaBaglanti.DugumKodla("ns=2;s=H1.V"));
  Assert.Equal(2,OpcUaBaglanti.DugumKodla("ns=300;i=70000")[0]);
  foreach(var bad in new[]{"","x=1","ns=a;i=1","i=-1","ns=1;g=nope","s="})Assert.Throws<ArgumentException>(()=>OpcUaBaglanti.DugumKodla(bad));
 }

 /// <summary>HEL/OPN/CreateSession/ActivateSession/Read akışını taklit eden küçük OPC UA sunucusu (None, anonim).</summary>
 [Fact]public async Task OpcUaSunucusundanAnonimOkunur(){
  var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;
  using var stop=new CancellationTokenSource(TimeSpan.FromSeconds(20));
  string? policySent=null;var nodesRead=new List<byte[]>();bool closed=false;
  const string none="http://opcfoundation.org/UA/SecurityPolicy#None";
  static void U32(List<byte> b,uint v){b.AddRange(BitConverter.GetBytes(v));}
  static void I32(List<byte> b,int v){b.AddRange(BitConverter.GetBytes(v));}
  static void Str(List<byte> b,string? v){if(v is null){I32(b,-1);return;}var x=Encoding.UTF8.GetBytes(v);I32(b,x.Length);b.AddRange(x);}
  static void RespHeader(List<byte> b,ushort type,uint status=0){b.AddRange([1,0,(byte)type,(byte)(type>>8)]);b.AddRange(BitConverter.GetBytes(0L));U32(b,1);U32(b,status);b.Add(0);I32(b,-1);b.AddRange([0,0,0]);}
  var server=Task.Run(async()=>{
   using var client=await listener.AcceptTcpClientAsync(stop.Token);var s=client.GetStream();
   async Task<(string,byte[])> Read(){var h=new byte[8];await s.ReadExactlyAsync(h,stop.Token);var b=new byte[BitConverter.ToUInt32(h,4)-8];await s.ReadExactlyAsync(b,stop.Token);return (Encoding.ASCII.GetString(h,0,3),b);}
   async Task Send(string t,List<byte> body){var m=new List<byte>(Encoding.ASCII.GetBytes(t)){(byte)'F'};U32(m,(uint)(8+body.Count));m.AddRange(body);await s.WriteAsync(m.ToArray(),stop.Token);}
   List<byte> Msg(uint req){var b=new List<byte>();U32(b,7);U32(b,1);U32(b,1);U32(b,req);return b;}
   while(!stop.IsCancellationRequested){
    var (t,b)=await Read();
    if(t=="HEL"){var a=new List<byte>();U32(a,0);U32(a,65536);U32(a,65536);U32(a,0);U32(a,0);await Send("ACK",a);}
    else if(t=="OPN"){int pl=BitConverter.ToInt32(b,4);Assert.Equal(none,Encoding.UTF8.GetString(b,8,pl));int off=8+pl+8;uint req=BitConverter.ToUInt32(b,off+4);
     var r=new List<byte>();U32(r,7);Str(r,none);I32(r,-1);I32(r,-1);U32(r,1);U32(r,req);RespHeader(r,449);U32(r,0);U32(r,7);U32(r,1);r.AddRange(BitConverter.GetBytes(0L));U32(r,600000);I32(r,0);await Send("OPN",r);}
    else if(t=="CLO"){closed=true;break;}
    else{
     uint req=BitConverter.ToUInt32(b,12);ushort type=BitConverter.ToUInt16(b,18);var r=Msg(req);
     if(type==461){RespHeader(r,464);r.AddRange([1,1,50,0]);r.AddRange([1,1,99,0]);r.AddRange(BitConverter.GetBytes(60000.0));I32(r,-1);I32(r,-1);
      I32(r,2);
      foreach(var (mode,pol,pid) in new[]{(3,"http://opcfoundation.org/UA/SecurityPolicy#Basic256Sha256","secure-anon"),(1,none,"anon")}){
       Str(r,"opc.tcp://x:4840");Str(r,"urn:x");Str(r,"urn:p");r.Add(2);Str(r,"Makine");I32(r,0);Str(r,null);Str(r,null);I32(r,-1);I32(r,-1);I32(r,mode);Str(r,pol);
       I32(r,2);Str(r,"user");I32(r,1);Str(r,null);Str(r,null);Str(r,null);Str(r,pid);I32(r,0);Str(r,null);Str(r,null);Str(r,null);Str(r,null);r.Add(0);}
      I32(r,-1);Str(r,null);I32(r,-1);U32(r,0);}
     else if(type==467){Assert.Equal(new byte[]{1,1,99,0},b[20..24]);int o=24+8+4+4+4+4+3+4+4+4+4;Assert.Equal(321,BitConverter.ToUInt16(b,o+2));o+=5;int len=BitConverter.ToInt32(b,o);int sl=BitConverter.ToInt32(b,o+4);policySent=Encoding.UTF8.GetString(b,o+8,sl);RespHeader(r,470);I32(r,0);I32(r,0);I32(r,0);}
     else if(type==631){
      int o=24+8+4+4+4+4+3+8+4;int n=BitConverter.ToInt32(b,o);o+=4;
      for(int i=0;i<n;i++){int st=o;byte e=b[o];o+=e switch{0=>2,1=>4,3=>3+4+BitConverter.ToInt32(b,o+3),_=>throw new InvalidDataException()};nodesRead.Add(b[st..o]);Assert.Equal(13u,BitConverter.ToUInt32(b,o));o+=4+4+2+4;}
      RespHeader(r,634);I32(r,3);
      r.Add(1);r.Add(11);r.AddRange(BitConverter.GetBytes(12.5));
      r.Add(3);r.Add(6);I32(r,7);U32(r,0);
      r.Add(3);r.Add(1);r.Add(1);U32(r,0x80340000);
      I32(r,-1);}
     else{RespHeader(r,397,0x80000000);}
     await Send("MSG",r);
    }
   }
  });
  try{
   var m=MakineServisi.Dogrula(new(0,"Pres","","","","","OPCUA","opc.tcp://127.0.0.1:"+port,null,1,1,[
    new("Hız","ns=2;s=Hat1.Hiz","m/dk",1,"Hiz",""),new("Durum","ns=2;i=1001","",1,"Durum",""),new("Yok","i=85","",1,"Diger","")],true));
   MakineOkumaSonucu res;
   await using(var r=new MakineOkuyucu(m))res=await r.OkuAsync(stop.Token);
   Assert.True(res.Basarili,res.Hata);
   Assert.Equal(12.5,res.Degerler["Hız"]);Assert.Equal(7,res.Degerler["Durum"]);Assert.Null(res.Degerler["Yok"]);
   Assert.Equal("anon",policySent);Assert.Equal(3,nodesRead.Count);Assert.Equal(new byte[]{1,2,0xE9,0x03},nodesRead[1]);
   await server.WaitAsync(TimeSpan.FromSeconds(5));Assert.True(closed);
  }finally{stop.Cancel();listener.Stop();}
 }

 [Fact]public void MakineTanimlariKaydedilirListelenirSilinirVeYetkiIstenir(){
  string name="MiapaxMakine_"+Guid.NewGuid().ToString("N");
  using var master=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=10");
  master.Open();using(var q=new SqlCommand("CREATE DATABASE ["+name+"]",master))q.ExecuteNonQuery();
  try{
   string cs=new SqlConnectionStringBuilder(master.ConnectionString){InitialCatalog=name}.ConnectionString;
   var codes=new List<string>();var svc=new MakineServisi(cs,1,(_,_,code)=>codes.Add(code));
   int id=svc.Kaydet(Modbus(502,new("Durum","HR:40001","",1,"Durum","0=Durdu;1=Çalışıyor"),new("Hız","HR:40002","m/dk",0.1,"Hiz","")));
   var list=svc.Liste();var m=Assert.Single(list);
   Assert.Equal(id,m.Id);Assert.Equal("Ekstruder 1",m.Ad);Assert.Equal(2,m.Alanlar.Length);Assert.Equal(0.1,m.Alanlar[1].Carpan);Assert.Equal("0=Durdu;1=Çalışıyor",m.Alanlar[0].Esleme);
   Assert.Equal(id,svc.Kaydet(m with{Ad="Ekstruder A",OkumaSaniye=5}));
   Assert.Equal("Ekstruder A",Assert.Single(svc.Liste()).Ad);Assert.Equal(5,svc.Liste()[0].OkumaSaniye);
   Assert.ThrowsAny<Exception>(()=>svc.Kaydet(Modbus(502,new MakineAlani("Hız","HR:1","",1,"Hiz",""))with{Ad="Ekstruder A"}));
   svc.Sil(id);Assert.Empty(svc.Liste());
   Assert.Contains("MACHINE.VIEW",codes);Assert.Contains("MACHINE.MANAGE",codes);
   var denied=new MakineServisi(cs,1,(_,_,code)=>{if(code=="MACHINE.MANAGE")throw new UnauthorizedAccessException();});
   Assert.Throws<UnauthorizedAccessException>(()=>denied.Kaydet(Modbus(502,new MakineAlani("Hız","HR:1","",1,"Hiz",""))));
  }finally{SqlConnection.ClearAllPools();using var q=new SqlCommand("ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]",master);q.ExecuteNonQuery();}
 }
}
