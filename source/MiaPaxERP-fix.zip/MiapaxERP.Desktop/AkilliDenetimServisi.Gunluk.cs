using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>
/// "Bugün yapmanız gerekenler": çalışanın yetkisine (muhasebe, depo, üretim, satış, finans, İK) ve takvime
/// (ay sonu, beyanname günleri, hafta başı/sonu) göre öncelik sıralı günlük iş listesi. Veri değiştirmez.
/// </summary>
public sealed partial class AkilliDenetimServisi
{
 /// <summary>Günlük görev listesi; en önemli iş başta. Önem: Kritik (bugün mutlaka), Uyarı (bugün), Öneri (yakında).</summary>
 public AkilliOneri[] BugunYapilacaklar(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<AkilliOneri[]>(connection,"AkilliDenetimServisi.BugunYapilacaklar","",[]);
  var list=new List<AkilliOneri>();
  using var c=access.Ac();
  var izinler=new Dictionary<string,bool>();
  bool Izin(string k)=>izinler.TryGetValue(k,out var v)?v:izinler[k]=Var(c,k);
  list.AddRange(TakvimGorevleri(DateTime.Today,Izin));
  void Kural(string izin,Action<SqlConnection,List<AkilliOneri>> kural){if(!Izin(izin))return;try{kural(c,list);}catch(SqlException){/* tablo bu kurulumda yok */}}
  Kural("CALENDAR.VIEW",(cn,o)=>BugunkuPlanlar(cn,o,user));
  Kural("WAREHOUSE.VIEW",GelecekMallar);
  if(!Izin("WAREHOUSE.VIEW"))Kural("PURCHASE.VIEW",GelecekMallar);
  Kural("PRODUCTION.VIEW",BugunBaslayacakUretim);
  Kural("FINANCE.VIEW",BugunVadeliOdemeler);
  Kural("FINANCE.VIEW",BugunVadeliCekler);
  return Sirala(list);
 }

 internal static AkilliOneri[] Sirala(IEnumerable<AkilliOneri> list){
  var sira=new Dictionary<string,int>{["Kritik"]=0,["Uyarı"]=1,["Öneri"]=2};
  return list.GroupBy(x=>x.Anahtar).Select(g=>g.First()).OrderBy(x=>sira.GetValueOrDefault(x.Onem,3)).ThenBy(x=>x.Alan,StringComparer.Ordinal).Take(40).ToArray();
 }

 static readonly CultureInfo trK=CultureInfo.GetCultureInfo("tr-TR");
 static bool IsGunu(DateTime d)=>d.DayOfWeek is not(DayOfWeek.Saturday or DayOfWeek.Sunday);
 /// <summary>Ayın son iş gününe kaç iş günü kaldığı (0 = bugün son iş günü).</summary>
 internal static int AySonunaIsGunu(DateTime gun){
  var son=new DateTime(gun.Year,gun.Month,DateTime.DaysInMonth(gun.Year,gun.Month));
  while(!IsGunu(son))son=son.AddDays(-1);
  int n=0;for(var d=gun.Date.AddDays(1);d<=son;d=d.AddDays(1))if(IsGunu(d))n++;
  return gun.Date>son?-1:n;
 }
 /// <summary>Resmî son gün hafta sonuna denk gelirse ilk iş gününe kayar.</summary>
 internal static DateTime SonGun(int yil,int ay,int gunNo){var d=new DateTime(yil,ay,Math.Min(gunNo,DateTime.DaysInMonth(yil,ay)));while(!IsGunu(d))d=d.AddDays(1);return d;}
 static int IsGunuFarki(DateTime bugun,DateTime hedef){int n=0;for(var d=bugun.Date;d<hedef.Date;d=d.AddDays(1))if(IsGunu(d.AddDays(1)))n++;return n;}
 static string Kalan(DateTime bugun,DateTime hedef){int g=(hedef.Date-bugun.Date).Days;return g==0?"bugün son gün":g==1?"yarın son gün":g+" gün kaldı ("+hedef.ToString("d MMMM",trK)+")";}

 /// <summary>Takvime ve role bağlı görevler (veritabanına bakmaz; test edilebilir).</summary>
 internal static List<AkilliOneri> TakvimGorevleri(DateTime bugun,Func<string,bool> izin){
  var o=new List<AkilliOneri>();
  string ay=bugun.ToString("yyyy-MM");
  int aySonu=AySonunaIsGunu(bugun);
  bool ayBasi=bugun.Day<=3;
  var onceki=bugun.AddMonths(-1);string oncekiAd=onceki.ToString("MMMM",trK);
  string Onem(int kalanIsGunu)=>kalanIsGunu<=0?"Kritik":kalanIsGunu<=2?"Uyarı":"Öneri";

  if(izin("ACCOUNTING.VIEW")){
   if(aySonu is >=0 and <=3)
    o.Add(new("gun-muh-aysonu-"+ay,"Muhasebe",aySonu<=1?"Kritik":"Uyarı","Ay sonu kapanışını hazırlayın ("+(aySonu==0?"bugün ayın son iş günü":aySonu+" iş günü kaldı")+")",
     "Banka ve kasa mutabakatı, cari mutabakat, açık faturaların kontrolü, dövizli hesapların kur değerlemesi, amortisman ve gider tahakkukları.",
     "Önce dengesiz fiş uyarılarını giderin; sonra mizanı alıp hesapları kontrol edin."));
   if(ayBasi)
    o.Add(new("gun-muh-aybasi-"+ay,"Muhasebe","Uyarı",oncekiAd+" ayının kapanışını tamamlayın","Geçen ayın eksik fatura ve masraf belgelerini toplayın, fişleri kesinleştirin, e-defter hazırlığına başlayın.","Belgeler tamamlandıysa dönemi muhasebe ekranından kapatın."));
   var muhtasar=SonGun(bugun.Year,bugun.Month,26);
   if(bugun.Day>=19&&bugun.Date<=muhtasar)
    o.Add(new("gun-muh-muhtasar-"+ay,"Muhasebe",Onem(IsGunuFarki(bugun,muhtasar)),"Muhtasar ve prim hizmet beyannamesi: "+Kalan(bugun,muhtasar),oncekiAd+" ayı ücret, stopaj ve SGK bildirimleri.","Bordro verilerini kontrol edip beyannameyi gönderin, tahakkuku ödeme planına ekleyin."));
   var kdv=SonGun(bugun.Year,bugun.Month,28);
   if(bugun.Day>=20&&bugun.Date<=kdv)
    o.Add(new("gun-muh-kdv-"+ay,"Muhasebe",Onem(IsGunuFarki(bugun,kdv)),"KDV beyannamesi: "+Kalan(bugun,kdv),oncekiAd+" ayı alış ve satış faturalarının KDV kontrolü.","İndirilecek ve hesaplanan KDV'yi mizanla karşılaştırın; beyannameyi gönderin."));
   if(aySonu is >=0 and <=2)
    o.Add(new("gun-muh-babs-"+ay,"Muhasebe","Öneri","Form Ba-Bs için cari mutabakatı","Bir önceki ayın 5.000 TL üzeri alış/satışlarını carilerle karşılaştırın.","Farklılıkları ay sonu bitmeden carilerle netleştirin."));
   // Geçici vergi: Şubat, Mayıs, Ağustos, Kasım ayının 17'si.
   if(bugun.Month is 2 or 5 or 8 or 11){var gv=SonGun(bugun.Year,bugun.Month,17);if(bugun.Day>=8&&bugun.Date<=gv)o.Add(new("gun-muh-gecici-"+ay,"Muhasebe",Onem(IsGunuFarki(bugun,gv)),"Geçici vergi beyannamesi: "+Kalan(bugun,gv),"Çeyrek dönem kâr hesabı, stok ve amortisman kontrolü.","Dönem sonu stok değerini ve tahakkukları kesinleştirin."));}
  }
  if(izin("PAYROLL.VIEW")||izin("HR.VIEW")){
   if(aySonu is >=0 and <=3)
    o.Add(new("gun-ik-bordro-"+ay,"İnsan kaynakları",aySonu<=1?"Kritik":"Uyarı","Puantaj ve bordroyu hazırlayın","Devamsızlık, izin, fazla mesai ve avansları işleyin; ay sonu bordro taslaklarını kontrol edin.","Maaş ödeme listesini finans ile paylaşın."));
   if(ayBasi)
    o.Add(new("gun-ik-maas-"+ay,"İnsan kaynakları","Uyarı","Maaş ödemelerini ve SGK bildirgelerini kontrol edin","Ödeme listesinin bankaya iletildiğini ve işe giriş/çıkış bildirimlerinin yapıldığını doğrulayın.",""));
  }
  if(izin("WAREHOUSE.VIEW")||izin("STOCK.VIEW")){
   if(aySonu is >=0 and <=1)
    o.Add(new("gun-depo-sayim-"+ay,"Depo",aySonu==0?"Kritik":"Uyarı","Ay sonu stok sayımı ("+(aySonu==0?"bugün":"yarın")+")","Raf raf sayım yapın; farkları sayım fişiyle işleyin. Sayım bitene kadar giriş/çıkışları not edin.","Önce yüksek değerli ve hızlı dönen ürünleri sayın."));
   else if(aySonu is 2 or 3)
    o.Add(new("gun-depo-onsayim-"+ay,"Depo","Öneri","Ay sonu öncesi ön sayım yapın","Ay sonu sayımını hızlandırmak için yavaş dönen ve ağır ürünleri şimdiden sayın.",""));
   if(bugun.DayOfWeek==DayOfWeek.Friday)
    o.Add(new("gun-depo-cuma-"+bugun.ToString("yyyy-MM-dd"),"Depo","Öneri","Haftalık raf düzeni ve eksi bakiye kontrolü","Hafta bitmeden eksi bakiyeli stokları ve yanlış rafa konmuş ürünleri düzeltin.",""));
  }
  if(izin("SALES.VIEW")||izin("CUSTOMER.VIEW")){
   if(bugun.DayOfWeek==DayOfWeek.Monday)
    o.Add(new("gun-satis-pzt-"+bugun.ToString("yyyy-MM-dd"),"Satış","Öneri","Haftalık tahsilat ve teklif takibi","Vadesi geçen alacakları ve yanıt bekleyen teklifleri arayın.",""));
   if(aySonu is >=0 and <=2)
    o.Add(new("gun-satis-aysonu-"+ay,"Satış","Uyarı","Ay sonu faturalarını kesin","Sevk edilip faturası kesilmemiş satışları bu ay içinde faturalayın.",""));
  }
  if(izin("FINANCE.VIEW")&&ayBasi)
   o.Add(new("gun-fin-aybasi-"+ay,"Finans","Uyarı","Aylık sabit ödemeleri planlayın","Kira, kredi taksidi, SGK ve vergi tahakkuklarını nakit planına ekleyin.",""));
  if(izin("PRODUCTION.VIEW")&&bugun.DayOfWeek==DayOfWeek.Monday)
   o.Add(new("gun-uretim-pzt-"+bugun.ToString("yyyy-MM-dd"),"Üretim","Öneri","Haftalık üretim planını kontrol edin","Bu hafta başlayacak emirlerin hammadde ve makine uygunluğunu kontrol edin.",""));
  return o;
 }

 // ---- VERİYE DAYALI GÜNLÜK GÖREVLER ----
 static void BugunkuPlanlar(SqlConnection c,List<AkilliOneri> o,int user){
  var rows=new List<string>();
  Oku(c,"SELECT TOP(15) PlanTarihi,Baslik FROM dbo.IsTakvimi WHERE Durum=N'Bekliyor' AND PlanTarihi<DATEADD(day,1,CAST(SYSDATETIME() AS date)) AND (OlusturanKullaniciId=@u OR AtananKullaniciId=@u) ORDER BY PlanTarihi",r=>{var d=r.GetDateTime(0);rows.Add((d.Date<DateTime.Today?"GECİKMİŞ ":"")+d.ToString("HH:mm",trK)+" "+r.GetString(1));},("@u",user));
  if(rows.Count>0)o.Add(new("gun-takvim-"+DateTime.Today.ToString("yyyyMMdd")+"-"+rows.Count,"İş takvimi",rows.Any(x=>x.StartsWith("GECİKMİŞ",StringComparison.Ordinal))?"Kritik":"Uyarı","Bugün "+rows.Count+" planınız var",Liste(rows,8),"Yapılanları iş takviminde 'Tamamlandı' olarak işaretleyin."));
 }
 static void GelecekMallar(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();int bugun=0;
  Oku(c,"""
SELECT TOP(15) COALESCE(JSON_VALUE(k.Veri,'$.no'),N''),TRY_CONVERT(date,JSON_VALUE(k.Veri,'$.termin')),COALESCE(ca.Unvan,N'')
FROM dbo.MPX310_Kayit k LEFT JOIN dbo.CariKartlari ca ON ca.Id=TRY_CONVERT(int,JSON_VALUE(k.Veri,'$.cari'))
WHERE k.Tur=N'SatinAlma' AND k.Durum=N'Taslak' AND TRY_CONVERT(date,JSON_VALUE(k.Veri,'$.termin')) BETWEEN DATEADD(day,-3,CAST(SYSDATETIME() AS date)) AND DATEADD(day,3,CAST(SYSDATETIME() AS date))
ORDER BY TRY_CONVERT(date,JSON_VALUE(k.Veri,'$.termin'))
""",r=>{var d=r.GetDateTime(1);if(d.Date<=DateTime.Today)bugun++;rows.Add(d.ToString("dd.MM",trK)+" "+r.GetString(2)+" ("+r.GetString(0)+")");});
  if(rows.Count>0)o.Add(new("gun-depo-gelecek-"+DateTime.Today.ToString("yyyyMMdd")+"-"+rows.Count,"Depo",bugun>0?"Uyarı":"Öneri",rows.Count+" satın alma siparişinin teslimi yakın","Mal kabul için hazırlanın: "+Liste(rows),"Rafta yer açın, ilgili ürünlerde erken sayım yapın; gelen malı mal kabul ekranından siparişle eşleştirerek alın."));
 }
 static void BugunBaslayacakUretim(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();
  Oku(c,"SELECT TOP(15) e.UretimEmriNo,s.StokAdi FROM dbo.UretimEmirleri e JOIN dbo.StokKartlari s ON s.Id=e.MamulStokId WHERE e.Durum=N'Planlandı' AND e.PlanlananBaslangic IS NOT NULL AND CAST(e.PlanlananBaslangic AS date)<=CAST(SYSDATETIME() AS date) ORDER BY e.PlanlananBaslangic",r=>rows.Add(r.GetString(0)+" "+r.GetString(1)));
  if(rows.Count>0)o.Add(new("gun-uretim-basla-"+DateTime.Today.ToString("yyyyMMdd")+"-"+rows.Count,"Üretim","Uyarı",rows.Count+" üretim emri bugün başlamalı",Liste(rows),"Hammadde ve makineyi hazırlayıp üretimi başlatın; ertelenecekse tarihini güncelleyin."));
 }
 static void BugunVadeliOdemeler(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();
  Oku(c,"SELECT TOP(15) Baslik,Tutar,ParaBirimi FROM dbo.PlanliOdemeler WHERE Durum=N'Bekliyor' AND VadeTarihi=CAST(SYSDATETIME() AS date)",r=>rows.Add(r.GetString(0)+" "+N(r.GetDecimal(1))+" "+r.GetString(2)));
  if(rows.Count>0)o.Add(new("gun-fin-odeme-"+DateTime.Today.ToString("yyyyMMdd")+"-"+rows.Count,"Finans","Kritik","Bugün vadesi gelen "+rows.Count+" ödeme",Liste(rows),"Ödemeyi yapıp kaydı 'Ödendi' olarak işaretleyin."));
 }
 static void BugunVadeliCekler(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();
  Oku(c,"SELECT TOP(15) EvrakNo,Yon,Tutar,ParaBirimi FROM dbo.CekSenetler WHERE Durum IN(N'Portföyde',N'Bekliyor',N'Açık',N'Verildi') AND VadeTarihi=CAST(SYSDATETIME() AS date)",r=>rows.Add(r.GetString(0)+" ("+r.GetString(1)+") "+N(r.GetDecimal(2))+" "+r.GetString(3)));
  if(rows.Count>0)o.Add(new("gun-fin-cek-"+DateTime.Today.ToString("yyyyMMdd")+"-"+rows.Count,"Finans","Kritik","Bugün vadesi gelen "+rows.Count+" çek/senet",Liste(rows),"Tahsil veya ödeme için bankaya iletin; durumunu güncelleyin."));
 }
}
