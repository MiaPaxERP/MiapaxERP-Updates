using System.Collections.Concurrent;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;

namespace MiapaxERP.Desktop;

/// <summary>
/// Arayüz dili. Türkçe metinler kaynak kabul edilir; seçilen dile yerleşik sözlükten,
/// sonra bu bilgisayardaki çeviri önbelleğinden çevrilir. Bulunamayan metinler Türkçe kalır
/// ve isteğe bağlı olarak yapay zekâ ile tamamlanmak üzere listelenir.
/// </summary>
public static class Dil
{
    public sealed record Secenek(string Kod,string Ad,bool SagdanSola=false);
    public static readonly Secenek[] Diller={
        new("tr","Türkçe"),new("en","English"),new("de","Deutsch"),new("fr","Français"),
        new("ru","Русский"),new("ar","العربية",true),new("zh","中文")};

    private static readonly object kilit=new();
    private static readonly Dictionary<string,Dictionary<string,string>> yerlesik=new();
    private static readonly ConcurrentDictionary<string,ConcurrentDictionary<string,string>> onbellek=new();
    private static readonly ConcurrentDictionary<string,byte> eksikler=new();
    private static readonly ConcurrentDictionary<string,byte> uretilen=new(StringComparer.Ordinal);
    private static bool yuklendi;
    private static string mevcut="tr";
    private static readonly CultureInfo Tr=CultureInfo.GetCultureInfo("tr-TR");

    public static event Action? Degisti;
    /// <summary>Oturum açan kullanıcının yapay zekâ ayar dosyası; sözlükte olmayan metinler arka planda bununla çevrilir.</summary>
    public static string? AsistanAyarYolu{get;set;}
    static int arkaPlanCalisiyor;
    /// <summary>Yapay zekâ bağlantısı ayarlıysa eksik metinleri sessizce çevirir (aynı anda tek iş).</summary>
    public static async Task ArkaPlandaTamamlaAsync()
    {
        if(Turkce||EksikSayisi==0||AsistanAyarYolu is null||Interlocked.Exchange(ref arkaPlanCalisiyor,1)==1)return;
        try{var ayar=AsistanAyari.Oku(AsistanAyarYolu);if(ayar.Tur!="Yerleşik rehber"){using var cts=new CancellationTokenSource(TimeSpan.FromMinutes(5));await YapayZekaIleTamamlaAsync(ayar,cts.Token);}}
        catch(Exception e) when(e is not OutOfMemoryException){DestekIzleme.Bildir(e,"Dil.ArkaPlan");}
        finally{Interlocked.Exchange(ref arkaPlanCalisiyor,0);}
    }
    public static string Mevcut{get{Yukle();return mevcut;}}
    public static bool SagdanSola=>Diller.Any(d=>d.Kod==Mevcut&&d.SagdanSola);
    public static bool Turkce=>Mevcut=="tr";
    public static int EksikSayisi=>eksikler.Count;

    private static string Klasor=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP");
    private static string AyarDosyasi=>Path.Combine(Klasor,"dil.json");
    private static string OnbellekDosyasi(string kod)=>Path.Combine(Klasor,"Ceviri",kod+".json");

    private sealed class DilAyari{public string Dil{get;set;}="tr";}

    private static void Yukle()
    {
        if(yuklendi)return;
        lock(kilit)
        {
            if(yuklendi)return;
            try{using var s=typeof(Dil).Assembly.GetManifestResourceStream("MiapaxERP.Desktop.Diller.ceviri.tsv");if(s!=null)SozlukOku(new StreamReader(s,Encoding.UTF8).ReadToEnd());}
            catch(Exception e) when(e is IOException or InvalidDataException){}
            try{if(File.Exists(AyarDosyasi)){var a=JsonSerializer.Deserialize<DilAyari>(File.ReadAllText(AyarDosyasi));if(a!=null&&Diller.Any(d=>d.Kod==a.Dil))mevcut=a.Dil;}}
            catch(Exception e) when(e is IOException or UnauthorizedAccessException or JsonException){}
            yuklendi=true;
        }
    }

    /// <summary>Sekme ile ayrılmış sözlük: ilk satır dil kodları, ilk sütun Türkçe.</summary>
    internal static void SozlukOku(string tsv)
    {
        var satirlar=tsv.Replace("\r\n","\n").Split('\n',StringSplitOptions.RemoveEmptyEntries);
        if(satirlar.Length<2)return;
        var kodlar=satirlar[0].Split('\t');
        for(int k=1;k<kodlar.Length;k++)if(!yerlesik.ContainsKey(kodlar[k]))yerlesik[kodlar[k]]=new(StringComparer.Ordinal);
        foreach(var satir in satirlar.Skip(1))
        {
            var p=satir.Split('\t');if(p.Length<2)continue;
            string anahtar=Anahtar(p[0]);if(anahtar.Length==0)continue;
            for(int k=1;k<Math.Min(p.Length,kodlar.Length);k++)
                if(!string.IsNullOrWhiteSpace(p[k]))yerlesik[kodlar[k]].TryAdd(anahtar,p[k].Trim());
        }
    }

    /// <summary>Sözlük anahtarı: kırpılmış, Türkçe küçük harf, tek boşluk.</summary>
    internal static string Anahtar(string metin)=>string.Join(' ',metin.Trim().ToLower(Tr).Split((char[]?)null,StringSplitOptions.RemoveEmptyEntries));

    public static void Degistir(string kod)
    {
        Yukle();
        if(!Diller.Any(d=>d.Kod==kod)||kod==mevcut)return;
        mevcut=kod;
        try{Directory.CreateDirectory(Klasor);var tmp=AyarDosyasi+".tmp";File.WriteAllText(tmp,JsonSerializer.Serialize(new DilAyari{Dil=kod}));File.Move(tmp,AyarDosyasi,true);}
        catch(Exception e) when(e is IOException or UnauthorizedAccessException){}
        eksikler.Clear();uretilen.Clear();
        Degisti?.Invoke();
    }

    /// <summary>Türkçe arayüz metnini seçili dile çevirir. Baştaki simge/boşluklar ve sondaki ":" veya " *" korunur.</summary>
    public static string Cevir(string? turkce)
    {
        if(string.IsNullOrEmpty(turkce))return turkce??"";
        Yukle();
        if(mevcut=="tr"||uretilen.ContainsKey(turkce))return turkce;
        var c=Cevir(turkce,mevcut,out bool bulundu);
        if(bulundu&&uretilen.Count<50000)uretilen.TryAdd(c,0);
        return c;
    }

    internal static string Cevir(string turkce,string kod,out bool bulundu)
    {
        bulundu=false;
        int bas=0,son=turkce.Length;
        while(bas<son&&!char.IsLetterOrDigit(turkce[bas]))bas++;
        if(bas==son)return turkce;
        while(son>bas&&(char.IsWhiteSpace(turkce[son-1])||turkce[son-1] is ':' or '*' or '…'))son--;
        // "..." ile biten metinler (ör. "Yükleniyor...") önce olduğu gibi aranır.
        string govde=turkce[bas..son],onEk=turkce[..bas],sonEk=turkce[son..];
        if(Bul(Anahtar(turkce[bas..]),kod) is {} tam){bulundu=true;return onEk+tam;}
        if(Bul(Anahtar(govde),kod) is {} c){bulundu=true;return onEk+c+sonEk;}
        if(govde.Length>1&&govde.Length<=400&&govde.Any(char.IsLetter)&&!SayiVeyaKod(govde))eksikler.TryAdd(govde.Trim(),0);
        return turkce;
    }

    private static string? Bul(string anahtar,string kod)
    {
        if(yerlesik.TryGetValue(kod,out var s)&&s.TryGetValue(anahtar,out var v))return v;
        return Onbellek(kod).TryGetValue(anahtar,out var o)?o:null;
    }

    private static bool SayiVeyaKod(string s)=>s.All(ch=>char.IsDigit(ch)||char.IsPunctuation(ch)||char.IsWhiteSpace(ch)||char.IsSymbol(ch)||(char.IsUpper(ch)&&s.Length<=4));

    private static ConcurrentDictionary<string,string> Onbellek(string kod)=>onbellek.GetOrAdd(kod,k=>
    {
        var d=new ConcurrentDictionary<string,string>(StringComparer.Ordinal);
        try{if(File.Exists(OnbellekDosyasi(k))&&JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(OnbellekDosyasi(k))) is {} okunan)
            foreach(var (a,v) in okunan)if(!string.IsNullOrWhiteSpace(v)&&v.Length<=1000)d[Anahtar(a)]=v;}
        catch(Exception e) when(e is IOException or UnauthorizedAccessException or JsonException){}
        return d;
    });

    private static void OnbellekKaydet(string kod)
    {
        try{Directory.CreateDirectory(Path.GetDirectoryName(OnbellekDosyasi(kod))!);var tmp=OnbellekDosyasi(kod)+".tmp";
            File.WriteAllText(tmp,JsonSerializer.Serialize(Onbellek(kod).OrderBy(x=>x.Key,StringComparer.Ordinal).ToDictionary(x=>x.Key,x=>x.Value),new JsonSerializerOptions{WriteIndented=true,Encoder=System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping}));
            File.Move(tmp,OnbellekDosyasi(kod),true);}
        catch(Exception e) when(e is IOException or UnauthorizedAccessException){}
    }

    /// <summary>
    /// Ekranlarda görülüp sözlükte bulunamayan metinleri yapay zekâ bağlantısıyla çevirir ve önbelleğe yazar.
    /// Yalnız arayüz etiketleri gönderilir; kayıt verisi gönderilmez. Dönen değer çevrilen metin sayısıdır.
    /// </summary>
    public static async Task<(int Cevrilen,string Durum)> YapayZekaIleTamamlaAsync(AsistanAyari ayar,CancellationToken token,IProgress<string>? ilerleme=null)
    {
        Yukle();
        string kod=mevcut;
        if(kod=="tr")return (0,"Türkçe seçiliyken çeviri gerekmez.");
        if(ayar.Tur=="Yerleşik rehber")return (0,"Yapay zekâ bağlantısı ayarlı değil. Ana sayfadaki asistan ayarlarından MiapaxERP sunucusu veya Ollama bağlantısı tanımlayın.");
        var liste=eksikler.Keys.Where(m=>Bul(Anahtar(m),kod)==null).Distinct(StringComparer.Ordinal).Take(400).ToList();
        if(liste.Count==0)return (0,"Çevrilecek eksik metin yok. Önce ekranları bu dilde açın, sonra tekrar deneyin.");
        string dilAdi=Diller.First(d=>d.Kod==kod).Ad;int toplam=0;var istemci=new AsistanIstemcisi();string durum="";
        foreach(var grup in liste.Chunk(40))
        {
            token.ThrowIfCancellationRequested();
            ilerleme?.Report($"{toplam}/{liste.Count} çevrildi…");
            string soru="Aşağıdaki JSON dizisindeki ERP yazılımı arayüz metinlerini Türkçeden "+dilAdi+" ("+kod+") diline çevir. "+
                "Yalnızca {\"türkçe metin\":\"çeviri\"} biçiminde tek bir JSON nesnesi döndür; açıklama ekleme. Kısa, yazılım arayüzüne uygun terimler kullan; ₺, %, sayı ve kodları koru.\n"+
                JsonSerializer.Serialize(grup,new JsonSerializerOptions{Encoder=System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping});
            var yanit=await istemci.SorAsync(ayar,soru,"Arayüz çevirisi",Array.Empty<AsistanMesaji>(),token);
            if(yanit.Metin==null){durum=yanit.Durum;break;}
            var sozluk=JsonAyikla(yanit.Metin);
            foreach(var m in grup)
                if(sozluk.TryGetValue(m,out var c)&&!string.IsNullOrWhiteSpace(c)&&c.Length<=1000){Onbellek(kod)[Anahtar(m)]=c.Trim();eksikler.TryRemove(m,out _);toplam++;}
        }
        if(toplam>0){OnbellekKaydet(kod);Degisti?.Invoke();}
        return (toplam,durum.Length>0?durum:$"{toplam} metin çevrildi ve bu bilgisayarda saklandı.");
    }

    internal static Dictionary<string,string> JsonAyikla(string metin)
    {
        var sonuc=new Dictionary<string,string>(StringComparer.Ordinal);
        int a=metin.IndexOf('{'),b=metin.LastIndexOf('}');
        if(a<0||b<=a)return sonuc;
        try
        {
            using var doc=JsonDocument.Parse(metin[a..(b+1)]);
            if(doc.RootElement.ValueKind!=JsonValueKind.Object)return sonuc;
            foreach(var p in doc.RootElement.EnumerateObject())if(p.Value.ValueKind==JsonValueKind.String)sonuc[p.Name]=p.Value.GetString()!;
        }
        catch(JsonException){}
        return sonuc;
    }

    /// <summary>Testler için: sözlüğü bellekte yükler ve dili kaydetmeden ayarlar.</summary>
    internal static void TestIcinAyarla(string tsv,string kod){lock(kilit){yerlesik.Clear();SozlukOku(tsv);yuklendi=true;mevcut=kod;}}
}
