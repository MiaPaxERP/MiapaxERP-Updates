﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName PresentationFramework
$panelRoot=Split-Path $PSScriptRoot -Parent
$privateFolder=Join-Path $env:USERPROFILE 'BoruERP_GizliAnahtarlar\BayiPaneli30'
$title='MiaPax Yönetim Paneli - İnternet paneline eşitle'
try {
    $dbPath=Join-Path $privateFolder 'portal.sqlite'
    $secretPath=Join-Path $privateFolder 'secrets.dpapi'
    if(-not (Test-Path -LiteralPath $dbPath)) { throw "Panel veritabanı bulunamadı: $dbPath" }
    Add-Type -AssemblyName Microsoft.VisualBasic
    $origin=[Microsoft.VisualBasic.Interaction]::InputBox("Yeni internet lisans panelinin adresi (ör. https://lisans.firmaniz.com).`nBoş bırakırsanız gizli ayarlardaki LICENSE_CLOUD_ORIGIN veya mevcut panel kullanılır.",$title,'')
    $answer=[Windows.MessageBox]::Show("Bu bilgisayardaki tüm müşteri ve lisans kayıtları internet lisans paneline gönderilecek. Lisans anahtarlarının kendisi gönderilmez; yalnız imzalı kayıt ve anahtar özeti gider.`n`nDevam edilsin mi?",$title,'YesNo','Question')
    if($answer -ne 'Yes') { return }
    $nodeCommand=Get-Command node -ErrorAction SilentlyContinue
    $nodePath=if($nodeCommand) {$nodeCommand.Source} else {Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'}
    if(-not (Test-Path -LiteralPath $nodePath)) { throw 'Node.js 24 bulunamadı. https://nodejs.org/en/download adresinden kurulmalıdır.' }
    $env:DB_PATH=$dbPath
    $env:PORTAL_SECRET_FILE=$secretPath
    if($origin.Trim().Length -gt 0) { $env:LICENSE_CLOUD_ORIGIN=$origin.Trim() }
    Push-Location $panelRoot
    try { $raw=& $nodePath (Join-Path $panelRoot 'src\sync-all.js') 2>$null } finally { Pop-Location }
    $result=$raw | ConvertFrom-Json
    if(-not $result.ok) { throw $result.error }
    $msg="Hedef: $($result.target)`nToplam lisans: $($result.total)`nBaşarılı: $($result.ok)`nHatalı: $($result.failed.Count)"
    if($result.failed.Count -gt 0) { $msg+="`n`nİlk hata: $($result.failed[0].message)" }
    [Windows.MessageBox]::Show($msg,$title,'OK','Information') | Out-Null
} catch {
    [Windows.MessageBox]::Show($_.Exception.Message,$title,'OK','Error') | Out-Null
    exit 1
}
