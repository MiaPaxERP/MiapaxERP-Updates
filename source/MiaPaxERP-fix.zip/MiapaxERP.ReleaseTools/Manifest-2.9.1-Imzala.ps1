﻿# MiaPaxERP 2.9.1 güncelleme listelerini (manifest) mevcut güncelleme anahtarıyla imzalar.
# Özel anahtar bu bilgisayardan çıkmaz; yalnız imzalı manifest dosyaları yazılır.
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Security
$pemPath=Join-Path $env:USERPROFILE 'BoruERP_GizliAnahtarlar\boruerp-private.pem'
if(!(Test-Path -LiteralPath $pemPath)){throw "Güncelleme imza anahtarı bulunamadı: $pemPath"}
$pem=[IO.File]::ReadAllText($pemPath)
$label=[regex]::Match($pem,'-----BEGIN ([A-Z ]+)-----').Groups[1].Value
$b64=($pem -replace '-----[^-]+-----','' -replace '\s','')
$der=[Convert]::FromBase64String($b64)
function DerLen([int]$n){ if($n -lt 128){return ,[byte[]]@($n)}; $b=[BitConverter]::GetBytes($n);[Array]::Reverse($b);$b=$b|Where-Object{$_ -ne $null};while($b[0] -eq 0){$b=$b[1..($b.Length-1)]};return ,[byte[]](@(0x80+$b.Length)+$b) }
function Der([byte]$tag,[byte[]]$body){ return ,[byte[]](@($tag)+(DerLen $body.Length)+$body) }
if($label -eq 'RSA PRIVATE KEY'){
 # PKCS#1 -> PKCS#8 (anahtar içeriği değişmez, yalnız zarflanır)
 $algo=[byte[]](0x30,0x0D,0x06,0x09,0x2A,0x86,0x48,0x86,0xF7,0x0D,0x01,0x01,0x01,0x05,0x00)
 $der=Der 0x30 ([byte[]](@(0x02,0x01,0x00)+$algo+(Der 0x04 $der)))
}elseif($label -ne 'PRIVATE KEY'){throw "Desteklenmeyen anahtar biçimi: $label (şifreli anahtarsa parola gerekir)."}
$key=[Security.Cryptography.CngKey]::Import($der,[Security.Cryptography.CngKeyBlobFormat]::Pkcs8PrivateBlob)
$rsa=New-Object Security.Cryptography.RSACng($key)
$out=Join-Path $PSScriptRoot 'Yayin-2.9.1-manifest'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$items=@(
    @{Kanal='Ana';Url='https://github.com/MiaPaxERP/MiapaxERP-Updates/releases/download/v2.9.1/MiaPaxERP-Ana-v2.9.1.zip';Sha='af87e3491592a5969d122ec8940a9336d64a397c9ea88ab3e179538de1e7bf29'}
    @{Kanal='Yan';Url='https://github.com/MiaPaxERP/MiapaxERP-Updates/releases/download/v2.9.1/MiaPaxERP-Yan-v2.9.1.zip';Sha='cbaa6616b2f8722f7c457a11794c5ce2a50cf847666a5cc305dfb8ac376710f2'}
    @{Kanal='Mobil';Url='https://github.com/MiaPaxERP/MiapaxERP-Updates/releases/download/v2.9.1/MiaPaxERP-Mobil-v2.9.1.apk';Sha='269d9da66e8cec58b0ddfc89884fd09996fd2ff6949e5524eb82bda83ce72aea'}
)
try{
 foreach($i in $items){
  $canonical="2.9.1`n$($i.Kanal)`n$($i.Url)`n$($i.Sha)`n"
  $sig=[Convert]::ToBase64String($rsa.SignData([Text.Encoding]::UTF8.GetBytes($canonical),[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pss))
  $json="{`r`n  `"Version`": `"2.9.1`",`r`n  `"Channel`": `"$($i.Kanal)`",`r`n  `"PackageUrl`": `"$($i.Url)`",`r`n  `"Sha256`": `"$($i.Sha)`",`r`n  `"Signature`": `"$sig`"`r`n}"
  [IO.File]::WriteAllText((Join-Path $out ('manifest-'+$i.Kanal.ToLowerInvariant()+'.json')),$json,(New-Object Text.UTF8Encoding($false)))
 }
 Write-Output 'İmzalı manifestler hazır.'
}finally{$rsa.Dispose();$key.Dispose()}
