using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
 readonly Queue<GuncelHaber> sonDakikaSirasi=new();readonly HashSet<string> sonDakikaGorulen=new();Border? sonDakikaBand;Button? sonDakikaMetni;DispatcherTimer? sonDakikaSure;int haberKullanici;bool ilkHaber=true;GuncelHaber? bantHaberi;
 string HaberGorulenDosya=>Path.Combine(GorunumDeposu.Klasor(baglantiAdresi,aktifKullanici?.KullaniciId??0),"son-dakika-gorulen.json");
 void HaberBandiniKur(){if(sonDakikaBand is not null)return;var old=Content;Content=null;var root=new DockPanel();sonDakikaBand=new Border{Background=new SolidColorBrush(Color.FromRgb(176,28,35)),Padding=new Thickness(14,5,14,5),Visibility=Visibility.Collapsed};var bar=new DockPanel();bar.Children.Add(new TextBlock{Text="SON DAKİKA",Foreground=Brushes.White,FontWeight=FontWeights.Bold,VerticalAlignment=System.Windows.VerticalAlignment.Center,Margin=new Thickness(0,0,18,0)});sonDakikaMetni=new Button{Foreground=Brushes.White,Background=Brushes.Transparent,BorderThickness=new Thickness(0),HorizontalContentAlignment=System.Windows.HorizontalAlignment.Left,Padding=new Thickness(4),FontSize=13};bar.Children.Add(sonDakikaMetni);sonDakikaBand.Child=bar;DockPanel.SetDock(sonDakikaBand,Dock.Top);root.Children.Add(sonDakikaBand);root.Children.Add((UIElement)old);Content=root;sonDakikaMetni.Click+=(_,_)=>{if(bantHaberi is not null)System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(bantHaberi.Url){UseShellExecute=true});};sonDakikaSure=new(){Interval=TimeSpan.FromSeconds(20)};sonDakikaSure.Tick+=(_,_)=>{sonDakikaSure.Stop();sonDakikaBand.Visibility=Visibility.Collapsed;SonDakikaGoster();};Closed+=(_,_)=>sonDakikaSure.Stop();}
 void SonDakikaIsle(GuncelHaber[] rows){int user=aktifKullanici?.KullaniciId??0;if(user<1)return;if(haberKullanici!=user){haberKullanici=user;ilkHaber=true;sonDakikaGorulen.Clear();sonDakikaSirasi.Clear();try{if(File.Exists(HaberGorulenDosya))sonDakikaGorulen.UnionWith(JsonSerializer.Deserialize<string[]>(File.ReadAllText(HaberGorulenDosya))??[]);}catch{}}
  foreach(var row in rows.Where(x=>x.SonDakika).OrderBy(x=>x.Yayin)){bool fresh=sonDakikaGorulen.Add(row.Id);if(!ilkHaber&&fresh&&row.Yayin>DateTimeOffset.UtcNow.AddMinutes(-20))sonDakikaSirasi.Enqueue(row);}ilkHaber=false;try{Directory.CreateDirectory(Path.GetDirectoryName(HaberGorulenDosya)!);File.WriteAllText(HaberGorulenDosya,JsonSerializer.Serialize(sonDakikaGorulen.TakeLast(1000)));}catch{}SonDakikaGoster();}
 void SonDakikaGoster(){if(sonDakikaBand is null||sonDakikaBand.Visibility==Visibility.Visible||sonDakikaSirasi.Count==0)return;bantHaberi=sonDakikaSirasi.Dequeue();sonDakikaMetni!.Content=bantHaberi.Baslik;sonDakikaBand.Visibility=Visibility.Visible;sonDakikaSure!.Start();}
}
