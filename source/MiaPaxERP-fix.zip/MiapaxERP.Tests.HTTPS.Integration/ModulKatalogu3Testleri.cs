using MiapaxERP.Lisans.Core;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;

public class ModulKatalogu3Testleri
{
 static LisansIcerigi License(string[] modules,int? catalog)=>new(1,Guid.NewGuid().ToString(),Guid.NewGuid().ToString(),"TEST","GENEL",modules,"D","B",DateTimeOffset.UtcNow,DateTimeOffset.UtcNow.AddDays(-1),null,DateTimeOffset.UtcNow.AddDays(7),1){Catalog=catalog};

 [Fact]public void EskiLisanstaAltModullerUstModulleAcikKalir(){
  var now=DateTimeOffset.UtcNow;var p=License(["STOK","URETIM","SATIS"],null);
  Assert.True(ModulSureleri.Acik(p,"DEPO",now));Assert.True(ModulSureleri.Acik(p,"MALIYET",now));Assert.DoesNotContain(UrunKatalogu.Moduller,m=>m.Kod=="HIZLISATIS");Assert.Equal("SATIS",UrunKatalogu.YetkiModulu("QUICKSALE.VIEW"));
  Assert.True(ModulSureleri.Acik(p,"TAKVIM",now));Assert.True(ModulSureleri.Acik(p,"ASISTAN",now));
  Assert.False(ModulSureleri.Acik(p,"SAHA",now));Assert.False(ModulSureleri.Acik(p,"MAKINA",now));Assert.False(ModulSureleri.Acik(p,"CEKSENET",now));
  Assert.Contains("DEPO",ModulSureleri.Etkin(p,now));Assert.DoesNotContain("MAKINA",ModulSureleri.Etkin(p,now));
 }

 [Fact]public void Katalog3LisanstaModullerTekTekSatilir(){
  var now=DateTimeOffset.UtcNow;var p=License(["STOK","URETIM","MAKINA","TAKVIM"],UrunKatalogu.ModulKataloguSurumu);
  Assert.False(ModulSureleri.Acik(p,"DEPO",now));Assert.False(ModulSureleri.Acik(p,"MALIYET",now));Assert.False(ModulSureleri.Acik(p,"ASISTAN",now));
  Assert.True(ModulSureleri.Acik(p,"MAKINA",now));Assert.True(ModulSureleri.Acik(p,"TAKVIM",now));
  var noParent=License(["DEPO"],UrunKatalogu.ModulKataloguSurumu);Assert.False(ModulSureleri.Acik(noParent,"DEPO",now));
  Assert.Throws<ArgumentException>(()=>UrunKatalogu.ModulDogrula(["DEPO"]));UrunKatalogu.ModulDogrula(["STOK","DEPO","MAKINA"]);
 }

 [Fact]public void IzinlerYeniModullereEslenir(){
  Assert.Equal("DEPO",UrunKatalogu.YetkiModulu("WAREHOUSE.VIEW"));Assert.Equal("MAKINA",UrunKatalogu.YetkiModulu("MACHINE.VIEW"));
  Assert.Equal("STOK",UrunKatalogu.YetkiModulu("STOCK.VIEW"));Assert.Equal("CEKSENET",UrunKatalogu.YetkiModulu("CHECKNOTE.VIEW"));
  Assert.All(UrunKatalogu.AltModuller.Keys,k=>Assert.Contains(UrunKatalogu.Moduller,m=>m.Kod==k));
  Assert.All(UrunKatalogu.EskiModuller,k=>Assert.Contains(UrunKatalogu.Moduller,m=>m.Kod==k));
 }
}
