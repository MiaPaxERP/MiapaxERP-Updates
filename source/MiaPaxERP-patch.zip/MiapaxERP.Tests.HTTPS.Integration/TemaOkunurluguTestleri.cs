using System.Windows.Media;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class TemaOkunurluguTestleri
{
 [Fact]public void TumPaletlerdeAcikKoyuVeUyariYazilariOkunur(){foreach(string theme in Tema170.Adlar){var p=Tema170.Sec(theme);foreach(string bg in new[]{p.Zemin,p.Yuzey,p.Menu,p.Vurgu})foreach(string fg in new[]{"#FFFFFF","#182E42","#64748B","#991B1B","#166534","#92400E"}){var surface=(Color)ColorConverter.ConvertFromString(bg);var result=TemaOkunurlugu.Uyumlu((Color)ColorConverter.ConvertFromString(fg),surface);Assert.True(TemaOkunurlugu.Kontrast(result,surface)>=4.5,theme+" "+bg+" "+fg);}}}
}
