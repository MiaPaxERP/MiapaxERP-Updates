using System.IO;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public static class IsletmeSemasi
{
 public static void Hazirla(string connection){
  using var c=new SqlConnection(connection);c.Open();
  using var check=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.MPX310_Kayit','U') IS NOT NULL AND EXISTS(SELECT 1 FROM sys.check_constraints WHERE parent_object_id=OBJECT_ID('dbo.StokHareketleri') AND name='CK_StokHareketleri_Tip' AND definition LIKE '%SATIS%') THEN 1 ELSE 0 END",c);
  try{MakineSemasi.Hazirla(c);}catch(SqlException ex){DestekIzleme.Bildir(ex,"MakineSemasi");}try{EkYetkiSemasi.Hazirla(c);}catch(SqlException ex){DestekIzleme.Bildir(ex,"EkYetkiSemasi");}
  if(Convert.ToInt32(check.ExecuteScalar())==1)return;
  using var q=new SqlCommand(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"Isletme310.sql")),c){CommandTimeout=120};q.ExecuteNonQuery();
 }
}
