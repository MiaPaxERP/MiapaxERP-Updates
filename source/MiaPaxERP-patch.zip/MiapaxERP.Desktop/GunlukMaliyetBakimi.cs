using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public static class GunlukMaliyetBakimi
{
 public static async Task Dongu(string connection,CancellationToken stop){while(!stop.IsCancellationRequested){try{if(LisansOturumu.Gecerli is not null&&LisansOturumu.ModulVar("URETIM")){using var c=new SqlConnection(connection);await c.OpenAsync(stop);using var q=new SqlCommand("IF OBJECT_ID('dbo.MPXNext_Gunluk','U') IS NOT NULL SELECT TOP(1) k.Id FROM dbo.Kullanicilar k JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId WHERE k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici' ORDER BY k.Id",c);var id=await q.ExecuteScalarAsync(stop);if(id is not null)await Task.Run(()=>new DetayliMaliyetServisi(connection,Convert.ToInt32(id)).Gunluk(),stop);}}catch(OperationCanceledException)when(stop.IsCancellationRequested){break;}catch(Exception e){System.Diagnostics.Trace.WriteLine("Günlük maliyet raporu sonraki denemede tekrar hazırlanacak: "+e.GetType().Name);}try{await Task.Delay(TimeSpan.FromHours(1),stop);}catch(OperationCanceledException){break;}}}
}
