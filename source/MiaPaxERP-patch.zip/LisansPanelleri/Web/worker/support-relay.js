const enc=new TextEncoder();
const reject=(message,status=403)=>{throw Object.assign(new Error(message),{status});};
const from64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const base64=b=>btoa(String.fromCharCode(...new Uint8Array(b)));
const canonical=b=>enc.encode(['MiaPaxERP.SupportRelay.1',b.action,b.licenseId,b.keyHash,b.issueId||'',b.at,b.nonce].join('\n')+'\n');
export async function signSupportRelay(env,license,action='read',issueId=''){
 const b={action,licenseId:license.id,keyHash:license.key_hash,issueId,at:Date.now(),nonce:crypto.randomUUID()};
 const key=await crypto.subtle.importKey('pkcs8',from64(env.LICENSE_PRIVATE_PKCS8),{name:'RSA-PSS',hash:'SHA-256'},false,['sign']);
 return {...b,signature:base64(await crypto.subtle.sign({name:'RSA-PSS',saltLength:32},key,canonical(b)))};
}
export async function verifySupportRelay(env,b){
 if(!b||!['read','resolve'].includes(b.action)||!/^[-a-zA-Z0-9]{1,80}$/.test(b.licenseId||'')||!/^[a-f0-9]{64}$/i.test(b.keyHash||'')||!Number.isSafeInteger(b.at)||Math.abs(Date.now()-b.at)>60000||!/^[-a-f0-9]{36}$/i.test(b.nonce||'')||typeof b.signature!=='string'||b.signature.length>2048||b.action==='resolve'&&!/^[a-f0-9]{64}$/i.test(b.issueId||''))reject('Destek eşitleme kimliği doğrulanamadı.');
 try{
  const privateKey=await crypto.subtle.importKey('pkcs8',from64(env.LICENSE_PRIVATE_PKCS8),{name:'RSA-PSS',hash:'SHA-256'},true,['sign']);
  const jwk=await crypto.subtle.exportKey('jwk',privateKey);
  const pub=await crypto.subtle.importKey('jwk',{kty:'RSA',n:jwk.n,e:jwk.e,alg:'PS256',ext:true},{name:'RSA-PSS',hash:'SHA-256'},false,['verify']);
  if(!await crypto.subtle.verify({name:'RSA-PSS',saltLength:32},pub,from64(b.signature),canonical(b)))reject('Destek eşitleme imzası geçersiz.');
 }catch{reject('Destek eşitleme imzası geçersiz.');}
 const license=await env.DB.prepare('SELECT id FROM licenses WHERE id=? AND key_hash=?').bind(b.licenseId,b.keyHash).first();
 if(!license)reject('Eşleşen müşteri lisansı bulunamadı.',404);
 return license.id;
}
