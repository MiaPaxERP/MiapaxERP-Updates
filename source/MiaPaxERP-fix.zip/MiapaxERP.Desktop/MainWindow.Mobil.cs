using System.Windows;
using System.Windows.Controls;
using System.Data;
namespace MiapaxERP.Desktop;
public partial class MainWindow{
 MobilYerelSunucu? yerelMobil;
 internal MobilYerelTanim? YerelMobilTanim=>yerelMobil?.Tanim;
 internal async Task<MobilYerelTanim> YerelMobilBaslat(string ip,string? disIp=null,int disPort=5189){
  if(HttpsOturumu.Uzak(baglantiAdresi))throw new InvalidOperationException("Yan cihazda sunucu başlatılmaz. Ana sunucunun HTTPS telefon kodunu kullanın.");
  if(aktifKullanici is null||DemoModu)throw new InvalidOperationException("SQL oturumu gerekli.");
  string cs=baglantiAdresi;int user=aktifKullanici.KullaniciId;
  using(var c=new ErpModulServisi(cs,user).Ac())MobilHesapServisi.Yonetici(c,null,user);
  if(yerelMobil is not null){await yerelMobil.DisposeAsync();yerelMobil=null;}
  var next=new MobilYerelSunucu();bool Active()=>Dispatcher.Invoke(()=>IsVisible&&!DemoModu&&aktifKullanici?.KullaniciId==user&&baglantiAdresi==cs);
  try{var info=await next.Baslat(cs,ip,Active,disIp,disPort);yerelMobil=next;Closed-=YerelMobilKapandi;Closed+=YerelMobilKapandi;return info;}catch{await next.DisposeAsync();throw;}
 }
 async void YerelMobilKapandi(object? sender,EventArgs e){if(yerelMobil is not null){await yerelMobil.DisposeAsync();yerelMobil=null;}}
 void MobilRaporlar_Click(object sender,RoutedEventArgs e){
  if(aktifKullanici is null||DemoModu){MessageBox.Show("SQL Server oturumu açın.");return;}
  try{new MobilHesapPenceresi(baglantiAdresi,aktifKullanici.KullaniciId,this){Owner=this}.ShowDialog();}catch(Exception ex){DestekIzleme.Bildir(ex,"MainWindow.Mobil");MessageBox.Show(ex.Message,"Mobil hesaplar");}
 }
}
public sealed class MobilHesapPenceresi:Window{
 sealed class Ayar{public string LanIp{get;set;}="";public string DisIp{get;set;}="";public int DisPort{get;set;}=5189;}
 static string AyarDosyasi=>System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","mobil-baglanti.json");
 static Ayar AyarOku(){try{return System.IO.File.Exists(AyarDosyasi)?System.Text.Json.JsonSerializer.Deserialize<Ayar>(System.IO.File.ReadAllText(AyarDosyasi))??new():new();}catch(Exception e) when(e is System.IO.IOException or UnauthorizedAccessException or System.Text.Json.JsonException){return new();}}
 static void AyarYaz(Ayar a){try{System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(AyarDosyasi)!);System.IO.File.WriteAllText(AyarDosyasi,System.Text.Json.JsonSerializer.Serialize(a));}catch(Exception e) when(e is System.IO.IOException or UnauthorizedAccessException){}}
 static TextBlock Baslik(string t)=>new(){Text=t,FontSize=19,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,18,0,6)};
 static StackPanel Alan(string etiket,FrameworkElement kutu){var sp=new StackPanel{Margin=new Thickness(0,0,12,6)};sp.Children.Add(new TextBlock{Text=etiket,Opacity=0.8});sp.Children.Add(kutu);return sp;}
 static Button Dugme(string t,bool ana=false){var b=new Button{Content=t,Padding=new Thickness(12,7,12,7),Margin=new Thickness(0,4,8,4)};if(ana)b.FontWeight=FontWeights.SemiBold;return b;}

 public MobilHesapPenceresi(string connection,int admin,MainWindow? ana=null){
  var service=new MobilHesapServisi(connection);service.Kur(admin);
  bool uzak=HttpsOturumu.Uzak(connection);var ayar=AyarOku();
  Title="MiaPaxERP • Mobil bağlantı";Width=900;Height=820;WindowStartupLocation=WindowStartupLocation.CenterOwner;
  var p=new StackPanel{Margin=new Thickness(24)};Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
  p.Children.Add(new TextBlock{Text="Mobil bağlantı",FontSize=26});
  p.Children.Add(new TextBlock{Text="1) Bağlantıyı başlatın  2) Çalışanı seçin  3) Telefon kodunu telefona gönderin. Aynı kod hem fabrikadaki Wi-Fi'de hem dışarıda (dış IP ile) çalışır.",TextWrapping=TextWrapping.Wrap,Opacity=0.85});

  // 1 · Bağlantı
  p.Children.Add(Baslik("1 · Bağlantıyı başlat"));
  var aglar=MobilYerelSunucu.Aglar();
  var ips=new ComboBox{ItemsSource=aglar,MinWidth=260,MinHeight=30};ips.SelectedItem=aglar.FirstOrDefault(a=>a.Ip==ayar.LanIp)??aglar.FirstOrDefault();
  var dis=new TextBox{Text=ayar.DisIp,MinWidth=170,MinHeight=30,ToolTip="Modemin internet (WAN) IP adresi. Boş bırakılırsa yalnız aynı Wi-Fi çalışır."};
  var disPort=new TextBox{Text=ayar.DisPort.ToString(System.Globalization.CultureInfo.InvariantCulture),Width=80,MinHeight=30};
  var bul=Dugme("Dış IP'mi bul");
  var satir=new WrapPanel();satir.Children.Add(Alan("Yerel IP (bu bilgisayar)",ips));
  var disSp=new StackPanel{Orientation=System.Windows.Controls.Orientation.Horizontal};disSp.Children.Add(dis);disSp.Children.Add(bul);bul.Margin=new Thickness(6,0,0,0);
  satir.Children.Add(Alan("Dış IP adresi (dışarıdan bağlanmak için)",disSp));satir.Children.Add(Alan("Dış port",disPort));p.Children.Add(satir);
  var bar1=new WrapPanel();p.Children.Add(bar1);
  var baslat=Dugme("Bağlantıyı başlat",true);var izin=Dugme("Windows iznini ver");var yz=Dugme("Yapay zekâ ile denetle ve düzelt");
  bar1.Children.Add(baslat);bar1.Children.Add(izin);bar1.Children.Add(yz);
  var durum=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,0)};p.Children.Add(durum);
  var rapor=new TextBox{IsReadOnly=true,TextWrapping=TextWrapping.Wrap,Visibility=Visibility.Collapsed,MaxHeight=260,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Margin=new Thickness(0,6,0,0)};p.Children.Add(rapor);
  void DurumYaz(){durum.Text=ana?.YerelMobilTanim is {} t?"✔ Bağlantı açık · Wi-Fi: "+t.Adres+(t.DisAdres is null?" · Dış IP girilmedi (yalnız aynı ağ).":" · Dışarıdan: "+t.DisAdres)+" · Ana programı açık tutun.":"Bağlantı kapalı. Yerel IP'yi seçip 'Bağlantıyı başlat'a basın.";}
  DurumYaz();
  int PortOku(){if(!int.TryParse(disPort.Text.Trim(),out int v)||!MobilYerelSunucu.DisPortGecerli(v))throw new ArgumentException("Dış port 1024–65535 arasında olmalı (1433, 1434, 3389 hariç).");return v;}
  async Task Baslat(){
   if(ana is null)throw new InvalidOperationException("Bu pencereyi ana programdan açın.");
   string lan=(ips.SelectedItem as MobilAgAdresi)?.Ip??throw new InvalidOperationException("Bu bilgisayarın yerel IP adresi bulunamadı. Wi-Fi veya kablolu ağa bağlı olun.");
   string d=dis.Text.Trim();int port=PortOku();
   await ana.YerelMobilBaslat(lan,d,port);
   AyarYaz(new Ayar{LanIp=lan,DisIp=d,DisPort=port});DurumYaz();
  }
  bul.Click+=async(_,_)=>{bul.IsEnabled=false;try{dis.Text=await MobilYerelSunucu.DisIpBulAsync();durum.Text="Dış IP bulundu: "+dis.Text+". Şimdi 'Bağlantıyı başlat'a basın.";}catch(Exception ex){durum.Text=ex.Message;}finally{bul.IsEnabled=true;}};
  baslat.Click+=async(_,_)=>{baslat.IsEnabled=false;try{await Baslat();}catch(Exception ex){durum.Text="✖ "+ex.Message;}finally{baslat.IsEnabled=true;}};
  izin.Click+=(_,_)=>{try{MobilYerelSunucu.AgIzni(dis.Text.Trim().Length>0);durum.Text="Açılan Windows penceresinde 'Evet' deyin. Dış IP kullanıyorsanız modemde dış porttan bu bilgisayarın "+((ips.SelectedItem as MobilAgAdresi)?.Ip??"yerel IP")+":5189 adresine port yönlendirmesi yapın.";}catch(Exception ex){durum.Text="İzin verilemedi: "+ex.Message;}};
  yz.Click+=async(_,_)=>{yz.IsEnabled=false;rapor.Visibility=Visibility.Visible;rapor.Text="Denetleniyor…";
   try{rapor.Text=await MobilBaglantiDenetimi.CalistirAsync(connection,admin,ana,(ips.SelectedItem as MobilAgAdresi)?.Ip,dis,disPort,Baslat,m=>Dispatcher.Invoke(()=>rapor.Text=m));DurumYaz();}
   catch(Exception ex){rapor.Text="Denetim tamamlanamadı: "+ex.Message;}finally{yz.IsEnabled=true;}};
  if(uzak){ips.IsEnabled=dis.IsEnabled=disPort.IsEnabled=bul.IsEnabled=baslat.IsEnabled=izin.IsEnabled=yz.IsEnabled=false;durum.Text="Bu cihaz ana sunucuya HTTPS ile bağlı. Telefon kodunu aşağıdaki 'Gelişmiş' bölümünden HTTPS koduyla üretin.";}

  // 2 · Çalışanlar
  p.Children.Add(Baslik("2 · Çalışanı seç"));
  var lisansDurum=new TextBlock{FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,6)};p.Children.Add(lisansDurum);
  var grid=new DataGrid{Height=280,IsReadOnly=true,AutoGenerateColumns=true,SelectionMode=DataGridSelectionMode.Single};p.Children.Add(grid);
  grid.AutoGeneratingColumn+=(_,e)=>{if(e.PropertyName=="Id")e.Cancel=true;else e.Column.Header=e.PropertyName switch{"KullaniciId"=>"ERP kullanıcı no","Ad"=>"Ad","Rol"=>"Rol","Aktif"=>"Aktif","Cihaz"=>"Cihaz sayısı",_=>e.PropertyName};};
  var user=new TextBox{Width=110,MinHeight=28};var name=new TextBox{Width=220,MinHeight=28};var role=new ComboBox{ItemsSource=new[]{"SAHA","PATRON"},SelectedIndex=0,Width=120};
  var ekle=Dugme("Çalışanı ekle");var yeni=new WrapPanel();yeni.Children.Add(Alan("ERP kullanıcı no",user));yeni.Children.Add(Alan("Görünen ad",name));yeni.Children.Add(Alan("Rol (SAHA: kendi müşterileri, PATRON: tümü)",role));
  var ekleSp=new StackPanel{VerticalAlignment=VerticalAlignment.Bottom};ekleSp.Children.Add(ekle);yeni.Children.Add(ekleSp);p.Children.Add(yeni);

  // 3 · Kod
  p.Children.Add(Baslik("3 · Telefon kodunu üret"));
  var bar3=new WrapPanel();p.Children.Add(bar3);
  var kod=Dugme("Telefon kodu üret ve kopyala",true);var iptal=Dugme("Seçili hesabı ve cihazlarını iptal et");bar3.Children.Add(kod);bar3.Children.Add(iptal);
  var code=new TextBox{IsReadOnly=true,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,6,0,6),MinHeight=48};p.Children.Add(code);
  var status=new TextBlock{TextWrapping=TextWrapping.Wrap};p.Children.Add(status);

  var gelismis=new Expander{Header="Gelişmiş",Margin=new Thickness(0,16,0,0)};var gp=new WrapPanel();gelismis.Content=gp;p.Children.Add(gelismis);
  var patron=Dugme("Kendi patron hesabımı hazırla");var https=Dugme("HTTPS sunucusu için telefon kodu");var tek=Dugme("Yalnız 15 dakikalık eşleme kodu");gp.Children.Add(patron);gp.Children.Add(https);gp.Children.Add(tek);

  void Refresh(){Guid? sec=grid.SelectedItem is DataRowView row?(Guid)row["Id"]:null;var tablo=service.Liste(admin);grid.ItemsSource=tablo.DefaultView;
   int bagli=tablo.AsEnumerable().Where(r=>Convert.ToBoolean(r["Aktif"])).Sum(r=>Convert.ToInt32(r["Cihaz"]));int hesap=tablo.AsEnumerable().Count(r=>Convert.ToBoolean(r["Aktif"]));
   lisansDurum.Text=LisansOturumu.MobilCihazSiniri is int s?$"📱 Mobil cihaz lisansı: {bagli} / {s} telefon bağlı · {hesap} etkin çalışan hesabı"+(bagli>=s?" — DOLU: yeni telefon bağlanamaz; kullanılmayan cihazları iptal edin veya lisansı artırın.":""):$"📱 Bağlı telefon: {bagli} · Etkin çalışan hesabı: {hesap} · Mobil cihaz sınırı yok (lisans panelinden tanımlanabilir).";if(sec.HasValue)grid.SelectedItem=grid.Items.Cast<DataRowView>().FirstOrDefault(r=>(Guid)r["Id"]==sec.Value);}
  Guid Selected(){
   if(grid.SelectedItem is DataRowView r)return (Guid)r["Id"];
   if(grid.Items.Count==1){grid.SelectedIndex=0;return (Guid)((DataRowView)grid.Items[0])["Id"];}
   throw new ArgumentException("Listeden çalışanı seçin (yoksa önce 'Çalışanı ekle').");}
  void Islem(Button b,Action a){b.Click+=(_,_)=>{try{a();Refresh();}catch(Exception ex){status.Text="✖ "+ex.Message;}};}
  Islem(ekle,()=>{if(!int.TryParse(user.Text.Trim(),out int u)||u<1)throw new ArgumentException("ERP kullanıcı numarasını yazın (Kullanıcı ve Yetkiler ekranındaki No).");var id=service.Kaydet(admin,u,name.Text.Trim().Length>0?name.Text.Trim():"Çalışan "+u,role.SelectedItem!.ToString()!);Refresh();grid.SelectedItem=grid.Items.Cast<DataRowView>().FirstOrDefault(r=>(Guid)r["Id"]==id);status.Text="Çalışan eklendi ve seçildi. Şimdi 'Telefon kodu üret ve kopyala'.";});
  Islem(kod,()=>{
   var id=Selected();
   if(uzak){https.RaiseEvent(new RoutedEventArgs(System.Windows.Controls.Primitives.ButtonBase.ClickEvent));return;}
   var info=ana?.YerelMobilTanim??throw new InvalidOperationException("Önce yukarıdan 'Bağlantıyı başlat'a basın.");
   code.Text=MobilYerelSunucu.Paket(info,service.Esle(admin,id));Clipboard.SetText(code.Text);
   status.Text="✔ Kod kopyalandı. Telefona (WhatsApp/e-posta) gönderin; telefonda MiaPaxERP Mobil'i açıp 'Bağlan'a basın ve kodu yapıştırın. 15 dakika geçerli, tek kullanımlık."+(info.DisAdres is null?" Dış IP girilmediği için yalnız aynı Wi-Fi'de çalışır.":"");});
  Islem(iptal,()=>{var id=Selected();if(MessageBox.Show("Seçili hesap ve bağlı tüm telefonlar kapatılsın mı?","Mobil bağlantı",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;service.Iptal(admin,id);code.Clear();status.Text="Hesap kapatıldı; eski cihazlar artık bağlanamaz.";});
  Islem(patron,()=>{var existing=service.Liste(admin).AsEnumerable().FirstOrDefault(r=>r.Field<int>("KullaniciId")==admin);var id=service.Kaydet(admin,admin,existing?.Field<string>("Ad")??"Patron","PATRON");Refresh();grid.SelectedItem=grid.Items.Cast<DataRowView>().First(r=>(Guid)r["Id"]==id);status.Text="Patron hesabınız seçildi.";});
  Islem(https,()=>{var profile=KolayBaglantiProfili.Oku();var address=KolayBaglantiProfili.KisaAdres(KolayBaglantiProfili.Https(uzak?HttpsOturumu.Istemci!.Adres:profile.MobilHttps));var pair=service.Esle(admin,Selected());var packet=System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(new{v=1,address,code=pair});code.Text="MPX-HTTPS1:"+Convert.ToBase64String(packet).TrimEnd('=').Replace('+','-').Replace('/','_');Clipboard.SetText(code.Text);status.Text="HTTPS kodu kopyalandı; telefonda bağlantı kodu alanına yapıştırın. 15 dakika geçerli.";});
  Islem(tek,()=>{code.Text=service.Esle(admin,Selected());status.Text="Bu kod HTTPS adresiyle birlikte telefona girilir. 15 dakika geçerli, tek kullanımlık.";});
  Refresh();
 }
}

/// <summary>Mobil bağlantıyı adım adım denetler, düzeltebildiğini düzeltir ve yapay zekâ bağlantısı varsa sonucu yorumlatır.</summary>
public static class MobilBaglantiDenetimi{
 static async Task<bool> PortAcik(string ip,int port,int ms=2500){
  try{using var tcp=new System.Net.Sockets.TcpClient();using var cts=new CancellationTokenSource(ms);await tcp.ConnectAsync(ip,port,cts.Token);return true;}
  catch(Exception e) when(e is System.Net.Sockets.SocketException or OperationCanceledException){return false;}
 }
 static bool KuralVar(string ad){
  try{var psi=new System.Diagnostics.ProcessStartInfo("netsh",$"advfirewall firewall show rule name=\"{ad}\""){RedirectStandardOutput=true,UseShellExecute=false,CreateNoWindow=true};
   using var pr=System.Diagnostics.Process.Start(psi)!;string o=pr.StandardOutput.ReadToEnd();pr.WaitForExit(5000);return pr.ExitCode==0&&o.Contains(ad,StringComparison.OrdinalIgnoreCase);}
  catch(Exception e) when(e is System.ComponentModel.Win32Exception or InvalidOperationException){return false;}
 }
 public static async Task<string> CalistirAsync(string connection,int admin,MainWindow? ana,string? lanIp,TextBox disKutu,TextBox portKutu,Func<Task> baslat,Action<string> ilerleme){
  var r=new System.Text.StringBuilder();void Satir(bool? ok,string m){r.AppendLine((ok switch{true=>"✔ ",false=>"✖ ",_=>"• "})+m);ilerleme(r.ToString()+"\n…");}
  // 1. yerel IP
  if(string.IsNullOrEmpty(lanIp)){Satir(false,"Bu bilgisayarda özel ağ (Wi-Fi/Ethernet) IPv4 adresi yok. Bilgisayarı modeme bağlayın.");}
  else Satir(true,"Yerel IP: "+lanIp);
  // 2. dış IP
  string? bulunan=null;try{bulunan=await MobilYerelSunucu.DisIpBulAsync();}catch(InvalidOperationException){}
  string girilen=disKutu.Dispatcher.Invoke(()=>disKutu.Text.Trim());
  if(bulunan is null)Satir(null,"İnternetteki dış IP öğrenilemedi (internet kapalı olabilir).");
  else if(girilen.Length==0){disKutu.Dispatcher.Invoke(()=>disKutu.Text=bulunan);girilen=bulunan;Satir(true,"Dış IP otomatik bulundu ve yazıldı: "+bulunan);}
  else if(girilen!=bulunan)Satir(false,$"Girilen dış IP ({girilen}) şu anki dış IP'den ({bulunan}) farklı. Dış IP değişmiş olabilir; düzeltip yeniden kod üretin.");
  else Satir(true,"Dış IP doğru: "+girilen);
  // 3. sunucu
  if(ana?.YerelMobilTanim is null||(girilen.Length>0&&ana.YerelMobilTanim.DisAdres is null)||(ana.YerelMobilTanim?.DisAdres is {} da&&!da.Contains(girilen,StringComparison.Ordinal))){
   try{await disKutu.Dispatcher.Invoke(baslat);Satir(true,"Mobil bağlantı başlatıldı.");}catch(Exception ex){Satir(false,"Bağlantı başlatılamadı: "+ex.Message);}
  }else Satir(true,"Mobil bağlantı zaten açık.");
  int port=5189;int.TryParse(portKutu.Dispatcher.Invoke(()=>portKutu.Text.Trim()),out port);
  // 4. yerel port
  if(!string.IsNullOrEmpty(lanIp)){bool acik=await PortAcik(lanIp,5189);Satir(acik,acik?"Bu bilgisayarda 5189 portu dinleniyor.":"5189 portu yanıt vermiyor; bağlantı başlatılamamış olabilir.");}
  // 5. güvenlik duvarı
  bool yerelKural=KuralVar("MiapaxERP Mobil Yerel TLS"),disKural=KuralVar("MiapaxERP Mobil Dis IP TLS");
  Satir(yerelKural,yerelKural?"Windows yerel ağ izni var.":"Windows yerel ağ izni yok → 'Windows iznini ver' düğmesine basın.");
  if(girilen.Length>0)Satir(disKural,disKural?"Windows dış IP izni var.":"Windows dış IP izni yok → 'Windows iznini ver' düğmesine basın (dış IP yazılıyken).");
  // 6. dış erişim
  if(girilen.Length>0&&MobilYerelSunucu.DisIp(girilen)){
   bool d=await PortAcik(girilen,port,4000);
   Satir(d?true:null,d?$"Dış IP {girilen}:{port} erişilebilir görünüyor.":$"Dış IP {girilen}:{port} bu bilgisayardan doğrulanamadı. Modemde port yönlendirme ({port} → {lanIp}:5189) yapılmamış olabilir; bazı modemler içeriden dış IP testine izin vermez, telefonda mobil veriyle deneyin.");
  }
  string ozet=r.ToString();
  // 7. yapay zekâ
  try{
   var ayar=AsistanAyari.Oku(System.IO.Path.Combine(GorunumDeposu.Klasor(connection,admin),"asistan.json"));
   if(ayar.Tur=="Yerleşik rehber"){r.AppendLine();r.AppendLine("Yapay zekâ bağlantısı ayarlı değil; yukarıdaki ✖ satırlarındaki adımları uygulayın. (Ana sayfadaki asistan ayarlarından yapay zekâ bağlantısı tanımlarsanız burada ayrıntılı yorum da yapılır.)");return r.ToString();}
   ilerleme(ozet+"\nYapay zekâ yorumluyor…");
   string soru="MiaPaxERP masaüstü programındaki mobil bağlantı denetiminin sonucu aşağıda. Telefonlar aynı Wi-Fi'de yerel IP:5189 ile, dışarıdan ise modemde port yönlendirmeyle dış IP:port üzerinden bağlanıyor (kendinden imzalı sertifika + parmak izi). "+
    "Sorunları teşhis et ve kullanıcıya Türkçe, numaralı, kısa ve uygulanabilir adımlar ver (modem port yönlendirme, CGNAT, Windows ağ profili Özel, güvenlik duvarı gibi). Parola isteme. Sorun yoksa telefonda kodu yapıştırmasını söyle.\n\n"+ozet;
   var y=await new AsistanIstemcisi().SorAsync(ayar,soru,"Mobil bağlantı",Array.Empty<AsistanMesaji>(),CancellationToken.None);
   r.AppendLine();r.AppendLine(y.Metin is {Length:>0} m?"Yapay zekâ önerisi:\n"+m.Trim():"Yapay zekâ yanıt vermedi: "+y.Durum);
  }catch(Exception ex) when(ex is not OutOfMemoryException){r.AppendLine();r.AppendLine("Yapay zekâ yorumu alınamadı: "+ex.Message);}
  return r.ToString();
 }
}
