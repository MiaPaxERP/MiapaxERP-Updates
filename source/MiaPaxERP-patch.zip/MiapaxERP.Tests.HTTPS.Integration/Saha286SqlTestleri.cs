using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class Saha286SqlTestleri
{
 static void Sql(SqlConnection c,string s){using var q=new SqlCommand(s,c);q.ExecuteNonQuery();}
 [Fact]public void SehirKisileriTekSayilirGorusmesizKartVeSayfalamaKorunur(){
  string name="MiapaxSaha286_"+Guid.NewGuid().ToString("N");using var master=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=5");master.Open();Sql(master,"CREATE DATABASE ["+name+"]");
  try{string cs=new SqlConnectionStringBuilder(master.ConnectionString){InitialCatalog=name}.ConnectionString;using var c=new SqlConnection(cs);c.Open();Sql(c,"""
   CREATE TABLE dbo.BERP210_SahaMusteri(Id uniqueidentifier PRIMARY KEY,IlId nvarchar(30),IlceId nvarchar(40),Koy nvarchar(160),Ad nvarchar(160),Telefon nvarchar(30),Olusturan int);
   CREATE TABLE dbo.BERP210_Gorusme(Id uniqueidentifier PRIMARY KEY,MusteriId uniqueidentifier,Tarih datetime2,KayitZamani datetime2,Sonuc nvarchar(2000));
   CREATE TABLE dbo.Kullanicilar(Id int PRIMARY KEY,Aktif bit);INSERT dbo.Kullanicilar VALUES(1,1),(2,1),(3,0);
   CREATE TABLE dbo.KullaniciRolleri(Id int PRIMARY KEY,RolAdi nvarchar(80),Aktif bit);INSERT dbo.KullaniciRolleri VALUES(1,N'Yönetici',1);
   CREATE TABLE dbo.KullaniciRolAtamalari(KullaniciId int,RolId int);INSERT dbo.KullaniciRolAtamalari VALUES(1,1);
   CREATE TABLE dbo.Yetkiler(YetkiKodu varchar(80),Modul nvarchar(100),Islem nvarchar(100),Aciklama nvarchar(200),Aktif bit);
   INSERT dbo.Yetkiler VALUES('STOCK.VIEW','Stok','Gor','',1),('FINANCE.VIEW','Finans','Gor','',1),('FIELD.VIEW','Saha','Gor','',1);
   CREATE TABLE dbo.TestYetki(KullaniciId int,YetkiKodu varchar(80),Yetkili bit);INSERT dbo.TestYetki VALUES(2,'STOCK.VIEW',1),(2,'FINANCE.VIEW',0),(3,'FINANCE.VIEW',1);
   """);Sql(c,"CREATE VIEW dbo.vw_KullaniciEtkinYetkileri AS SELECT * FROM dbo.TestYetki");
   foreach(var (il,count) in new[]{("58",5),("65",30),("38",5),("34",111)})for(int n=0;n<count;n++){using var q=new SqlCommand("INSERT dbo.BERP210_SahaMusteri VALUES(NEWID(),@il,'1',N'Köy',@ad,'05555555555',2)",c);q.Parameters.AddWithValue("@il",il);q.Parameters.AddWithValue("@ad","Kişi "+n.ToString("D3"));q.ExecuteNonQuery();}
   Sql(c,"DECLARE @id uniqueidentifier=(SELECT TOP(1) Id FROM dbo.BERP210_SahaMusteri WHERE IlId='58');INSERT dbo.BERP210_Gorusme VALUES(NEWID(),@id,'2026-01-01','2026-01-01',N'İlk'),(NEWID(),@id,'2026-01-02','2026-01-02',N'İkinci')");
   // Only licensing/permission setup is replaced; the production counting and paging SQL runs unchanged.
   var service=new SahaServisi(cs,2,(_,_,_)=>{});var counts=service.IlSayilari().ToDictionary(x=>x.IlId,x=>x.KisiSayisi);Assert.Equal(5,counts["58"]);Assert.Equal(30,counts["65"]);Assert.Equal(5,counts["38"]);
   var sivas=service.IlGorusmeleri("58");Assert.Equal(5,sivas.TotalCount);Assert.Equal(5,sivas.Rows.Length);Assert.Equal("İkinci",sivas.Rows[0].Sonuc);Assert.Equal(4,sivas.Rows.Count(x=>x.SonGorusme is null));
   var first=service.IlGorusmeleri("34");var second=service.IlGorusmeleri("34",offset:first.NextOffset);Assert.Equal(100,first.Rows.Length);Assert.Equal(111,first.TotalCount);Assert.True(first.HasMore);Assert.Equal(11,second.Rows.Length);Assert.False(second.HasMore);Assert.Empty(first.Rows.Select(x=>x.Id).Intersect(second.Rows.Select(x=>x.Id)));
   var filtered=service.IlGorusmeleri("34",search:"Kişi 110");Assert.Single(filtered.Rows);Assert.Equal(1,filtered.TotalCount);
   Assert.Equal(new[]{"STOCK.VIEW"},new MenuYetkiServisi(cs,2).Yetkiler());Assert.Empty(new MenuYetkiServisi(cs,3).Yetkiler());Assert.Equal(3,new MenuYetkiServisi(cs,1).Yetkiler().Length);
   Sql(c,"UPDATE dbo.TestYetki SET Yetkili=0 WHERE KullaniciId=2");Assert.Empty(new MenuYetkiServisi(cs,2).Yetkiler());
  }finally{if(!System.Text.RegularExpressions.Regex.IsMatch(name,"^MiapaxSaha286_[a-f0-9]{32}$"))throw new InvalidOperationException();Sql(master,"ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]");}
 }
}
