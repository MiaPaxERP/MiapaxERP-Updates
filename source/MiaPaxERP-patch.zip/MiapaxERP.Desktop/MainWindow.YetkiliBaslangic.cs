using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
 bool yetkiYonlendirmesi;
 void KisayolSatisYeni_Click(object sender,RoutedEventArgs e)=>YetkiliTicaretKisayolu("SALES");
 void KisayolAlisYeni_Click(object sender,RoutedEventArgs e)=>YetkiliTicaretKisayolu("PURCHASE");
 void YetkiliTicaretKisayolu(string code){var b=TemaMenuOgeleri.Children.OfType<Button>().FirstOrDefault(x=>x.Tag as string==code&&x.Visibility==Visibility.Visible);if(b is null)return;sonMenuHedefi=b;b.RaiseEvent(new RoutedEventArgs(Button.ClickEvent,b));}
 bool EkranYetkisi(string code)=>DemoModu||aktifKullanici is not null&&menuYetkileri.Contains(code)&&(MiapaxERP.Lisans.Core.UrunKatalogu.YetkiModulu(code) is not string module||LisansOturumu.ModulVar(module));
 void YetkiliEkranaYonlendir(){
  if(yetkiYonlendirmesi)return;yetkiYonlendirmesi=true;try{
   TumIcerikleriGizle();sonMenuHedefi=null;SayfaBasligi.Text=aktifKullanici is null?"Oturum açın":"Yetkili ekranınızı seçin";
   if(aktifKullanici is null&&!DemoModu)return;
   var target=TemaMenuOgeleri.Children.OfType<Button>().FirstOrDefault(b=>b.Visibility==Visibility.Visible&&b.IsEnabled);
   if(target is null){SayfaBasligi.Text="Bu hesap için ekran yetkisi tanımlanmamış";return;}
   sonMenuHedefi=target;target.RaiseEvent(new RoutedEventArgs(Button.ClickEvent,target));
  }finally{yetkiYonlendirmesi=false;}
 }
 void YardimciEkranYetkileriniUygula(){
  if(BtnTakvimBildirim is null)return;
  bool home=EkranYetkisi("DASHBOARD.VIEW"),calendar=EkranYetkisi("CALENDAR.VIEW"),assistant=EkranYetkisi("ASSISTANT.VIEW");
  BtnTakvimBildirim.Visibility=calendar?Visibility.Visible:Visibility.Collapsed;
  BrdIsTakvimi.Visibility=calendar&&home?Visibility.Visible:Visibility.Collapsed;
  if(!calendar){BrdTakvimAcilUyari.Visibility=Visibility.Collapsed;takvimUyariPenceresi?.Close();}
  BtnAnaYardim.Visibility=assistant?Visibility.Visible:Visibility.Collapsed;
  if(!assistant)AnaSayfaYardimKatmani.Visibility=Visibility.Collapsed;
  BtnAgDurumu.Visibility=EkranYetkisi("USERS.MANAGE")?Visibility.Visible:Visibility.Collapsed;
  BtnYerelVeriler.Visibility=EkranYetkisi("USERS.MANAGE")?Visibility.Visible:Visibility.Collapsed;
  if(!home&&sonDakikaBand is not null){sonDakikaBand.Visibility=Visibility.Collapsed;sonDakikaSirasi.Clear();}
  foreach(var b in KartKisayol.Children.OfType<Button>())b.Visibility=b.Tag is string code&&EkranYetkisi(code)?Visibility.Visible:Visibility.Collapsed;
  void Card(FrameworkElement control,bool allowed){for(DependencyObject? p=control.Parent;p is FrameworkElement f;p=f.Parent)if(f is Border border){border.Visibility=allowed?Visibility.Visible:Visibility.Collapsed;break;}}
  Card(AnaKritikStokTablosu,EkranYetkisi("STOCK.VIEW"));Card(AnaAktifUretimTablosu,EkranYetkisi("PRODUCTION.VIEW"));Card(AnaBorcluCarilerTablosu,EkranYetkisi("CUSTOMER.VIEW")||EkranYetkisi("FINANCE.VIEW"));Card(AnaBugunEvrakTablosu,EkranYetkisi("CHECKNOTE.VIEW"));Card(AnaYaklasanOdemeTablosu,EkranYetkisi("FINANCE.VIEW"));
 }
}
