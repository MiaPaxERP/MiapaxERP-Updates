﻿using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Web.WebView2.Wpf;
using Microsoft.Web.WebView2.Core;

namespace MiapaxERP.Desktop;
public partial class KrokiYonetimi
{
    private WebView2? web;
    private WebView2? aiWeb;
    private CoreWebView2Environment? krokiOrtami;
    private bool webBasladi;
    // Kroki tek ekrandır: Arazi Stüdyosu (konum → tarla → su kaynağı → borular → analiz → PDF).
    // Önceki planlayıcı ve AI sihirbazı aynı tarayıcıda "Klasik araçlar" ile açılır; üstte geri dönüş şeridi eklenir.
    private const string StudyoAdresi="https://kroki.boruerp.local/arazi.html";
    private void GelismisKrokiyiBagla()
    {
        Content=null;
        var gelismis=new ContentControl();Content=gelismis;
        web=new WebView2();
        // Sağda açılıp kapanan TKGM ada/parsel paneli için iki sütun: kroki + panel (ayrı pencere açılmaz).
        krokiIzgara=new Grid();krokiIzgara.ColumnDefinitions.Add(new ColumnDefinition());krokiIzgara.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
        krokiIzgara.Children.Add(web);gelismis.Content=krokiIzgara;
        WebCeviri.Bagla(web);// Arazi Stüdyosu ve klasik araçlar program diliyle görünür
        Loaded+=async (_,_)=>{
            if(webBasladi)return;webBasladi=true;
            try{
                var profile=krokiProfil??Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","KrokiTarayici");
                var env=krokiOrtami=await CoreWebView2Environment.CreateAsync(null,profile);
                await web.EnsureCoreWebView2Async(env);
                web.CoreWebView2.SetVirtualHostNameToFolderMapping("kroki.boruerp.local",Path.Combine(AppContext.BaseDirectory,"Assets","KrokiWeb"),CoreWebView2HostResourceAccessKind.DenyCors);
                web.CoreWebView2.Settings.AreDevToolsEnabled=false;
                web.CoreWebView2.NavigationStarting+=(_,e)=>{if(!Yerel(e.Uri))e.Cancel=true;};
                web.CoreWebView2.NewWindowRequested+=(_,e)=>{e.Handled=true;};
                web.CoreWebView2.WebMessageReceived+=async (_,e)=>await MesajIsle(web!,e);
                web.CoreWebView2.NavigationCompleted+=async (_,_)=>await KlasikSeritEkle(web!);
                // Canlı konum yalnız programın kendi kroki sayfasına verilir (Windows konum izni de açık olmalı).
                web.CoreWebView2.PermissionRequested+=(_,e)=>{if(e.PermissionKind==CoreWebView2PermissionKind.Geolocation&&Yerel(e.Uri)){e.State=CoreWebView2PermissionState.Allow;e.SavesInProfile=true;}};
                web.Source=new Uri(StudyoAdresi+"?v="+typeof(KrokiYonetimi).Assembly.GetName().Version);
                if(Window.GetWindow(this) is Window owner)owner.Closed+=(_,_)=>web.Dispose();
            }catch(Exception ex){gelismis.Content=new TextBlock{Text="Arazi Stüdyosu açılamadı. Microsoft Edge WebView2 Runtime kurulu olmalı.\n"+ex.Message,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(24)};}
        };
    }
    private async Task MesajIsle(WebView2 w,CoreWebView2WebMessageReceivedEventArgs e)
    {
                if(!Yerel(e.Source))return;
                try{
                    using var msg=JsonDocument.Parse(e.WebMessageAsJson);var root=msg.RootElement;
                    switch(root.GetProperty("action").GetString()){
                        case "stockSearch":
                            try{KrokiYetkiKontrol();var rows=await Task.Run(()=>new KrokiTeklifServisi(ServisBaglantisi!,ServisKullanici).StokAra(root.GetProperty("search").GetString()??""));w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="stockResult",rows}));}
                            catch(Exception ex){w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="stockResult",error=ex.Message}));}break;
                        case "designSettings":KrokiAsistanAyarlari();break;
                        case "designAsk":await KrokiAsistanSor(w,root);break;
                        case "projectAsk":await KrokiProjeSor(w,root);break;
                        case "studioAsk":await KrokiStudyoSor(w,root);break;
                        case "studioReview":await KrokiStudyoYorum(w,root);break;
                        case "tkgm":await TkgmPaneliAc(w);break;
                        case "map":MessageBox.Show("Harici tarayıcı yerine program içindeki haritayı kullanın.","Kroki");break;
                        case "googleSettings":KrokiHaritaAyarlari.Ayarlar(Window.GetWindow(this));goto case "googleRead";
                        case "googleRead":w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="googleSettings",key=KrokiHaritaAyarlari.Oku()}));break;
                        case "parcelSettings":ParselServisi.Ayarlar(Window.GetWindow(this));break;
                        case "parcelQuery":
                            try{var geometry=await ParselServisi.Sorgula(root.GetProperty("fields"));w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="parcelResult",geometry}));}
                            catch(Exception ex){w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="parcelResult",error=ex.Message}));}break;
                        case "ready":
                            string logo=Tema170.Mevcut.Logo;
                            if(File.Exists(logo) && !GorunumDeposu.EskiUygulamaLogosu(logo)){var image=GorunumDeposu.Resim(logo);var png=new System.Windows.Media.Imaging.PngBitmapEncoder();png.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(image));using var stream=new MemoryStream();png.Save(stream);w.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="logo",url="data:image/png;base64,"+Convert.ToBase64String(stream.ToArray())}));}
                            break;
                        case "pdf":
                            var save=new SaveFileDialog{Filter="PDF belgesi|*.pdf",FileName=root.TryGetProperty("file",out var fn)&&fn.ValueKind==JsonValueKind.String&&fn.GetString() is { Length:>0 and <=80 } ad&&ad.IndexOfAny(Path.GetInvalidFileNameChars())<0?ad:"MiapaxERP-Sulama-Plani.pdf"};
                            if(save.ShowDialog(Window.GetWindow(this))==true){await WebCeviri.CevirAsync(w.CoreWebView2);var settings=w.CoreWebView2.Environment.CreatePrintSettings();settings.PageWidth=8.2677;settings.PageHeight=11.6929;settings.MarginTop=.47;settings.MarginBottom=.47;settings.MarginLeft=.47;settings.MarginRight=.47;settings.ShouldPrintBackgrounds=true;settings.ShouldPrintHeaderAndFooter=false;if(!await w.CoreWebView2.PrintToPdfAsync(save.FileName,settings))throw new IOException("PDF oluşturulamadı.");}
                            await w.ExecuteScriptAsync("document.body.classList.remove('fp-printing')");break;
                    }
                }catch(Exception ex){DestekIzleme.Bildir(ex,"KrokiYonetimi.Web");MessageBox.Show(Window.GetWindow(this),ex.Message,"Kroki işlemi tamamlanamadı");await w.ExecuteScriptAsync("document.body.classList.remove('fp-printing')");}
    }
    /// <summary>Yapay zekâ proje sihirbazı: ölçü, boru, sulama türü, aksesuar ve su kaynağından otomatik hesap, 3D görünüm ve PDF.</summary>
    private async Task AiProjeAc(TabItem tab)
    {
        if(aiWeb is not null)return;
        try{
            KrokiYetkiKontrol();
            if(krokiOrtami is null)throw new InvalidOperationException("Kroki tarayıcısı henüz hazır değil; birkaç saniye sonra tekrar deneyin.");
            aiWeb=new WebView2();tab.Content=aiWeb;
            await aiWeb.EnsureCoreWebView2Async(krokiOrtami);
            aiWeb.CoreWebView2.SetVirtualHostNameToFolderMapping("kroki.boruerp.local",Path.Combine(AppContext.BaseDirectory,"Assets","KrokiWeb"),CoreWebView2HostResourceAccessKind.DenyCors);
            aiWeb.CoreWebView2.Settings.AreDevToolsEnabled=false;
            aiWeb.CoreWebView2.NavigationStarting+=(_,e)=>{if(!Yerel(e.Uri))e.Cancel=true;};
            aiWeb.CoreWebView2.NewWindowRequested+=(_,e)=>{e.Handled=true;};
            var hedef=aiWeb;hedef.CoreWebView2.WebMessageReceived+=async (_,e)=>await MesajIsle(hedef,e);
            aiWeb.Source=new Uri("https://kroki.boruerp.local/ai-proje.html?v="+typeof(KrokiYonetimi).Assembly.GetName().Version);
            if(Window.GetWindow(this) is Window owner)owner.Closed+=(_,_)=>hedef.Dispose();
        }catch(Exception ex){aiWeb?.Dispose();aiWeb=null;DestekIzleme.Bildir(ex,"KrokiYonetimi.AiProje");tab.Content=new TextBlock{Text="Yapay zekâ proje sihirbazı açılamadı: "+ex.Message+"\nSekmeyi yeniden seçerek tekrar deneyebilirsiniz.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(24)};}
    }
    private Grid? krokiIzgara;
    private Border? tkgmPanel;
    private string? sonParsel;
    /// <summary>
    /// Resmî TKGM Parsel Sorgu sitesini kroki ekranının sağında panel olarak açar (ayrı pencere yok).
    /// Kullanıcı ada/parseli sitede sorgulayınca sitenin kendi aldığı parsel yanıtı (GeoJSON) okunup tarla sınırı
    /// olarak krokiye çizilir; dosya indirmek gerekmez. Program siteye kendi adına istek göndermez, oturum veya
    /// doğrulama atlatılmaz. Sitede yine de indirme yapılırsa uzantısına bakılmadan içerik (KML/KMZ/GeoJSON) okunur.
    /// </summary>
    private async Task TkgmPaneliAc(WebView2 studyo)
    {
        if(krokiIzgara is null)return;
        if(tkgmPanel is not null){tkgmPanel.Visibility=tkgmPanel.Visibility==Visibility.Visible?Visibility.Collapsed:Visibility.Visible;return;}
        var tw=new WebView2();
        var bilgi=new TextBlock{Text="İl, ilçe, mahalle/köy, ada ve parseli seçip sorgulayın. Parsel bulununca sınırı kendiliğinden soldaki krokiye çizilir — dosya indirmeniz gerekmez.",TextWrapping=TextWrapping.Wrap,Padding=new Thickness(12,8,12,8),VerticalAlignment=VerticalAlignment.Center};
        var kapat=new System.Windows.Controls.Button{Content="✕ Paneli kapat",Margin=new Thickness(6),Padding=new Thickness(10,4,10,4)};
        var ust=new DockPanel{Background=new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xE7,0xF6,0xF0))};DockPanel.SetDock(kapat,Dock.Right);ust.Children.Add(kapat);ust.Children.Add(bilgi);
        var kok=new DockPanel();DockPanel.SetDock(ust,Dock.Top);kok.Children.Add(ust);kok.Children.Add(tw);
        var panel=tkgmPanel=new Border{Width=Math.Clamp(ActualWidth*0.45,480,760),BorderThickness=new Thickness(1,0,0,0),BorderBrush=System.Windows.Media.Brushes.Gray,Child=kok};
        kapat.Click+=(_,_)=>panel.Visibility=Visibility.Collapsed;
        Grid.SetColumn(panel,1);krokiIzgara.Children.Add(panel);
        if(Window.GetWindow(this) is Window owner)owner.Closed+=(_,_)=>tw.Dispose();
        try{
            var env=await CoreWebView2Environment.CreateAsync(null,Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","TkgmTarayici"));
            await tw.EnsureCoreWebView2Async(env);
            // Yalnız TKGM alan adlarında gezinilir; diğer bağlantılar engellenir.
            tw.CoreWebView2.NavigationStarting+=(_,e)=>{if(!TkgmAdresi(e.Uri)&&!e.Uri.StartsWith("blob:",StringComparison.Ordinal)&&!e.Uri.StartsWith("data:",StringComparison.Ordinal))e.Cancel=true;};
            tw.CoreWebView2.NewWindowRequested+=(_,e)=>{e.Handled=true;if(TkgmAdresi(e.Uri))tw.CoreWebView2.Navigate(e.Uri);};
            // Sitenin kendi sorgu yanıtı: tek parsel içeren GeoJSON gelirse doğrudan krokiye aktarılır.
            tw.CoreWebView2.WebResourceResponseReceived+=async(_,e)=>{
                try{
                    if(e.Response is null||e.Response.StatusCode!=200||!TkgmAdresi(e.Request.Uri))return;
                    if(!e.Response.Headers.Contains("Content-Type")||!e.Response.Headers.GetHeader("Content-Type").Contains("json",StringComparison.OrdinalIgnoreCase))return;
                    using var akis=await e.Response.GetContentAsync();if(akis is null)return;
                    var metin=await SinirliOku(akis,2_000_000);if(metin is null||!ParselYaniti(metin)||metin==sonParsel)return;
                    sonParsel=metin;
                    studyo.CoreWebView2?.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="parcelFile",name="TKGM Parsel Sorgu",text=metin}));
                }catch(Exception ex){DestekIzleme.Bildir(ex,"KrokiYonetimi.TkgmYanit");}
            };
            tw.CoreWebView2.DownloadStarting+=(_,e)=>{
                string ad=Path.GetFileName(e.ResultFilePath);
                string hedef=Path.Combine(Path.GetTempPath(),"MiapaxERP-parsel-"+Guid.NewGuid().ToString("N")+".indir");
                e.ResultFilePath=hedef;e.Handled=true;
                e.DownloadOperation.StateChanged+=async (_,_)=>{
                    if(e.DownloadOperation.State==CoreWebView2DownloadState.InProgress)return;
                    try{
                        if(e.DownloadOperation.State!=CoreWebView2DownloadState.Completed)throw new IOException("İndirme tamamlanamadı.");
                        var fi=new FileInfo(hedef);if(!fi.Exists||fi.Length>5_000_000)throw new IOException("Parsel dosyası okunamadı veya çok büyük.");
                        string metin=ParselDosyasiMetni(await File.ReadAllBytesAsync(hedef));
                        studyo.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="parcelFile",name=ad,text=metin}));
                    }catch(Exception ex){studyo.CoreWebView2?.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="tkgmStatus",text="Parsel dosyası aktarılamadı: "+ex.Message,error=true}));}
                    finally{try{File.Delete(hedef);}catch(IOException){}catch(UnauthorizedAccessException){}}
                };
            };
            tw.Source=new Uri("https://parselsorgu.tkgm.gov.tr/");
        }catch(Exception ex){DestekIzleme.Bildir(ex,"KrokiYonetimi.Tkgm");bilgi.Text="TKGM Parsel Sorgu açılamadı: "+ex.Message;}
    }
    private static bool TkgmAdresi(string u)=>Uri.TryCreate(u,UriKind.Absolute,out var x)&&x.Scheme=="https"&&(x.Host=="tkgm.gov.tr"||x.Host.EndsWith(".tkgm.gov.tr",StringComparison.OrdinalIgnoreCase));
    private static async Task<string?> SinirliOku(Stream akis,int sinir)
    {
        using var ms=new MemoryStream();var tampon=new byte[16384];int n;
        while((n=await akis.ReadAsync(tampon))>0){ms.Write(tampon,0,n);if(ms.Length>sinir)return null;}
        return System.Text.Encoding.UTF8.GetString(ms.ToArray());
    }
    /// <summary>Yanıt tek parsel (Polygon/MultiPolygon) içeren GeoJSON Feature veya tek öğeli FeatureCollection mı?</summary>
    internal static bool ParselYaniti(string metin)
    {
        try{
            using var d=JsonDocument.Parse(metin);var r=d.RootElement;if(r.ValueKind!=JsonValueKind.Object||!r.TryGetProperty("type",out var t))return false;
            if(t.GetString()=="FeatureCollection"){if(!r.TryGetProperty("features",out var f)||f.ValueKind!=JsonValueKind.Array||f.GetArrayLength()!=1)return false;r=f[0];}
            else if(t.GetString()!="Feature")return false;
            return r.TryGetProperty("geometry",out var g)&&g.ValueKind==JsonValueKind.Object&&g.TryGetProperty("type",out var gt)&&gt.GetString() is "Polygon" or "MultiPolygon";
        }catch(JsonException){return false;}
    }
    /// <summary>İndirilen parsel dosyasını uzantısına bakmadan çözer: KMZ (zip) içindeki KML veya düz KML/GeoJSON metni.</summary>
    internal static string ParselDosyasiMetni(byte[] veri)
    {
        if(veri.Length>4&&veri[0]==(byte)'P'&&veri[1]==(byte)'K'){
            using var zip=new System.IO.Compression.ZipArchive(new MemoryStream(veri),System.IO.Compression.ZipArchiveMode.Read);
            var giris=zip.Entries.FirstOrDefault(x=>x.FullName.EndsWith(".kml",StringComparison.OrdinalIgnoreCase))??zip.Entries.FirstOrDefault(x=>x.FullName.EndsWith(".geojson",StringComparison.OrdinalIgnoreCase)||x.FullName.EndsWith(".json",StringComparison.OrdinalIgnoreCase))
                ??throw new InvalidDataException("Arşivde KML veya GeoJSON parsel dosyası yok.");
            if(giris.Length>5_000_000)throw new InvalidDataException("Parsel dosyası çok büyük.");
            using var s=giris.Open();using var r=new StreamReader(s,System.Text.Encoding.UTF8,true);return r.ReadToEnd();
        }
        using var rd=new StreamReader(new MemoryStream(veri),System.Text.Encoding.UTF8,true);return rd.ReadToEnd();
    }
    /// <summary>Klasik planlayıcı / AI sihirbazı sayfalarına Arazi Stüdyosu'na dönüş şeridi ekler.</summary>
    private static async Task KlasikSeritEkle(WebView2 w)
    {
        if(w.CoreWebView2 is null||w.Source is null||w.Source.AbsolutePath.EndsWith("/arazi.html",StringComparison.OrdinalIgnoreCase))return;
        const string js="""
(()=>{if(document.getElementById('mpxSerit'))return;const d=document.createElement('div');d.id='mpxSerit';
d.style.cssText='position:sticky;top:0;z-index:99999;display:flex;gap:8px;align-items:center;padding:8px 14px;background:#123b31;color:#fff;font:14px Segoe UI,sans-serif';
const b=(t,u)=>{const a=document.createElement('a');a.textContent=t;a.href=u;a.style.cssText='color:#fff;background:#ffffff22;border-radius:9px;padding:6px 12px;text-decoration:none';return a;};
d.append(b('← Arazi Stüdyosu','/arazi.html'),b('Klasik planlayıcı','/index.html'),b('AI proje sihirbazı','/ai-proje.html'));
const s=document.createElement('span');s.textContent='Klasik araçlar';s.style.cssText='margin-left:auto;opacity:.7';d.append(s);document.body.prepend(d);})();
""";
        try{await w.ExecuteScriptAsync(js);}catch(Exception e){DestekIzleme.Bildir(e,"KrokiYonetimi.Serit");}
    }
    private static bool Yerel(string value)=>Uri.TryCreate(value,UriKind.Absolute,out var uri)&&uri.Scheme=="https"&&uri.Host=="kroki.boruerp.local";
    private static void HaritaAc(string value)
    {
        if(!Uri.TryCreate(value,UriKind.Absolute,out var uri)||uri.Scheme!="https"||!new[]{"parselsorgu.tkgm.gov.tr","www.google.com","earth.google.com","www.openstreetmap.org","openstreetmap.org"}.Contains(uri.Host))return;
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(uri.AbsoluteUri){UseShellExecute=true});
    }
}


