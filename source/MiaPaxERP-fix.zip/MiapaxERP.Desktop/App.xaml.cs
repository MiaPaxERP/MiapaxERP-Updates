using System.Configuration;
using System.Data;
using System.Windows;

namespace MiapaxERP.Desktop
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        internal static bool LisansAcilistaDogrulandi;
        private static void EskiDosyalariYetkiyleTemizle()
        {
            try
            {
                var start = new System.Diagnostics.ProcessStartInfo(System.IO.Path.Combine(AppContext.BaseDirectory, "MiapaxERP.Updater.exe")) { UseShellExecute = true, Verb = "runas" };
                start.ArgumentList.Add("cleanup"); start.ArgumentList.Add(AppContext.BaseDirectory.TrimEnd(System.IO.Path.DirectorySeparatorChar));
                start.ArgumentList.Add(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MiapaxERP", "GecisYedekleri"));
                using var process = System.Diagnostics.Process.Start(start); process?.WaitForExit(30000);
            }
            catch (Exception ex) { MessageBox.Show("Eski program dosyaları temizlenemedi: " + ex.Message, "Miapax ERP"); }
        }
        protected override async void OnStartup(StartupEventArgs e)
        {
            try
            {
                MarkaGecisi.Temizle(AppContext.BaseDirectory, System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MiapaxERP", "GecisYedekleri"));
            }
            catch (UnauthorizedAccessException) { EskiDosyalariYetkiyleTemizle(); }
            catch (System.IO.IOException) { /* Kullanımda olan eski dosyalar bir sonraki açılışta tekrar denenir. */ }
            catch (System.Text.Json.JsonException) { /* Geçersiz eski ayar değiştirilmez; program kendi hata bildirimini kullanır. */ }
            TemaPencereServisi.Baslat();DilUygulayici.Baslat();
            Tema170.Uygula(new GorunumTercihleri());
            DispatcherUnhandledException+=(_,args)=>{
                DestekIzleme.Bildir(args.Exception,"ERP");
                // Ekran hatası programı kapatmasın: kullanıcıya bildirilir, açık işlem korunur. Ölümcül hatalar (bellek vb.) yine kapanır.
                if(args.Exception is OutOfMemoryException or StackOverflowException or AccessViolationException)return;
                args.Handled=true;
                try{MessageBox.Show("Bu ekranda beklenmeyen bir hata oluştu, program açık kalmaya devam ediyor.\n\n"+args.Exception.Message+"\n\nHata destek kaydına eklendi.","MiaPaxERP",MessageBoxButton.OK,MessageBoxImage.Warning);}catch(Exception){}
            };
            base.OnStartup(e);
            ShutdownMode = ShutdownMode.OnExplicitShutdown;
            try
            {
                if(MiapaxERPGuncelleme.AcilistaBekleyenGuncelleme(e.Args)){Shutdown();return;}
                KolayBaglantiProfili profil;
                try { profil=KolayBaglantiProfili.Oku(); }
                catch(Exception ex)when(ex is System.IO.IOException or System.Text.Json.JsonException or ArgumentException or UnauthorizedAccessException){profil=new();}
                if(profil.Rol=="Ana"&&!e.Args.Contains("--baglanti",StringComparer.OrdinalIgnoreCase)&&!e.Args.Contains("--https-client",StringComparer.OrdinalIgnoreCase)){
                    bool ready=false;try{ready=await Task.Run(()=>IlkKurulumServisi.HazirMi(MiapaxERPBaglantiAyarlari.Oku().BaglantiDizesi()));}catch(Microsoft.Data.SqlClient.SqlException){}catch(ArgumentException){}
                    if(!ready||e.Args.Contains("--ilk-kurulum",StringComparer.OrdinalIgnoreCase)){if(new IlkKurulumPenceresi().ShowDialog()!=true){Shutdown();return;}profil=KolayBaglantiProfili.Oku();}
                }
                // Yan PC kısayolu eskiden her açılışta --baglanti verirdi; sunucu adresi kayıtlıysa ayar ekranı atlanır (giriş ekranındaki "Sunucu bağlantı ayarları" ile değiştirilir).
                bool yanHazir=!e.Args.Contains("--baglanti-ayarla",StringComparer.OrdinalIgnoreCase)&&(profil.Rol=="Yan"&&profil.MasaustuHttps.Length>0||e.Args.Contains("--baglanti",StringComparer.OrdinalIgnoreCase)&&await Task.Run(SqlYanHazir));
                if((e.Args.Contains("--baglanti",StringComparer.OrdinalIgnoreCase)&&!yanHazir)||e.Args.Contains("--baglanti-ayarla",StringComparer.OrdinalIgnoreCase)||profil.Rol=="Mobil")
                {
                    new BaglantiAyarlariPenceresi{WindowStartupLocation=WindowStartupLocation.CenterScreen}.ShowDialog();
                    profil=KolayBaglantiProfili.Oku();
                    if(profil.Rol!="Yan"&&!await Task.Run(SqlYanHazir)){Shutdown();return;}
                }
                // Yan PC iki şekilde bağlanabilir: ana PC'nin HTTPS servisine veya aynı ağdaki SQL sunucusuna doğrudan.
                // SQL ayarı "Yan" olarak kaydedilmiş ve HTTPS adresi yoksa program doğrudan SQL ile açılır (HTTPS ekranına düşmez).
                static bool SqlYanHazir(){try{var a=MiapaxERPBaglantiAyarlari.Oku();if(a.Rol!="Yan"||string.IsNullOrWhiteSpace(a.Sunucu))return false;var b=new Microsoft.Data.SqlClient.SqlConnectionStringBuilder(a.BaglantiDizesi()){ConnectTimeout=5};using var c=new Microsoft.Data.SqlClient.SqlConnection(b.ConnectionString);c.Open();return true;}catch(Exception x) when(x is Microsoft.Data.SqlClient.SqlException or ArgumentException or InvalidOperationException or System.IO.IOException or System.Text.Json.JsonException){return false;}}
                // Ofisteyken (SQL erişilebilir) SQL ile, dışarıdayken kayıtlı HTTPS adresiyle açılır.
                bool sqlYan=await Task.Run(SqlYanHazir);
                if(!sqlYan&&(profil.Rol=="Yan"||e.Args.Contains("--https-client",StringComparer.OrdinalIgnoreCase)))
                {
                    if(profil.MasaustuHttps.Length==0)
                    {
                        new BaglantiAyarlariPenceresi{WindowStartupLocation=WindowStartupLocation.CenterScreen}.ShowDialog();
                        profil=KolayBaglantiProfili.Oku();
                        if(profil.MasaustuHttps.Length==0&&await Task.Run(SqlYanHazir))goto sqlIleAc;
                        if(profil.MasaustuHttps.Length==0){MessageBox.Show("Ana PC bağlantısı tamamlanmadı.\n\nAna PC'nin SQL sunucusuna bağlanmak için Bağlantı türünü \"Yan PC\" seçip SQL sunucu adını girin ve \"Bağlantıyı test et\" başarılı olduktan sonra Kaydet'e basın; ya da ana PC'nin HTTPS adresini girin.","MiaPaxERP",MessageBoxButton.OK,MessageBoxImage.Information);Shutdown();return;}
                    }
                    profil=profil with{Rol="Yan"};profil.Dogrula(true);
                    var giris=new HttpsGirisPenceresi(profil.MasaustuHttps);
                    if(giris.ShowDialog()!=true||giris.Istemci is null){Shutdown();return;}
                    HttpsOturumu.Baslat(giris.Istemci);
                    var native=new MainWindow(false,giris.Istemci);native.Closed+=async(_,_)=>{try{await giris.Istemci.Cikis();}finally{HttpsOturumu.Temizle();}};MainWindow=native;
                    ShutdownMode=ShutdownMode.OnMainWindowClose;MainWindow.Show();DestekIzleme.Baslat();if(MiapaxERPBaglantiAyarlari.Oku().Rol=="Ana")HttpsAgKesfi.Baslat(MiapaxERPBaglantiAyarlari.BaglantiAdresi(),()=>KolayBaglantiProfili.Oku().MasaustuHttps);return;
                }
                sqlIleAc:
                if (LisansOturumu.Zorunlu)
                {
                    LisansOturumu.Hazirla(MiapaxERPBaglantiAyarlari.BaglantiAdresi());
                    if (!await LisansOturumu.YenileAsync())
                    {
                        var activation = new LisansPenceresi { WindowStartupLocation = WindowStartupLocation.CenterScreen };
                        if (activation.ShowDialog() != true) { Shutdown(); return; }
                    }
                    LisansAcilistaDogrulandi = true;
                }
                await Task.Run(()=>IsletmeSemasi.Hazirla(MiapaxERPBaglantiAyarlari.BaglantiAdresi()));
                MainWindow = new MainWindow();
                ShutdownMode = ShutdownMode.OnMainWindowClose;
                MainWindow.Show();DestekIzleme.Baslat();if(MiapaxERPBaglantiAyarlari.Oku().Rol=="Ana")HttpsAgKesfi.Baslat(MiapaxERPBaglantiAyarlari.BaglantiAdresi(),()=>KolayBaglantiProfili.Oku().MasaustuHttps);
            }
            catch (Exception ex)
            {DestekIzleme.Bildir(ex,"App.xaml");
                MessageBox.Show(ex.Message, "MiapaxERP açılış hatası", MessageBoxButton.OK, MessageBoxImage.Error);
                Shutdown(1);
            }
        }
    }

}

