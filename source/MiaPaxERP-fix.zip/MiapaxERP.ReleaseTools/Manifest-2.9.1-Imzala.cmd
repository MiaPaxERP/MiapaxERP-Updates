@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Manifest-2.9.1-Imzala.ps1" > "%~dp0manifest-imzalama-sonucu.txt" 2>&1
type "%~dp0manifest-imzalama-sonucu.txt"
pause
