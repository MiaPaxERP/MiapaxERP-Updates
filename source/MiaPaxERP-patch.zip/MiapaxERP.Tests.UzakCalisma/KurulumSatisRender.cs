using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MiapaxERP.Desktop;
internal static class KurulumSatisRender
{
 public static void Run(string output){
  Directory.CreateDirectory(output);
  foreach(string theme in new[]{"Acik","Koyu"}){
   var setup=new IlkKurulumPenceresi();var setupContent=(FrameworkElement)setup.Content;Save(setupContent,"ilk-giris",720,720);typeof(IlkKurulumPenceresi).GetMethod("Baglanti",BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(setup,null);Save(setupContent,"sql-baglanti",720,780);
   var sale=new HizliSatisPenceresi("Server=localhost;Database=QA_ONLY;Integrated Security=true;TrustServerCertificate=true",1,true);Save((FrameworkElement)sale.Content,"satis",1100,900);
   setup.Close();sale.Close();
   void Save(FrameworkElement child,string name,int width,int height){
    var host=new Border{Background=theme=="Koyu"?new SolidColorBrush(Color.FromRgb(23,35,51)):Brushes.White,Child=null};
    // Detach without displaying a window: rendering must not fire database Loaded handlers.
    if(child.Parent is ContentControl parent)parent.Content=null;
    host.Child=child;host.Measure(new Size(width,height));host.Arrange(new Rect(0,0,width,height));host.UpdateLayout();TemaOkunurlugu.Uygula(host);host.UpdateLayout();
    var bitmap=new RenderTargetBitmap(width,height,96,96,PixelFormats.Pbgra32);bitmap.Render(host);var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(bitmap));using var stream=File.Create(Path.Combine(output,name+"-"+theme+".png"));png.Save(stream);host.Child=null;
   }
  }
 }
}
