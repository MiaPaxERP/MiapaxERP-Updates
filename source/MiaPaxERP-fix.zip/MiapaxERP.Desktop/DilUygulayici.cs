using FlowDirection = System.Windows.FlowDirection;
using DataGridCell = System.Windows.Controls.DataGridCell;
using ToolTip = System.Windows.Controls.ToolTip;
using ListBox = System.Windows.Controls.ListBox;
using TreeView = System.Windows.Controls.TreeView;
using TextBoxBase = System.Windows.Controls.Primitives.TextBoxBase;
using ListViewItem = System.Windows.Controls.ListViewItem;
using TabControl = System.Windows.Controls.TabControl;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace MiapaxERP.Desktop;

/// <summary>
/// Açılan pencerelerdeki sabit arayüz metinlerini seçili dile çevirir.
/// Veriye bağlı metinler, giriş kutuları ve liste öğeleri (veri olabilecekleri için) değiştirilmez.
/// Türkçe asıllar saklanır; dil Türkçeye dönünce geri yazılır.
/// </summary>
public static class DilUygulayici
{
    private sealed class Asil{public readonly Dictionary<object,(string Asil,string Son)> Degerler=new();}
    private static readonly ConditionalWeakTable<DependencyObject,Asil> asillar=new();
    private static readonly ConditionalWeakTable<Window,object> rtlPencereler=new();
    private static readonly ConditionalWeakTable<DataGrid,object> izlenenTablolar=new();
    private static bool basladi,kullanildi;

    public static void Baslat()
    {
        if(basladi)return;basladi=true;
        kullanildi=!Dil.Turkce;
        foreach(var tip in new[]{typeof(TextBlock),typeof(ContentControl),typeof(DataGrid),typeof(HeaderedItemsControl)})
            EventManager.RegisterClassHandler(tip,FrameworkElement.LoadedEvent,new RoutedEventHandler((s,_)=>{if(kullanildi)Uygula((DependencyObject)s);}));
        EventManager.RegisterClassHandler(typeof(Window),FrameworkElement.LoadedEvent,new RoutedEventHandler((s,_)=>{if(kullanildi)PencereyiUygula((Window)s);}));
        // Kodla sonradan yazılan metinler için etkin pencere 3 sn'de bir yeniden çevrilir; 30 sn'de bir eksikler yapay zekâyla tamamlanır.
        int tik=0;var zamanlayici=new System.Windows.Threading.DispatcherTimer(System.Windows.Threading.DispatcherPriority.Background){Interval=TimeSpan.FromSeconds(3)};
        zamanlayici.Tick+=async(_,_)=>{
            if(Dil.Turkce||Application.Current is not {} uyg)return;
            tik++;
            // Etkin pencere her turda; açık diğer pencereler 4 turda bir (modül pencereleri sonradan panel doldurur).
            foreach(Window w in uyg.Windows)if(w.IsVisible&&(w.IsActive||tik%4==0))PencereyiUygula(w);
            // Pencere olmayan yüzeyler: açılır paneller (bildirim, öneriler), sağ tık menüleri, ipuçları.
            AcilirYuzeyler();
            if(tik%10==0)await Dil.ArkaPlandaTamamlaAsync();
        };
        zamanlayici.Start();
        Dil.Degisti+=()=>
        {
            kullanildi=true;
            var app=Application.Current;if(app==null)return;
            app.Dispatcher.BeginInvoke(()=>{foreach(Window w in app.Windows)PencereyiUygula(w);AcilirYuzeyler();});
        };
    }

    public static void PencereyiUygula(Window w)
    {
        try
        {
            bool rtl=Dil.SagdanSola;
            if(rtl){if(w.FlowDirection!=FlowDirection.RightToLeft){w.FlowDirection=FlowDirection.RightToLeft;rtlPencereler.AddOrUpdate(w,true);}}
            else if(rtlPencereler.TryGetValue(w,out _)){w.FlowDirection=FlowDirection.LeftToRight;rtlPencereler.Remove(w);}
            Ozellik(w,Window.TitleProperty);
            var gorulen=new HashSet<DependencyObject>(ReferenceEqualityComparer.Instance);
            Gez(w,gorulen);
        }
        catch(InvalidOperationException){}
    }

    /// <summary>Popup, ContextMenu ve ToolTip kendi HWND'lerinde çizilir; pencere ağacından ulaşılamadıkları için ayrıca gezilir.</summary>
    public static void AcilirYuzeyler()
    {
        try
        {
            var gorulen=new HashSet<DependencyObject>(ReferenceEqualityComparer.Instance);
            foreach(PresentationSource kaynak in PresentationSource.CurrentSources)
                if(kaynak is { IsDisposed: false, RootVisual: { } kok }&&kok is not Window)Gez(kok,gorulen);
        }
        catch(InvalidOperationException){}
    }

    private static void Gez(DependencyObject d,HashSet<DependencyObject> gorulen)
    {
        if(!gorulen.Add(d))return;
        Uygula(d);
        if(d is Visual or System.Windows.Media.Media3D.Visual3D)
            for(int i=0;i<VisualTreeHelper.GetChildrenCount(d);i++)Gez(VisualTreeHelper.GetChild(d,i),gorulen);
        // Seçili olmayan sekmeler görsel ağaçta yoktur; mantıksal ağaçtan da gezilir.
        foreach(var c in LogicalTreeHelper.GetChildren(d))if(c is DependencyObject child)Gez(child,gorulen);
    }

    private static void Uygula(DependencyObject d)
    {
        try
        {
            switch(d)
            {
                case TextBlock tb:
                    if(VeriIcinde(tb)||tb.Inlines.Count>1||tb.Inlines.FirstInline is not (null or Run))return;
                    Ozellik(tb,TextBlock.TextProperty);break;
                case HeaderedContentControl hc:
                    if(!OgeKabi(hc))Ozellik(hc,HeaderedContentControl.HeaderProperty);
                    Ozellik(hc,ContentControl.ContentProperty);break;
                case HeaderedItemsControl hi:
                    Ozellik(hi,HeaderedItemsControl.HeaderProperty);break;
                case ContentControl cc when cc is not Window:
                    if(OgeKabi(cc)||cc is DataGridCell or DataGridColumnHeader or ToolTip)break;
                    Ozellik(cc,ContentControl.ContentProperty);break;
                case DataGrid dg:
                    if(!izlenenTablolar.TryGetValue(dg,out _)){izlenenTablolar.Add(dg,true);dg.AutoGeneratedColumns+=(_,_)=>{if(kullanildi)Basliklar(dg);};}
                    Basliklar(dg);break;
                case FlowDocumentScrollViewer fv when fv.Document is FlowDocument fd:Belge(fd);break;
                case FlowDocumentReader fr when fr.Document is FlowDocument fd2:Belge(fd2);break;
            }
            if(d is FrameworkElement fe&&fe.ToolTip is string)Ozellik(fe,FrameworkElement.ToolTipProperty);
        }
        catch(InvalidOperationException){}
    }

    /// <summary>ComboBox, ListBox, TabControl gibi bir listenin öğe kabı mı? (TabItem başlığı hariç tutulmaz.)</summary>
    private static bool OgeKabi(DependencyObject d)
    {
        if(d is TabItem)return false;
        return ItemsControl.ItemsControlFromItemContainer(d) is ComboBox or ListBox or TreeView or DataGrid;
    }

    /// <summary>Veri tablosu hücresi, liste öğesi veya metin kutusu şablonu içindeki metinler veri sayılır.</summary>
    private static bool VeriIcinde(DependencyObject d)
    {
        var p=d;
        for(int i=0;i<40&&p!=null;i++)
        {
            p=VisualTreeHelper.GetParent(p) ?? LogicalTreeHelper.GetParent(p);
            switch(p)
            {
                case DataGridCell or DataGridRow or ListBoxItem or ComboBoxItem or ComboBox or TextBoxBase or ListViewItem or TreeViewItem or DatePicker or PasswordBox:return true;
                case Window or Page:return false;
            }
        }
        return false;
    }

    private static void Ozellik(DependencyObject d,DependencyProperty p)
    {
        if(BindingOperations.IsDataBound(d,p))return;
        if(d.GetValue(p) is not string simdiki)return;
        string asil=simdiki;
        var kayit=asillar.GetOrCreateValue(d);
        if(kayit.Degerler.TryGetValue(p,out var onceki)&&onceki.Son==simdiki)asil=onceki.Asil; // kendi yazdığımız çeviri
        string yeni=Dil.Cevir(asil);
        kayit.Degerler[p]=(asil,yeni);
        if(!string.Equals(yeni,simdiki,StringComparison.Ordinal))d.SetCurrentValue(p,yeni);
    }

    /// <summary>Düğme yazısının Türkçe aslı (çeviri uygulanmışsa kayıttan, değilse mevcut yazı).</summary>
    public static string TurkceAsil(ContentControl c)
    {
        if(c.Content is not string s)return "";
        return asillar.TryGetValue(c,out var k)&&k.Degerler.TryGetValue(ContentControl.ContentProperty,out var o)&&o.Son==s?o.Asil:s;
    }
    /// <summary>Yazının başındaki simgeyi değiştirir; Türkçe aslı ve çevirisi birlikte güncellenir (dil değişince simge korunur).</summary>
    public static void IkonDegistir(ContentControl c,string ikon,int bosluk=3)
    {
        if(c.Content is not string s)return;
        string Ikonla(string metin,string simge){int k=0;while(k<metin.Length&&!char.IsLetterOrDigit(metin[k]))k++;return simge.Length==0?metin[k..]:simge.TrimEnd()+new string(' ',bosluk)+metin[k..];}
        var p=ContentControl.ContentProperty;
        if(asillar.TryGetValue(c,out var kayit)&&kayit.Degerler.TryGetValue(p,out var o)&&o.Son==s)
        {
            string yeni=Ikonla(s,ikon);kayit.Degerler[p]=(Ikonla(o.Asil,ikon),yeni);c.SetCurrentValue(p,yeni);
        }
        else c.SetCurrentValue(p,Ikonla(s,ikon));
    }

    /// <summary>
    /// Yazdırılan / önizlenen FlowDocument (fatura, bordro, sektör raporu) içindeki sabit metinler çevrilir.
    /// Yalnız sözlükte tam karşılığı olan metin değişir; tablo verisi (ad, tutar) olduğu gibi kalır. Türkçede asıl geri yazılır.
    /// </summary>
    public static void Belge(FlowDocument belge)
    {
        if(!kullanildi&&Dil.Turkce)return;
        foreach(var run in Runlar(belge.Blocks))
        {
            var kayit=asillar.GetOrCreateValue(run);string simdiki=run.Text;string asil=simdiki;
            if(kayit.Degerler.TryGetValue(Run.TextProperty,out var o)&&o.Son==simdiki)asil=o.Asil;
            string yeni=Dil.CevirKayitsiz(asil);kayit.Degerler[Run.TextProperty]=(asil,yeni);
            if(!string.Equals(yeni,simdiki,StringComparison.Ordinal))run.Text=yeni;
        }
    }
    static IEnumerable<Run> Runlar(IEnumerable<Block> bloklar)
    {
        foreach(var b in bloklar)
            switch(b)
            {
                case Paragraph p:foreach(var r in Satirici(p.Inlines))yield return r;break;
                case Section s:foreach(var r in Runlar(s.Blocks))yield return r;break;
                case List l:foreach(var li in l.ListItems)foreach(var r in Runlar(li.Blocks))yield return r;break;
                case Table t:foreach(var g in t.RowGroups)foreach(var row in g.Rows)foreach(var c in row.Cells)foreach(var r in Runlar(c.Blocks))yield return r;break;
                case BlockUIContainer:break;
            }
    }
    static IEnumerable<Run> Satirici(InlineCollection satirlar)
    {
        foreach(var i in satirlar)
            switch(i)
            {
                case Run r:yield return r;break;
                case Span s:foreach(var r in Satirici(s.Inlines))yield return r;break;
            }
    }

    /// <summary>DataGridColumn ağaçta değildir; başlıkları doğrudan çevrilir.</summary>
    private static void Basliklar(DataGrid dg){foreach(var col in dg.Columns)Ozellik(col,DataGridColumn.HeaderProperty);}
}
