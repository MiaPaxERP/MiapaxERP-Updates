using System.IO;
using System.Text;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class DilTestleri
{
    private static string Sozluk()
    {
        using var s=typeof(Dil).Assembly.GetManifestResourceStream("MiapaxERP.Desktop.Diller.ceviri.tsv");
        Assert.NotNull(s);
        return new StreamReader(s!,Encoding.UTF8).ReadToEnd();
    }
    [Fact]public void YerlesikSozlukTumDillerdeEksiksizdir()
    {
        var satirlar=Sozluk().Replace("\r\n","\n").Split('\n',StringSplitOptions.RemoveEmptyEntries);
        Assert.Equal("tr\ten\tde\tfr\tru\tar\tzh",satirlar[0]);
        Assert.True(satirlar.Length>300);
        foreach(var s in satirlar)Assert.True(s.Split('\t').Length==7&&s.Split('\t').All(x=>x.Trim().Length>0),s);
        Assert.Equal(Dil.Diller.Select(d=>d.Kod),satirlar[0].Split('\t'));
    }
    [Fact]public void SimgeVeIkiNoktaKorunarakCevrilir()
    {
        try
        {
            Dil.TestIcinAyarla(Sozluk(),"en");
            Assert.Equal("Save",Dil.Cevir("Kaydet"));
            Assert.Equal("▤   Stock management",Dil.Cevir("▤   Stok Yönetimi"));
            Assert.Equal("Date:",Dil.Cevir("Tarih:"));
            Assert.Equal("Loading...",Dil.Cevir("Yükleniyor..."));
            Assert.Equal("ABC-123",Dil.Cevir("ABC-123"));
            Dil.TestIcinAyarla(Sozluk(),"ar");
            Assert.True(Dil.SagdanSola);
            Assert.Equal("حفظ",Dil.Cevir("kaydet"));
        }
        finally{Dil.TestIcinAyarla(Sozluk(),"tr");}
    }
    [Fact]public void YeniEkranlarVeRaporlarCevrilirVeriDegismez()
    {
        try
        {
            Dil.TestIcinAyarla(Sozluk(),"en");
            Assert.Equal("📌 Today's tasks",Dil.Cevir("📌 Bugün yapılacaklar"));
            Assert.Equal("You have 3 plans today",Dil.Cevir("Bugün 3 planınız var"));
            Assert.Equal("Grand total",Dil.CevirKayitsiz("Genel toplam"));
            Assert.Equal("Block / Parcel",Dil.CevirKayitsiz("Ada / Parsel"));
            int once=Dil.EksikSayisi;
            // Rapor/web verisi (müşteri adı) sözlükte yoksa değişmez ve yapay zekâ eksik listesine eklenmez.
            Assert.Equal("Ahmet Yılmaz Tarım Ltd.",Dil.CevirKayitsiz("Ahmet Yılmaz Tarım Ltd."));
            Assert.Equal(once,Dil.EksikSayisi);
            string html=WebCeviri.Html("<!doctype html><html lang='tr'><style>.a{}</style><h1>Laboratuvar test raporu</h1><p>Ahmet &amp; Oğulları</p><script>var x='Kaydet';</script><th>Genel toplam</th></html>");
            Assert.Contains("<h1>Laboratory test report</h1>",html);
            Assert.Contains("<th>Grand total</th>",html);
            Assert.Contains("<p>Ahmet &amp; Oğulları</p>",html);
            Assert.Contains("var x='Kaydet'",html);
            Assert.Contains("<html lang='en'>",html);
        }
        finally{Dil.TestIcinAyarla(Sozluk(),"tr");}
    }
    [Fact]public void YapayZekaYanitindanJsonAyiklanir()
    {
        var d=Dil.JsonAyikla("Tabii:\n```json\n{\"Kaydet\":\"Save\",\"Sil\":\"Delete\"}\n```");
        Assert.Equal("Save",d["Kaydet"]);Assert.Equal("Delete",d["Sil"]);
        Assert.Empty(Dil.JsonAyikla("yanıt yok"));
    }
}
