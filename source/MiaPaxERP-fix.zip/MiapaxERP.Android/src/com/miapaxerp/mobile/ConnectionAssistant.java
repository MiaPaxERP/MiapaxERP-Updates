package com.miapaxerp.mobile;
import java.net.*;
import javax.net.ssl.*;

/** Deterministic connection diagnostics; no credentials are sent to an AI service. */
public final class ConnectionAssistant {
 private ConnectionAssistant(){}
 public static String address(String raw)throws Exception{
  String s=raw.trim();if(!s.contains("://"))s="https://"+s;
  LanTls.validate(s,"");URL u=new URL(s);
  int p=u.getPort();return "https://"+u.getHost().toLowerCase(java.util.Locale.ROOT)+(p==-1||p==443?"":":"+p);
 }
 /** Adres kutusu ile ayrı port kutusunu birleştirir. Boş port 443 demektir; port adrese de yazıldıysa aynı olmalıdır. */
 public static String address(String raw,String port)throws Exception{
  String p=port==null?"":port.trim();if(p.isEmpty())p="443";
  if(!p.matches("[0-9]{1,5}"))throw new IllegalArgumentException("Port geçersiz.");int n=Integer.parseInt(p);if(!LanTls.portOk(n)||n==-1)throw new IllegalArgumentException("Port geçersiz.");
  String s=raw.trim();while(s.endsWith("/"))s=s.substring(0,s.length()-1);if(!s.contains("://"))s="https://"+s;
  URL u=new URL(s+"/");if(u.getPort()!=-1&&u.getPort()!=n)throw new IllegalArgumentException("Portu adres yerine Port kutusuna yazın.");
  return address("https://"+u.getHost()+(n==443?"":":"+n));
 }
 public static String port(String base){try{int p=new URL(base).getPort();return p==-1?"443":String.valueOf(p);}catch(Exception e){return "443";}}
 public static String host(String base){try{return "https://"+new URL(base).getHost();}catch(Exception e){return "";}}
 public static String diagnosis(Throwable error){
  for(Throwable e=error;e!=null;e=e.getCause()){
   if(e instanceof UnknownHostException)return "Alan adı bulunamadı. Telefonun internetini ve alan adının ana sunucunun sabit dış IP adresine yönlendiğini kontrol edin.";
   if(e instanceof SSLException)return "HTTPS sertifikası doğrulanamadı. Ana sunucuda HTTPS kurulumunu ve alan adını kontrol edin. Güvenlik doğrulaması kapatılmadı.";
   if(e instanceof SocketTimeoutException||e instanceof ConnectException)return "Ana sunucuya ulaşılamadı. Sunucu açık, MiaPaxERP HTTPS servisi çalışır durumda olmalı; modem HTTPS portunu ana sunucuya yönlendirmeli. CGNAT varsa internet sağlayıcısından gerçek sabit dış IP isteyin.";
  }
  return "MiaPaxERP mobil servisi doğrulanamadı. Ana sunucuyu 2.9.2 sürümüne güncelleyin ve bağlantı panelinden yeni mobil bağlantı kodu alın.";
 }
}
