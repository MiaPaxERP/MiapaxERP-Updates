using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using Microsoft.Win32;
using MiapaxERP.Lisans.Core;

namespace MiapaxERP.Desktop;

public sealed record LisansOnbellek(string Anahtar,ImzaliLisans? Belge,DateTimeOffset SonGorulenUtc){public long PortalAck{get;init;}}
public static class LisansOturumu
{
    public const string VarsayilanSunucu="https://boruerp-lisans-yonetimi.ali-can-0001.chatgpt.site";
    public static string Sunucu=>PortalBaglantisi.LisansSunucusu;
#if CUSTOMER_BUILD
    public static bool Zorunlu=>true;
#else
    public static bool Zorunlu=>false;
#endif
    static readonly object sync=new();
    static readonly SemaphoreSlim yenile=new(1);
    static LisansOnbellek? cached;
    static DateTimeOffset saatCipasi=DateTimeOffset.UtcNow;
    static readonly System.Diagnostics.Stopwatch gecen=System.Diagnostics.Stopwatch.StartNew();
    static string file="",device="",database="",portalConnection="";
    public static string SonMesaj {get;private set;}="Lisans etkinleştirilmedi.";
    public static string CihazKimligi=>device;
    public static string VeritabaniKimligi=>database;
    public static LisansIcerigi? Gecerli
    {
        get{lock(sync){try{if(cached?.Belge is null)return null;var now=DateTimeOffset.UtcNow;if(now<cached.SonGorulenUtc.AddMinutes(-5)||now<(saatCipasi+gecen.Elapsed).AddMinutes(-5))return null;return LisansKripto.Dogrula(cached.Belge,LisansAcikAnahtari.Pem,device,database,now);}catch{return null;}}}
    }
    public static string SektorKodu=>HttpsOturumu.Istemci?.Oturum?.Sektor??Gecerli?.Sector??"GENEL";
    public static bool ModulVar(string module)=>HttpsOturumu.Istemci?.Oturum is { } remote ? remote.Bitis>DateTimeOffset.UtcNow&&ModulSureleri.Acik(remote.Moduller,remote.ModuleExpiresAt,module,DateTimeOffset.UtcNow) : !Zorunlu||Gecerli is {} license&&ModulSureleri.Acik(license,module,DateTimeOffset.UtcNow);
    public static void Gerekli(string module){if(!ModulVar(module)){var ex=new UnauthorizedAccessException("Bu modül lisansınızda açık değil veya lisans doğrulaması gerekiyor: "+module);DestekIzleme.Bildir(ex,module);throw ex;}}
    public static void YetkiGerekli(string permission)
    {
        if(HttpsOturumu.Istemci?.Oturum is not null){var remoteModule=UrunKatalogu.YetkiModulu(permission);if(remoteModule is not null)Gerekli(remoteModule);return;}
        if(!Zorunlu)return;if(Gecerli is null)throw new UnauthorizedAccessException("Geçerli lisans doğrulaması gerekiyor.");
        var module=UrunKatalogu.YetkiModulu(permission);if(module is not null)Gerekli(module);
    }
    public static void Hazirla(string connection)
    {
        portalConnection=connection;
        var b=new SqlConnectionStringBuilder(connection);
        string fingerprint=b.DataSource.Trim().ToUpperInvariant()+"|"+b.InitialCatalog.Trim().ToUpperInvariant();
        string machine=Convert.ToString(Registry.GetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography","MachineGuid",null))??throw new InvalidOperationException("Cihaz kimliği okunamadı.");
        lock(sync)
        {
            device=LisansKripto.Ozet(machine);database=LisansKripto.Ozet(fingerprint);
            file=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","Lisans",database,"lisans-v2.dpapi");cached=null;saatCipasi=DateTimeOffset.UtcNow;gecen.Restart();
            if(File.Exists(file))try{cached=JsonSerializer.Deserialize<LisansOnbellek>(ProtectedData.Unprotect(File.ReadAllBytes(file),null,DataProtectionScope.CurrentUser),LisansKripto.Json);}catch{SonMesaj="Kayıtlı lisans açılamadı. Yeniden etkinleştirin.";}
        }
    }
    static void Kaydet()
    {
        if(cached is null||string.IsNullOrEmpty(file))return;
        Directory.CreateDirectory(Path.GetDirectoryName(file)!);
        var bytes=ProtectedData.Protect(JsonSerializer.SerializeToUtf8Bytes(cached,LisansKripto.Json),null,DataProtectionScope.CurrentUser);
        File.WriteAllBytes(file+".tmp",bytes);File.Move(file+".tmp",file,true);
    }
    public static void SaatIziniGuncelle()
    {
        lock(sync){if(cached is not null){var seen=saatCipasi+gecen.Elapsed;if(DateTimeOffset.UtcNow>seen)seen=DateTimeOffset.UtcNow;if(cached.SonGorulenUtc>seen)seen=cached.SonGorulenUtc;cached=cached with{SonGorulenUtc=seen};Kaydet();}}
    }
    public static async Task<bool> YenileAsync(string? newKey=null,CancellationToken cancellation=default)
    {
        await yenile.WaitAsync(cancellation);
        try
        {
            string key;lock(sync){
                // An expired receipt cannot authorize offline use, but its protected
                // key can still be revalidated by the authoritative online server.
                key=LisansYenilemeKurallari.Anahtar(newKey,cached?.Anahtar);
            }
            if(key.Length!=64){SonMesaj="Panelde oluşturulan 64 karakterlik lisans anahtarını girin.";return false;}
            long noticeAfter;lock(sync){noticeAfter=newKey is null?cached?.PortalAck??0:0;}
            using var http=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(20),MaxResponseContentBufferSize=64*1024};
            using var response=await http.PostAsJsonAsync(Sunucu+"/api/activate",new{licenseKey=key,deviceId=device,databaseId=database,deviceName=Environment.MachineName,announcementAfter=noticeAfter,support=DestekIzleme.Paket()},cancellation);
            if(response.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized)
            {
                lock(sync){cached=new(key,null,DateTimeOffset.UtcNow);Kaydet();}
                SonMesaj="Lisans etkin değil, süresi dolmuş veya cihaz sınırı dolu. Lisans yöneticinizle görüşün.";return false;
            }
            response.EnsureSuccessStatusCode();
            using var responseJson=JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellation));
            var envelope=responseJson.RootElement.Deserialize<ImzaliLisans>(LisansKripto.Json)??throw new InvalidDataException("Sunucu yanıtı boş.");
            var validated=LisansKripto.Dogrula(envelope,LisansAcikAnahtari.Pem,device,database,DateTimeOffset.UtcNow);
            lock(sync){cached=new(key,envelope,DateTimeOffset.UtcNow){PortalAck=noticeAfter};Kaydet();}
            if(responseJson.RootElement.TryGetProperty("supportAck",out var supportAck))try{DestekIzleme.Onayla(supportAck.Deserialize<Guid[]>()??[]);}catch(JsonException){}
            if(validated.PortalNotices is {Length:>0}&&portalConnection.Length>0)try{
                long ack=await Task.Run(()=>PortalDuyuruAktar.Kaydet(portalConnection,Sunucu,validated));
                lock(sync){if(cached?.Belge==envelope){cached=cached with{PortalAck=Math.Max(cached.PortalAck,ack)};Kaydet();}}
            }catch(Exception noticeError){System.Diagnostics.Trace.WriteLine("Portal duyuruları sonraki bağlantıda yeniden alınacak: "+noticeError.GetType().Name);}
            SonMesaj=$"{validated.Company} • {UrunKatalogu.SektorBul(validated.Sector).Ad} • Sonraki doğrulama: {validated.ValidUntil.ToLocalTime():g}";return true;
        }
        catch(Exception ex)when(ex is HttpRequestException or TaskCanceledException)
        {bool offline=LisansYenilemeKurallari.CevrimdisiDevam(!string.IsNullOrWhiteSpace(newKey),Gecerli is not null);SonMesaj=offline?"Sunucuya ulaşılamadı; mevcut imzalı izin süresi içinde çevrimdışı kullanım devam ediyor.":"Girilen lisans internetten doğrulanamadı. İnternet bağlantısını ve lisansın doğru sunucuya aktarıldığını kontrol edip yeniden deneyin.";SaatIziniGuncelle();return offline;}
        catch(UnauthorizedAccessException ex)
        {SonMesaj=ex.Message+" Bilgisayarın tarih ve saatini kontrol edin. Anahtarı tekrar girip Etkinleştir / yenile düğmesine basabilirsiniz.";return false;}
        catch(Exception ex)when(ex is CryptographicException or InvalidDataException or JsonException)
        {lock(sync){if(cached is not null){cached=cached with{Belge=null};Kaydet();}}SonMesaj="Lisans imzası veya içeriği doğrulanamadı. İşlem kapatıldı.";return false;}
        finally{yenile.Release();}
    }
}

