import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import app from '../worker/index.js';
class DB{
 constructor(){this.db=new DatabaseSync(':memory:');this.db.exec('PRAGMA foreign_keys=ON;');this.db.exec(readFileSync('drizzle/0000_license.sql','utf8').replaceAll('--> statement-breakpoint',''));this.db.exec(readFileSync('drizzle/0001_customer_tax.sql','utf8'));this.db.exec(readFileSync('drizzle/0002_mail.sql','utf8'));this.db.exec(readFileSync('drizzle/0003_customer_mail.sql','utf8'));this.db.exec(readFileSync('drizzle/0005_module_dates.sql','utf8'));this.db.exec(readFileSync('drizzle/0006_announcements.sql','utf8'));this.db.exec(readFileSync('drizzle/0004_support.sql','utf8').replaceAll('--> statement-breakpoint',''));this.db.exec(readFileSync('drizzle/0007_license_panel_sync.sql','utf8'));}
 prepare(sql){const db=this.db;let args=[];return {bind(...v){args=v;return this;},async first(){return db.prepare(sql).get(...args)||null;},async run(){const r=db.prepare(sql).run(...args);return {success:true,meta:{changes:Number(r.changes)}};},async all(){const results=db.prepare(sql).all(...args);return {results,success:true,meta:{changes:Number(db.prepare('SELECT changes() AS n').get().n)}};}};}
 async batch(queries){this.db.exec('BEGIN IMMEDIATE');try{const out=[];for(const q of queries)out.push(await q.all());this.db.exec('COMMIT');return out;}catch(e){this.db.exec('ROLLBACK');throw e;}}
}
const pair=await crypto.subtle.generateKey({name:'RSA-PSS',modulusLength:3072,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
const env={DB:new DB(),ADMIN_USER_ID:'test-owner',LICENSE_PRIVATE_PKCS8:Buffer.from(await crypto.subtle.exportKey('pkcs8',pair.privateKey)).toString('base64')};
const origin='https://license.example';let checks=0;
const check=(v,label)=>{assert.ok(v,label);console.log('PASS '+label);checks++;};
async function call(path,b,user='test-owner',withOrigin=true){const headers={};if(user)headers['oai-authenticated-user-id']=user;if(withOrigin)headers.origin=origin;if(b)headers['content-type']='application/json';const r=await app.fetch(new Request(origin+path,{method:b?'POST':'GET',headers,body:b?JSON.stringify(b):undefined}),env);let j;try{j=await r.json();}catch{j=null;}return {r,j};}
check((await call('/api/admin/state',null,null)).r.status===401,'Anonim yönetim isteği reddedilir');
check((await call('/api/admin/state',null,'other')).r.status===403,'Başka oturum yönetim yapamaz');
check((await call('/api/admin/customer',{name:'X'},'test-owner',false)).r.status===403,'Yönetim mutasyonunda kaynak denetimi');
const automatic=(await call('/api/admin/customer',{name:'Test Firma',sector:'GENEL',email:'test@example.com',tax:{number:'1234567890',office:'Test',title:'Test Firma'},initialLicense:{modules:['STOK'],maxDevices:1,startsAt:'2026-01-01',expiresAt:null}}));check(automatic.r.ok,'Müşteri oluşturma');check(automatic.j.key.length===64,'Müşteri oluşturma yanıtı otomatik anahtarı verir');
check((await call('/api/admin/customer',{name:'Eksik lisans',sector:'GENEL'})).r.status===400,'İlk lisans bilgisi eksikse müşteri oluşmaz');
check((await call('/api/admin/customer',{name:'Hatalı vergi',sector:'GENEL',email:'test@example.com',tax:{number:'abc'}})).r.status===400,'Hatalı vergi numarası reddedilir');
let state=(await call('/api/admin/state')).j;check(state.customers.length===1,'Başarısız istekte kısmi müşteri kaydı kalmaz');check(!JSON.stringify(state).includes(automatic.j.key),'Otomatik anahtar listelerde açığa çıkmaz');const customer=state.customers[0];
check(JSON.parse(customer.tax_info).number==='1234567890','Vergi bilgisi saklanır');check(state.licenses.length===1,'Müşteriyle otomatik ilk lisans oluşturulur');
const input={customerId:customer.id,label:'Süresiz test',modules:['STOK','SATIS','LABORATUVAR'],maxDevices:1,startsAt:'2026-01-01T00:00:00Z',expiresAt:null,active:true};
check((await call('/api/admin/license',{...input,modules:['RESTORAN']})).r.status===400,'Modül bağımlılığı denetlenir');
check((await call('/api/admin/license',{...input,modules:['LABORATUVAR']})).r.status===400,'Laboratuvar stok modülü olmadan açılamaz');
check((await call('/api/admin/state')).j.modules.some(m=>m[0]==='LABORATUVAR'),'Panel modül kataloğunda laboratuvar sunulur');
const created=await call('/api/admin/license',input);check(created.r.ok&&created.j.key.length===64,'Süresiz lisans ve rastgele anahtar');
const license=(await call('/api/admin/state')).j.licenses.find(x=>x.id===created.j.id);
check(!JSON.stringify((await call('/api/admin/state')).j).includes(created.j.key),'Ham anahtar yönetim yanıtında saklanmaz');
const activation={licenseKey:created.j.key,deviceId:'A'.repeat(64),databaseId:'B'.repeat(64),deviceName:'Test PC'};
const signed=await call('/api/activate',activation,null,false);check(signed.r.ok,'Doğru anahtar cihazı etkinleştirir');
const bytes=Buffer.from(signed.j.payload,'base64'),sig=Buffer.from(signed.j.signature,'base64');
check(await crypto.subtle.verify({name:'RSA-PSS',saltLength:32},pair.publicKey,sig,bytes),'RSA-PSS imzası doğrulanır');
const payload=JSON.parse(bytes);check(payload.modules.includes('LABORATUVAR'),'Laboratuvar hakkı imzalı masaüstü lisansına aktarılır');check(payload.customerId===customer.id&&payload.deviceId===activation.deviceId&&payload.expiresAt===null,'Firma, cihaz ve süresiz hak imzaya bağlı');
check(Date.parse(payload.validUntil)-Date.parse(payload.issuedAt)<=7*86400000+60000,'Çevrimdışı izin 7 günü aşmaz');
check((await call('/api/admin/customer',{name:'Bilinmeyen sektör',sector:'YOK',email:'s@example.com',tax:{},initialLicense:{modules:['STOK'],maxDevices:1,startsAt:'2026-01-01',expiresAt:null}})).r.status===400,'Katalog dışı sektör reddedilir');
const cafe=await call('/api/admin/customer',{name:'Kafe Firma',sector:'KAFE',email:'kafe@example.com',tax:{},initialLicense:{modules:['STOK','URETIM','SATIS','FINANS','RESTORAN'],maxDevices:1,startsAt:'2026-01-01',expiresAt:null}});check(cafe.r.ok,'Yeni katalog sektörüyle müşteri ve lisans oluşur');
const cafeActivation={licenseKey:cafe.j.key,deviceId:'E'.repeat(64),databaseId:'F'.repeat(64),deviceName:'Kafe PC'};
const oldClient=JSON.parse(Buffer.from((await call('/api/activate',cafeActivation,null,false)).j.payload,'base64'));check(oldClient.sector==='RESTORAN','Eski (2.8.x) istemciye yeni sektörün eski karşılığı imzalanır');
const newClient=JSON.parse(Buffer.from((await call('/api/activate',{...cafeActivation,catalog:2},null,false)).j.payload,'base64'));check(newClient.sector==='KAFE','Katalog 2 istemcisine ayrıntılı sektör imzalanır');
const mach=await call('/api/admin/customer',{name:'Makine Firma',sector:'PLASTIK',email:'mak@example.com',tax:{},initialLicense:{modules:['STOK','DEPO','URETIM','MAKINA','TAKVIM'],maxDevices:2,startsAt:'2026-01-01',expiresAt:null}});check(mach.r.ok,'Katalog 3 modülleriyle lisans oluşur');
check((await call('/api/admin/customer',{name:'Eksik üst',sector:'GENEL',email:'u@example.com',tax:{},initialLicense:{modules:['DEPO'],maxDevices:1,startsAt:'2026-01-01',expiresAt:null}})).r.status===400,'Alt modül üst modülsüz satılamaz');
const machAct={licenseKey:mach.j.key,deviceId:'1'.repeat(64),databaseId:'2'.repeat(64),deviceName:'Makine PC'};
const oldMach=JSON.parse(Buffer.from((await call('/api/activate',{...machAct,catalog:2},null,false)).j.payload,'base64'));check(oldMach.modules.join()==='STOK,URETIM'&&oldMach.catalog===undefined,'Eski istemciye yalnız tanıdığı modüller imzalanır');
const newMach=JSON.parse(Buffer.from((await call('/api/activate',{...machAct,catalog:3},null,false)).j.payload,'base64'));check(newMach.modules.includes('MAKINA')&&newMach.modules.includes('DEPO')&&newMach.catalog===3,'Katalog 3 istemcisine kesin modül listesi ve katalog imzalanır');
check((await call('/api/admin/state')).j.sectorCatalog.length>=20,'Yönetim durumunda ayrıntılı sektör kataloğu sunulur');
check((await call('/api/activate',activation,null,false)).r.ok,'Cihaz sınırı doluyken aynı cihaz yenilenir');
check((await call('/api/activate',{...activation,deviceId:'C'.repeat(64)},null,false)).r.status===403,'Fazla cihaz reddedilir');
check((await call('/api/activate',{...activation,licenseKey:'wrong'},null,false)).r.status===403,'Yanlış anahtar reddedilir');
const device=(await call('/api/admin/state')).j.activations[0];
check((await call('/api/admin/device',{id:device.id,revoked:true})).r.ok,'Cihaz iptal edilir');
check((await call('/api/activate',activation,null,false)).r.status===403,'İptal cihaz tekrar etkinleşemez');
check((await call('/api/admin/device',{id:device.id,revoked:false})).r.ok,'Yönetici cihazı açabilir');
const changed=await call('/api/admin/license',{...input,id:license.id,revision:license.revision,active:false});check(changed.r.ok,'Lisans askıya alınır');
check((await call('/api/activate',activation,null,false)).r.status===403,'Askıdaki lisans yenilenmez');
check((await call('/api/admin/license',{...input,id:license.id,revision:license.revision})).r.status===409,'Eski kayıt sürümü reddedilir');
let latest=(await call('/api/admin/state')).j.licenses.find(x=>x.id===created.j.id);
check((await call('/api/admin/license',{...input,id:license.id,revision:latest.revision,expiresAt:'2026-01-02T00:00:00Z'})).r.ok,'Süreli lisans kaydedilir');
check((await call('/api/activate',activation,null,false)).r.status===403,'Süresi dolan lisans reddedilir');
const second=await call('/api/admin/license',{...input,label:'Cihaz yarışı'});const competing={...activation,licenseKey:second.j.key};
const race=await Promise.all([call('/api/activate',competing,null,false),call('/api/activate',{...competing,deviceId:'D'.repeat(64)},null,false)]);check(race.filter(x=>x.r.ok).length===1,'Eşzamanlı cihaz sınırı aşılamaz');
const history=(await call('/api/admin/state')).j.audit;check(history.length>5&&!JSON.stringify(history).includes(created.j.key),'İşlem geçmişi anahtar içermez');
check((await app.fetch(new Request(origin),env)).status===200,'Anonim giriş sayfası erişilebilir');
check((await call('/api/admin/customer',{name:'Eksik eposta',sector:'GENEL'})).r.status===400,'E-posta zorunlu');
check((await call('/api/admin/customer',{name:'Hatalı eposta',sector:'GENEL',email:'bad'})).r.status===400,'E-posta biçimi denetlenir');
check((await call('/api/admin/key',{id:automatic.j.licenseId})).j.key===automatic.j.key,'Yönetici saklanan anahtarı açar');
check((await call('/api/admin/key',{id:automatic.j.licenseId},'other')).r.status===403,'Başka hesap anahtarı açamaz');
const {seal}=await import('../worker/mail.js');env.DB.db.prepare('INSERT INTO mail_settings(id,value) VALUES(?,?)').run('refresh',await seal(env,'test-refresh'));
let sends=0;const originalFetch=globalThis.fetch;globalThis.fetch=async url=>{if(String(url).includes('oauth2.googleapis.com'))return Response.json({access_token:'test-access'});sends++;return Response.json({id:'test-message'});};
try{await call('/api/admin/send-mail',{id:automatic.j.licenseId});await call('/api/admin/send-mail',{id:automatic.j.licenseId});check(sends===1,'Başarılı gönderim tekrar edilmez');check(env.DB.db.prepare('SELECT mail_status FROM licenses WHERE id=?').get(automatic.j.licenseId).mail_status==='sent','Gönderim durumu saklanır');}finally{globalThis.fetch=originalFetch;}
// Sıfırla + yeni anahtar: süresi dolmuş lisans yeni tarihle açılır, eski anahtar ve cihazlar temizlenir.
latest=(await call('/api/admin/state')).j.licenses.find(x=>x.id===created.j.id);
check((await call('/api/activate',activation,null,false)).j.message.includes('süresi dolmuş'),'Süre dolumu PC\'ye açık nedenle bildirilir');
check((await call('/api/admin/reset',{id:latest.id,revision:latest.revision})).r.status===400,'Süresi dolmuş lisans yeni tarih olmadan sıfırlanmaz');
const reset=await call('/api/admin/reset',{id:latest.id,revision:latest.revision,expiresAt:'2099-12-31T23:59:59.999+03:00'});check(reset.r.ok&&reset.j.key.length===64&&reset.j.key!==created.j.key,'Sıfırlama yeni anahtar üretir');
check((await call('/api/activate',activation,null,false)).r.status===403,'Sıfırlamadan sonra eski anahtar çalışmaz');
check((await call('/api/activate',{...activation,licenseKey:reset.j.key},null,false)).r.ok,'Yeni anahtarla aynı PC yeniden etkinleşir');
check((await call('/api/activate',{...activation,licenseKey:reset.j.key,deviceId:'9'.repeat(64)},null,false)).r.status===403,'Cihaz sınırı sıfırlamadan sonra da korunur');
check((await call('/api/admin/reset',{id:latest.id,revision:latest.revision,expiresAt:null})).r.status===409,'Eski sürümle sıfırlama reddedilir');
// Müşteri silme: ad onayı gerekir, lisans/cihaz/destek kayıtlarıyla birlikte silinir.
const victim=(await call('/api/admin/state')).j.customers.find(c=>c.name==='Makine Firma');
check((await call('/api/admin/customer-delete',{id:victim.id,confirmName:'yanlış'})).r.status===400,'Firma adı onayı olmadan müşteri silinmez');
check((await call('/api/admin/customer-delete',{id:victim.id,confirmName:'Makine Firma'},'other')).r.status===403,'Başka hesap müşteri silemez');
check((await call('/api/admin/customer-delete',{id:victim.id,confirmName:'Makine Firma'})).r.ok,'Müşteri silinir');
state=(await call('/api/admin/state')).j;check(!state.customers.some(c=>c.id===victim.id)&&!state.licenses.some(l=>l.customer_id===victim.id),'Müşterinin lisansları da silinir');
check(env.DB.db.prepare('SELECT COUNT(*) n FROM activations WHERE device_id=?').get('1'.repeat(64)).n===0,'Müşterinin cihaz kayıtları silinir');
check((await call('/api/activate',machAct,null,false)).r.status===403,'Silinen müşterinin anahtarı çalışmaz');
check(state.audit.some(a=>a.action==='Müşteri silindi'),'Silme işlem geçmişine yazılır');
const {panelPage}=await import('../worker/ui.js');const {Script}=await import('node:vm');new Script(panelPage.match(/<script>([\s\S]*?)<\/script>/)[1]);check(true,'Panel tarayıcı betiği geçerli');
mkdirSync('.test-results',{recursive:true});writeFileSync('.test-results/envelope.json',JSON.stringify(signed.j));writeFileSync('.test-results/public.pem','-----BEGIN PUBLIC KEY-----\n'+Buffer.from(await crypto.subtle.exportKey('spki',pair.publicKey)).toString('base64').match(/.{1,64}/g).join('\n')+'\n-----END PUBLIC KEY-----');
writeFileSync('.test-results/result.json',JSON.stringify({passed:checks,at:new Date().toISOString()}));console.log('PASSED '+checks);
