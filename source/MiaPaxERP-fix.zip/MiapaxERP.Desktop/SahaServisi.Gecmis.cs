using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>
/// Saha müşterisi değişiklik geçmişi ve silme. Kart güncellendiğinde değişen alanlar tarihle
/// <c>BERP299_SahaGecmis</c> tablosuna yazılır; müşteri kartındaki zaman çizelgesinde görüşmelerle birlikte görünür,
/// il listesi ve raporlar "son işlem" tarihini buna göre gösterir.
/// </summary>
public sealed partial class SahaServisi
{
 internal const string GecmisDdl="""
IF OBJECT_ID('dbo.BERP299_SahaGecmis','U') IS NULL
BEGIN
 CREATE TABLE dbo.BERP299_SahaGecmis(Id uniqueidentifier NOT NULL CONSTRAINT PK_BERP299_SahaGecmis PRIMARY KEY DEFAULT NEWID(),MusteriId uniqueidentifier NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),Ozet nvarchar(2000) NOT NULL,KullaniciId int NOT NULL);
 CREATE INDEX IX_BERP299_SahaGecmis_Musteri ON dbo.BERP299_SahaGecmis(MusteriId,Tarih DESC);
END
""";
 static readonly System.Collections.Concurrent.ConcurrentDictionary<string,bool> gecmisHazir=new(StringComparer.OrdinalIgnoreCase);
 /// <summary>Tabloyu ilk kullanımda oluşturur (işlem dışında çağrılır; eşzamanlı oluşturma yarışı zararsızdır).</summary>
 static void GecmisHazirla(SqlConnection c){
  string key=c.DataSource+"|"+c.Database;if(gecmisHazir.ContainsKey(key))return;
  try{using var k=new SqlCommand(GecmisDdl,c);k.ExecuteNonQuery();}
  catch(SqlException e)when(e.Number is 2714 or 1913){/* başka oturum aynı anda oluşturdu */}
  gecmisHazir[key]=true;
 }

 static readonly CultureInfo trG=CultureInfo.GetCultureInfo("tr-TR");
 static string Deger(object? v)=>v switch{null=>"—",decimal d=>d.ToString("0.###",trG),string s when s.Length==0=>"—",string s=>s.Length>60?s[..60]+"…":s,_=>v.ToString()??"—"};
 /// <summary>İki kart arasındaki farkları "Alan: eski → yeni" biçiminde özetler (değişiklik yoksa boş).</summary>
 public static string Degisiklikler(SahaMusterisi eski,SahaMusterisi yeni){
  var l=new List<string>();
  void K(string ad,object? a,object? b){if(!Equals(a,b)&&!(a is string sa&&b is string sb&&sa.Trim()==sb.Trim()))l.Add(ad+": "+Deger(a)+" → "+Deger(b));}
  K("Ad soyad",eski.Ad,yeni.Ad);K("Telefon",eski.Telefon,yeni.Telefon);K("Köy / mahalle",eski.Koy,yeni.Koy);
  K("Tarla",eski.Alan is null?null:Deger(eski.Alan)+" "+eski.AlanBirimi,yeni.Alan is null?null:Deger(yeni.Alan)+" "+yeni.AlanBirimi);
  K("Ürünler",eski.Urunler,yeni.Urunler);K("Debi",eski.Debi is null?null:Deger(eski.Debi)+" "+eski.DebiBirimi,yeni.Debi is null?null:Deger(yeni.Debi)+" "+yeni.DebiBirimi);
  K("Basınç",eski.Basinc,yeni.Basinc);K("Sulama",eski.Sulama,yeni.Sulama);K("Su kaynağı",eski.SuKaynagi,yeni.SuKaynagi);
  if((eski.Aciklama??"").Trim()!=(yeni.Aciklama??"").Trim())l.Add("Açıklama güncellendi");
  var s=string.Join(" · ",l);return s.Length>1900?s[..1900]+"…":s;
 }

 /// <summary>Müşteriyi görüşmeleri ve değişiklik geçmişiyle birlikte kalıcı siler. Sürüm verilirse başka kullanıcının değişikliği korunur.</summary>
 public void Sil(Guid id,string? version){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"SahaServisi.Sil","",new object?[]{id,version});return;}

  if(fixtureCheck is null)LisansOturumu.Gerekli("SAHA");if(id==Guid.Empty)throw new ArgumentException("Müşteri seçin.");
  using var c=access.Ac();GecmisHazirla(c);using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"FIELD.EDIT");
  byte[]? v=string.IsNullOrEmpty(version)?null:Convert.FromBase64String(version);
  using(var q=ErpModulServisi.Komut(c,tx,"SELECT COUNT(*) FROM dbo.BERP210_SahaMusteri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND (@own=0 OR Olusturan=@u) AND (@v IS NULL OR Surum=@v)",("@id",id),("@own",Own),("@u",user),("@v",v)))
   if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new InvalidOperationException("Müşteri bulunamadı, size ait değil veya başka kullanıcı tarafından değiştirildi. Listeyi yenileyin.");
  using(var q=ErpModulServisi.Komut(c,tx,"""
DELETE dbo.BERP299_SahaGecmis WHERE MusteriId=@id;
DELETE dbo.BERP210_Gorusme WHERE MusteriId=@id;
IF OBJECT_ID('dbo.BERP298_WaGonderim','U') IS NOT NULL UPDATE dbo.BERP298_WaGonderim SET MusteriId=NULL WHERE MusteriId=@id;
DELETE dbo.BERP210_SahaMusteri WHERE Id=@id;
""",("@id",id)))q.ExecuteNonQuery();
  tx.Commit();
 }
}
