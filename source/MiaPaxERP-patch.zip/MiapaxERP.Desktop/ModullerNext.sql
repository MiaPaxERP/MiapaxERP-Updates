SET XACT_ABORT ON;
IF OBJECT_ID('dbo.MPXNext_Departman','U') IS NULL CREATE TABLE dbo.MPXNext_Departman(Id int IDENTITY PRIMARY KEY,Ad nvarchar(100) NOT NULL UNIQUE,Aktif bit NOT NULL DEFAULT 1);
IF OBJECT_ID('dbo.MPXNext_DepartmanUye','U') IS NULL CREATE TABLE dbo.MPXNext_DepartmanUye(Departman int NOT NULL REFERENCES dbo.MPXNext_Departman(Id),Kullanici int NOT NULL REFERENCES dbo.Kullanicilar(Id),PRIMARY KEY(Departman,Kullanici));
IF OBJECT_ID('dbo.MPXNext_Duyuru','U') IS NULL CREATE TABLE dbo.MPXNext_Duyuru(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,Kaynak nvarchar(180) NULL,Gonderen int NOT NULL,Baslik nvarchar(160) NOT NULL,Metin nvarchar(4000) NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MPXNext_Duyuru') AND name='UX_Duyuru_Kaynak') CREATE UNIQUE INDEX UX_Duyuru_Kaynak ON dbo.MPXNext_Duyuru(Kaynak) WHERE Kaynak IS NOT NULL;
IF OBJECT_ID('dbo.MPXNext_DuyuruAlici','U') IS NULL CREATE TABLE dbo.MPXNext_DuyuruAlici(Duyuru bigint NOT NULL REFERENCES dbo.MPXNext_Duyuru(Id),Kullanici int NOT NULL REFERENCES dbo.Kullanicilar(Id),Okundu datetime2 NULL,PRIMARY KEY(Duyuru,Kullanici));
IF OBJECT_ID('dbo.MPXNext_Mesaj','U') IS NULL CREATE TABLE dbo.MPXNext_Mesaj(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,Gonderen int NOT NULL REFERENCES dbo.Kullanicilar(Id),Alici int NULL REFERENCES dbo.Kullanicilar(Id),Departman int NULL REFERENCES dbo.MPXNext_Departman(Id),Metin nvarchar(4000) NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),CHECK((Alici IS NULL AND Departman IS NOT NULL) OR (Alici IS NOT NULL AND Departman IS NULL)));
IF OBJECT_ID('dbo.MPXNext_MesajOkuma','U') IS NULL CREATE TABLE dbo.MPXNext_MesajOkuma(Kullanici int NOT NULL REFERENCES dbo.Kullanicilar(Id),Mesaj bigint NOT NULL REFERENCES dbo.MPXNext_Mesaj(Id),PRIMARY KEY(Kullanici,Mesaj));
IF OBJECT_ID('dbo.MPXNext_Barkod','U') IS NULL CREATE TABLE dbo.MPXNext_Barkod(Barkod varchar(100) COLLATE Latin1_General_100_BIN2 PRIMARY KEY,Stok int NOT NULL REFERENCES dbo.StokKartlari(Id),Carpan decimal(18,3) NOT NULL DEFAULT 1 CHECK(Carpan>0),Olusturan int NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID('dbo.MPXNext_Maliyet','U') IS NULL CREATE TABLE dbo.MPXNext_Maliyet(Id bigint IDENTITY PRIMARY KEY,Emir int NOT NULL,Veri nvarchar(max) NOT NULL CHECK(ISJSON(Veri)=1),Olusturan int NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),Surum rowversion);
IF OBJECT_ID('dbo.MPXNext_Gunluk','U') IS NULL CREATE TABLE dbo.MPXNext_Gunluk(Tarih date PRIMARY KEY,Kayit datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID('dbo.Yetkiler','U') IS NOT NULL
 INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
 SELECT x.Kod,x.Modul,N'Kullan',x.Aciklama,1 FROM (VALUES
 ('MOBILE.ACCESS',N'Mobil',N'Mobil uygulamaya giriş'),
 ('MOBILE.STOCK',N'Mobil',N'Departman: Stok / barkod'),
 ('MOBILE.PURCHASE',N'Mobil',N'Departman: Satın alma'),
 ('MOBILE.SALES',N'Mobil',N'Departman: Satış'),
 ('MOBILE.PRODUCTION',N'Mobil',N'Departman: Üretim'),
 ('MOBILE.FINANCE',N'Mobil',N'Departman: Muhasebe / finans'),
 ('MOBILE.FIELD',N'Mobil',N'Departman: Saha pazarlama'),
 ('MOBILE.CHAT',N'Mobil',N'Departman: Departman ve kullanıcı mesajlaşma'),
 ('DATA.VIEW',N'Veri araçları',N'Excel ve yazdırma araçları ekranını aç'),
 ('DASHBOARD.VIEW',N'Ana sayfa',N'Ana sayfa ve yönetim özeti ekranını görüntüle'),
 ('ASSISTANT.VIEW',N'Asistan',N'ERP asistanını aç'),
 ('NOTIFICATION.PUBLISH',N'Bildirim',N'Departman ve kullanıcılara duyuru yayımla'),
 ('CHAT.VIEW',N'Mesajlaşma',N'Kendi ve üye departman konuşmalarını gör'),
 ('CHAT.SEND',N'Mesajlaşma',N'Kullanıcı ve üye departmanlarına mesaj gönder'),
 ('COST.VIEW',N'Maliyet',N'Ayrıntılı üretim maliyetini gör'),
 ('COST.EDIT',N'Maliyet',N'Maliyet çalışma tablosunu düzenle'),
 ('COST.PUBLISH',N'Maliyet',N'Günlük maliyet raporu oluştur ve bildir'),
 ('QUICKSALE.VIEW',N'Hızlı satış',N'Barkodla hızlı satış ekranını aç')) x(Kod,Modul,Aciklama)
 WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=x.Kod);

IF OBJECT_ID('dbo.MPXNext_MaliyetRevizyon','U') IS NULL CREATE TABLE dbo.MPXNext_MaliyetRevizyon(Id bigint IDENTITY PRIMARY KEY,Kayit bigint NOT NULL REFERENCES dbo.MPXNext_Maliyet(Id),Veri nvarchar(max) NOT NULL CHECK(ISJSON(Veri)=1),Kullanici int NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MPXNext_DuyuruAlici') AND name='IX_MPXNext_DuyuruUser') CREATE INDEX IX_MPXNext_DuyuruUser ON dbo.MPXNext_DuyuruAlici(Kullanici,Duyuru) INCLUDE(Okundu);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MPXNext_Mesaj') AND name='IX_MPXNext_MesajAlici') CREATE INDEX IX_MPXNext_MesajAlici ON dbo.MPXNext_Mesaj(Alici,Departman,Id);
