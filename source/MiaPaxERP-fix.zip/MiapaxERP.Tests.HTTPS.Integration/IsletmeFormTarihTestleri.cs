using System.Globalization;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;

/// <summary>Basınç testi formundaki tarih-saat alanı program dilinden bağımsız okunur.</summary>
public class IsletmeFormTarihTestleri
{
    [Fact]public void TarihSaatDildenBagimsizOkunur()
    {
        var eski=CultureInfo.CurrentCulture;
        try
        {
            foreach(var kultur in new[]{"tr-TR","en-US","de-DE","ar-SA"})
            {
                CultureInfo.CurrentCulture=CultureInfo.GetCultureInfo(kultur);
                var a=IsletmeForm.Zaman("24.11.2026 14:30");Assert.NotNull(a);Assert.Equal(new DateTime(2026,11,24,14,30,0),a!.Value.DateTime);
                var b=IsletmeForm.Zaman("24.11.2026 14:30 +03:00");Assert.NotNull(b);Assert.Equal(TimeSpan.FromHours(3),b!.Value.Offset);
                Assert.NotNull(IsletmeForm.Zaman("2026-11-24 09:05"));
            }
            Assert.Null(IsletmeForm.Zaman(""));Assert.Null(IsletmeForm.Zaman("dün"));
        }
        finally{CultureInfo.CurrentCulture=eski;}
    }
}
