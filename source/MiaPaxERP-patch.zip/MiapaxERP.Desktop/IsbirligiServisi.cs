using System.Data;
using System.IO;
using Microsoft.Data.SqlClient;
using MiapaxERP.Lisans.Core;
namespace MiapaxERP.Desktop;
public sealed record IsbirligiSecim(int Id,string Ad);
public sealed record IletisimSecimleri(IsbirligiSecim[] Kullanicilar,IsbirligiSecim[] Departmanlar,bool Yayin,bool Yonetici,bool Mesaj);
public sealed record DuyuruGirdisi(Guid Anahtar,string Baslik,string Metin,int? Departman,int? Alici);
public sealed record DuyuruSatiri(long Id,string Baslik,string Metin,DateTime Tarih,bool Okundu);
public sealed record MesajGirdisi(Guid Anahtar,int? Alici,int? Departman,string Metin);
public sealed record MesajSatiri(long Id,int Gonderen,string Ad,string Metin,DateTime Tarih);
public sealed class IsbirligiServisi(string connection,int user)
{
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps)=>ErpModulServisi.Komut(c,t,sql,ps);
 SqlConnection Open(){var c=new SqlConnection(connection);c.Open();using var q=Q(c,null,"SELECT COUNT(*) FROM dbo.Kullanicilar WHERE Id=@u AND Aktif=1",("@u",user));if(Convert.ToInt32(q.ExecuteScalar())!=1){c.Dispose();throw new UnauthorizedAccessException("Aktif kullanıcı gerekli.");}return c;}
 internal bool Has(string permission)=>new MenuYetkiServisi(connection,user).Yetkiler().Contains(permission,StringComparer.OrdinalIgnoreCase);
 void Require(string permission){if(!Has(permission))throw new UnauthorizedAccessException("İşlem yetkisi yok: "+permission);}
 static void Text(string s,int max){if(string.IsNullOrWhiteSpace(s)||s.Length>max||s.Contains('\0'))throw new ArgumentException("Metin uzunluğu geçersiz.");}
 public void Hazirla(){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsbirligiServisi.Hazirla","",[]);return;}
  Require("USERS.MANAGE");using var c=Open();using var t=c.BeginTransaction(IsolationLevel.Serializable);using(var gate=Q(c,t,"DECLARE @r int;EXEC @r=sys.sp_getapplock @Resource='MiaPaxNextSchema',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;IF @r<0 THROW 51000,'Kurulum kilidi alinamadi',1"))gate.ExecuteNonQuery();using(var q=Q(c,t,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"ModullerNext.sql"))))q.ExecuteNonQuery();t.Commit();
 }
 public IletisimSecimleri Secimler(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<IletisimSecimleri>(connection,"IsbirligiServisi.Secimler","",[]);
  using var c=Open();var users=new List<IsbirligiSecim>();using(var q=Q(c,null,"SELECT Id,COALESCE(NULLIF(AdSoyad,N''),KullaniciAdi) FROM dbo.Kullanicilar WHERE Aktif=1 ORDER BY AdSoyad,Id")){using var r=q.ExecuteReader();while(r.Read())users.Add(new(r.GetInt32(0),r.GetString(1)));}
  bool admin=Has("USERS.MANAGE"),publish=Has("NOTIFICATION.PUBLISH"),chat=Has("CHAT.VIEW");var deps=new List<IsbirligiSecim>();using(var q=Q(c,null,"SELECT d.Id,d.Ad FROM dbo.MPXNext_Departman d WHERE d.Aktif=1 AND (@admin=1 OR @publish=1 OR EXISTS(SELECT 1 FROM dbo.MPXNext_DepartmanUye m WHERE m.Departman=d.Id AND m.Kullanici=@u)) ORDER BY d.Ad",("@admin",admin),("@publish",publish),("@u",user))){using var r=q.ExecuteReader();while(r.Read())deps.Add(new(r.GetInt32(0),r.GetString(1)));}return new(users.ToArray(),deps.ToArray(),publish,admin,chat);
 }
 public void DepartmanKaydet(string name,int[] members){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsbirligiServisi.DepartmanKaydet","",[name,members]);return;}
  Require("USERS.MANAGE");Text(name,100);if(members is null||members.Length>1000)throw new ArgumentException();using var c=Open();using var t=c.BeginTransaction(IsolationLevel.Serializable);int id;using(var q=Q(c,t,"SELECT Id FROM dbo.MPXNext_Departman WITH(UPDLOCK,HOLDLOCK) WHERE Ad=@a",("@a",name.Trim()))){var v=q.ExecuteScalar();if(v is null){using var insert=Q(c,t,"INSERT dbo.MPXNext_Departman(Ad) OUTPUT INSERTED.Id VALUES(@a)",("@a",name.Trim()));id=Convert.ToInt32(insert.ExecuteScalar());}else id=Convert.ToInt32(v);}
  using(var q=Q(c,t,"DELETE dbo.MPXNext_DepartmanUye WHERE Departman=@d",("@d",id)))q.ExecuteNonQuery();foreach(int member in members.Distinct()){using var q=Q(c,t,"INSERT dbo.MPXNext_DepartmanUye SELECT @d,Id FROM dbo.Kullanicilar WHERE Id=@u AND Aktif=1",("@d",id),("@u",member));if(q.ExecuteNonQuery()!=1)throw new ArgumentException("Etkin kullanıcı seçin.");}t.Commit();
 }
 public long Yayinla(DuyuruGirdisi g){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<long>(connection,"IsbirligiServisi.Yayinla","",[g]);
  Require("NOTIFICATION.PUBLISH");Text(g.Baslik,160);Text(g.Metin,4000);if(g.Anahtar==Guid.Empty||g.Departman.HasValue&&g.Alici.HasValue)throw new ArgumentException("Tek alıcı türü seçin.");using var c=Open();using var t=c.BeginTransaction(IsolationLevel.Serializable);long id=Insert(c,t,g.Anahtar,null,user,g.Baslik,g.Metin,g.Departman,g.Alici);t.Commit();return id;
 }
 internal static long Insert(SqlConnection c,SqlTransaction t,Guid key,string? source,int sender,string title,string text,int? dep,int? recipient){
  using(var old=Q(c,t,"SELECT Id,Gonderen,Baslik,Metin FROM dbo.MPXNext_Duyuru WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k OR (@s IS NOT NULL AND Kaynak=@s)",("@k",key),("@s",source))){using var r=old.ExecuteReader();if(r.Read()){if(source is null&&(r.GetInt32(1)!=sender||r.GetString(2)!=title||r.GetString(3)!=text))throw new InvalidOperationException("Duyuru kimliği farklı içerikte kullanılmış.");return r.GetInt64(0);}}
  long id;using(var q=Q(c,t,"INSERT dbo.MPXNext_Duyuru(Anahtar,Kaynak,Gonderen,Baslik,Metin) OUTPUT INSERTED.Id VALUES(@k,@s,@u,@b,@m)",("@k",key),("@s",source),("@u",sender),("@b",title),("@m",text)))id=Convert.ToInt64(q.ExecuteScalar());
  using(var q=Q(c,t,"INSERT dbo.MPXNext_DuyuruAlici(Duyuru,Kullanici) SELECT @i,k.Id FROM dbo.Kullanicilar k WHERE k.Aktif=1 AND (@u IS NULL OR k.Id=@u) AND (@d IS NULL OR EXISTS(SELECT 1 FROM dbo.MPXNext_DepartmanUye m JOIN dbo.MPXNext_Departman d ON d.Id=m.Departman WHERE m.Kullanici=k.Id AND m.Departman=@d AND d.Aktif=1))",("@i",id),("@u",recipient),("@d",dep))){if(q.ExecuteNonQuery()==0)throw new ArgumentException("Hedefte etkin kullanıcı bulunamadı.");}return id;
 }
 public DuyuruSatiri[] Bildirimler(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<DuyuruSatiri[]>(connection,"IsbirligiServisi.Bildirimler","",[]);
  using var c=Open();var rows=new List<DuyuruSatiri>();using(var q=Q(c,null,"SELECT TOP(100) d.Id,d.Baslik,d.Metin,d.Tarih,a.Okundu FROM dbo.MPXNext_Duyuru d JOIN dbo.MPXNext_DuyuruAlici a ON a.Duyuru=d.Id WHERE a.Kullanici=@u ORDER BY d.Id DESC",("@u",user))){using var r=q.ExecuteReader();while(r.Read())rows.Add(new(r.GetInt64(0),r.GetString(1),r.GetString(2),DateTime.SpecifyKind(r.GetDateTime(3),DateTimeKind.Utc),!r.IsDBNull(4)));}
  using(var exists=Q(c,null,"SELECT OBJECT_ID('dbo.Bildirimler','U')"))if(exists.ExecuteScalar() is not DBNull and not null){using var q=Q(c,null,"SELECT TOP(50) Id,Baslik,Mesaj,KayitTarihiUtc,OkunduUtc FROM dbo.Bildirimler WHERE AliciKullaniciId=@u ORDER BY Id DESC",("@u",user));using var r=q.ExecuteReader();while(r.Read())rows.Add(new(-Convert.ToInt64(r[0]),r.GetString(1),r.GetString(2),DateTime.SpecifyKind(r.GetDateTime(3),DateTimeKind.Utc),!r.IsDBNull(4)));}
  return rows.OrderByDescending(x=>x.Tarih).ToArray();
 }
 public void Okundu(long[] ids){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsbirligiServisi.Okundu","",[ids]);return;}
  if(ids is null||ids.Length>100)throw new ArgumentException();using var c=Open();using var t=c.BeginTransaction();foreach(long id in ids){if(id<0){using var legacy=Q(c,t,"UPDATE dbo.Bildirimler SET OkunduUtc=COALESCE(OkunduUtc,SYSUTCDATETIME()) WHERE Id=@i AND AliciKullaniciId=@u",("@i",-id),("@u",user));legacy.ExecuteNonQuery();continue;}using var q=Q(c,t,"UPDATE dbo.MPXNext_DuyuruAlici SET Okundu=COALESCE(Okundu,SYSUTCDATETIME()) WHERE Duyuru=@i AND Kullanici=@u",("@i",id),("@u",user));q.ExecuteNonQuery();}t.Commit();
 }
 void Channel(SqlConnection c,int? to,int? dep,SqlTransaction? transaction=null){
  if(to.HasValue==dep.HasValue)throw new ArgumentException("Kullanıcı veya departman seçin.");using var q=to.HasValue?Q(c,transaction,"SELECT COUNT(*) FROM dbo.Kullanicilar WITH(HOLDLOCK) WHERE Id=@v AND Aktif=1",("@v",to)):Q(c,transaction,"SELECT COUNT(*) FROM dbo.MPXNext_DepartmanUye m WITH(HOLDLOCK) JOIN dbo.MPXNext_Departman d ON d.Id=m.Departman AND d.Aktif=1 WHERE m.Kullanici=@u AND m.Departman=@v",("@u",user),("@v",dep));if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new UnauthorizedAccessException("Bu konuşmaya erişiminiz yok.");
 }
 public MesajSatiri[] Mesajlar(int? to,int? dep,long after){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<MesajSatiri[]>(connection,"IsbirligiServisi.Mesajlar","",[to,dep,after]);
  Require("CHAT.VIEW");using var c=Open();Channel(c,to,dep);using var q=Q(c,null,"SELECT TOP(100) m.Id,m.Gonderen,COALESCE(NULLIF(k.AdSoyad,N''),k.KullaniciAdi),m.Metin,m.Tarih FROM dbo.MPXNext_Mesaj m JOIN dbo.Kullanicilar k ON k.Id=m.Gonderen WHERE m.Id>@a AND ((@d IS NOT NULL AND m.Departman=@d) OR (@d IS NULL AND m.Departman IS NULL AND ((m.Gonderen=@u AND m.Alici=@v) OR (m.Gonderen=@v AND m.Alici=@u)))) ORDER BY CASE WHEN @a=0 THEN -m.Id ELSE m.Id END",("@a",after),("@u",user),("@v",to),("@d",dep));using var r=q.ExecuteReader();var rows=new List<MesajSatiri>();while(r.Read())rows.Add(new(r.GetInt64(0),r.GetInt32(1),r.GetString(2),r.GetString(3),DateTime.SpecifyKind(r.GetDateTime(4),DateTimeKind.Utc)));return rows.OrderBy(x=>x.Id).ToArray();
 }
 public long MesajGonder(MesajGirdisi g){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<long>(connection,"IsbirligiServisi.MesajGonder","",[g]);
  Require("CHAT.SEND");Require("CHAT.VIEW");Text(g.Metin,4000);if(g.Anahtar==Guid.Empty)throw new ArgumentException();using var c=Open();using var t=c.BeginTransaction(IsolationLevel.Serializable);Channel(c,g.Alici,g.Departman,t);using(var old=Q(c,t,"SELECT Id,Gonderen,Metin,Alici,Departman FROM dbo.MPXNext_Mesaj WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",g.Anahtar))){using var r=old.ExecuteReader();if(r.Read()){if(r.GetInt32(1)!=user)throw new UnauthorizedAccessException();if(r.GetString(2)!=g.Metin||(!r.IsDBNull(3)?r.GetInt32(3):(int?)null)!=g.Alici||(!r.IsDBNull(4)?r.GetInt32(4):(int?)null)!=g.Departman)throw new InvalidOperationException("İşlem kimliği farklı mesaj için kullanılamaz.");return r.GetInt64(0);}}
  using var q=Q(c,t,"INSERT dbo.MPXNext_Mesaj(Anahtar,Gonderen,Alici,Departman,Metin) OUTPUT INSERTED.Id VALUES(@k,@u,@a,@d,@m)",("@k",g.Anahtar),("@u",user),("@a",g.Alici),("@d",g.Departman),("@m",g.Metin));long id=Convert.ToInt64(q.ExecuteScalar());t.Commit();return id;
 }
 public void LisansUyarilari(){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsbirligiServisi.LisansUyarilari","",[]);return;}
  if(!Has("USERS.MANAGE"))return;var license=LisansOturumu.Gecerli;if(license is null)return;using var c=Open();using var t=c.BeginTransaction(IsolationLevel.Serializable);
  foreach(var x in ModulSureleri.Yaklasan(license,DateTimeOffset.UtcNow)){var label=UrunKatalogu.Moduller.First(m=>m.Kod==x.Modul).Ad;Insert(c,t,Guid.NewGuid(),"MODUL:"+license.LicenseId+":"+x.Modul+":"+x.Bitis.ToUnixTimeSeconds()+":"+user,user,"Modül süresi bitmek üzere",label+" · "+x.Bitis.ToLocalTime().ToString("dd.MM.yyyy")+"\nModül entegrasyonunuz bitmek üzere. Program yöneticisi ile iletişime geçin.",null,user);}t.Commit();
 }
 internal string Sinyal(){using var c=Open();using var q=Q(c,null,"SELECT COALESCE((SELECT MAX(a.Duyuru) FROM dbo.MPXNext_DuyuruAlici a WHERE a.Kullanici=@u),0),COALESCE((SELECT MAX(m.Id) FROM dbo.MPXNext_Mesaj m WHERE m.Alici=@u OR m.Gonderen=@u OR EXISTS(SELECT 1 FROM dbo.MPXNext_DepartmanUye d WHERE d.Departman=m.Departman AND d.Kullanici=@u)),0)",("@u",user));using var r=q.ExecuteReader();r.Read();return Convert.ToString(r[0])+":"+Convert.ToString(r[1]);}
}
