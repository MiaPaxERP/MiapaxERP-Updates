using System.Globalization;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using ZXing;
using ZXing.Common;
using Size = System.Windows.Size;
namespace MiapaxERP.Desktop;
public static class UrunEtiketYazici
{
 public static (double En,double Boy) Olcu(string text){var parts=text.ToLowerInvariant().Replace("mm","").Replace('×','x').Split('x',StringSplitOptions.TrimEntries);if(parts.Length!=2||!double.TryParse(parts[0],NumberStyles.Number,CultureInfo.GetCultureInfo("tr-TR"),out double w)||!double.TryParse(parts[1],NumberStyles.Number,CultureInfo.GetCultureInfo("tr-TR"),out double h)||!double.IsFinite(w)||!double.IsFinite(h)||w<25||w>300||h<20||h>300)throw new ArgumentException("Ölçüyü mm olarak 100x100 biçiminde girin. En 25–300, boy 20–300 mm olabilir.");return(w,h);}
 public static FrameworkElement Etiket(UrunEtiketBilgisi p,string barcode,decimal miktar,double mmW,double mmH,int? sira=null){
  _=Olcu(mmW.ToString(CultureInfo.GetCultureInfo("tr-TR"))+"x"+mmH.ToString(CultureInfo.GetCultureInfo("tr-TR")));
  if(string.IsNullOrWhiteSpace(barcode)||barcode.Length>100||barcode.Any(c=>c<'!'||c>'~'))throw new ArgumentException("Code 128 için 1–100 görünür Latin karakterli barkod seçin.");if(miktar<=0)throw new ArgumentException("Etiket miktarı sıfırdan büyük olmalı.");
  var matrix=new ZXing.OneD.Code128Writer().encode(barcode,BarcodeFormat.CODE_128,0,1,new Dictionary<EncodeHintType,object>{{EncodeHintType.MARGIN,20}});
  var pixel=new BarcodeWriterPixelData{Format=BarcodeFormat.CODE_128,Options=new EncodingOptions{Width=matrix.Width*4,Height=200,Margin=20,PureBarcode=true}}.Write(barcode);
  var bmp=BitmapSource.Create(pixel.Width,pixel.Height,96,96,PixelFormats.Bgra32,null,pixel.Pixels,pixel.Width*4);bmp.Freeze();
  var content=new StackPanel{Width=760,Background=Brushes.White};
  void Line(string t,int size,bool bold=false)=>content.Children.Add(new TextBlock{Text=t,TextWrapping=TextWrapping.Wrap,FontSize=size,FontWeight=bold?FontWeights.Bold:FontWeights.Normal,Foreground=Brushes.Black,Margin=new Thickness(0,4,0,4)});
  Line("MiaPaxERP · "+(p.PaketId.HasValue?"PAKET ETİKETİ":"ÜRÜN ETİKETİ"),27,true);Line(p.Ad,36,true);Line("Stok: "+p.Kod,24);Line(p.Ozellikler,22);Line((p.PaketId.HasValue?"Paket içi: ":"Miktar: ")+miktar.ToString("0.###",CultureInfo.GetCultureInfo("tr-TR"))+" "+p.Birim,32,true);
  if(p.PaketId.HasValue)Line("Üretim emri: "+p.Emir+" · Paket: "+sira+" / "+p.PaketSayisi,22);
  var img=new System.Windows.Controls.Image{Source=bmp,Height=155,Stretch=Stretch.Fill,Margin=new Thickness(0,12,0,2)};RenderOptions.SetBitmapScalingMode(img,BitmapScalingMode.NearestNeighbor);content.Children.Add(img);Line(barcode,23,true);
  content.Measure(new Size(760,double.PositiveInfinity));double w=mmW*96/25.4,h=mmH*96/25.4,pad=3*96/25.4,scale=Math.Min((w-2*pad)/760,(h-2*pad)/content.DesiredSize.Height);
  if(760*scale*25.4/96/matrix.Width<0.19)throw new ArgumentException("Bu barkod ve ürün metni seçilen etikette okunamayacak kadar küçük kalıyor. Daha büyük ölçü veya daha kısa barkod kullanın.");
  return new Border{Width=w,Height=h,Background=Brushes.White,Padding=new Thickness(pad),Child=new Viewbox{Stretch=Stretch.Uniform,StretchDirection=StretchDirection.Both,Child=content}};
 }
 public static void Yazdir(Window owner,UrunEtiketBilgisi data,string barkod,decimal miktar,double w,double h,int adet,int ilk){
  if(adet<1||adet>1000||ilk<1||data.PaketId.HasValue&&(long)ilk+adet-1>data.PaketSayisi)throw new ArgumentException("En fazla 1000 etiket yazdırın; paket sıra aralığı kayıtlı paket sayısını aşamaz.");
  var dialog=new System.Windows.Controls.PrintDialog();dialog.PrintTicket.PageMediaSize=new PageMediaSize(w*96/25.4,h*96/25.4);dialog.PrintTicket.PageOrientation=PageOrientation.Portrait;dialog.PrintTicket.PageScalingFactor=100;
  if(dialog.ShowDialog()!=true)return;
  var caps=dialog.PrintQueue.GetPrintCapabilities(dialog.PrintTicket);double pageW=dialog.PrintTicket.PageMediaSize?.Width??0,pageH=dialog.PrintTicket.PageMediaSize?.Height??0;
  if(Math.Abs(pageW-w*96/25.4)>4||Math.Abs(pageH-h*96/25.4)>4)throw new InvalidOperationException("Yazıcı seçilen ölçüyü değiştirdi. Yazıcı özelliklerinden aynı özel etiket ölçüsünü seçip yeniden deneyin.");
  double x=caps.PageImageableArea?.OriginWidth??0,y=caps.PageImageableArea?.OriginHeight??0,availableW=caps.PageImageableArea?.ExtentWidth??dialog.PrintableAreaWidth,availableH=caps.PageImageableArea?.ExtentHeight??dialog.PrintableAreaHeight;
  // Three millimetre quiet padding absorbs ordinary printer hard margins. Never silently scale the label.
  if(x>3*96/25.4||y>3*96/25.4||x+availableW<pageW-3*96/25.4||y+availableH<pageH-3*96/25.4)throw new InvalidOperationException("Yazıcının kenar boşluğu etiketteki 3 mm alanı aşıyor. Sürücüde etiket kâğıdı ve kenar boşluğunu kontrol edin.");
  var doc=new FixedDocument();doc.DocumentPaginator.PageSize=new Size(pageW,pageH);
  for(int i=0;i<adet;i++){int n=ilk+i;var label=Etiket(data,data.PaketId is int id?UrunEtiketServisi.PaketBarkodu(id,n):barkod,miktar,w,h,data.PaketId.HasValue?n:null);var page=new FixedPage{Width=pageW,Height=pageH,Background=Brushes.White};page.Children.Add(label);var pc=new PageContent{Child=page};doc.Pages.Add(pc);}
  dialog.PrintDocument(doc.DocumentPaginator,"MiaPaxERP ürün/paket etiketleri");
 }
}
