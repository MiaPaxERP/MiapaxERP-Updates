const fail=(message,status=400)=>{throw Object.assign(new Error(message),{status});};
const clean=(v,max)=>typeof v==='string'&&!/[\x00-\x1f]/.test(v)?v.trim().slice(0,max):'';
const hex=v=>typeof v==='string'&&/^[a-f0-9]{64}$/i.test(v);
const guid=v=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
export const summaries={MODULE_LICENSE_MISSING:'İstenen modül lisans kapsamında açık değil.',ACCOUNT_CODE_INVALID:'Muhasebe hesap kodu bulunamadı veya kullanıma uygun değil.',SQL_SCHEMA_MISSING:'Veritabanında gerekli tablo veya alan eksik.',SQL_CONNECTION:'Veritabanı bağlantısı kurulamadı.',PERMISSION_DENIED:'Kullanıcının bu işlem için yetkisi yok.',STOCK_INSUFFICIENT:'İşlem için kullanılabilir stok veya parti miktarı yetersiz.',VALIDATION_FAILED:'İşlem bilgileri doğrulama kontrolünden geçmedi.',ACCOUNTING_PERIOD_CLOSED:'Muhasebe dönemi kapalı olduğu için işlem yapılamadı.',APPLICATION_ERROR:'Uygulama işlemi tamamlanamadı.',HTTPS_CONNECTION:'Ana sunucuya HTTPS bağlantısı kurulamadı.',LICENSE_INVALID:'Lisans doğrulaması gerekiyor.'};
const digest=async s=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))),v=>v.toString(16).padStart(2,'0')).join('');
const number=(v,max=1048576)=>typeof v==='number'&&Number.isFinite(v)&&v>0&&v<=max?Math.round(v*100)/100:null;
export async function recordSupport(env,license,activation,reports){
 if(reports===undefined)return [];
 if(!Array.isArray(reports)||reports.length>4)fail('Destek bildirimi sınırı aşıldı.');
 const accepted=[],now=new Date().toISOString();
 for(const r of reports){
  if(!r||!guid(r.id)||!hex(r.deviceId)||!Array.isArray(r.events)||r.events.length>10)continue;
  const device=r.deviceId.toUpperCase(),role=device===activation.device_id?'Ana PC':'Yan PC';
  const info=r.info||{};const events=[];
  for(const e of r.events){if(!guid(e?.id)||!Object.hasOwn(summaries,e.code)||typeof e.module!=='string'||!/^[-A-Z0-9_]{1,40}$/.test(e.module))continue;events.push({...e,key:await digest(license.id+'|'+device+'|'+e.module+'|'+e.code)});}
  const known=await env.DB.prepare('SELECT device_id FROM support_devices WHERE license_id=? AND device_id=?').bind(license.id,device).first();
  if(!known&&(await env.DB.prepare('SELECT COUNT(*) n FROM support_devices WHERE license_id=?').bind(license.id).first()).n>=1000)continue;
  const statements=[env.DB.prepare('INSERT INTO support_devices(license_id,device_id,role,device_name,os,cpu,ram_gb,disk_total_gb,disk_free_gb,app_version,last_seen) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(license_id,device_id) DO UPDATE SET role=excluded.role,device_name=excluded.device_name,os=excluded.os,cpu=excluded.cpu,ram_gb=excluded.ram_gb,disk_total_gb=excluded.disk_total_gb,disk_free_gb=excluded.disk_free_gb,app_version=excluded.app_version,last_seen=excluded.last_seen').bind(license.id,device,role,clean(info.name,80)||'Müşteri bilgisayarı',clean(info.os,120),clean(info.cpu,160),number(info.ramGb),number(info.diskTotalGb),number(info.diskFreeGb),/^\d+(\.\d+){1,3}$/.test(info.version||'')?info.version:'',now)];
  for(const e of events){statements.push(env.DB.prepare('INSERT OR IGNORE INTO support_events(license_id,event_id,received_at) VALUES(?,?,?)').bind(license.id,e.id,now));statements.push(env.DB.prepare("INSERT INTO support_issues(id,license_id,device_id,module,code,summary,occurrences,first_seen,last_seen,status) SELECT ?,?,?,?,?,?,1,?,?,'open' WHERE changes()>0 ON CONFLICT(id) DO UPDATE SET occurrences=support_issues.occurrences+1,last_seen=excluded.last_seen,status='open'").bind(e.key,license.id,device,e.module,e.code,summaries[e.code],now,now));}
  await env.DB.batch(statements);accepted.push(r.id);
 }
 await env.DB.prepare('DELETE FROM support_events WHERE received_at<?').bind(new Date(Date.now()-30*86400000).toISOString()).run();
 return accepted;
}
export async function readSupport(env,licenseId){
 const license=await env.DB.prepare('SELECT l.label,c.name FROM licenses l JOIN customers c ON c.id=l.customer_id WHERE l.id=?').bind(licenseId).first();
 const [d,i,a]=await env.DB.batch([env.DB.prepare('SELECT * FROM support_devices WHERE license_id=? ORDER BY role, last_seen DESC LIMIT 1000').bind(licenseId),env.DB.prepare('SELECT * FROM support_issues WHERE license_id=? ORDER BY CASE status WHEN \'open\' THEN 0 ELSE 1 END,last_seen DESC LIMIT 300').bind(licenseId),env.DB.prepare('SELECT device_id,last_seen FROM activations WHERE license_id=? AND revoked=0').bind(licenseId)]);
 const devices=d.results,issues=i.results,registered=new Set(a.results.map(r=>r.device_id));
 for(const device of devices)if(Date.parse(device.last_seen)>Date.now()-30*86400000)registered.add(device.device_id);
 return {license,devices,issues,registeredPcCount:registered.size,licensedPcCount:a.results.length,recentPcCount:devices.filter(r=>Date.parse(r.last_seen)>Date.now()-86400000).length,reportedDeviceCount:devices.length};
}
export async function resolveSupport(env,licenseId,id){return env.DB.prepare("UPDATE support_issues SET status='resolved' WHERE id=? AND license_id=?").bind(clean(id,64),licenseId).run();}
