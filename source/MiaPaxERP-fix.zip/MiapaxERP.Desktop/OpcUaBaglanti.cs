using System.Buffers.Binary;
using System.Globalization;
using System.IO;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
namespace MiapaxERP.Desktop;

/// <summary>
/// Dış kütüphanesiz, yalnız okuma yapan küçük OPC UA istemcisi (UA TCP ikili protokolü, Part 6).
/// Güvenlik politikası None ve anonim oturumla bağlanır; düğüm değerlerini Read servisiyle okur, makineye yazmaz.
/// Makine firmasının sunucusunda "None / Anonymous" uç noktası açık olmalıdır.
/// </summary>
public sealed class OpcUaBaglanti(string adres):IDisposable
{
 const string PolicyNone="http://opcfoundation.org/UA/SecurityPolicy#None";
 TcpClient? tcp;NetworkStream? s;uint kanal,token,sira,istek;byte[]? oturumAnahtari;
 int maxMesaj=1<<20;

 public async Task<double?[]> OkuAsync(string[] nodeIds,CancellationToken ct){
  var ids=nodeIds.Select(DugumKodla).ToArray();
  using var cc=CancellationTokenSource.CreateLinkedTokenSource(ct);cc.CancelAfter(TimeSpan.FromSeconds(10));
  if(oturumAnahtari is null)await BaglanAsync(cc.Token);
  var w=new UaYazici();Istek(w,631);w.Double(0);w.Int32(3);w.Int32(ids.Length);
  foreach(var id in ids){w.Ham(id);w.UInt32(13);w.String(null);w.UInt16(0);w.String(null);}
  var r=await GonderAlAsync("MSG",w.Bitir(),634,cc.Token);
  int n=r.Int32();var sonuc=new double?[nodeIds.Length];
  for(int i=0;i<n;i++){var v=r.DataValue(out bool devam);if(i<sonuc.Length)sonuc[i]=v;if(!devam)break;}
  return sonuc;
 }

 async Task BaglanAsync(CancellationToken ct){
  if(!Uri.TryCreate(adres,UriKind.Absolute,out var u)||u.Scheme!="opc.tcp")throw new ArgumentException("OPC UA adresi opc.tcp://ip:4840 biçiminde olmalı.");
  tcp=new TcpClient{NoDelay=true};await tcp.ConnectAsync(u.Host,u.Port>0?u.Port:4840,ct);s=tcp.GetStream();
  // HEL / ACK
  var hel=new UaYazici();hel.UInt32(0);hel.UInt32(65536);hel.UInt32(65536);hel.UInt32(0);hel.UInt32(0);hel.String(adres);
  await YazAsync("HEL",hel.Bitir(),ct);
  var (tip,ack)=await MesajOkuAsync(ct);
  if(tip=="ERR")throw new IOException("OPC UA sunucusu bağlantıyı reddetti: "+HataMetni(ack));
  if(tip!="ACK")throw new IOException("OPC UA sunucusu HEL mesajını kabul etmedi.");
  ack.UInt32();ack.UInt32();ack.UInt32();uint mm=ack.UInt32();if(mm>0)maxMesaj=(int)Math.Min(mm,16u<<20);
  // OpenSecureChannel (None)
  var opn=new UaYazici();Istek(opn,446,kimlikYok:true);opn.UInt32(0);opn.Int32(0);opn.Int32(1);opn.ByteString([]);opn.UInt32(600000);
  var r=await GonderAlAsync("OPN",opn.Bitir(),449,ct);
  r.UInt32();kanal=r.UInt32();token=r.UInt32();
  // CreateSession
  var cs=new UaYazici();Istek(cs,461,kimlikYok:true);
  cs.String("urn:"+System.Net.Dns.GetHostName()+":MiaPaxERP:Makine");cs.String("urn:miapaxerp");cs.Byte(2);cs.String("MiaPaxERP Makine");cs.Int32(1);cs.String(null);cs.String(null);cs.Int32(-1);
  cs.String(null);cs.String(adres);cs.String("MiaPaxERP-"+Environment.MachineName);cs.ByteString(RandomNumberGenerator.GetBytes(32));cs.ByteString(null);cs.Double(120000);cs.UInt32(0);
  r=await GonderAlAsync("MSG",cs.Bitir(),464,ct);
  r.DugumHam();oturumAnahtari=r.DugumHam();r.Double();r.ByteString();r.ByteString();
  string? anonimNone=null,anonimHerhangi=null;int ep=r.Int32();
  for(int i=0;i<ep;i++){
   r.String();r.UygulamaAciklamasi();r.ByteString();int mode=r.Int32();string? policy=r.String();int tn=r.Int32();
   for(int k=0;k<tn;k++){string? pid=r.String();int tt=r.Int32();r.String();r.String();r.String();if(tt!=0)continue;if(mode==1&&policy==PolicyNone)anonimNone??=pid;anonimHerhangi??=pid;}
   r.String();r.Byte();
  }
  // ActivateSession (anonim)
  var act=new UaYazici();Istek(act,467);act.String(null);act.ByteString(null);act.Int32(-1);act.Int32(0);
  var tok=new UaYazici();tok.String(anonimNone??anonimHerhangi??"Anonymous");var tb=tok.Bitir();
  act.Ham([1,0,0x41,0x01]);act.Byte(1);act.Int32(tb.Length);act.Ham(tb);act.String(null);act.ByteString(null);
  await GonderAlAsync("MSG",act.Bitir(),470,ct);
 }

 void Istek(UaYazici w,ushort tip,bool kimlikYok=false){
  w.Ham([1,0,(byte)tip,(byte)(tip>>8)]);
  if(kimlikYok||oturumAnahtari is null)w.Ham([0,0]);else w.Ham(oturumAnahtari);
  w.Int64(DateTime.UtcNow.ToFileTimeUtc());w.UInt32(++istek);w.UInt32(0);w.String(null);w.UInt32(10000);w.Ham([0,0,0]);
 }

 async Task<UaOkuyucu> GonderAlAsync(string tip,byte[] govde,ushort beklenen,CancellationToken ct){
  uint id=istek;var h=new UaYazici();h.UInt32(kanal);
  if(tip=="OPN"){h.String(PolicyNone);h.ByteString(null);h.ByteString(null);}else h.UInt32(token);
  h.UInt32(++sira);h.UInt32(id);h.Ham(govde);
  await YazAsync(tip,h.Bitir(),ct);
  var parcalar=new MemoryStream();
  while(true){
   var (gelen,r)=await MesajOkuAsync(ct);
   if(gelen=="ERR")throw new IOException("OPC UA hatası: "+HataMetni(r));
   if(gelen!=tip)throw new IOException("OPC UA beklenmeyen yanıt: "+gelen);
   r.UInt32();
   if(tip=="OPN"){string? p=r.String();r.ByteString();r.ByteString();if(p!=PolicyNone)throw new IOException("Sunucu güvenliksiz (None) bağlantıyı kabul etmiyor. Makine firmasından None/Anonymous uç noktası açmasını isteyin.");}
   else r.UInt32();
   r.UInt32();r.UInt32();parcalar.Write(r.Kalan());
   if(r.Parca=='F')break;
   if(r.Parca=='A')throw new IOException("OPC UA sunucusu yanıtı iptal etti.");
   if(parcalar.Length>maxMesaj)throw new InvalidDataException("OPC UA yanıtı çok büyük.");
  }
  var body=new UaOkuyucu(parcalar.ToArray(),'F');
  var typeId=body.DugumHam();ushort gelenTip=typeId.Length==4&&typeId[0]==1?BinaryPrimitives.ReadUInt16LittleEndian(typeId.AsSpan(2)):typeId.Length==2?typeId[1]:(ushort)0;
  body.Int64();body.UInt32();uint status=body.UInt32();body.DiagnosticInfo();int st=body.Int32();for(int i=0;i<st;i++)body.String();body.ExtensionObject();
  if(gelenTip==397||(status&0x80000000)!=0)throw new IOException("OPC UA servisi reddetti: 0x"+status.ToString("X8",CultureInfo.InvariantCulture)+Aciklama(status));
  if(gelenTip!=beklenen)throw new IOException("OPC UA beklenmeyen yanıt tipi "+gelenTip.ToString(CultureInfo.InvariantCulture));
  return body;
 }
 static string HataMetni(UaOkuyucu r){uint c=r.UInt32();return "0x"+c.ToString("X8",CultureInfo.InvariantCulture)+Aciklama(c)+" "+r.String();}
 static string Aciklama(uint s)=>(s>>16) switch{0x8034=>" (düğüm bulunamadı)",0x801F=>" (kimlik reddedildi; anonim giriş kapalı olabilir)",0x8020=>" (kimlik reddedildi)",0x8055=>" (güvenlik politikası reddedildi)",0x8025=>" (oturum geçersiz)",0x8026=>" (oturum kapandı)",0x800A=>" (zaman aşımı)",_=>""};

 async Task YazAsync(string tip,byte[] govde,CancellationToken ct){
  var b=new byte[8+govde.Length];Encoding.ASCII.GetBytes(tip,b);b[3]=(byte)'F';BinaryPrimitives.WriteUInt32LittleEndian(b.AsSpan(4),(uint)b.Length);govde.CopyTo(b,8);
  await s!.WriteAsync(b,ct);
 }
 async Task<(string Tip,UaOkuyucu Govde)> MesajOkuAsync(CancellationToken ct){
  var h=new byte[8];await s!.ReadExactlyAsync(h,ct);uint n=BinaryPrimitives.ReadUInt32LittleEndian(h.AsSpan(4));
  if(n<8||n>maxMesaj+1024)throw new InvalidDataException("OPC UA mesaj boyu geçersiz.");
  var b=new byte[n-8];await s.ReadExactlyAsync(b,ct);return (Encoding.ASCII.GetString(h,0,3),new UaOkuyucu(b,(char)h[3]));
 }

 /// <summary>"ns=2;s=Hat1.Hiz", "ns=2;i=1001", "i=2258", "ns=3;g=…", "ns=1;b=base64" biçimindeki düğüm kimliğini ikili kodlar.</summary>
 public static byte[] DugumKodla(string nodeId){
  var t=(nodeId??"").Trim();ushort ns=0;
  if(t.StartsWith("ns=",StringComparison.OrdinalIgnoreCase)){int semi=t.IndexOf(';');if(semi<0||!ushort.TryParse(t.AsSpan(3,semi-3),NumberStyles.None,CultureInfo.InvariantCulture,out ns))throw new ArgumentException("OPC UA düğümü ns=2;s=Ad biçiminde olmalı.");t=t[(semi+1)..];}
  if(t.Length<3||t[1]!='=')throw new ArgumentException("OPC UA düğümü i=, s=, g= veya b= ile belirtilmeli (ör. ns=2;s=Hat1.Hiz).");
  var w=new UaYazici();string v=t[2..];
  switch(char.ToLowerInvariant(t[0])){
   case 'i':
    if(!uint.TryParse(v,NumberStyles.None,CultureInfo.InvariantCulture,out uint id))throw new ArgumentException("OPC UA sayısal düğüm kimliği geçersiz.");
    if(ns==0&&id<=255)w.Ham([0,(byte)id]);else if(ns<=255&&id<=65535){w.Ham([1,(byte)ns]);w.UInt16((ushort)id);}else{w.Byte(2);w.UInt16(ns);w.UInt32(id);}
    break;
   case 's':if(v.Length is 0 or >512)throw new ArgumentException("OPC UA düğüm adı boş veya çok uzun.");w.Byte(3);w.UInt16(ns);w.String(v);break;
   case 'g':if(!Guid.TryParse(v,out var g))throw new ArgumentException("OPC UA GUID düğümü geçersiz.");w.Byte(4);w.UInt16(ns);w.Ham(g.ToByteArray());break;
   case 'b':
    byte[] raw;try{raw=Convert.FromBase64String(v);}catch(FormatException){throw new ArgumentException("OPC UA b= düğümü base64 olmalı.");}
    w.Byte(5);w.UInt16(ns);w.ByteString(raw);break;
   default:throw new ArgumentException("OPC UA düğümü i=, s=, g= veya b= ile belirtilmeli.");
  }
  return w.Bitir();
 }

 public void Dispose(){
  try{
   if(s is not null&&kanal!=0){
    var w=new UaYazici();Istek(w,452);var h=new UaYazici();h.UInt32(kanal);h.UInt32(token);h.UInt32(++sira);h.UInt32(istek);h.Ham(w.Bitir());var b=h.Bitir();
    var m=new byte[8+b.Length];Encoding.ASCII.GetBytes("CLO",m);m[3]=(byte)'F';BinaryPrimitives.WriteUInt32LittleEndian(m.AsSpan(4),(uint)m.Length);b.CopyTo(m,8);s.Write(m);
   }
  }catch(Exception){}
  tcp?.Dispose();tcp=null;s=null;oturumAnahtari=null;kanal=0;
 }
}

sealed class UaYazici
{
 readonly MemoryStream m=new();
 public void Ham(ReadOnlySpan<byte> b)=>m.Write(b);
 public void Byte(byte v)=>m.WriteByte(v);
 public void UInt16(ushort v){Span<byte> b=stackalloc byte[2];BinaryPrimitives.WriteUInt16LittleEndian(b,v);m.Write(b);}
 public void UInt32(uint v){Span<byte> b=stackalloc byte[4];BinaryPrimitives.WriteUInt32LittleEndian(b,v);m.Write(b);}
 public void Int32(int v){Span<byte> b=stackalloc byte[4];BinaryPrimitives.WriteInt32LittleEndian(b,v);m.Write(b);}
 public void Int64(long v){Span<byte> b=stackalloc byte[8];BinaryPrimitives.WriteInt64LittleEndian(b,v);m.Write(b);}
 public void Double(double v){Span<byte> b=stackalloc byte[8];BinaryPrimitives.WriteDoubleLittleEndian(b,v);m.Write(b);}
 public void String(string? v){if(v is null){Int32(-1);return;}var b=Encoding.UTF8.GetBytes(v);Int32(b.Length);m.Write(b);}
 public void ByteString(byte[]? v){if(v is null){Int32(-1);return;}Int32(v.Length);m.Write(v);}
 public byte[] Bitir()=>m.ToArray();
}

sealed class UaOkuyucu(byte[] b,char parca)
{
 int p;
 public char Parca{get;}=parca;
 ReadOnlySpan<byte> Al(int n){if(n<0||p+n>b.Length)throw new InvalidDataException("OPC UA yanıtı eksik.");var r=b.AsSpan(p,n);p+=n;return r;}
 public byte[] Kalan(){var r=b[p..];p=b.Length;return r;}
 public byte Byte()=>Al(1)[0];
 public ushort UInt16()=>BinaryPrimitives.ReadUInt16LittleEndian(Al(2));
 public uint UInt32()=>BinaryPrimitives.ReadUInt32LittleEndian(Al(4));
 public int Int32()=>BinaryPrimitives.ReadInt32LittleEndian(Al(4));
 public long Int64()=>BinaryPrimitives.ReadInt64LittleEndian(Al(8));
 public double Double()=>BinaryPrimitives.ReadDoubleLittleEndian(Al(8));
 public string? String(){int n=Int32();return n<0?null:Encoding.UTF8.GetString(Al(n));}
 public byte[]? ByteString(){int n=Int32();return n<0?null:Al(n).ToArray();}
 /// <summary>Düğüm kimliğini ham baytlarıyla döndürür (oturum anahtarı aynen geri gönderilir).</summary>
 public byte[] DugumHam(){
  int start=p;byte e=Byte();
  switch(e&0x3F){case 0:Al(1);break;case 1:Al(3);break;case 2:Al(6);break;case 3:UInt16();String();break;case 4:Al(18);break;case 5:UInt16();ByteString();break;default:throw new InvalidDataException("OPC UA düğüm kodlaması bilinmiyor.");}
  if((e&0x80)!=0)String();
  if((e&0x40)!=0)UInt32();
  var r=b[start..p];r[0]=(byte)(r[0]&0x3F);return r;
 }
 public void LocalizedText(){byte m=Byte();if((m&1)!=0)String();if((m&2)!=0)String();}
 public void UygulamaAciklamasi(){String();String();LocalizedText();Int32();String();String();int n=Int32();for(int i=0;i<n;i++)String();}
 public void DiagnosticInfo(){byte m=Byte();if((m&1)!=0)Int32();if((m&2)!=0)Int32();if((m&4)!=0)Int32();if((m&8)!=0)Int32();if((m&0x10)!=0)String();if((m&0x20)!=0)UInt32();if((m&0x40)!=0)DiagnosticInfo();}
 public void ExtensionObject(){DugumHam();byte e=Byte();if(e is 1 or 2)Al(Int32());}
 /// <summary>DataValue okur; sayısal, boolean veya sayı içeren metin değeri döndürür. Çözülemeyen tipte devam=false olur.</summary>
 public double? DataValue(out bool devam){
  devam=true;byte m=Byte();double? v=null;
  if((m&1)!=0)v=Variant(out devam);
  if(!devam)return v;
  uint status=0;if((m&2)!=0)status=UInt32();if((m&4)!=0)Int64();if((m&0x10)!=0)UInt16();if((m&8)!=0)Int64();if((m&0x20)!=0)UInt16();
  return (status&0x80000000)!=0?null:v;
 }
 double? Variant(out bool devam){
  devam=true;byte m=Byte();int tip=m&0x3F;bool dizi=(m&0x80)!=0;int adet=1;double? ilk=null;
  if(dizi){adet=Int32();if(adet<0)adet=0;}
  for(int i=0;i<adet;i++){var v=Skaler(tip,out devam);if(!devam)return ilk;if(i==0)ilk=v;}
  if(dizi&&(m&0x40)!=0){int d=Int32();for(int i=0;i<d;i++)Int32();}
  return ilk;
 }
 double? Skaler(int tip,out bool devam){
  devam=true;
  switch(tip){
   case 0:return null;
   case 1:return Byte()!=0?1:0;
   case 2:return (sbyte)Byte();
   case 3:return Byte();
   case 4:return BinaryPrimitives.ReadInt16LittleEndian(Al(2));
   case 5:return UInt16();
   case 6:return Int32();
   case 7:return UInt32();
   case 8:return Int64();
   case 9:return BinaryPrimitives.ReadUInt64LittleEndian(Al(8));
   case 10:return BinaryPrimitives.ReadSingleLittleEndian(Al(4));
   case 11:return Double();
   case 12:{var t=String();return double.TryParse(t,NumberStyles.Float,CultureInfo.InvariantCulture,out double x)?x:null;}
   case 13:Int64();return null;
   case 14:Al(16);return null;
   case 15:ByteString();return null;
   case 16:String();return null;
   case 17:DugumHam();return null;
   case 19:UInt32();return null;
   case 20:UInt16();String();return null;
   case 21:LocalizedText();return null;
   default:devam=false;return null;
  }
 }
}
