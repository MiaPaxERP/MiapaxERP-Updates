using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record PanoDegeri(string Ad,decimal Deger);
/// <summary>Temaya özel gösterge panolarını besleyen özet. Yetkisi olmayan alan boş/null gelir.</summary>
public sealed record PanoOzeti(
 bool Satis,decimal SatisBugun,decimal SatisAy,decimal SatisGecenAy,decimal[] Son7Gun,PanoDegeri[] EnIyiCariler,
 bool Cari,decimal AcikAlacak,decimal TahsilatAy,
 bool Stok,int KritikStok,int EksiStok,int ToplamStokKarti,
 bool Uretim,int AktifUretim,int PlanliUretim,int GecikenUretim,PanoDegeri[] UretimIlerleme,
 bool Takvim,string[] Gecikmis,string[] Bugun,string[] Yarin,
 PanoDegeri[] Ekip,DateTime Zaman);

/// <summary>Salt okunur gösterge paneli özeti; her alan kendi görüntüleme yetkisiyle okunur.</summary>
public sealed class PanoOzetiServisi(string connection,int user)
{
 readonly ErpModulServisi access=new(connection,user);
 public PanoOzeti Oku(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<PanoOzeti>(connection,"PanoOzetiServisi.Oku","",[]);
  using var c=access.Ac();
  bool Var(string izin){try{access.Yetki(c,null,izin);return true;}catch(UnauthorizedAccessException){return false;}}
  T Dene<T>(Func<T> f,T yedek){try{return f();}catch(SqlException){return yedek;}}
  decimal Sayi(string sql,params(string,object?)[] ps){using var q=ErpModulServisi.Komut(c,null,sql,ps);q.CommandTimeout=20;var v=q.ExecuteScalar();return v is null||v is DBNull?0m:Convert.ToDecimal(v);}
  List<PanoDegeri> Liste(string sql,params(string,object?)[] ps){var l=new List<PanoDegeri>();using var q=ErpModulServisi.Komut(c,null,sql,ps);q.CommandTimeout=20;using var r=q.ExecuteReader();while(r.Read())l.Add(new(r.GetString(0),r.IsDBNull(1)?0m:Convert.ToDecimal(r.GetValue(1))));return l;}
  List<string> Metin(string sql,params(string,object?)[] ps){var l=new List<string>();using var q=ErpModulServisi.Komut(c,null,sql,ps);q.CommandTimeout=20;using var r=q.ExecuteReader();while(r.Read())l.Add(r.GetString(0));return l;}

  bool satis=Var("SALES.VIEW")||Var("CUSTOMER.VIEW");
  decimal bugun=0,ay=0,gecen=0;var son7=new decimal[7];PanoDegeri[] enIyi=[];
  if(satis){
   const string kosul="BelgeTipi=N'Satış' AND Durum<>N'İptal'";
   bugun=Dene(()=>Sayi($"SELECT SUM(GenelToplam) FROM dbo.TicariBelgeler WHERE {kosul} AND CAST(BelgeTarihi AS date)=CAST(SYSDATETIME() AS date)"),0m);
   ay=Dene(()=>Sayi($"SELECT SUM(GenelToplam) FROM dbo.TicariBelgeler WHERE {kosul} AND BelgeTarihi>=DATEFROMPARTS(YEAR(SYSDATETIME()),MONTH(SYSDATETIME()),1)"),0m);
   gecen=Dene(()=>Sayi($"SELECT SUM(GenelToplam) FROM dbo.TicariBelgeler WHERE {kosul} AND BelgeTarihi>=DATEADD(month,-1,DATEFROMPARTS(YEAR(SYSDATETIME()),MONTH(SYSDATETIME()),1)) AND BelgeTarihi<DATEADD(month,-1,CAST(SYSDATETIME() AS date))"),0m);
   foreach(var g in Dene(()=>Liste($"SELECT CONVERT(varchar(10),CAST(BelgeTarihi AS date),23),SUM(GenelToplam) FROM dbo.TicariBelgeler WHERE {kosul} AND BelgeTarihi>=DATEADD(day,-6,CAST(SYSDATETIME() AS date)) GROUP BY CAST(BelgeTarihi AS date)"),[]))
    if(DateTime.TryParse(g.Ad,out var d)){int i=6-(DateTime.Today-d.Date).Days;if(i is >=0 and <7)son7[i]=g.Deger;}
   enIyi=Dene(()=>Liste("SELECT TOP(5) ca.Unvan,SUM(b.GenelToplam) FROM dbo.TicariBelgeler b JOIN dbo.CariKartlari ca ON ca.Id=b.CariId WHERE b.BelgeTipi=N'Satış' AND b.Durum<>N'İptal' AND b.BelgeTarihi>=DATEFROMPARTS(YEAR(SYSDATETIME()),MONTH(SYSDATETIME()),1) GROUP BY ca.Unvan ORDER BY SUM(b.GenelToplam) DESC"),[]).ToArray();
  }
  bool cari=Var("CUSTOMER.VIEW");decimal alacak=0,tahsilat=0;
  if(cari){
   alacak=Dene(()=>Sayi("SELECT SUM(CASE WHEN x.Bakiye>0 THEN x.Bakiye ELSE 0 END) FROM (SELECT CariId,SUM(CASE WHEN HareketTipi=N'Borç' THEN Tutar ELSE -Tutar END) Bakiye FROM dbo.CariHareketleri GROUP BY CariId) x"),0m);
   tahsilat=Dene(()=>Sayi("SELECT SUM(Tutar) FROM dbo.CariHareketleri WHERE HareketTipi=N'Alacak' AND Kaynak NOT IN(N'Belge',N'E-Belge') AND TersKayitId IS NULL AND Tarih>=DATEFROMPARTS(YEAR(SYSDATETIME()),MONTH(SYSDATETIME()),1)"),0m);
  }
  bool stok=Var("STOCK.VIEW");int kritik=0,eksi=0,kart=0;
  if(stok){
   kritik=(int)Dene(()=>Sayi("SELECT COUNT(*) FROM dbo.StokKartlari s LEFT JOIN dbo.StokBakiyeleri b ON b.StokKartId=s.Id WHERE s.Aktif=1 AND s.MinimumStokMiktari>0 AND ISNULL(b.Miktar,0)<=s.MinimumStokMiktari"),0m);
   eksi=(int)Dene(()=>Sayi("SELECT COUNT(*) FROM dbo.StokBakiyeleri WHERE Miktar<0"),0m);
   kart=(int)Dene(()=>Sayi("SELECT COUNT(*) FROM dbo.StokKartlari WHERE Aktif=1"),0m);
  }
  bool uretim=Var("PRODUCTION.VIEW");int aktif=0,planli=0,geciken=0;PanoDegeri[] ilerleme=[];
  if(uretim){
   aktif=(int)Dene(()=>Sayi("SELECT COUNT(*) FROM dbo.UretimEmirleri WHERE Durum=N'Üretimde'"),0m);
   planli=(int)Dene(()=>Sayi("SELECT COUNT(*) FROM dbo.UretimEmirleri WHERE Durum=N'Planlandı'"),0m);
   geciken=(int)Dene(()=>Sayi("SELECT COUNT(*) FROM dbo.UretimEmirleri WHERE Durum IN(N'Planlandı',N'Üretimde') AND PlanlananBitis<CAST(SYSDATETIME() AS date)"),0m);
   ilerleme=Dene(()=>Liste("SELECT TOP(6) s.StokAdi,CASE WHEN e.PlanlananMiktar>0 THEN CASE WHEN e.UretilenMiktar*100.0/e.PlanlananMiktar>100 THEN 100 ELSE e.UretilenMiktar*100.0/e.PlanlananMiktar END ELSE 0 END FROM dbo.UretimEmirleri e JOIN dbo.StokKartlari s ON s.Id=e.MamulStokId WHERE e.Durum=N'Üretimde' ORDER BY e.Id DESC"),[]).ToArray();
  }
  bool takvim=Var("CALENDAR.VIEW");string[] gec=[],bug=[],yar=[];
  if(takvim){
   bool tum=Var("CALENDAR.ALL");
   const string t="SELECT TOP(8) FORMAT(PlanTarihi,'HH:mm')+N' · '+Baslik FROM dbo.IsTakvimi WHERE Durum=N'Bekliyor' AND (@tum=1 OR OlusturanKullaniciId=@u OR AtananKullaniciId=@u) AND ";
   gec=Dene(()=>Metin(t+"PlanTarihi<CAST(SYSDATETIME() AS date) ORDER BY PlanTarihi",("@tum",tum),("@u",user)),[]).ToArray();
   bug=Dene(()=>Metin(t+"CAST(PlanTarihi AS date)=CAST(SYSDATETIME() AS date) ORDER BY PlanTarihi",("@tum",tum),("@u",user)),[]).ToArray();
   yar=Dene(()=>Metin(t+"CAST(PlanTarihi AS date)=DATEADD(day,1,CAST(SYSDATETIME() AS date)) ORDER BY PlanTarihi",("@tum",tum),("@u",user)),[]).ToArray();
  }
  // Ekip: son giriş yapan etkin çalışanlar (ad ve kaç dakika önce). Silinmiş hesaplar hariç.
  var ekip=Dene(()=>Liste("SELECT TOP(6) COALESCE(NULLIF(AdSoyad,N''),KullaniciAdi),DATEDIFF(minute,SonGirisUtc,SYSUTCDATETIME()) FROM dbo.Kullanicilar WHERE Aktif=1 AND SonGirisUtc IS NOT NULL AND KullaniciAdi NOT LIKE N'~silindi~%' ORDER BY SonGirisUtc DESC"),[]).ToArray();
  return new(satis,bugun,ay,gecen,son7,enIyi,cari,alacak,tahsilat,stok,kritik,eksi,kart,uretim,aktif,planli,geciken,ilerleme,takvim,gec,bug,yar,ekip,DateTime.Now);
 }
}
