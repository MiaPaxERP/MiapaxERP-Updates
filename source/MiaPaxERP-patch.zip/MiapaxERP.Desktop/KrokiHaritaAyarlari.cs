using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
public static class KrokiHaritaAyarlari
{
 static string Dosya=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","Kroki","google-maps.dpapi");
 public static string Oku(){try{return File.Exists(Dosya)?Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(Dosya),null,DataProtectionScope.CurrentUser)):"";}catch{return "";}}
 public static void Ayarlar(Window? owner){
  LisansOturumu.Gerekli("KROKI");var w=new Window{Title="MiaPaxERP Google Maps ayarları",Owner=owner,Width=640,Height=490,WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(24)};w.Content=p;
  p.Children.Add(new TextBlock{Text="Google uydu ve gerçek 3D arazi için kendi Google Cloud projenizin anahtarını tanımlayın. Maps JavaScript API, 3D erişimi ve faturalandırma etkin olmalıdır. Kullanım ücretleri Google hesabınıza aittir.",TextWrapping=TextWrapping.Wrap});
  p.Children.Add(new TextBlock{Text="Web sitesi kısıtı: https://kroki.boruerp.local/*\nAPI kısıtlarını da Google Cloud üzerinden belirleyin. Bu anahtar tarayıcıda harita yüklemek için kullanılır; sunucu gizli anahtarı girmeyin.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,18,0,14)});
  p.Children.Add(new TextBlock{Text=string.IsNullOrEmpty(Oku())?"Henüz kayıtlı anahtar yok.":"Kayıtlı anahtar var. Değiştirmeyecekseniz alanı boş bırakın."});
  var key=new PasswordBox{Margin=new Thickness(0,8,0,14),MinHeight=34};p.Children.Add(key);var clear=new System.Windows.Controls.CheckBox{Content="Kayıtlı anahtarı temizle"};p.Children.Add(clear);
  var status=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,0)};p.Children.Add(status);
  var save=new System.Windows.Controls.Button{Content="Kaydet",Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,16,0,0)};p.Children.Add(save);
  save.Click+=(_,_)=>{try{if(clear.IsChecked==true){if(File.Exists(Dosya))File.Delete(Dosya);}else if(!string.IsNullOrEmpty(key.Password)){if(!System.Text.RegularExpressions.Regex.IsMatch(key.Password,"^[A-Za-z0-9_-]{20,200}$"))throw new ArgumentException("Geçerli Google Maps tarayıcı anahtarını girin.");Directory.CreateDirectory(Path.GetDirectoryName(Dosya)!);File.WriteAllBytes(Dosya,ProtectedData.Protect(Encoding.UTF8.GetBytes(key.Password),null,DataProtectionScope.CurrentUser));}w.DialogResult=true;}catch(Exception e){status.Text=e.Message;}};w.ShowDialog();
 }
}
