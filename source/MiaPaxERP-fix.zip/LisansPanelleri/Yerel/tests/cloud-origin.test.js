import test from 'node:test';
import assert from 'node:assert/strict';
import {cloudOrigin,DEFAULT_CLOUD_ORIGIN} from '../src/cloud-origin.js';
test('cloud origin defaults to existing panel and accepts own https domain',()=>{
 assert.equal(cloudOrigin({}),DEFAULT_CLOUD_ORIGIN);
 assert.equal(cloudOrigin({LICENSE_CLOUD_ORIGIN:'https://lisans.firma.com/'}),'https://lisans.firma.com');
 for(const bad of ['http://lisans.firma.com','https://u:p@x.com','https://x.com/api','https://x.com/?a=1','yok'])assert.throws(()=>cloudOrigin({LICENSE_CLOUD_ORIGIN:bad}));
});
