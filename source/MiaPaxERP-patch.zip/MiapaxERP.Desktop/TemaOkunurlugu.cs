using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using DataGridCell = System.Windows.Controls.DataGridCell;
using RadioButton = System.Windows.Controls.RadioButton;
namespace MiapaxERP.Desktop;
public static class TemaOkunurlugu
{
 static bool started;
 internal static double Parlaklik(Color c){double F(byte x){double v=x/255d;return v<=.04045?v/12.92:Math.Pow((v+.055)/1.055,2.4);}return .2126*F(c.R)+.7152*F(c.G)+.0722*F(c.B);}
 internal static double Kontrast(Color a,Color b){double x=Parlaklik(a),y=Parlaklik(b);return(Math.Max(x,y)+.05)/(Math.Min(x,y)+.05);}
 internal static Color Uyumlu(Color text,Color surface){text=Color.FromRgb(text.R,text.G,text.B);if(Kontrast(text,surface)>=4.5)return text;Color target=Kontrast(Colors.Black,surface)>=Kontrast(Colors.White,surface)?Colors.Black:Colors.White;for(int i=1;i<=40;i++){double k=i/40d;var next=Color.FromRgb((byte)Math.Round(text.R+(target.R-text.R)*k),(byte)Math.Round(text.G+(target.G-text.G)*k),(byte)Math.Round(text.B+(target.B-text.B)*k));if(Kontrast(next,surface)>=4.5)return next;}return target;}
 public static void Baslat(){if(started)return;started=true;EventManager.RegisterClassHandler(typeof(TextBlock),FrameworkElement.LoadedEvent,new RoutedEventHandler((s,_)=>Duzelt((DependencyObject)s)));EventManager.RegisterClassHandler(typeof(Control),FrameworkElement.LoadedEvent,new RoutedEventHandler((s,_)=>Duzelt((DependencyObject)s)));foreach(var ev in new[]{DataGridCell.SelectedEvent,DataGridCell.UnselectedEvent})EventManager.RegisterClassHandler(typeof(DataGridCell),ev,new RoutedEventHandler((s,_)=>{var cell=(DataGridCell)s;cell.Dispatcher.BeginInvoke(()=>Uygula(cell),DispatcherPriority.Render);}));}
 static DependencyObject? Parent(DependencyObject node){try{return VisualTreeHelper.GetParent(node)??LogicalTreeHelper.GetParent(node);}catch(InvalidOperationException){return LogicalTreeHelper.GetParent(node);}}
 static Color Surface(DependencyObject node){double remain=1,red=0,green=0,blue=0;for(var p=node;p is not null&&remain>.001;p=Parent(p)){Brush? b=p switch{Control c when c is not CheckBox and not RadioButton=>c.Background,Border border=>border.Background,Panel panel=>panel.Background,TextBlock t=>t.Background,_=>null};if(b is not SolidColorBrush s||s.Color.A==0)continue;double alpha=s.Color.A/255d;red+=s.Color.R*alpha*remain;green+=s.Color.G*alpha*remain;blue+=s.Color.B*alpha*remain;remain*=1-alpha;}bool dark=Tema170.Mevcut.Tema=="Koyu";Color fallback=dark?Color.FromRgb(23,35,51):Colors.White;return Color.FromRgb((byte)Math.Round(red+fallback.R*remain),(byte)Math.Round(green+fallback.G*remain),(byte)Math.Round(blue+fallback.B*remain));}
 static void Duzelt(DependencyObject node){DependencyProperty? property=node is TextBlock?TextBlock.ForegroundProperty:node is Control?Control.ForegroundProperty:null;if(property is null||node.GetValue(property) is not SolidColorBrush fg||fg.Color.A==0)return;Color surface=Surface(node),current=fg.Color;var visible=Color.FromRgb((byte)Math.Round(current.R*current.A/255d+surface.R*(1-current.A/255d)),(byte)Math.Round(current.G*current.A/255d+surface.G*(1-current.A/255d)),(byte)Math.Round(current.B*current.A/255d+surface.B*(1-current.A/255d)));if(Kontrast(visible,surface)<4.5)node.SetCurrentValue(property,new SolidColorBrush(Uyumlu(visible,surface)));}
 public static void Uygula(DependencyObject root){Duzelt(root);for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++)Uygula(VisualTreeHelper.GetChild(root,i));}
}
