using System.Net.Http;
using System.Windows;

namespace MiapaxERP.Desktop
{
    /// <summary>Yan PC için uzaktan (HTTPS) bağlantı adresi: ofis dışında SQL'e ulaşılamazsa program bu adresle açılır.</summary>
    public partial class BaglantiAyarlariPenceresi
    {
        void HttpsAdresiniGoster()
        {
            try { TxtUzakHttps.Text = KolayBaglantiProfili.Oku().MasaustuHttps; } catch (Exception e) when (e is System.IO.IOException or System.Text.Json.JsonException or ArgumentException or InvalidOperationException or UnauthorizedAccessException) { }
        }

        /// <summary>Girilen HTTPS adresini doğrular ve yan PC profiline yazar (boşsa siler).</summary>
        void HttpsAdresiniKaydet()
        {
            string adres = TxtUzakHttps.Text.Trim();
            KolayBaglantiProfili p;
            try { p = KolayBaglantiProfili.Oku(); } catch (Exception e) when (e is System.IO.IOException or System.Text.Json.JsonException or ArgumentException or InvalidOperationException) { p = new(); }
            if (adres.Length == 0 && p.MasaustuHttps.Length == 0) return;
            if (adres.Length > 0) adres = KolayBaglantiProfili.Https(adres).ToString().TrimEnd('/');
            p = p with { Rol = "Yan", MasaustuHttps = adres };
            if (adres.Length == 0) { System.IO.File.WriteAllText(KolayBaglantiProfili.DosyaYolu + ".tmp", System.Text.Json.JsonSerializer.Serialize(p)); System.IO.File.Move(KolayBaglantiProfili.DosyaYolu + ".tmp", KolayBaglantiProfili.DosyaYolu, true); return; }
            p.Kaydet();
        }

        private async void HttpsTest_Click(object sender, RoutedEventArgs e)
        {
            BtnHttpsTest.IsEnabled = false;
            try
            {
                var uri = KolayBaglantiProfili.Https(TxtUzakHttps.Text.Trim());
                using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
                using var r = await http.GetAsync(uri);
                TxtDurum.Text = "✔ HTTPS sunucusuna güvenli bağlantı kuruldu: " + uri.Host + " (HTTP " + (int)r.StatusCode + "). Kaydet'e basın; ofis dışında program bu adresle açılır.";
            }
            catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or ArgumentException or UriFormatException)
            {
                TxtDurum.Text = "✖ HTTPS adresine ulaşılamadı: " + ex.Message + "\nGerekenler: ana sunucuda Kolay Sunucu Kurulumu (alan adı + geçerli sertifika), modemde 443 portunun ana sunucuya yönlendirilmesi. Yalnız IP adresiyle (alan adı olmadan) güvenli HTTPS kurulamaz.";
            }
            finally { BtnHttpsTest.IsEnabled = true; }
        }
    }
}
