using System.Data;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Orientation = System.Windows.Controls.Orientation;
using ProgressBar = System.Windows.Controls.ProgressBar;
using TabControl = System.Windows.Controls.TabControl;
using HorizontalAlignment = System.Windows.HorizontalAlignment;
namespace MiapaxERP.Desktop;

/// <summary>
/// Saha pazarlamanın kaydettiği müşterilerin listesi ve WhatsApp hazır mesaj paneli:
/// tek müşteriye veya seçilen müşterilerin hepsine hazır mesaj otomatik gönderilir (WhatsApp Business Cloud API).
/// </summary>
public sealed class SahaMusteriWhatsAppPenceresi : Window
{
 readonly SahaServisi servis;
 readonly DataGrid tablo=new(){AutoGenerateColumns=true,CanUserAddRows=false,CanUserDeleteRows=false,SelectionMode=DataGridSelectionMode.Extended,HeadersVisibility=DataGridHeadersVisibility.Column,Margin=new Thickness(0,8,0,0)};
 readonly DataGrid gecmis=new(){AutoGenerateColumns=true,IsReadOnly=true,CanUserAddRows=false,HeadersVisibility=DataGridHeadersVisibility.Column};
 readonly TextBox arama=new(){MinWidth=260,Padding=new Thickness(6,4,6,4),ToolTip="Ad, telefon, şehir, ilçe, köy veya ürün ile arayın"};
 readonly TextBlock sayac=new(){VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(10,0,0,0)};
 readonly ComboBox sablonlar=new(){DisplayMemberPath="Ad",MinWidth=200};
 readonly TextBox metin=new(){AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,MinHeight=260,FontFamily=new FontFamily("Segoe UI Emoji, Segoe UI")};
 readonly TextBlock durum=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,0)};
 readonly ProgressBar ilerleme=new(){Height=8,Margin=new Thickness(0,8,0,0),Visibility=Visibility.Collapsed};
 readonly List<Button> islemDugmeleri=new();
 DataTable? veri;bool gonderiliyor;

 public SahaMusteriWhatsAppPenceresi(string connection,int user)
 {
  LisansOturumu.Gerekli("SAHA");servis=new(connection,user);
  Title="Saha pazarlama müşterileri · WhatsApp mesajları";Width=1400;Height=860;WindowStartupLocation=WindowStartupLocation.CenterOwner;
  var kok=new DockPanel{Margin=new Thickness(16)};
  var baslik=Tema170.Baslik("SAHA PAZARLAMA","Müşteri listesi ve WhatsApp hazır mesajları");DockPanel.SetDock(baslik,Dock.Top);kok.Children.Add(baslik);
  var sekmeler=new TabControl();kok.Children.Add(sekmeler);
  sekmeler.Items.Add(new TabItem{Header="Müşteriler",Content=MusteriSekmesi()});
  sekmeler.Items.Add(new TabItem{Header="Gönderim geçmişi",Content=GecmisSekmesi()});
  sekmeler.SelectionChanged+=(_,e)=>{if(ReferenceEquals(e.OriginalSource,sekmeler)&&sekmeler.SelectedIndex==1)GecmisiYukle();};
  Content=kok;
  Loaded+=(_,_)=>{Yukle();SablonlariYukle();};
  Closing+=(_,e)=>{if(gonderiliyor&&MessageBox.Show("Gönderim sürüyor. Pencere kapatılırsa kalan müşterilere gönderilmez. Kapatılsın mı?","WhatsApp",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)e.Cancel=true;};
 }

 Button Dugme(string yazi,RoutedEventHandler tik,string? ipucu=null,bool vurgu=false){
  var b=new Button{Content=yazi,Margin=new Thickness(0,0,8,8),Padding=new Thickness(12,6,12,6),ToolTip=ipucu};
  if(vurgu){b.SetResourceReference(BackgroundProperty,"ErpVurgu");b.Foreground=Brushes.White;b.FontWeight=FontWeights.SemiBold;}
  b.Click+=tik;islemDugmeleri.Add(b);return b;
 }

 UIElement MusteriSekmesi(){
  var g=new Grid{Margin=new Thickness(0,10,0,0)};
  g.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
  g.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(16)});
  g.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(440)});
  // Sol: müşteri listesi
  var sol=new DockPanel();
  var ust=new WrapPanel();
  ust.Children.Add(new TextBlock{Text="Ara:",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,6,8)});
  arama.Margin=new Thickness(0,0,8,8);ust.Children.Add(arama);
  arama.KeyDown+=(_,e)=>{if(e.Key==System.Windows.Input.Key.Enter)Yukle();};
  ust.Children.Add(Dugme("🔍 Ara / Yenile",(_,_)=>Yukle()));
  ust.Children.Add(Dugme("☑ Tümünü seç",(_,_)=>Sec(true)));
  ust.Children.Add(Dugme("☐ Seçimi temizle",(_,_)=>Sec(false)));
  ust.Children.Add(Dugme("⇩ Excel'e aktar",(_,_)=>ExcelAktar()));
  ust.Children.Add(sayac);
  DockPanel.SetDock(ust,Dock.Top);sol.Children.Add(ust);
  var not=new TextBlock{Text="İpucu: soldaki 'Seç' kutularını işaretleyin; birden fazla satırı fareyle seçip boşluk tuşuna basarak da işaretleyebilirsiniz.",Opacity=.75,TextWrapping=TextWrapping.Wrap};
  DockPanel.SetDock(not,Dock.Bottom);sol.Children.Add(not);
  tablo.AutoGeneratingColumn+=(_,e)=>{
   if(e.PropertyName=="Id"){e.Cancel=true;return;}
   if(e.PropertyName!="Seç")e.Column.IsReadOnly=true;
   if(e.PropertyName=="Kayıt tarihi"&&e.Column is DataGridTextColumn t)t.Binding.StringFormat="dd.MM.yyyy HH:mm";
   if(e.PropertyName is "Açıklama" or "Ürünler")e.Column.MaxWidth=260;
  };
  tablo.PreviewKeyDown+=(_,e)=>{if(e.Key==System.Windows.Input.Key.Space&&veri is not null&&tablo.SelectedItems.Count>0&&tablo.CurrentColumn?.Header?.ToString()!="Seç"){bool hedef=!tablo.SelectedItems.OfType<DataRowView>().All(r=>r["Seç"] is true);foreach(DataRowView r in tablo.SelectedItems.OfType<DataRowView>().ToList())r["Seç"]=hedef;SayaciYenile();e.Handled=true;}};
  tablo.CellEditEnding+=(_,_)=>Dispatcher.BeginInvoke(SayaciYenile);
  tablo.CurrentCellChanged+=(_,_)=>SayaciYenile();
  sol.Children.Add(tablo);
  g.Children.Add(sol);
  // Sağ: hazır mesaj paneli
  var sag=new StackPanel();
  var kart=Tema170.Kart(new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=sag},"WhatsApp hazır mesaj");kart.Margin=new Thickness(0);
  Grid.SetColumn(kart,2);g.Children.Add(kart);
  sag.Children.Add(new TextBlock{Text="Hazır mesaj",FontWeight=FontWeights.SemiBold});
  var sablonSatiri=new DockPanel{Margin=new Thickness(0,4,0,8)};
  var sablonDugmeleri=new StackPanel{Orientation=Orientation.Horizontal};DockPanel.SetDock(sablonDugmeleri,Dock.Right);
  foreach(var (y,a,ip) in new (string,Action,string)[]{("＋",()=>SablonDuzenle(null),"Yeni hazır mesaj"),("✎",()=>SablonDuzenle(sablonlar.SelectedItem as WhatsAppSablonu),"Seçili hazır mesajı düzenle"),("🗑",SablonSil,"Seçili hazır mesajı sil")})
  {var b=new Button{Content=y,Width=34,Margin=new Thickness(6,0,0,0),ToolTip=ip};b.Click+=(_,_)=>a();islemDugmeleri.Add(b);sablonDugmeleri.Children.Add(b);}
  sablonSatiri.Children.Add(sablonDugmeleri);sablonSatiri.Children.Add(sablonlar);sag.Children.Add(sablonSatiri);
  sablonlar.SelectionChanged+=(_,_)=>{if(sablonlar.SelectedItem is WhatsAppSablonu s)metin.Text=s.Metin;};
  sag.Children.Add(new TextBlock{Text="Mesaj (gönderimden önce düzenleyebilirsiniz)",FontWeight=FontWeights.SemiBold});
  metin.Margin=new Thickness(0,4,0,4);sag.Children.Add(metin);
  sag.Children.Add(new TextBlock{Text="[Müşteri Adı], [Şehir] ve [Tarih] her müşteri için otomatik doldurulur. *yıldız* arasındaki yazı WhatsApp'ta kalın görünür.",TextWrapping=TextWrapping.Wrap,Opacity=.75,Margin=new Thickness(0,0,0,10)});
  var dugmeler=new WrapPanel();
  dugmeler.Children.Add(Dugme("📨 Seçililere otomatik gönder",async(_,_)=>await TopluGonder(),"İşaretli tüm müşterilere WhatsApp ile otomatik gönderir",true));
  dugmeler.Children.Add(Dugme("📨 Bu müşteriye gönder",async(_,_)=>await TekGonder(),"Tabloda üzerinde durduğunuz müşteriye otomatik gönderir"));
  dugmeler.Children.Add(Dugme("💬 WhatsApp'ta aç",(_,_)=>SohbetAc(),"Otomatik gönderim ayarı yoksa: WhatsApp sohbetini mesaj yazılmış hâlde açar, gönder tuşuna siz basarsınız"));
  dugmeler.Children.Add(Dugme("🧪 Kendime test gönder",async(_,_)=>await TestGonder(),"Ayarlardaki test numarasına deneme mesajı gönderir"));
  dugmeler.Children.Add(Dugme("⚙ WhatsApp ayarları",(_,_)=>Ayarlar(),"Meta WhatsApp Business bağlantı bilgileri"));
  sag.Children.Add(dugmeler);sag.Children.Add(ilerleme);sag.Children.Add(durum);
  return g;
 }

 UIElement GecmisSekmesi(){
  var d=new DockPanel{Margin=new Thickness(0,10,0,0)};
  var b=new Button{Content="↻ Yenile",HorizontalAlignment=HorizontalAlignment.Left,Padding=new Thickness(12,6,12,6),Margin=new Thickness(0,0,0,8)};b.Click+=(_,_)=>GecmisiYukle();
  DockPanel.SetDock(b,Dock.Top);d.Children.Add(b);d.Children.Add(gecmis);
  gecmis.AutoGeneratingColumn+=(_,e)=>{if(e.PropertyName=="Zaman"&&e.Column is DataGridTextColumn t)t.Binding.StringFormat="dd.MM.yyyy HH:mm";if(e.PropertyName=="Açıklama")e.Column.MaxWidth=520;};
  return d;
 }

 void Hata(Exception e)=>MessageBox.Show(this,e.Message,"Saha müşterileri · WhatsApp",MessageBoxButton.OK,MessageBoxImage.Warning);

 async void Yukle(){
  try{
   string a=arama.Text;var t=await Task.Run(()=>servis.WaMusteriler(a));
   var sec=new DataColumn("Seç",typeof(bool)){DefaultValue=false};t.Columns.Add(sec);sec.SetOrdinal(0);foreach(DataRow r in t.Rows)r["Seç"]=false;
   veri=t;tablo.ItemsSource=t.DefaultView;SayaciYenile();
  }catch(Exception e){Hata(e);}
 }
 async void SablonlariYukle(int? sec=null){
  try{
   var l=await Task.Run(servis.WaSablonlar);sablonlar.ItemsSource=l;
   sablonlar.SelectedItem=l.FirstOrDefault(x=>x.Id==sec)??l.FirstOrDefault();
  }catch(Exception e){Hata(e);}
 }
 async void GecmisiYukle(){try{gecmis.ItemsSource=(await Task.Run(servis.WaGecmis)).DefaultView;}catch(Exception e){Hata(e);}}
 void Sec(bool deger){if(veri is null)return;tablo.CommitEdit();foreach(DataRowView r in veri.DefaultView)r["Seç"]=deger;SayaciYenile();}
 List<DataRow> Secililer()=>veri is null?[]:veri.DefaultView.Cast<DataRowView>().Where(r=>r["Seç"] is true).Select(r=>r.Row).ToList();
 void SayaciYenile(){if(veri is null)return;sayac.Text=$"{veri.DefaultView.Count} müşteri · {Secililer().Count} seçili";}
 void Kilitle(bool kilit){gonderiliyor=kilit;foreach(var b in islemDugmeleri)b.IsEnabled=!kilit;tablo.IsReadOnly=kilit;ilerleme.Visibility=kilit?Visibility.Visible:Visibility.Collapsed;}

 bool Hazir(out WhatsAppSablonu sablon){
  sablon=null!;
  if(sablonlar.SelectedItem is not WhatsAppSablonu s){MessageBox.Show(this,"Önce bir hazır mesaj seçin veya ＋ ile yeni hazır mesaj ekleyin.","WhatsApp");return false;}
  if(string.IsNullOrWhiteSpace(metin.Text)){MessageBox.Show(this,"Mesaj metni boş olamaz.","WhatsApp");return false;}
  sablon=s;return true;
 }

 async Task TopluGonder(){
  tablo.CommitEdit(DataGridEditingUnit.Row,true);
  if(!Hazir(out var s))return;
  var liste=Secililer();
  if(liste.Count==0){MessageBox.Show(this,"Gönderilecek müşteri seçilmedi. Tablodaki 'Seç' kutularını işaretleyin veya 'Tümünü seç'e basın.","WhatsApp");return;}
  if(MessageBox.Show(this,$"'{s.Ad}' mesajı {liste.Count} müşteriye WhatsApp ile otomatik gönderilecek. Devam edilsin mi?","Toplu WhatsApp gönderimi",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
  await Gonder(liste,s);
 }
 async Task TekGonder(){
  if(!Hazir(out var s))return;
  if(tablo.CurrentItem is not DataRowView&&tablo.SelectedItem is not DataRowView){MessageBox.Show(this,"Tablodan bir müşteri seçin.","WhatsApp");return;}
  var row=((tablo.CurrentItem as DataRowView)??(DataRowView)tablo.SelectedItem).Row;
  if(MessageBox.Show(this,$"'{s.Ad}' mesajı {row["Ad Soyad"]} ({row["Telefon"]}) numarasına gönderilecek. Devam edilsin mi?","WhatsApp",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
  await Gonder([row],s);
 }
 async Task Gonder(List<DataRow> liste,WhatsAppSablonu s){
  string govde=metin.Text;int basarili=0;var hatalar=new List<string>();
  Kilitle(true);ilerleme.Maximum=liste.Count;ilerleme.Value=0;
  try{
   for(int i=0;i<liste.Count;i++){
    var row=liste[i];Guid id=(Guid)row["Id"];durum.Text=$"Gönderiliyor {i+1}/{liste.Count}: {row["Ad Soyad"]}…";
    try{
     var sonuc=await Task.Run(()=>servis.WaGonder(id,s.Id,govde));
     if(sonuc.Basarili){basarili++;row["Son WhatsApp"]=DateTime.Now.ToString("yyyy-MM-dd HH:mm")+" · gönderildi";}
     else{hatalar.Add($"{sonuc.Ad}: {sonuc.Mesaj}");row["Son WhatsApp"]=DateTime.Now.ToString("yyyy-MM-dd HH:mm")+" · hata";
      // Ayar/anahtar hatasında diğer müşterilerde de aynı hata alınır; gönderim durdurulur.
      if(sonuc.Mesaj.Contains("ayar",StringComparison.OrdinalIgnoreCase)||sonuc.Mesaj.Contains("anahtar",StringComparison.OrdinalIgnoreCase)||sonuc.Mesaj.Contains("kimliği",StringComparison.OrdinalIgnoreCase)){hatalar.Add("Gönderim durduruldu: önce WhatsApp ayarlarını düzeltin.");break;}}
    }catch(Exception e){hatalar.Add($"{row["Ad Soyad"]}: {e.Message}");}
    ilerleme.Value=i+1;
    if(i<liste.Count-1)await Task.Delay(1100);// WhatsApp gönderim sınırına takılmamak için
   }
  }finally{Kilitle(false);}
  durum.Text=$"✔ {basarili} müşteriye gönderildi"+(hatalar.Count>0?$" · ✖ {hatalar.Count} hata: "+string.Join(" | ",hatalar.Take(5))+(hatalar.Count>5?" …":""):"");
  MessageBox.Show(this,$"{basarili} müşteriye gönderildi, {liste.Count-basarili} müşteriye gönderilemedi."+(hatalar.Count>0?"\n\n"+string.Join("\n",hatalar.Take(8)):""),"WhatsApp gönderimi",MessageBoxButton.OK,hatalar.Count>0?MessageBoxImage.Warning:MessageBoxImage.Information);
 }
 async Task TestGonder(){
  if(!Hazir(out var s))return;
  Kilitle(true);try{var r=await Task.Run(()=>servis.WaTest(s.Id,metin.Text));durum.Text=r.Basarili?"✔ Test mesajı gönderildi: "+r.Telefon:"✖ "+r.Mesaj;}
  catch(Exception e){durum.Text="✖ "+e.Message;}finally{Kilitle(false);}
 }
 void SohbetAc(){
  try{
   var row=((tablo.CurrentItem as DataRowView)??(tablo.SelectedItem as DataRowView))?.Row??throw new InvalidOperationException("Tablodan bir müşteri seçin.");
   string numara=WhatsAppBulut.Numara(Convert.ToString(row["Telefon"])??"");
   string govde=WhatsAppBulut.MetniHazirla(metin.Text,Convert.ToString(row["Ad Soyad"])??"",Convert.ToString(row["Şehir"])??"");
   Process.Start(new ProcessStartInfo(WhatsAppBulut.SohbetAdresi(numara,govde)){UseShellExecute=true});
   durum.Text="WhatsApp sohbeti açıldı; mesaj yazılı hâlde. Göndermek için WhatsApp'ta gönder tuşuna basın.";
  }catch(Exception e){Hata(e);}
 }
 void ExcelAktar(){
  if(veri is null)return;
  try{
   var dlg=new Microsoft.Win32.SaveFileDialog{Filter="Excel çalışma kitabı (*.xlsx)|*.xlsx",FileName="Saha_Musterileri_"+DateTime.Now.ToString("yyyyMMdd")+".xlsx"};
   if(dlg.ShowDialog(this)!=true)return;
   var t=veri.DefaultView.ToTable(false,veri.Columns.Cast<DataColumn>().Where(c=>c.ColumnName is not "Id" and not "Seç").Select(c=>c.ColumnName).ToArray());
   using var wb=new ClosedXML.Excel.XLWorkbook();var ws=wb.Worksheets.Add(t,"Saha müşterileri");ws.Columns().AdjustToContents(1,200,10,60);wb.SaveAs(dlg.FileName);
   durum.Text="Excel kaydedildi: "+dlg.FileName;
  }catch(Exception e){Hata(e);}
 }

 async void SablonSil(){
  if(sablonlar.SelectedItem is not WhatsAppSablonu s)return;
  if(MessageBox.Show(this,$"'{s.Ad}' hazır mesajı silinsin mi?","Hazır mesaj",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
  try{await Task.Run(()=>servis.WaSablonSil(s.Id));SablonlariYukle();}catch(Exception e){Hata(e);}
 }

 void SablonDuzenle(WhatsAppSablonu? s){
  var w=new Window{Owner=this,Title=s is null?"Yeni hazır mesaj":"Hazır mesajı düzenle",Width=620,Height=720,WindowStartupLocation=WindowStartupLocation.CenterOwner,ResizeMode=ResizeMode.CanResize};
  var p=new StackPanel{Margin=new Thickness(18)};
  var ad=new TextBox{Text=s?.Ad??"",Margin=new Thickness(0,4,0,10)};
  var govde=new TextBox{Text=s?.Metin??metin.Text,AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,Height=300,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Margin=new Thickness(0,4,0,10),FontFamily=new FontFamily("Segoe UI Emoji, Segoe UI")};
  var meta=new TextBox{Text=s?.MetaSablon??"",Margin=new Thickness(0,4,0,4)};
  var dil=new TextBox{Text=s?.Dil??"tr",Width=80,HorizontalAlignment=HorizontalAlignment.Left,Margin=new Thickness(0,4,0,4)};
  var param=new CheckBox{Content="Meta şablonunda müşteri adı değişkeni ({{1}}) var",IsChecked=s?.AdParametresi??true,Margin=new Thickness(0,4,0,10)};
  p.Children.Add(new TextBlock{Text="Hazır mesaj adı (ör. Bayram kutlaması)",FontWeight=FontWeights.SemiBold});p.Children.Add(ad);
  p.Children.Add(new TextBlock{Text="Mesaj metni",FontWeight=FontWeights.SemiBold});p.Children.Add(govde);
  p.Children.Add(new TextBlock{Text="Meta onaylı şablon adı (isteğe bağlı)",FontWeight=FontWeights.SemiBold});p.Children.Add(meta);
  p.Children.Add(new TextBlock{Text="WhatsApp, son 24 saatte size yazmamış müşterilere yalnız Meta'nın onayladığı şablonla mesaj gönderilmesine izin verir. Bu mesajın aynısını Meta Business > WhatsApp > Mesaj şablonları bölümünde oluşturup onaylatın ve şablon adını buraya yazın (ör. gorusme_tesekkur). Boş bırakılırsa serbest metin gönderilir.",TextWrapping=TextWrapping.Wrap,Opacity=.75,Margin=new Thickness(0,0,0,6)});
  p.Children.Add(new TextBlock{Text="Şablon dili",FontWeight=FontWeights.SemiBold});p.Children.Add(dil);p.Children.Add(param);
  var kaydet=new Button{Content="Kaydet",Padding=new Thickness(18,6,18,6),HorizontalAlignment=HorizontalAlignment.Right};kaydet.SetResourceReference(BackgroundProperty,"ErpVurgu");kaydet.Foreground=Brushes.White;
  kaydet.Click+=async(_,_)=>{try{kaydet.IsEnabled=false;var yeni=new WhatsAppSablonu(s?.Id??0,ad.Text,govde.Text,meta.Text,dil.Text,param.IsChecked==true);int id=await Task.Run(()=>servis.WaSablonKaydet(yeni));w.Close();SablonlariYukle(id);}catch(Exception e){kaydet.IsEnabled=true;MessageBox.Show(w,e.Message,"Hazır mesaj");}};
  p.Children.Add(kaydet);
  w.Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};w.ShowDialog();
 }

 void Ayarlar(){
  WhatsAppAyari ayar;try{ayar=servis.WaAyar();}catch(Exception e){Hata(e);return;}
  var w=new Window{Owner=this,Title="WhatsApp Business bağlantı ayarları",Width=640,Height=640,WindowStartupLocation=WindowStartupLocation.CenterOwner};
  var p=new StackPanel{Margin=new Thickness(18)};
  p.Children.Add(new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,12),Text=
   "Otomatik gönderim için Meta'nın resmî WhatsApp Business Cloud API'si kullanılır:\n"+
   "1) business.facebook.com üzerinden işletme hesabı açın ve developers.facebook.com'da bir uygulama oluşturup WhatsApp ürününü ekleyin.\n"+
   "2) Şirket telefon numaranızı WhatsApp > API Kurulumu bölümünde ekleyip doğrulayın.\n"+
   "3) Aşağıya 'Telefon numarası kimliği (Phone number ID)' ve 'WhatsApp işletme hesabı kimliği'ni kopyalayın.\n"+
   "4) İşletme ayarları > Sistem kullanıcıları'ndan kalıcı erişim anahtarı (whatsapp_business_messaging izniyle) oluşturup girin.\n"+
   "5) Hazır mesajlarınızı Mesaj şablonları bölümünde onaylatın.\n"+
   "Anahtar sunucu bilgisayarında şifreli saklanır ve tekrar gösterilmez."});
  TextBox Alan(string etiket,string deger){p.Children.Add(new TextBlock{Text=etiket,FontWeight=FontWeights.SemiBold});var t=new TextBox{Text=deger,Margin=new Thickness(0,4,0,10)};p.Children.Add(t);return t;}
  var tel=Alan("Telefon numarası kimliği (Phone number ID)",ayar.TelefonNumarasiId);
  var waba=Alan("WhatsApp işletme hesabı kimliği (isteğe bağlı)",ayar.IsletmeHesapId);
  p.Children.Add(new TextBlock{Text="Kalıcı erişim anahtarı"+(ayar.AnahtarVar?" (kayıtlı — değiştirmek için yeni anahtarı girin)":""),FontWeight=FontWeights.SemiBold});
  var anahtar=new PasswordBox{Margin=new Thickness(0,4,0,10)};p.Children.Add(anahtar);
  var test=Alan("Test numaram (ör. 05xx xxx xx xx)",ayar.TestNumarasi);
  var kaydet=new Button{Content="Kaydet",Padding=new Thickness(18,6,18,6),HorizontalAlignment=HorizontalAlignment.Right};kaydet.SetResourceReference(BackgroundProperty,"ErpVurgu");kaydet.Foreground=Brushes.White;
  kaydet.Click+=(_,_)=>{try{servis.WaAyarKaydet(tel.Text,waba.Text,anahtar.Password,test.Text);w.Close();durum.Text="✔ WhatsApp ayarları kaydedildi. 'Kendime test gönder' ile deneyin.";}catch(Exception e){MessageBox.Show(w,e.Message,"WhatsApp ayarları");}};
  p.Children.Add(kaydet);
  w.Content=new ScrollViewer{Content=p};w.ShowDialog();
 }
}

public partial class MainWindow{
 void SahaMusteriWhatsApp_Click(object sender,RoutedEventArgs e){if(aktifKullanici is null){MessageBox.Show("Önce oturum açın.");return;}try{new SahaMusteriWhatsAppPenceresi(baglantiAdresi,aktifKullanici.KullaniciId){Owner=this}.Show();}catch(Exception ex){DestekIzleme.Bildir(ex,"SahaMusteriWhatsApp");MessageBox.Show(ex.Message,"Saha müşterileri");}}
}
