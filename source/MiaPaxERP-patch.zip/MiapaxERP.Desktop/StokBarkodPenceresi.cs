using System.Globalization;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
public sealed class StokBarkodPenceresi:Window
{
 public StokBarkodPenceresi(string connection,int user,int stock){
  Title="MiaPaxERP • Ürünün barkodları";Width=750;Height=550;WindowStartupLocation=WindowStartupLocation.CenterOwner;var service=new HizliSatisServisi(connection,user);var panel=new StackPanel{Margin=new Thickness(22)};Content=panel;panel.Children.Add(new TextBlock{Text="Aynı ürüne birden fazla barkod",FontSize=24});panel.Children.Add(new TextBlock{Text="Barkodlar ürünler arasında benzersizdir. Birim çarpanı: bir okutma ile satılacak stok birimi miktarı (ör. 1 koli = 10 adet).",TextWrapping=TextWrapping.Wrap});var grid=new DataGrid{Height=260,IsReadOnly=true,AutoGenerateColumns=true};panel.Children.Add(grid);TextBox barcode=new TextBox{MaxLength=100},factor=new TextBox{Text="1"};panel.Children.Add(new TextBlock{Text="Barkod"});panel.Children.Add(barcode);panel.Children.Add(new TextBlock{Text="Stok birimi çarpanı"});panel.Children.Add(factor);var buttons=new WrapPanel();Button save=new Button{Content="Ekle / çarpanı güncelle",Margin=new Thickness(0,10,10,0)},delete=new Button{Content="Seçili barkodu kaldır",Margin=new Thickness(0,10,10,0)};buttons.Children.Add(save);buttons.Children.Add(delete);panel.Children.Add(buttons);var status=new TextBlock{TextWrapping=TextWrapping.Wrap};panel.Children.Add(status);
  Height=650;var print=new Button{Content="Ürün barkod etiketi yazdır",Margin=new Thickness(0,10,0,0)};buttons.Children.Add(print);print.Click+=(_,_)=>new UrunEtiketPenceresi(connection,user,stock,false){Owner=this}.ShowDialog();
  async Task Refresh(){grid.ItemsSource=await Task.Run(()=>service.Barkodlar(stock));}Loaded+=async(_,_)=>{try{await Refresh();}catch(Exception e){DestekIzleme.Bildir(e,"STOK");status.Text=e.Message;}};
  save.Click+=async(_,_)=>{try{string b=barcode.Text.Trim();if(!decimal.TryParse(factor.Text,NumberStyles.Number,CultureInfo.GetCultureInfo("tr-TR"),out decimal m))throw new ArgumentException("Çarpanı sayı olarak girin.");await Task.Run(()=>service.BarkodKaydet(stock,b,m));await Refresh();status.Text="Barkod kaydedildi.";}catch(Exception e){DestekIzleme.Bildir(e,"STOK");status.Text=e.Message;}};
  delete.Click+=async(_,_)=>{try{if(grid.SelectedItem is not UrunBarkodu b)return;await Task.Run(()=>service.BarkodSil(stock,b.Barkod));await Refresh();}catch(Exception e){DestekIzleme.Bildir(e,"STOK");status.Text=e.Message;}};
 }
}
