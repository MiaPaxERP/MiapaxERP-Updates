param(
 [Parameter(Mandatory=$true)][string]$Payload,
 [Parameter(Mandatory=$true)][string]$Output,
 [string]$ISCC,
 [string]$Version='2.9.8',
 [switch]$Release
)
$ErrorActionPreference='Stop'
$Payload=(Resolve-Path -LiteralPath $Payload).Path
New-Item -ItemType Directory -Force -Path $Output | Out-Null
$Output=(Resolve-Path -LiteralPath $Output).Path
if(!$ISCC){$ISCC=Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6/ISCC.exe'}
if(!(Test-Path -LiteralPath $ISCC)){throw 'Inno Setup 6 compiler is required. Pass -ISCC with its verified executable path.'}
foreach($file in @('Masaustu/MiapaxERP.Desktop.exe','Masaustu/IlkKurulum/Sema.sql','Masaustu/IlkKurulum/Tohum.sql','Sunucu/MiapaxERP.MobileServer.exe')){
 if(!(Test-Path -LiteralPath (Join-Path $Payload $file))){throw "Missing current publish payload: $file"}
}
if($Version -notmatch '^\d+\.\d+\.\d+(\.\d+)?$'){throw 'Invalid version'}
$preview=if($Release){'0'}else{'1'}
foreach($role in @('Ana','Yan')){
 [ordered]@{ManifestUrl="https://raw.githubusercontent.com/MiaPaxERP/MiapaxERP-Updates/main/manifest-$($role.ToLowerInvariant()).json";Channel=$role;CheckMinutes=30} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $Output "guncelleme-$role.json") -Encoding utf8
 & $ISCC "/DPayload=$Payload" "/DOutput=$Output" "/DPackageVersion=$Version" "/DRole=$role" "/DPreview=$preview" "$PSScriptRoot/MiaPaxERP.iss"
 if($LASTEXITCODE -ne 0){throw "$role setup compilation failed"}
}
Get-ChildItem -LiteralPath $Output -Filter "MiaPaxERP-*-Setup-$Version*.exe" | ForEach-Object {
 $hash=Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256
 "$($hash.Hash.ToLowerInvariant())  $($_.Name)"
} | Set-Content -LiteralPath (Join-Path $Output 'SETUP-SHA256SUMS.txt') -Encoding utf8
