using System.Windows;
using System.Windows.Controls;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class BaslangicEkraniTestleri
{
 [Fact]public async Task AnaSayfaYetkisiMenudekiSatisSirasindanBagimsizdir(){await Sta(()=>{
  var sales=new Button{Name="Satis",Visibility=Visibility.Visible};var home=new Button{Name="BtnMenuAnaSayfa",Visibility=Visibility.Visible};
  Assert.Same(home,MainWindow.BaslangicHedefi([sales,home],true));
  Assert.Same(sales,MainWindow.BaslangicHedefi([home,sales],false));
  home.Visibility=Visibility.Collapsed;Assert.Same(sales,MainWindow.BaslangicHedefi([home,sales],true));
  sales.IsEnabled=false;Assert.Null(MainWindow.BaslangicHedefi([home,sales],true));
 });}
 [Fact]public async Task GercekMenuAnaSayfayiBulurVeYetkisizHesaptaAcmaz(){await Sta(()=>{
  var window=new MainWindow(true);try{var menu=(WrapPanel)window.FindName("TemaMenuOgeleri");var home=(Button)window.FindName("BtnMenuAnaSayfa");
   foreach(var b in menu.Children.OfType<Button>())b.Visibility=Visibility.Visible;
   Assert.Same(home,MainWindow.BaslangicHedefi(menu.Children.OfType<Button>(),true));
   Assert.NotSame(home,MainWindow.BaslangicHedefi(menu.Children.OfType<Button>(),false));
   foreach(var b in menu.Children.OfType<Button>())b.Visibility=Visibility.Collapsed;
   Assert.Null(MainWindow.BaslangicHedefi(menu.Children.OfType<Button>(),false));
  }finally{window.Close();}
 });}
 static async Task Sta(Action action){var done=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);var thread=new Thread(()=>{try{action();done.SetResult();}catch(Exception e){done.SetException(e);}});thread.SetApartmentState(ApartmentState.STA);thread.Start();await done.Task.WaitAsync(TimeSpan.FromSeconds(30));}
}
