// MiapaxERP Arazi Stüdyosu · saf model (DOM yok, test edilebilir).
// Koordinatlar: yerel metre (x doğu, y kuzey), başlangıç noktası = proje konumu (lat/lng).
import {calculate,normalize,PIPE_OD,MATERIALS,METHODS,ACCESSORIES} from './ai-project.mjs?v=arazi1';

export const VERSION=1;
export const R=111320;
export const r1=x=>Math.round(x*10)/10, r2=x=>Math.round(x*100)/100;

/** Çizilebilir öğe türleri. line: çoklu nokta; point: tek nokta. */
export const TYPES={
 source:{label:'Su kaynağı',icon:'💧',point:true,color:'#1e88e5'},
 main:{label:'Ana boru',icon:'━',line:true,color:'#0b5fa5',od:63},
 manifold:{label:'Dağıtım borusu',icon:'┅',line:true,color:'#1f7a4d',od:50},
 lateral:{label:'Damla / hat borusu',icon:'┄',line:true,color:'#222222',od:16},
 head:{label:'Yağmurlama başlığı',icon:'◉',point:true,color:'#f2b134'},
 fitting:{label:'Ek parça',icon:'⊤',point:true,color:'#c0392b'}
};
export const SOURCE_KINDS={well:'Kuyu (sondaj)',tank:'Depo / havuz',canal:'Kanal / gölet',network:'Şebeke'};
export const FITTINGS={
 tee:{label:'T (te)',key:'te'},elbow:{label:'Dirsek 90°',key:'dirsek'},valve:{label:'Vana',key:'vana'},
 reducer:{label:'İndirgeme (redüksiyon)',key:'redüksiyon'},cap:{label:'Kör tapa',key:'tapa'},coupling:{label:'Manşon',key:'manşon'},
 filter:{label:'Filtre',key:'filtre'},pump:{label:'Pompa',key:'pompa'},airValve:{label:'Hava tahliye vanası',key:'hava'},
 manometer:{label:'Manometre',key:'manometre'},regulator:{label:'Basınç düzenleyici',key:'regülatör'},meter:{label:'Su sayacı',key:'sayaç'},
 fertilizer:{label:'Gübre tankı',key:'gübre'},solenoid:{label:'Selenoid vana',key:'selenoid'}
};

export const uid=()=>(globalThis.crypto?.randomUUID?.()??(Date.now().toString(36)+Math.random().toString(36).slice(2)));
export function empty(){return {version:VERSION,name:'Yeni tarla',address:'',geo:null,boundary:[],items:[],crop:'',method:'drip',analysis:null,ai:null,updated:null};}

// ---- Coğrafi dönüşüm (yerel düzlem; tarla ölçeğinde hata < %0,1) ----
export function toLatLng(p,geo){const c=Math.cos(geo.lat*Math.PI/180);return {lat:geo.lat+p.y/R,lng:geo.lng+p.x/(R*c)};}
export function fromLatLng(ll,geo){const c=Math.cos(geo.lat*Math.PI/180);return {x:(ll.lng-geo.lng)*R*c,y:(ll.lat-geo.lat)*R};}
export const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
export const polyLength=pts=>pts.reduce((s,p,i)=>i?s+dist(pts[i-1],p):0,0);
export function polyArea(p){if(p.length<3)return 0;return Math.abs(p.reduce((s,a,i)=>{const b=p[(i+1)%p.length];return s+a.x*b.y-b.x*a.y;},0)/2);}
export const perimeter=p=>p.length<2?0:p.reduce((s,a,i)=>s+dist(a,p[(i+1)%p.length]),0);
export function bbox(pts){return {minX:Math.min(...pts.map(p=>p.x)),maxX:Math.max(...pts.map(p=>p.x)),minY:Math.min(...pts.map(p=>p.y)),maxY:Math.max(...pts.map(p=>p.y))};}
export function centroid(p){const b=bbox(p);return {x:(b.minX+b.maxX)/2,y:(b.minY+b.maxY)/2};}
export function inside(pt,poly){let yes=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a.y>pt.y)!==(b.y>pt.y)&&pt.x<(b.x-a.x)*(pt.y-a.y)/(b.y-a.y)+a.x)yes=!yes;}return yes;}
/** Noktanın çoklu çizgiye en kısa uzaklığı. */
export function distToLine(p,pts){let best=Infinity;for(let i=1;i<pts.length;i++){const a=pts[i-1],b=pts[i],dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy,t=l?Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l)):0;best=Math.min(best,Math.hypot(p.x-(a.x+t*dx),p.y-(a.y+t*dy)));}return best;}
/** Ölçülerle (en × boy, metre) merkezde dikdörtgen tarla. */
export const rectangle=(w,h,c={x:0,y:0})=>[{x:c.x-w/2,y:c.y-h/2},{x:c.x+w/2,y:c.y-h/2},{x:c.x+w/2,y:c.y+h/2},{x:c.x-w/2,y:c.y+h/2}];
/** Dekar → kabaca 1:2 oranlı dikdörtgen ölçüsü. */
export function sizeFromArea(m2,ratio=2){const w=Math.sqrt(m2/ratio);return {width:r1(w),length:r1(m2/w)};}

// ---- Doğrulama ----
const fin=v=>Number.isFinite(v)&&Math.abs(v)<1e6;
const cleanPt=p=>p&&fin(p.x)&&fin(p.y)?{x:p.x,y:p.y}:null;
export function clean(raw){
 const s=empty();if(!raw||typeof raw!=='object')return s;
 s.name=String(raw.name??s.name).replace(/[\u0000-\u001f<>]/g,'').slice(0,80)||s.name;
 s.address=String(raw.address??'').replace(/[\u0000-\u001f<>]/g,'').slice(0,200);
 s.crop=String(raw.crop??'').replace(/[\u0000-\u001f<>]/g,'').slice(0,60);
 s.method=METHODS[raw.method]?raw.method:'drip';
 if(raw.geo&&Number.isFinite(raw.geo.lat)&&Number.isFinite(raw.geo.lng)&&Math.abs(raw.geo.lat)<=85&&Math.abs(raw.geo.lng)<=180)s.geo={lat:raw.geo.lat,lng:raw.geo.lng};
 s.boundary=(Array.isArray(raw.boundary)?raw.boundary:[]).map(cleanPt).filter(Boolean).slice(0,500);
 s.items=(Array.isArray(raw.items)?raw.items:[]).slice(0,20000).map(i=>{
  if(!i||!TYPES[i.type])return null;const t=TYPES[i.type],o={id:typeof i.id==='string'?i.id.slice(0,64):uid(),type:i.type};
  if(t.line){o.points=(Array.isArray(i.points)?i.points:[]).map(cleanPt).filter(Boolean).slice(0,2000);if(o.points.length<2)return null;o.od=PIPE_OD.includes(Number(i.od))?Number(i.od):t.od;}
  else{o.p=cleanPt(i.p);if(!o.p)return null;}
  if(i.type==='source'){o.kind=SOURCE_KINDS[i.kind]?i.kind:'well';o.depth=Math.max(0,Math.min(500,Number(i.depth)||0));}
  if(i.type==='fitting'){o.kind=FITTINGS[i.kind]?i.kind:'tee';o.od=PIPE_OD.includes(Number(i.od))?Number(i.od):63;}
  if(i.type==='head'){o.range=Math.max(1,Math.min(60,Number(i.range)||12));o.flow=Math.max(0.05,Math.min(50,Number(i.flow)||1.2));}
  if(i.type==='lateral'){o.drip=i.drip!==false;o.emitterGap=Math.max(0.1,Math.min(5,Number(i.emitterGap)||0.33));o.emitterFlow=Math.max(0.5,Math.min(20,Number(i.emitterFlow)||2));}
  return o;}).filter(Boolean);
 s.analysis=raw.analysis&&typeof raw.analysis==='object'?raw.analysis:null;
 s.ai=typeof raw.ai==='string'?raw.ai.slice(0,4000):null;
 return s;
}

// ---- Otomatik yerleşim: tarla sınırı + su kaynağı → ana boru, dağıtım, hatlar, başlıklar ----
/** Kaynağın tarlanın hangi tarafında olduğunu bulur (calculate() için). */
export function sourceSide(src,b){const cx=(b.minX+b.maxX)/2,cy=(b.minY+b.maxY)/2,W=b.maxX-b.minX,L=b.maxY-b.minY;
 const dx=(src.x-cx)/Math.max(1,W),dy=(src.y-cy)/Math.max(1,L);
 if(Math.abs(dy)>=Math.abs(dx))return dy>=0?{side:'north',offset:Math.min(1,Math.max(0,(src.x-b.minX)/Math.max(1,W))),distance:Math.max(0,src.y-b.maxY)}:{side:'south',offset:Math.min(1,Math.max(0,(src.x-b.minX)/Math.max(1,W))),distance:Math.max(0,b.minY-src.y)};
 return dx>=0?{side:'east',offset:Math.min(1,Math.max(0,(src.y-b.minY)/Math.max(1,L))),distance:Math.max(0,src.x-b.maxX)}:{side:'west',offset:Math.min(1,Math.max(0,(src.y-b.minY)/Math.max(1,L))),distance:Math.max(0,b.minX-src.x)};}

/**
 * Hesap motorunu (calculate) tarla sınırının kapsayan dikdörtgenine uygular ve çizim öğeleri üretir.
 * Sınırın dışına düşen hat ve başlıklar kırpılır. Kullanıcının elle eklediği ek parçalar korunur.
 */
export function autoLayout(state,opts={}){
 if(state.boundary.length<3)throw Error('Önce tarla sınırını çizin.');
 const b=bbox(state.boundary),W=b.maxX-b.minX,L=b.maxY-b.minY;
 let src=state.items.find(i=>i.type==='source');
 const srcPt=src?.p??{x:b.minX+W/2,y:b.minY-20};
 const s=sourceSide(srcPt,b);
 const input=normalize({width:r1(W),length:r1(L),method:opts.method||state.method,crop:state.crop,sourceType:src?.kind||opts.sourceType||'well',sourceSide:s.side,sourceOffset:s.offset,sourceDistance:r1(s.distance),wellDepth:src?.depth||opts.wellDepth||40,
  elevation:opts.elevation??0,mainDiameter:opts.mainDiameter||0,lateralDiameter:opts.lateralDiameter,rowGap:opts.rowGap,emitterGap:opts.emitterGap,emitterFlow:opts.emitterFlow,material:opts.material,accessories:opts.accessories});
 const c=calculate(input);
 const T=p=>({x:b.minX+p.x,y:b.minY+p.y});
 const keep=state.items.filter(i=>i.type==='fitting'&&i.manual);
 const items=[];
 if(!src){src={id:uid(),type:'source',p:T(c.source),kind:input.sourceType,depth:input.wellDepth};}
 items.push(src);
 // Ana boru: kaynak → tarla kenarı → dağıtım girişi
 const route=[src.p,...c.route.slice(1).map(T)];
 items.push({id:uid(),type:'main',points:route,od:c.mainOd});
 const yM=b.minY+c.manifoldY;const xs=c.lateralRows.map(x=>b.minX+x);
 const m0=Math.max(b.minX,xs[0]-input.rowGap/2),m1=Math.min(b.maxX,xs[xs.length-1]+input.rowGap/2);
 items.push({id:uid(),type:'manifold',points:[{x:m0,y:yM},{x:m1,y:yM}],od:c.manifoldOd});
 const drip=input.method==='drip';
 const ends=c.split?[yM-c.lateralLen,yM+c.lateralLen]:[c.manifoldY===0?yM+c.lateralLen:yM-c.lateralLen];
 for(const x of xs)for(const e of ends){
  const seg=clipToPolygon({x,y:yM},{x,y:e},state.boundary);if(!seg)continue;
  items.push({id:uid(),type:'lateral',points:seg,od:input.lateralDiameter,drip,emitterGap:input.emitterGap,emitterFlow:drip?input.emitterFlow:2});
  if(!drip){const dir=Math.sign(e-yM)||1;for(let y=yM+dir*input.emitterGap/2;dir>0?y<=e:y>=e;y+=dir*input.emitterGap){const p={x,y};if(inside(p,state.boundary))items.push({id:uid(),type:'head',p,range:Math.max(4,input.emitterGap*0.75),flow:input.emitterFlow});}}
 }
 // Bölüm vanaları dağıtım hattı üzerinde
 for(let k=0;k<c.sections;k++)items.push({id:uid(),type:'fitting',kind:'valve',od:c.manifoldOd,p:{x:m0+(k+0.5)*(m1-m0)/c.sections,y:yM},auto:true});
 if(input.accessories.includes('filter'))items.push({id:uid(),type:'fitting',kind:'filter',od:c.mainOd,p:route[1]??route[0],auto:true});
 if(input.accessories.includes('pump')&&input.sourceType!=='network')items.push({id:uid(),type:'fitting',kind:'pump',od:c.mainOd,p:{x:src.p.x+3,y:src.p.y},auto:true});
 return {items:[...items,...keep],calc:c,input};
}
/** Doğru parçasını çokgenin içinde kalan en uzun aralığa kırpar (dışbükey olmayan tarlalarda yaklaşık). */
export function clipToPolygon(a,b,poly){
 const n=60;let best=null,cur=null;
 for(let i=0;i<=n;i++){const t=i/n,p={x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t},ok=inside(p,poly)||distToLine(p,[...poly,poly[0]])<0.05;
  if(ok){if(!cur)cur={s:t,e:t};else cur.e=t;}else if(cur){if(!best||cur.e-cur.s>best.e-best.s)best=cur;cur=null;}}
 if(cur&&(!best||cur.e-cur.s>best.e-best.s))best=cur;
 if(!best||best.e-best.s<1/n)return null;
 const P=t=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t});return [P(best.s),P(best.e)];
}

// ---- Malzeme listesi (çizimden) ----
const pieces=(len,unit)=>Math.max(1,Math.ceil(len/unit));
/** Çizilen öğelerden ürün bazında malzeme listesi; key stok eşleştirmesi içindir. */
export function materials(state,opt={}){
 const rows=[],add=(group,name,size,qty,unit,key,note='')=>{if(qty>0)rows.push({group,name,size,qty:unit==='m'?r1(qty):Math.ceil(qty),unit,key,note});};
 const mat=MATERIALS[opt.material]||MATERIALS.PE100,coil=opt.pieceLength||mat.coil;
 const by=(type)=>state.items.filter(i=>i.type===type);
 const sumBy=(list)=>{const m=new Map();for(const i of list){const l=polyLength(i.points);m.set(i.od,(m.get(i.od)||0)+l);}return m;};
 for(const [od,len] of sumBy(by('main')))add('Ana hat',`${mat.label} ana hat`,`Ø${od} mm`,len*1.03,'m',`${od}`,`%3 fire dahil · ${pieces(len,coil)} ${coil>=50?'kangal':'boy'} (${coil} m)`);
 for(const [od,len] of sumBy(by('manifold')))add('Dağıtım','Dağıtım borusu (manifold)',`Ø${od} mm`,len*1.03,'m',`${od}`);
 const lats=by('lateral');const dripLats=lats.filter(l=>l.drip),pipeLats=lats.filter(l=>!l.drip);
 for(const [od,len] of sumBy(dripLats))add('Hatlar','Damla borusu (lateral)',`Ø${od} mm`,len*1.02,'m',`${od}`,`${pieces(len*1.02,400)} rulo (400 m)`);
 for(const [od,len] of sumBy(pipeLats))add('Hatlar','Lateral boru',`Ø${od} mm`,len*1.02,'m',`${od}`,`${pieces(len*1.02,coil)} ${coil>=50?'kangal':'boy'}`);
 // Otomatik bağlantı parçaları
 const mains=by('main'),manifolds=by('manifold');
 let elbows=0;for(const m of mains)for(let k=1;k<m.points.length-1;k++){const a=m.points[k-1],p=m.points[k],c=m.points[k+1];const cross=Math.abs((p.x-a.x)*(c.y-p.y)-(p.y-a.y)*(c.x-p.x));if(cross>0.5)elbows++;}
 const mainOd=mains[0]?.od||manifolds[0]?.od||63,manOd=manifolds[0]?.od||mainOd;
 add('Ana hat','Dirsek 90°',`Ø${mainOd} mm`,elbows,'adet',`dirsek ${mainOd}`);
 for(const m of mains){const n=pieces(polyLength(m.points),coil)-1;add('Ana hat','Ana hat ek parçası (manşon)',`Ø${m.od} mm`,n,'adet',`manşon ${m.od}`);}
 const feeders=[...manifolds,...mains];
 const connected=lats.filter(l=>feeders.some(f=>distToLine(l.points[0],f.points)<2||distToLine(l.points[l.points.length-1],f.points)<2)).length;
 if(manifolds.length&&mains.length)add('Dağıtım','Te (ana hat → dağıtım)',`Ø${mainOd}×${manOd} mm`,manifolds.length,'adet',`te ${mainOd}`);
 if(manifolds.length)add('Dağıtım','Kör tapa (dağıtım sonu)',`Ø${manOd} mm`,manifolds.length*2,'adet',`tapa ${manOd}`);
 const latOd=lats[0]?.od||16;
 add('Hatlar',dripLats.length>=pipeLats.length?'Başlangıç bağlantısı (mini vana + conta)':'Lateral çıkış (priz kolye)',`${manOd}×${latOd} mm`,connected,'adet',`priz ${manOd}`);
 add('Hatlar','Hat sonu tapası',`Ø${latOd} mm`,lats.length,'adet',`tapa ${latOd}`);
 // Sulama elemanları
 const emitters=dripLats.reduce((s,l)=>s+Math.floor(polyLength(l.points)/l.emitterGap),0);
 if(emitters)add('Sulama elemanı',`Damlatıcı (${dripLats[0].emitterFlow} l/sa, ${Math.round(dripLats[0].emitterGap*100)} cm ara)`,'',emitters,'adet','damlatıcı','Damla borusu tümleşik ise ayrıca alınmaz');
 const heads=by('head');
 if(heads.length){add('Sulama elemanı',`Yağmurlama başlığı (${heads[0].flow} m³/sa)`,'',heads.length,'adet','yağmurlama');add('Sulama elemanı','Yükseltme borusu + adaptör','',heads.length,'adet','yükseltme');add('Sulama elemanı','Te / priz (başlık bağlantısı)',`Ø${latOd} mm`,heads.length,'adet',`te ${latOd}`);}
 // Elle ve otomatik yerleştirilen ek parçalar
 const fit=new Map();for(const f of by('fitting')){const k=f.kind+'|'+f.od;fit.set(k,(fit.get(k)||0)+1);}
 for(const [k,n] of fit){const [kind,od]=k.split('|');const F=FITTINGS[kind];const sized=!['pump','filter','manometer','fertilizer'].includes(kind);
  if(kind==='pump'){const h=hydraulics(state,opt);add('Kaynak',(by('source')[0]?.kind==='well'?'Dalgıç pompa':'Santrifüj pompa'),`${Math.ceil(h.flow)} m³/sa · ${h.head} m · ≈${h.kw} kW`,n,'adet','pompa','Pompa seçimini üretici eğrisiyle doğrulayın');}
  else add('Ek parça',F.label,sized?`Ø${od} mm`:'',n,'adet',sized?`${F.key} ${od}`:F.key);}
 const src=by('source')[0];
 if(src?.kind==='well'&&src.depth>0&&[...fit.keys()].some(k=>k.startsWith('pump|')))add('Kaynak','Pompa çıkış borusu (kuyu içi)',`Ø${mainOd} mm`,src.depth+5,'m',`${mainOd}`);
 add('Montaj','Kelepçe / boru askısı','',Math.ceil(mains.reduce((s,m)=>s+polyLength(m.points),0)/6),'adet','kelepçe');
 add('Montaj','Teflon bant','',Math.max(2,Math.ceil(by('fitting').length/4)),'adet','teflon');
 return rows;
}

/** Çizimden kaba hidrolik özet: toplam debi, basma yüksekliği ve pompa gücü. */
export function hydraulics(state,opt={}){
 const dripLats=state.items.filter(i=>i.type==='lateral'&&i.drip),heads=state.items.filter(i=>i.type==='head');
 const dripFlow=dripLats.reduce((s,l)=>s+Math.floor(polyLength(l.points)/l.emitterGap)*l.emitterFlow/1000,0);
 const headFlow=heads.reduce((s,h)=>s+h.flow,0);
 const total=dripFlow+headFlow;const valves=state.items.filter(i=>i.type==='fitting'&&i.kind==='valve').length||1;
 const flow=total/valves;const src=state.items.find(i=>i.type==='source');
 const mainLen=state.items.filter(i=>i.type==='main').reduce((s,m)=>s+polyLength(m.points),0);
 const od=state.items.find(i=>i.type==='main')?.od||63,id=od-2*od/11;
 const loss=flow<=0?0:10.67*mainLen*Math.pow(flow/3600,1.852)/(Math.pow(150,1.852)*Math.pow(id/1000,4.87));
 const pressure=heads.length>dripLats.length?30:10;
 const head=r1(pressure+loss*1.1+(src?.kind==='well'?src.depth||0:0)+(opt.elevation||0)+(state.items.some(i=>i.kind==='filter')?5:0));
 const kw=Math.max(0.37,Math.ceil(9.81*(flow/3600)*head/0.62*1.15*10)/10);
 return {flow:r2(flow),totalFlow:r2(total),sections:valves,head,kw,mainLen:r1(mainLen),velocity:flow<=0?0:r2((flow/3600)/(Math.PI*Math.pow(id/2000,2)))};
}

/** Özet sayılar (üst bilgi şeridi için). */
export function summary(state){
 const a=polyArea(state.boundary),lines=state.items.filter(i=>TYPES[i.type].line);
 return {area:r1(a),dekar:r2(a/1000),hectare:r2(a/10000),perimeter:r1(perimeter(state.boundary)),pipe:r1(lines.reduce((s,l)=>s+polyLength(l.points),0)),items:state.items.length};
}

// ---- Ürün su ihtiyacı (FAO-56 orta dönem Kc) ----
export const CROPS={
 'mısır':{kc:1.2,depth:1.0,drip:true},'domates':{kc:1.15,depth:0.7,drip:true},'biber':{kc:1.05,depth:0.6,drip:true},'pamuk':{kc:1.15,depth:1.2,drip:true},
 'buğday':{kc:1.15,depth:1.2,drip:false},'arpa':{kc:1.15,depth:1.0,drip:false},'ayçiçeği':{kc:1.1,depth:1.2,drip:true},'şeker pancarı':{kc:1.2,depth:0.9,drip:false},
 'patates':{kc:1.15,depth:0.5,drip:true},'yonca':{kc:0.95,depth:1.5,drip:false},'elma':{kc:0.95,depth:1.2,drip:true},'kiraz':{kc:0.95,depth:1.2,drip:true},
 'ceviz':{kc:1.1,depth:2.0,drip:true},'zeytin':{kc:0.7,depth:1.5,drip:true},'üzüm':{kc:0.7,depth:1.5,drip:true},'bağ':{kc:0.7,depth:1.5,drip:true},
 'çilek':{kc:0.85,depth:0.3,drip:true},'karpuz':{kc:1.0,depth:1.0,drip:true},'kavun':{kc:1.0,depth:1.0,drip:true},'fındık':{kc:1.0,depth:1.0,drip:true},
 'fıstık':{kc:1.05,depth:0.8,drip:true},'nohut':{kc:1.0,depth:0.8,drip:false},'mercimek':{kc:1.1,depth:0.7,drip:false}
};
export function crop(name){const n=String(name||'').toLocaleLowerCase('tr-TR').trim();const k=Object.keys(CROPS).find(c=>n.includes(c));return k?{name:k,...CROPS[k]}:{name:n||'genel',kc:1.0,depth:0.8,drip:true};}

/** USDA tekstür sınıfı (kum/kil/silt %). */
export function texture(sand,clay,silt){
 if(silt+1.5*clay<15)return 'Kum';if(silt+1.5*clay>=15&&silt+2*clay<30)return 'Tınlı kum';
 if((clay>=7&&clay<20&&sand>52&&silt+2*clay>=30)||(clay<7&&silt<50&&silt+2*clay>=30))return 'Kumlu tın';
 if(clay>=7&&clay<27&&silt>=28&&silt<50&&sand<=52)return 'Tın';
 if((silt>=50&&clay>=12&&clay<27)||(silt>=50&&silt<80&&clay<12))return 'Siltli tın';if(silt>=80&&clay<12)return 'Silt';
 if(clay>=20&&clay<35&&silt<28&&sand>45)return 'Kumlu killi tın';if(clay>=27&&clay<40&&sand>20&&sand<=45)return 'Killi tın';
 if(clay>=27&&clay<40&&sand<=20)return 'Siltli killi tın';if(clay>=35&&sand>45)return 'Kumlu kil';if(clay>=40&&silt>=40)return 'Siltli kil';return 'Kil';
}
/** Tekstüre göre yaklaşık infiltrasyon (mm/sa) ve kullanılabilir su (mm/m). */
export function soilWater(tex){const t=String(tex);
 if(/^Kum$|Tınlı kum/.test(t))return {infiltration:30,available:70,note:'Su tutma kapasitesi düşük; sık ve az sulama (damla) uygundur.'};
 if(/Kumlu tın|Kumlu killi/.test(t))return {infiltration:20,available:110,note:'Su geçirgenliği iyi; damla ve yağmurlama uygundur.'};
 if(/^Tın$|Siltli tın|Silt/.test(t))return {infiltration:12,available:170,note:'Su tutma dengeli; sulama aralığı uzatılabilir.'};
 if(/Killi tın/.test(t))return {infiltration:8,available:180,note:'Geçirgenlik orta-düşük; yağmurlamada düşük yağış hızlı başlık seçin.'};
 return {infiltration:5,available:200,note:'Killi toprak; göllenme riski. Yavaş uygulama (damla) ve drenaj önerilir.'};}
export function phNote(ph){if(ph<5.5)return 'Asidik — kireçleme düşünülebilir';if(ph<6.5)return 'Hafif asidik — çoğu ürün için uygun';if(ph<=7.5)return 'Nötr — çoğu ürün için ideal';if(ph<=8.4)return 'Hafif alkali — demir/çinko eksikliğine dikkat';return 'Alkali — mikro element alımı zayıflar';}
export function omNote(soc){const om=soc*1.724/10;if(om<1)return {om:r2(om),note:'Çok düşük — organik madde (gübre, yeşil gübre) takviyesi gerekli'};if(om<2)return {om:r2(om),note:'Düşük — organik madde artırılmalı'};if(om<3.5)return {om:r2(om),note:'Orta'};return {om:r2(om),note:'İyi'};}

/** Toprak ve hava verisinden sulama önerisi. et0: günlük ortalama mm, rain: günlük ortalama efektif yağış mm. */
export function irrigationAdvice({et0,rain,cropName,areaM2,texture:tex,method}){
 const c=crop(cropName),w=soilWater(tex||'Tın'),eff=method==='drip'?0.9:0.75;
 const etc=et0*c.kc,need=Math.max(0,etc-rain*0.8);const gross=need/eff;
 const daily=r1(gross*areaM2/1000);// m³/gün
 const raw=w.available*c.depth*0.5;// kolay kullanılabilir su (mm)
 const interval=need<=0?null:Math.max(1,Math.min(15,Math.floor(raw/need)));
 const dose=interval?r1(need*interval/eff):0;
 const fitDrip=c.drip;
 const text=need<=0?'Önümüzdeki dönemde yağış ürün ihtiyacını karşılıyor; sulama gerekmeyebilir.':
  `${c.name} için günlük bitki su tüketimi ≈${r1(etc)} mm. Efektif yağış düşüldükten sonra net ihtiyaç ≈${r1(need)} mm/gün, `+
  `sulama randımanı (%${Math.round(eff*100)}) ile ≈${daily} m³/gün su gerekir. Toprak (${tex||'bilinmiyor'}) için sulama aralığı ≈${interval} gün, her sulamada ≈${dose} mm uygulayın.`;
 return {crop:c.name,kc:c.kc,etc:r1(etc),need:r1(need),dailyM3:daily,interval,dose,method:method==='drip'?'Damla':'Yağmurlama',recommendDrip:fitDrip,text,infiltration:w.infiltration};
}

export {PIPE_OD,MATERIALS,METHODS,ACCESSORIES};
