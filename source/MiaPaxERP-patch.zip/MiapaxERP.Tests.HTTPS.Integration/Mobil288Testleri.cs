using MiapaxERP.Desktop;using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class Mobil288Testleri
{
 static HashSet<string> P(params string[] p)=>new(p,StringComparer.OrdinalIgnoreCase);
 [Fact]public void MasaustuYetkisiTekBasinaMobilAcmaz(){Assert.Empty(MobilDepartmanKurallari.Sec(P("STOCK.VIEW"),_=>true));Assert.Empty(MobilDepartmanKurallari.Sec(P("MOBILE.ACCESS","MOBILE.STOCK"),_=>true));}
 [Fact]public void MobilDepartmanIzinleriKendiErpYetkisiyleKesisir(){var p=P("MOBILE.ACCESS","MOBILE.STOCK","STOCK.VIEW","FINANCE.VIEW","PRODUCTION.VIEW");Assert.Equal("stok",Assert.Single(MobilDepartmanKurallari.Sec(p,_=>true)).Kod);p.Add("MOBILE.PRODUCTION");Assert.Equal(new[]{"stok","uretim"},MobilDepartmanKurallari.Sec(p,_=>true).Select(x=>x.Kod));}
 [Fact]public void MobilLisansVeIzinIptaliAnindaKapandirir(){var p=P("MOBILE.ACCESS","MOBILE.STOCK","STOCK.VIEW");Assert.Empty(MobilDepartmanKurallari.Sec(p,_=>false));p.Remove("MOBILE.ACCESS");Assert.Empty(MobilDepartmanKurallari.Sec(p,_=>true));}
 [Fact]public void MesajlasmaAyriMobilVeSohbetIzniIster(){Assert.Empty(MobilDepartmanKurallari.Sec(P("MOBILE.ACCESS","CHAT.VIEW"),_=>true));Assert.Equal("mesaj",Assert.Single(MobilDepartmanKurallari.Sec(P("MOBILE.ACCESS","MOBILE.CHAT","CHAT.VIEW"),_=>true)).Kod);}
}
