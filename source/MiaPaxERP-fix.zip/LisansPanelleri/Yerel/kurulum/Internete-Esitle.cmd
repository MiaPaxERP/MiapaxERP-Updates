@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Internete-Esitle.ps1"
