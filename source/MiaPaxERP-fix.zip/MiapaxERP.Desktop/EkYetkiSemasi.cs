using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>
/// Sonradan eklenen yetki kodları. STOCK.PRICE: stok fiyatlarını (alış, bayi, perakende, KDV) görme ve girme.
/// Depo personeli stoğu görür ama fiyatı göremez; yetki satın alma ve muhasebe rollerine atanır.
/// Yetki ilk kez oluşturulduğunda satın alma, muhasebe/finans veya satış yetkisi olan rollere bir kez otomatik verilir;
/// sonrasında yönetici rol ekranından istediği role verip alabilir.
/// </summary>
public static class EkYetkiSemasi
{
 internal const string Ddl="""
IF OBJECT_ID('dbo.Yetkiler','U') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu=N'STOCK.PRICE')
BEGIN
 INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif) VALUES(N'STOCK.PRICE',N'Stok',N'Fiyat',N'Stok alış/satış fiyatlarını ve KDV oranlarını gör ve gir',1);
 IF OBJECT_ID('dbo.RolYetkileri','U') IS NOT NULL
  INSERT dbo.RolYetkileri(RolId,YetkiId,AtamaTarihiUtc)
  SELECT DISTINCT ry.RolId,(SELECT Id FROM dbo.Yetkiler WHERE YetkiKodu=N'STOCK.PRICE'),SYSUTCDATETIME()
  FROM dbo.RolYetkileri ry JOIN dbo.Yetkiler y ON y.Id=ry.YetkiId
  WHERE y.YetkiKodu LIKE N'PURCHASE.%' OR y.YetkiKodu LIKE N'ACCOUNTING.%' OR y.YetkiKodu LIKE N'FINANCE.%' OR y.YetkiKodu LIKE N'SALES.%';
END
""";
 static readonly System.Collections.Concurrent.ConcurrentDictionary<string,bool> hazir=new(StringComparer.OrdinalIgnoreCase);
 public static void Hazirla(SqlConnection c){
  string key=c.DataSource+"|"+c.Database;if(hazir.ContainsKey(key))return;
  using var t=c.BeginTransaction();
  using(var l=new SqlCommand("EXEC sp_getapplock @Resource='MiaPaxNextSchema',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;",c,t))l.ExecuteNonQuery();
  using(var k=new SqlCommand(Ddl,c,t))k.ExecuteNonQuery();
  t.Commit();hazir[key]=true;
 }
}
