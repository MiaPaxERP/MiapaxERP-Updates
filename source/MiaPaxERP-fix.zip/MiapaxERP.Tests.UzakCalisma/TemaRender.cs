using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using MiapaxERP.Desktop;

/// <summary>
/// Tema görsel denetimi: her temada ana pencerenin ana sayfasını, birkaç ekranını ve Görünüm ayarlarını
/// SQL'e bağlanmadan çizip PNG olarak kaydeder. CI bu dosyaları yapıt olarak yükler.
/// </summary>
internal static class TemaRender
{
 static void Bekle(){var frame=new DispatcherFrame();Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle,new Action(()=>frame.Continue=false));Dispatcher.PushFrame(frame);}
 static void Kaydet(FrameworkElement v,string path){
  v.UpdateLayout();int w=(int)Math.Max(1,Math.Ceiling(v.ActualWidth)),h=(int)Math.Max(1,Math.Ceiling(v.ActualHeight));
  var bmp=new RenderTargetBitmap(w,h,96,96,PixelFormats.Pbgra32);bmp.Render(v);
  var enc=new PngBitmapEncoder();enc.Frames.Add(BitmapFrame.Create(bmp));using var s=File.Create(path);enc.Save(s);
 }
 static string Dosya(string s)=>new string(s.Select(c=>char.IsLetterOrDigit(c)?c:'_').ToArray());
 public static void Run(string output,string? tek=null)
 {
  Directory.CreateDirectory(output);
  var app=Application.Current as App??new App();app.InitializeComponent();app.ShutdownMode=ShutdownMode.OnExplicitShutdown;
  TemaPencereServisi.Baslat();
  var temalar=Tema170.Adlar.Where(t=>t!="Sistem").ToList();if(tek is not null)temalar=[tek];
  string[] sayfalar=["", "StokIcerik", "YeniStokIcerik", "UretimIcerik", "StokHareketIcerik"];
  foreach(string tema in temalar)
  {
   string ad=Dosya(tema);
   try
   {
    var w=new MainWindow(true){Width=1500,Height=940,Left=-32000,Top=0,WindowStartupLocation=WindowStartupLocation.Manual,ShowActivated=false,ShowInTaskbar=false};
    w.Show();Bekle();
    try{w.GorunumuUygula(new GorunumTercihleri{Tema=tema});}catch(Exception e){Console.WriteLine("UYARI "+tema+" GorunumuUygula: "+e.Message);}
    Bekle();Bekle();
    var hepsi=sayfalar.Where(s=>s.Length>0).Concat(["AnaSayfaArkaPlan","AnaSayfaIcerik"]).Select(n=>w.FindName(n)).OfType<FrameworkElement>().ToList();
    foreach(string sayfa in sayfalar)
    {
     foreach(var e in hepsi)e.Visibility=Visibility.Collapsed;
     if(sayfa.Length==0){foreach(var n in new[]{"AnaSayfaArkaPlan","AnaSayfaIcerik"})if(w.FindName(n) is FrameworkElement e)e.Visibility=Visibility.Visible;}
     else if(w.FindName(sayfa) is FrameworkElement hedef)hedef.Visibility=Visibility.Visible;
     Bekle();TemaOkunurlugu.Uygula(w);Bekle();
     Kaydet((FrameworkElement)w.Content,Path.Combine(output,ad+"-"+(sayfa.Length==0?"AnaSayfa":sayfa)+".png"));
    }
    w.Close();
    var klasor=Path.Combine(Path.GetTempPath(),"tema-render-"+ad);Directory.CreateDirectory(klasor);
    var g=new GorunumPenceresi(klasor,new GorunumTercihleri{Tema=tema},()=>{},_=>{}){Left=-32000,Top=0,WindowStartupLocation=WindowStartupLocation.Manual,ShowActivated=false,ShowInTaskbar=false};
    g.Show();Bekle();Bekle();TemaOkunurlugu.Uygula(g);Bekle();
    Kaydet((FrameworkElement)g.Content,Path.Combine(output,ad+"-GorunumAyarlari.png"));g.Close();
    Console.WriteLine("RENDER "+tema);
   }
   catch(Exception e){Console.WriteLine("RENDER HATASI "+tema+": "+e);}
  }
 }
}
