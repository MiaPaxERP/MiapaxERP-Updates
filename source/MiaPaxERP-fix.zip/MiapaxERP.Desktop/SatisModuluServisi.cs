using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed class SatisModuluServisi(string connection,int user)
{
 readonly ErpModulServisi access=new(connection,user);
 readonly Action<SqlConnection,SqlTransaction?,string>? fixtureCheck;
 internal SatisModuluServisi(string connection,int user,Action<SqlConnection,SqlTransaction?,string> check):this(connection,user){fixtureCheck=check;}
 void Check(SqlConnection c,SqlTransaction? t,string permission){if(fixtureCheck is null)access.Yetki(c,t,permission);else fixtureCheck(c,t,permission);}
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps)=>ErpModulServisi.Komut(c,t,sql,ps);
 public DataTable Stoklar(bool uretim,string search){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<DataTable>(connection,"SatisModuluServisi.Stoklar","",[uretim,search]);
  if(search is null||search.Length>100)throw new ArgumentException("Arama en fazla 100 karakter olmalı.");using var c=access.Ac();Check(c,null,"STOCK.VIEW");if(uretim)Check(c,null,"PRODUCTION.VIEW");
  using var q=Q(c,null,"""
  SELECT TOP(1000) s.Id,s.StokKodu,s.StokAdi,s.StokTipi,s.Birim,COALESCE(b.Miktar,0) ToplamStok,
  CASE WHEN p.Mevcut IS NULL THEN CASE WHEN COALESCE(e.Toplam,0)<=0 THEN 0 WHEN COALESCE(b.Miktar,0)<e.Toplam THEN COALESCE(b.Miktar,0) ELSE e.Toplam END ELSE p.Mevcut END UretilmisMevcut,
  CASE WHEN p.Mevcut IS NULL THEN CASE WHEN COALESCE(e.Toplam,0)<=0 THEN 0 WHEN COALESCE(b.Miktar,0)<e.Toplam THEN COALESCE(b.Miktar,0) ELSE e.Toplam END ELSE COALESCE(p.Serbest,0) END UretilmisSatilabilir,COALESCE(p.Bloke,0) UretilmisBloke,
  CASE WHEN a.Serbest IS NULL AND NOT EXISTS(SELECT 1 FROM dbo.MPX310_Lot lx WHERE lx.StokId=s.Id) THEN COALESCE(b.Miktar,0) ELSE COALESCE(a.Serbest,0) END Satilabilir,f.PerakendeSatisFiyati SatisFiyati,COALESCE(f.ParaBirimi,'TRY') ParaBirimi
  FROM dbo.StokKartlari s LEFT JOIN dbo.StokBakiyeleri b ON b.StokKartId=s.Id LEFT JOIN dbo.StokFiyatlari f ON f.StokKartId=s.Id
  OUTER APPLY(SELECT SUM(lb.Miktar) Mevcut,SUM(CASE WHEN l.Kalite=N'Serbest' THEN lb.Miktar-COALESCE(r.Miktar,0) ELSE 0 END) Serbest,SUM(CASE WHEN l.Kalite<>N'Serbest' THEN lb.Miktar ELSE 0 END) Bloke FROM dbo.MPX310_Lot l JOIN dbo.MPX310_LotBakiye lb ON lb.LotId=l.Id OUTER APPLY(SELECT SUM(Miktar) Miktar FROM dbo.MPX310_Rezervasyon WHERE LotId=l.Id AND RafId=lb.RafId AND Durum=N'Bekliyor') r WHERE l.StokId=s.Id AND l.Kaynak='Uretim') p
  OUTER APPLY(SELECT SUM(lb.Miktar-COALESCE(r.Miktar,0)) Serbest FROM dbo.MPX310_Lot l JOIN dbo.MPX310_LotBakiye lb ON lb.LotId=l.Id OUTER APPLY(SELECT SUM(Miktar) Miktar FROM dbo.MPX310_Rezervasyon WHERE LotId=l.Id AND RafId=lb.RafId AND Durum=N'Bekliyor') r WHERE l.StokId=s.Id AND l.Kalite=N'Serbest') a
  OUTER APPLY(SELECT SUM(CASE WHEN h.HareketTipi=N'URETIM_MAMUL_GIRIS' OR (h.HareketTipi=N'MANUEL_GIRIS' AND h.Aciklama LIKE N'Üretim emri #%') THEN h.Miktar WHEN h.HareketTipi=N'MANUEL_CIKIS' AND h.Aciklama LIKE N'Üretim emri #%' THEN -h.Miktar ELSE 0 END) Toplam FROM dbo.StokHareketleri h WHERE h.StokKartId=s.Id AND h.HareketTipi IN (N'URETIM_MAMUL_GIRIS',N'MANUEL_GIRIS',N'MANUEL_CIKIS')) e
  WHERE s.Aktif=1 AND (@u=0 OR EXISTS(SELECT 1 FROM dbo.MPX310_Lot l WHERE l.StokId=s.Id AND l.Kaynak='Uretim') OR e.Toplam>0) AND (@q='' OR CHARINDEX(@q,s.StokKodu)>0 OR CHARINDEX(@q,s.StokAdi)>0) ORDER BY s.StokAdi,s.Id
  """,("@u",uretim),("@q",search.Trim()));using var reader=q.ExecuteReader();var data=new DataTable();data.Load(reader);return data;
 }
 public HizliUrun[] UrunAra(string search,bool barcode){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<HizliUrun[]>(connection,"SatisModuluServisi.UrunAra","",[search,barcode]);
  if(search is null||search.Length>100)throw new ArgumentException("Arama geçersiz.");using var c=access.Ac();Check(c,null,"SALES.VIEW");Check(c,null,"STOCK.VIEW");using var q=Q(c,null,"SELECT TOP(100) s.Id,s.StokKodu,s.StokAdi,s.Birim,COALESCE(b.Carpan,1),f.PerakendeSatisFiyati,COALESCE(f.ParaBirimi,'TRY') FROM dbo.StokKartlari s LEFT JOIN dbo.MPXNext_Barkod b ON b.Stok=s.Id AND b.Barkod=@q COLLATE Latin1_General_100_BIN2 LEFT JOIN dbo.StokFiyatlari f ON f.StokKartId=s.Id WHERE s.Aktif=1 AND ((@b=1 AND(s.StokKodu=@q OR b.Barkod IS NOT NULL)) OR(@b=0 AND(CHARINDEX(@q,s.StokKodu)>0 OR CHARINDEX(@q,s.StokAdi)>0))) ORDER BY s.StokAdi,s.Id",("@q",search.Trim()),("@b",barcode));using var r=q.ExecuteReader();var rows=new List<HizliUrun>();while(r.Read())rows.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),Convert.ToDecimal(r.GetValue(4)),r.IsDBNull(5)?null:Convert.ToDecimal(r.GetValue(5)),r.GetString(6)));return rows.ToArray();
 }
 public int PerakendeCari(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<int>(connection,"SatisModuluServisi.PerakendeCari","",[]);
  using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Check(c,tx,"SALES.VIEW");Check(c,tx,"CUSTOMER.EDIT");using var q=Q(c,tx,"DECLARE @i int;SELECT @i=Id FROM dbo.CariKartlari WITH(UPDLOCK,HOLDLOCK) WHERE CariKodu=N'MPX-PERAKENDE' AND Aktif=1;IF @i IS NULL BEGIN IF EXISTS(SELECT 1 FROM dbo.CariKartlari WHERE CariKodu=N'MPX-PERAKENDE') THROW 51000,N'Perakende cari pasif; yönetici etkinleştirmelidir.',1;INSERT dbo.CariKartlari(CariKodu,Unvan,CariTipi,Aktif) VALUES(N'MPX-PERAKENDE',N'Perakende müşteri',N'Müşteri',1);SET @i=SCOPE_IDENTITY();END;SELECT @i;");int id=Convert.ToInt32(q.ExecuteScalar());tx.Commit();return id;
 }
 public long Satis(SatisGirdisi g){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<long>(connection,"SatisModuluServisi.Satis","",[g]);
  using(var c=access.Ac())Check(c,null,"SALES.VIEW");if(g.Teklif)throw new ArgumentException("Satış ekranından teklif kaydedilemez.");return(fixtureCheck is null?new IsletmeServisi(connection,user):new IsletmeServisi(connection,user,fixtureCheck)).SatisKaydet(g);
 }
 public long? Sonuc(Guid key){if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<long?>(connection,"SatisModuluServisi.Sonuc","",[key]);using var c=access.Ac();Check(c,null,"SALES.VIEW");using var q=Q(c,null,"SELECT b.Id FROM dbo.MPX310_Kayit k JOIN dbo.BoruERP_YeniBelgeler b ON b.BelgeNo=JSON_VALUE(k.Veri,'$.no') AND b.YapanKullaniciId=k.Olusturan WHERE k.Anahtar=@k AND k.Tur='Satis' AND k.Olusturan=@u",("@k",key),("@u",user));var v=q.ExecuteScalar();return v is null?null:Convert.ToInt64(v);}
}
