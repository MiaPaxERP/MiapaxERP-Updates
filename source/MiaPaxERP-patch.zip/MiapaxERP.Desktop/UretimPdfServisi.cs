using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed class UretimPdfServisi(string connection,int user)
{
 public DataTable Rapor(int order,bool packages){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<DataTable>(connection,"UretimPdfServisi.Rapor","",[order,packages]);
  var access=new ErpModulServisi(connection,user);using var c=access.Ac();access.Yetki(c,null,"PRODUCTION.VIEW");using var q=ErpModulServisi.Komut(c,null,packages?"SELECT * FROM dbo.UretimPaketlemeKayitlari WHERE UretimEmriId=@o ORDER BY Id":"SELECT u.UretimEmriNo,s.StokKodu,s.StokAdi,u.PlanlananMiktar,u.MiktarBirimi,u.UretilenMiktar,u.FireMiktari,u.Durum,u.Aciklama FROM dbo.UretimEmirleri u JOIN dbo.StokKartlari s ON s.Id=u.MamulStokId WHERE u.Id=@o",("@o",order));using var r=q.ExecuteReader();var table=new DataTable();table.Load(r);if(packages)return table;if(table.Rows.Count!=1)throw new ArgumentException("Üretim emri bulunamadı.");var report=new DataTable();report.Columns.Add("Bilgi");report.Columns.Add("Değer");foreach(DataColumn col in table.Columns)report.Rows.Add(col.ColumnName,table.Rows[0][col]);return report;
 }
}
