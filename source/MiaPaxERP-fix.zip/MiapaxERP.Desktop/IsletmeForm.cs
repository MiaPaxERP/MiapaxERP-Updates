using System.Data;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
internal sealed class IsletmeForm:Window
{
    readonly StackPanel fields=new(){Margin=new Thickness(22)};
    readonly Dictionary<string,FrameworkElement> controls=new();
    readonly Dictionary<string,DataGrid> grids=new();
    readonly Dictionary<string,object?> values=new();
    internal IsletmeForm(Window owner,string title)
    {
        Owner=owner;Title="MiaPaxERP · "+title;Width=980;Height=760;MinWidth=650;MinHeight=500;WindowStartupLocation=WindowStartupLocation.CenterOwner;
        Background=TryFindResource("ErpZemin") as System.Windows.Media.Brush??System.Windows.Media.Brushes.White;Foreground=TryFindResource("ErpMetin") as System.Windows.Media.Brush??System.Windows.Media.Brushes.Black;
        var root=new DockPanel{Background=Background};System.Windows.Documents.TextElement.SetForeground(root,Foreground);Content=root;var bar=new StackPanel{Orientation=System.Windows.Controls.Orientation.Horizontal,Margin=new Thickness(22)};DockPanel.SetDock(bar,Dock.Bottom);root.Children.Add(bar);
        var save=new Button{Content="Devam et",Padding=new Thickness(24,10,24,10),IsDefault=true};save.Click+=(_,_)=>{try{foreach(var g in grids.Values){if(!g.CommitEdit()||!g.CommitEdit(DataGridEditingUnit.Row,true))throw new ArgumentException("Kalemlerdeki hatalı alanları düzeltin.");}values.Clear();foreach(var pair in controls)values[pair.Key]=pair.Value switch{TextBox t=>t.Text.Trim(),ComboBox c=>c.SelectedValuePath.Length>0?c.SelectedValue:c.SelectedItem,DatePicker d=>d.SelectedDate?.Date,CheckBox b=>b.IsChecked==true,_=>null};Dogrula?.Invoke();DialogResult=true;}catch(Exception e){DestekIzleme.Bildir(e,"IsletmeForm");System.Windows.MessageBox.Show(this,e.Message,Title);}};bar.Children.Add(save);
        var cancel=new Button{Content="Vazgeç",Margin=new Thickness(10,0,0,0),Padding=new Thickness(24,10,24,10),IsCancel=true};bar.Children.Add(cancel);root.Children.Add(new ScrollViewer{Content=fields,VerticalScrollBarVisibility=ScrollBarVisibility.Auto});
    }
    /// <summary>"Devam et"te çalışır; hata fırlatırsa mesaj gösterilir ve form girilen bilgilerle açık kalır.</summary>
    internal Action? Dogrula{get;set;}
    internal void Note(string text)=>fields.Children.Add(new TextBlock{Text=text,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,14)});
    void Add(string key,string label,FrameworkElement control){fields.Children.Add(new TextBlock{Text=label,Margin=new Thickness(0,10,0,5),FontWeight=FontWeights.SemiBold});control.MinHeight=32;fields.Children.Add(control);controls.Add(key,control);}
    internal void Text(string key,string label,string value="",int max=400)=>Add(key,label,new TextBox{Text=value,MaxLength=max,Padding=new Thickness(8,5,8,5)});
    internal void Number(string key,string label,decimal value=0)=>Text(key,label,value.ToString(CultureInfo.CurrentCulture),40);
    internal void Date(string key,string label,DateTime? value=null)=>Add(key,label,new DatePicker{SelectedDate=value??DateTime.Today});
    internal void Check(string key,string label,bool value=false)=>Add(key,label,new CheckBox{IsChecked=value,Content=label});
    internal void Choice(string key,string label,string[] choices,string? selected=null){var c=new ComboBox{ItemsSource=choices,SelectedItem=selected??choices.FirstOrDefault()};Add(key,label,c);}
    internal void Select(string key,string label,DataTable choices,object? selected=null)
    {var c=new ComboBox{ItemsSource=choices.DefaultView,DisplayMemberPath="Ad",SelectedValuePath="Id",IsEditable=false};if(selected is not null)c.SelectedValue=selected;Add(key,label,c);}
    internal string S(string key)=>values.TryGetValue(key,out var value)?Convert.ToString(value)??"":throw new ArgumentException("Form henüz tamamlanmadı.");
    internal decimal N(string key){if(!SayiKutusu.Oku(S(key),out var n))throw new ArgumentException("Sayı girin (örn. 12,5 veya 1.250).");return n;}
    internal long L(string key){if(values.TryGetValue(key,out var value)&&value is not null)return Convert.ToInt64(value);throw new ArgumentException("Listeden seçim yapın.");}
    internal int I(string key)=>checked((int)L(key));
    internal DateTime D(string key)=>values.TryGetValue(key,out var value)&&value is DateTime d?d:throw new ArgumentException("Tarih seçin.");
    /// <summary>Tarih-saat: program dili ne olursa olsun Türkçe gün.ay.yıl biçimi kabul edilir; saat dilimi yazılmazsa bilgisayarın saat dilimi kullanılır.</summary>
    internal DateTimeOffset Time(string key)=>Zaman(S(key))??throw new ArgumentException("Tarih ve saat girin; örnek: 13.11.2026 14:30 (saat dilimi isteğe bağlı: +03:00).");
    internal static DateTimeOffset? Zaman(string text)
    {
        text=(text??"").Trim();if(text.Length==0)return null;
        var tr=CultureInfo.GetCultureInfo("tr-TR");
        string[] offsetli={"dd.MM.yyyy HH:mm zzz","d.M.yyyy HH:mm zzz","dd.MM.yyyy HH:mm:ss zzz","yyyy-MM-dd HH:mm zzz","yyyy-MM-ddTHH:mm:sszzz"};
        if(DateTimeOffset.TryParseExact(text,offsetli,CultureInfo.InvariantCulture,DateTimeStyles.AllowWhiteSpaces,out var o))return o;
        string[] yerel={"dd.MM.yyyy HH:mm","d.M.yyyy HH:mm","dd.MM.yyyy H:mm","dd.MM.yyyy HH:mm:ss","dd.MM.yyyy","yyyy-MM-dd HH:mm","yyyy-MM-dd"};
        if(DateTime.TryParseExact(text,yerel,CultureInfo.InvariantCulture,DateTimeStyles.AllowWhiteSpaces,out var d))return new DateTimeOffset(d,TimeZoneInfo.Local.GetUtcOffset(d));
        if(DateTimeOffset.TryParse(text,tr,DateTimeStyles.AssumeLocal,out o)||DateTimeOffset.TryParse(text,CultureInfo.CurrentCulture,DateTimeStyles.AssumeLocal,out o))return o;
        return null;
    }
    internal bool B(string key)=>values.TryGetValue(key,out var value)&&value is true;
    internal DataTable Lines(string key,string label,params(string Name,Type Type)[] columns)
    {
        var table=new DataTable();foreach(var x in columns)table.Columns.Add(x.Name,x.Type);var g=new DataGrid{ItemsSource=table.DefaultView,AutoGenerateColumns=false,CanUserAddRows=true,CanUserDeleteRows=true,Height=230,MinHeight=170};
        foreach(var x in columns)g.Columns.Add(new DataGridTextColumn{Header=x.Name,Binding=new System.Windows.Data.Binding(x.Name){UpdateSourceTrigger=System.Windows.Data.UpdateSourceTrigger.LostFocus}});Add(key,label,g);grids[key]=g;return table;
    }
    internal void LineChoice(string key,string column,DataTable choices)
    {
        var grid=grids[key];int index=grid.Columns.ToList().FindIndex(c=>Convert.ToString(c.Header)==column||c.SortMemberPath==column);if(index<0)throw new ArgumentException("Kalem sütunu bulunamadı.");grid.Columns[index]=new DataGridComboBoxColumn{Header=column,ItemsSource=choices.DefaultView,DisplayMemberPath="Ad",SelectedValuePath="Id",SelectedValueBinding=new System.Windows.Data.Binding(column){UpdateSourceTrigger=System.Windows.Data.UpdateSourceTrigger.PropertyChanged}};
    }
}


