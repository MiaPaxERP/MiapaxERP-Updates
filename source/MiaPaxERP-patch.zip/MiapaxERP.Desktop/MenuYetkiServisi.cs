using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed class MenuYetkiServisi(string connection,int user)
{
 readonly ErpModulServisi access=new(connection,user);
 public string[] Yetkiler(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<string[]>(connection,"MenuYetkiServisi.Yetkiler","",[]);
  if(user<1)throw new UnauthorizedAccessException();using var c=access.Ac();
  using var q=ErpModulServisi.Komut(c,null,"SELECT y.YetkiKodu FROM dbo.Yetkiler y WHERE y.Aktif=1 AND EXISTS(SELECT 1 FROM dbo.Kullanicilar k WHERE k.Id=@u AND k.Aktif=1) AND (EXISTS(SELECT 1 FROM dbo.KullaniciRolAtamalari a JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId WHERE a.KullaniciId=@u AND r.Aktif=1 AND r.RolAdi=N'Yönetici') OR EXISTS(SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri v WHERE v.KullaniciId=@u AND v.Yetkili=1 AND v.YetkiKodu=y.YetkiKodu))",("@u",user));
  using var r=q.ExecuteReader();var codes=new HashSet<string>(StringComparer.OrdinalIgnoreCase);while(r.Read())codes.Add(r.GetString(0));return codes.ToArray();
 }
 public void KrokiYetkisiniHazirla(){
  if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"MenuYetkiServisi.KrokiYetkisiniHazirla","",[]);return;}
  using var c=access.Ac();using var tx=c.BeginTransaction(System.Data.IsolationLevel.Serializable);access.Yetki(c,tx,"USERS.MANAGE");
  using var q=ErpModulServisi.Komut(c,tx,"IF NOT EXISTS(SELECT 1 FROM dbo.Yetkiler WITH(UPDLOCK,HOLDLOCK) WHERE YetkiKodu='KROKI.VIEW') INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif) VALUES('KROKI.VIEW',N'Kroki',N'Görüntüle ve tasarla',N'Parsel haritası ve sulama tasarımını aç',1)");q.ExecuteNonQuery();tx.Commit();
 }
}
public static class MenuYetkiKurallari
{
 public static bool Gorunur(string name,string? tag,IReadOnlySet<string> codes,Func<string,bool> module,string sector="BORU"){
  bool Has(string code)=>codes.Contains(code)&&(MiapaxERP.Lisans.Core.UrunKatalogu.YetkiModulu(code) is not string m||module(m));
  bool Any(params string[] keys)=>keys.Any(Has);
  if(name=="BtnMenuAnaSayfa")return true;
  if(name=="BtnMenuStokHareket")return Has("STOCK.VIEW")&&Any("STOCK.HISTORY","STOCK.RECEIVE","STOCK.ISSUE","STOCK.MINIMUM");
  if(name=="BtnMenuKroki")return module("KROKI")&&Any("KROKI.VIEW","USERS.MANAGE");
  if(name is "BtnMenuUretim" or "BtnMenuRecete")return sector=="BORU"&&Has("PRODUCTION.VIEW");
  if(name=="BtnMenuFinans")return module("FINANS")&&Any("FINANCE.VIEW","CUSTOMER.VIEW","CHECKNOTE.VIEW","HR.PAYROLL.VIEW","FINANCE.RECONCILE.VIEW","REPORT.VIEW");
  if(name=="BtnMenuVeriAraclari")return Any("STOCK.VIEW","FINANCE.VIEW","CUSTOMER.VIEW","PRODUCTION.VIEW","REPORT.VIEW");
  if(name=="BtnMenuSektorUretim")return sector!="BORU"&&Has(sector=="RESTORAN"?"RESTAURANT.VIEW":"PRODUCTION.VIEW");
  if(name is "BtnMenuLisans" or "BtnMenuMagaza" or "BtnMenuUzakCalisma" or "BtnMenuMobil")return Has("USERS.MANAGE");
  string? permission=name switch{
   "BtnMenuStok"=>"STOCK.VIEW","BtnMenuFirmaBilgileri"=>"SETTINGS.VIEW","BtnMenuKullanici"=>"USERS.MANAGE",
   "BtnMenuLaboratuvar"=>"LAB.VIEW","BtnMenuWebYonetim"=>"ECOM.VIEW","BtnMenuRestoran"=>"RESTAURANT.VIEW","BtnMenuSaha"=>"FIELD.VIEW",
   "BtnMenuAyarlar"=>"SETTINGS.VIEW","BtnMenuIk"=>"HR.VIEW",
   // These obsolete shortcuts are deliberately replaced by the current module menus.
   "BtnMenuCari" or "BtnMenuTeklifSatis" or "BtnMenuRaporlar"=>null,
   _=>tag switch{"CRM"=>"CRM.VIEW","SALES"=>"SALES.VIEW","PURCHASE"=>"PURCHASE.VIEW","TRADE"=>"TRADE.VIEW","ECOM"=>"ECOM.VIEW","Sevkiyat"=>"SHIPMENT.VIEW","BasincTest"=>"PRESSURE.VIEW","Depo"=>"WAREHOUSE.VIEW","SatinAlma"=>"PURCHASE.VIEW","Muhasebe"=>"ACCOUNTING.VIEW","Tahsilat"=>"FINANCE.VIEW","Makine"=>"PRODUCTION.CAPACITY","UretimMaliyet"=>"PRODUCTION.PLAN",_=>null}};
  return permission is not null&&Has(permission);
 }
}
