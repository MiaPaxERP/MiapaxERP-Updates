const fail=(m,s=400)=>{throw Object.assign(Error(m),{status:s});};
const guid=x=>typeof x==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x);
export async function publishAnnouncement(env,actor,b){
 if(!guid(b.id)||typeof b.title!=='string'||!b.title.trim()||b.title.length>120||/[\x00-\x1f]/.test(b.title)||typeof b.body!=='string'||!b.body.trim()||b.body.length>2000||/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(b.body))fail('Duyuru başlığı veya metni geçersiz.');
 if(b.audience!=='ALL'&&b.audience!=='CUSTOMER')fail('Tek müşteri veya tüm müşteriler seçin.');
 const customer=b.audience==='CUSTOMER'?b.customerId:null;if(b.audience==='CUSTOMER'&&!guid(customer))fail('Müşteri seçin.');
 const title=b.title.trim(),body=b.body.trim();if(new TextEncoder().encode(JSON.stringify({title,body})).length>8000)fail('Duyuru metnini kısaltın.');
 const now=new Date().toISOString();
 const match=n=>n&&n.title===title&&n.body===body&&n.audience===b.audience&&n.customer_id===customer;
 const existing=await env.DB.prepare('SELECT * FROM portal_announcements WHERE id=?').bind(b.id).first();
 if(existing){if(!match(existing))fail('İşlem kimliği farklı duyuru için kullanılamaz.',409);return {ok:true,id:existing.id,sequence:existing.seq};}
 await env.DB.batch([
  env.DB.prepare('INSERT OR IGNORE INTO portal_announcements(id,title,body,audience,customer_id,actor,created_at) SELECT ?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM customers WHERE active=1 AND (? IS NULL OR id=?))').bind(b.id,title,body,b.audience,customer,actor,now,customer,customer),
  env.DB.prepare('INSERT OR IGNORE INTO portal_announcement_recipients(announcement_id,customer_id) SELECT n.id,c.id FROM portal_announcements n JOIN customers c ON c.active=1 AND (n.audience=\'ALL\' OR c.id=n.customer_id) WHERE n.id=? AND n.title=? AND n.body=? AND n.audience=? AND COALESCE(n.customer_id,\'\')=COALESCE(?,\'\')').bind(b.id,title,body,b.audience,customer)
 ]);
 const saved=await env.DB.prepare('SELECT * FROM portal_announcements WHERE id=?').bind(b.id).first();if(!saved)fail('Hedefte etkin müşteri yok.',409);if(!match(saved))fail('İşlem kimliği farklı duyuru için kullanılamaz.',409);
 return {ok:true,id:saved.id,sequence:saved.seq};
}
export async function listAnnouncements(env){return (await env.DB.prepare('SELECT n.id,n.seq,n.title,n.body,n.audience,n.customer_id,n.created_at,c.name AS customer_name,(SELECT COUNT(*) FROM portal_announcement_recipients r WHERE r.announcement_id=n.id) AS recipient_count FROM portal_announcements n LEFT JOIN customers c ON c.id=n.customer_id ORDER BY n.seq DESC LIMIT 100').all()).results;}
export async function customerAnnouncements(env,customer,after=0){
 if(!Number.isSafeInteger(after)||after<0)fail('Duyuru imleci geçersiz.');
 const rows=(await env.DB.prepare('SELECT n.seq AS sequence,n.id,n.title,n.body,n.created_at AS createdAt FROM portal_announcements n JOIN portal_announcement_recipients r ON r.announcement_id=n.id WHERE r.customer_id=? AND n.seq>? ORDER BY n.seq LIMIT 10').bind(customer,after).all()).results;
 const result=[];for(const row of rows){if(new TextEncoder().encode(JSON.stringify([...result,row])).length>9000)break;result.push(row);}return result;
}
