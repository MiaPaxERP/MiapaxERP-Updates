using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>
/// Yanlış girilen elle stok hareketinin iptali. Hareket geçmişi silinmez: aynı miktarda ters yönlü hareket yazılır
/// (parti ve bakiye kuralları normal hareketle aynı işler), açıklamasına "İPTAL · hareket #N" eklenir. Bir hareket yalnız bir kez iptal edilir.
/// Alış girişinin iptalinde alış kaydı "[İPTAL]" ile işaretlenir ve son alış fiyatı hesabına katılmaz.
/// </summary>
public sealed partial class EskiStokServisi
{
 public static string IptalEtiketi(long hareketId)=>"İPTAL · hareket #"+hareketId.ToString(CultureInfo.InvariantCulture);

 public decimal HareketIptal(long hareketId,string gerekce){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<decimal>(connection,"EskiStokServisi.HareketIptal","",new object?[]{hareketId,gerekce});
  if(hareketId<1)throw new ArgumentException("İptal edilecek hareketi seçin.");
  gerekce=(gerekce??"").Trim();if(gerekce.Length is <3 or >300)throw new ArgumentException("İptal gerekçesini yazın (3–300 karakter).");
  using var kilit=new SqlConnection(connection);kilit.Open();
  using(var l=new SqlCommand("DECLARE @r int;EXEC @r=sp_getapplock @Resource=@k,@LockMode='Exclusive',@LockOwner='Session',@LockTimeout=15000;IF @r<0 THROW 51000,N'Hareket başka bir kullanıcı tarafından işleniyor; tekrar deneyin.',1;",kilit)){l.Parameters.Add("@k",SqlDbType.NVarChar,64).Value="MiaPaxStokIptal#"+hareketId;l.ExecuteNonQuery();}
  try{
   int stok;string yon;decimal miktar;string tip;bool alis;
   using(var k=new SqlCommand("SELECT h.StokKartId,h.Yon,h.Miktar,h.HareketTipi,CASE WHEN EXISTS(SELECT 1 FROM dbo.StokAlimKayitlari a WHERE a.StokHareketId=h.Id) THEN 1 ELSE 0 END FROM dbo.StokHareketleri h WHERE h.Id=@h",kilit)){
    k.Parameters.Add("@h",SqlDbType.BigInt).Value=hareketId;using var r=k.ExecuteReader();
    if(!r.Read())throw new InvalidOperationException("Hareket bulunamadı.");
    stok=r.GetInt32(0);yon=r.GetString(1);miktar=r.GetDecimal(2);tip=r.GetString(3);alis=r.GetInt32(4)==1;
   }
   if(tip is not ("MANUEL_GIRIS" or "MANUEL_CIKIS"))throw new InvalidOperationException("Yalnız elle girilen stok giriş/çıkışları buradan iptal edilir. Üretim, satış veya satın alma belgesinden gelen hareketi kendi ekranından düzeltin.");
   string etiket=IptalEtiketi(hareketId);
   using(var k=new SqlCommand("SELECT COUNT(*) FROM dbo.StokHareketleri WHERE StokKartId=@s AND (Aciklama=@e OR Aciklama LIKE @p ESCAPE '\\')",kilit)){
    k.Parameters.Add("@s",SqlDbType.Int).Value=stok;k.Parameters.Add("@e",SqlDbType.NVarChar,500).Value=etiket;k.Parameters.Add("@p",SqlDbType.NVarChar,500).Value=etiket.Replace("_","\\_").Replace("%","\\%")+" · %";
    if(Convert.ToInt32(k.ExecuteScalar())>0)throw new InvalidOperationException("Bu hareket daha önce iptal edilmiş.");
   }
   using(var k=new SqlCommand("SELECT COUNT(*) FROM dbo.StokHareketleri WHERE Id=@h AND Aciklama LIKE N'İPTAL · hareket #%'",kilit)){k.Parameters.Add("@h",SqlDbType.BigInt).Value=hareketId;if(Convert.ToInt32(k.ExecuteScalar())>0)throw new InvalidOperationException("İptal hareketi tekrar iptal edilemez; doğru miktarla yeni hareket girin.");}
   string ters=yon=="G"?"C":"G";
   decimal bakiye=Hareket(new(stok,ters,miktar,(etiket+" · "+gerekce)[..Math.Min(500,etiket.Length+3+gerekce.Length)],false,null,null,0,"TRY"));
   if(alis){using var a=new SqlCommand("UPDATE dbo.StokAlimKayitlari SET Aciklama=LEFT(N'[İPTAL] '+ISNULL(Aciklama,N''),500) WHERE StokHareketId=@h AND (Aciklama IS NULL OR Aciklama NOT LIKE N'\\[İPTAL\\]%' ESCAPE '\\')",kilit);a.Parameters.Add("@h",SqlDbType.BigInt).Value=hareketId;a.ExecuteNonQuery();}
   return bakiye;
  }finally{
   try{using var u=new SqlCommand("EXEC sp_releaseapplock @Resource=@k,@LockOwner='Session';",kilit);u.Parameters.Add("@k",SqlDbType.NVarChar,64).Value="MiaPaxStokIptal#"+hareketId;u.ExecuteNonQuery();}catch(SqlException){}
  }
 }
}
