using ComboBoxItem = System.Windows.Controls.ComboBoxItem;
using System.Data;
using System.Globalization;
using System.Windows;
namespace MiapaxERP.Desktop;

public partial class MainWindow
{
 /// <summary>Miktar/fiyat kutularına Türkçe sayı biçimi (1.500,25) bağlanır.</summary>
 void SayiKutulariniBagla(){
  SayiKutusu.Bagla(TxtHareketMiktar,3);
  SayiKutusu.Bagla(TxtHareketMinimum,3);
  SayiKutusu.Bagla(TxtHareketAlisFiyati,4);
  SayiKutusu.Bagla(TxtStokAcilisMiktar,3);
  SayiKutusu.Bagla(TxtGerceklesenUretim,3);
  SayiKutusu.Bagla(TxtGerceklesenFire,3);
  SayiKutusu.Bagla(TxtPlanlananMiktar,3);
  SayiKutusu.Bagla(TxtUretimHedefKg,3);
  StokFiyatPaneliniBagla();
 }

 /// <summary>Basit metin sorusu; iptalde null döner.</summary>
 internal static string? MetinSor(string soru,string baslik,string varsayilan,Window? sahip=null){
  var w=new Window{Title=baslik,Width=480,SizeToContent=SizeToContent.Height,WindowStartupLocation=sahip is null?WindowStartupLocation.CenterScreen:WindowStartupLocation.CenterOwner,Owner=sahip??Application.Current?.MainWindow,ResizeMode=ResizeMode.NoResize};
  var p=new System.Windows.Controls.StackPanel{Margin=new Thickness(16)};w.Content=p;
  p.Children.Add(new System.Windows.Controls.TextBlock{Text=soru,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,8)});
  var t=new TextBox{Text=varsayilan,MaxLength=300,Padding=new Thickness(6,4,6,4)};p.Children.Add(t);
  var bar=new System.Windows.Controls.StackPanel{Orientation=System.Windows.Controls.Orientation.Horizontal,HorizontalAlignment=System.Windows.HorizontalAlignment.Right,Margin=new Thickness(0,12,0,0)};p.Children.Add(bar);
  var ok=new Button{Content="Tamam",IsDefault=true,Padding=new Thickness(14,6,14,6),Margin=new Thickness(0,0,8,0)};var no=new Button{Content="Vazgeç",IsCancel=true,Padding=new Thickness(14,6,14,6)};bar.Children.Add(ok);bar.Children.Add(no);
  ok.Click+=(_,_)=>w.DialogResult=true;w.Loaded+=(_,_)=>{t.Focus();t.SelectAll();};
  return w.ShowDialog()==true?t.Text:null;
 }

 void StokHareketIptal_Click(object sender,RoutedEventArgs e){
  if(!StokYetkisiGerekli("STOCK.VIEW")||DemoModu)return;
  if(StokHareketGecmisiTablosu.SelectedItem is not DataRowView row||row.Row.Table.Columns.Contains("HareketId")==false||row["HareketId"] is not long id){
   MessageBox.Show("Hareket geçmişinden iptal edilecek satırı seçin.","MiapaxERP",MessageBoxButton.OK,MessageBoxImage.Information);return;
  }
  string tip=Convert.ToString(row["HareketTipi"])??"";
  if(tip is not ("MANUEL_GIRIS" or "MANUEL_CIKIS")){
   MessageBox.Show("Yalnız elle girilen stok giriş/çıkışları buradan iptal edilir. Üretim, satış ve satın alma hareketlerini kendi ekranından düzeltin.","MiapaxERP",MessageBoxButton.OK,MessageBoxImage.Information);return;
  }
  string miktar=row["Miktar"] is decimal m?m.ToString("#,0.###",CultureInfo.GetCultureInfo("tr-TR")):"";
  string gerekce=MetinSor("Hareket #"+id+" ("+row["StokKodu"]+" · "+(Convert.ToString(row["Yon"])=="G"?"giriş":"çıkış")+" "+miktar+" "+row["Birim"]+") iptal edilecek.\nAynı miktarda ters hareket yazılır, kayıt silinmez.\n\nİptal gerekçesi:","Stok hareketi iptali","Yanlış giriş");
  if(string.IsNullOrWhiteSpace(gerekce))return;
  try{
   decimal bakiye=new EskiStokServisi(baglantiAdresi,aktifKullanici!.KullaniciId).HareketIptal(id,gerekce);
   StokHareketSeciliStokuGoster();StokHareketRaporunuYukle();
   MessageBox.Show("Hareket #"+id+" iptal edildi. Güncel bakiye: "+bakiye.ToString("#,0.###",CultureInfo.GetCultureInfo("tr-TR")),"MiapaxERP",MessageBoxButton.OK,MessageBoxImage.Information);
  }catch(Exception ex){MessageBox.Show("İptal yapılamadı:\n\n"+ex.Message,"MiapaxERP",MessageBoxButton.OK,MessageBoxImage.Warning);}
 }
}

public partial class MainWindow
{
 System.Windows.Threading.DispatcherTimer? stokAramaZamanlayici;

 /// <summary>
 /// Stok kartı araması: Enter'a basınca (veya barkod okuyucu kodu tam okuyunca) bulunan ilk kart seçilir, tabloda gösterilir
 /// ve arama kutusu bir sonraki arama için kendiliğinden temizlenir.
 /// </summary>
 void StokAramaTemizlemeyiBagla(){
  TxtStokAra.KeyDown+=(_,e)=>{if(e.Key==System.Windows.Input.Key.Enter){e.Handled=true;StokAramaSonucunuSec(false);}};
  stokAramaZamanlayici=new System.Windows.Threading.DispatcherTimer{Interval=TimeSpan.FromMilliseconds(700)};
  stokAramaZamanlayici.Tick+=(_,_)=>{stokAramaZamanlayici.Stop();StokAramaSonucunuSec(true);};
  TxtStokAra.TextChanged+=(_,_)=>{stokAramaZamanlayici.Stop();if(TxtStokAra.Text.Trim().Length>=3)stokAramaZamanlayici.Start();};
 }

 void StokAramaSonucunuSec(bool yalnizTamEslesme){
  string aranan=TxtStokAra.Text.Trim();if(aranan.Length==0||StokTablosu.ItemsSource is not DataView gorunum)return;
  DataRowView? bulunan=null;
  foreach(DataRowView r in gorunum){
   string kod=Convert.ToString(r["StokKodu"])??"",ad=Convert.ToString(r["StokAdi"])??"";
   if(string.Equals(kod,aranan,StringComparison.CurrentCultureIgnoreCase)){bulunan=r;break;}
   if(!yalnizTamEslesme&&bulunan is null&&(kod.Contains(aranan,StringComparison.CurrentCultureIgnoreCase)||ad.Contains(aranan,StringComparison.CurrentCultureIgnoreCase)))bulunan=r;
  }
  if(bulunan is null)return;
  object id=bulunan["Id"];
  TxtStokAra.Clear();// filtre kalkar, tüm kartlar görünür
  foreach(DataRowView r in (DataView)StokTablosu.ItemsSource){if(Equals(r["Id"],id)){StokTablosu.SelectedItem=r;StokTablosu.ScrollIntoView(r);break;}}
  TxtStokAra.Focus();
 }
}

public partial class MainWindow
{
 static readonly decimal[] stokKdvOranlari=[0m,1m,10m,20m];
 bool StokFiyatYetkisi=>!DemoModu&&StokArayuzYetkisiVar("STOCK.VIEW")&&StokArayuzYetkisiVar("STOCK.PRICE");

 /// <summary>Stok kartı formu açılınca fiyat bölümü yalnız fiyat yetkisi olanlara gösterilir ve kayıtlı fiyat yüklenir.</summary>
 void StokFiyatPaneliniBagla(){
  SayiKutusu.Bagla(TxtStokAlisFiyat,4);SayiKutusu.Bagla(TxtStokSatisFiyat,4);SayiKutusu.Bagla(TxtStokBayiFiyat,4);
  YeniStokIcerik.IsVisibleChanged+=async(_,e)=>{
   if(e.NewValue is not true)return;
   TxtStokAlisFiyat.Clear();TxtStokSatisFiyat.Clear();TxtStokBayiFiyat.Clear();CmbStokAlisKdv.SelectedIndex=0;CmbStokSatisKdv.SelectedIndex=1;CmbStokKdvOrani.SelectedIndex=3;CmbStokFiyatPara.SelectedIndex=0;
   PnlStokFiyat.Visibility=StokFiyatYetkisi?Visibility.Visible:Visibility.Collapsed;
   if(PnlStokFiyat.Visibility!=Visibility.Visible||duzenlenenStokId is not int id)return;
   try{
    var f=await Task.Run(()=>new StokFiyatKdvServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Fiyat(id));
    if(f is null||duzenlenenStokId!=id)return;
    TxtStokAlisFiyat.Text=f.Alis is decimal a?SayiKutusu.Yaz(a,4):"";TxtStokSatisFiyat.Text=f.Perakende is decimal p?SayiKutusu.Yaz(p,4):"";TxtStokBayiFiyat.Text=f.Bayi is decimal b?SayiKutusu.Yaz(b,4):"";
    CmbStokAlisKdv.SelectedIndex=f.AlisKdvDahil?1:0;CmbStokSatisKdv.SelectedIndex=f.SatisKdvDahil?1:0;
    int k=Array.IndexOf(stokKdvOranlari,f.KdvOrani);CmbStokKdvOrani.SelectedIndex=k<0?3:k;
    CmbStokFiyatPara.SelectedIndex=f.ParaBirimi switch{"USD"=>1,"EUR"=>2,_=>0};
   }catch(Exception ex){DestekIzleme.Bildir(ex,"StokFiyat");}
  };
 }

 void StokFiyatiniKaydet(string stokKodu){
  if(!StokFiyatYetkisi||PnlStokFiyat.Visibility!=Visibility.Visible)return;
  decimal? Oku(TextBox t){if(string.IsNullOrWhiteSpace(t.Text))return null;if(!SayiKutusu.Oku(t.Text,out var d)||d<0)throw new ArgumentException("Fiyat alanında geçersiz sayı: "+t.Text);return decimal.Round(d,4);}
  try{
   decimal? alis=Oku(TxtStokAlisFiyat),satis=Oku(TxtStokSatisFiyat),bayi=Oku(TxtStokBayiFiyat);
   int id=duzenlenenStokId??new StokBilesenServisi(baglantiAdresi,aktifKullanici!.KullaniciId).IdBul(stokKodu);
   bool kayitliVar=duzenlenenStokId.HasValue&&new StokFiyatKdvServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Fiyat(id) is not null;
   if(alis is null&&satis is null&&bayi is null&&!kayitliVar)return;
   string para=(CmbStokFiyatPara.SelectedItem as ComboBoxItem)?.Content?.ToString()??"TRY";
   new StokFiyatKdvServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Kaydet([new StokFiyatGirdisi(id,alis,CmbStokAlisKdv.SelectedIndex==1,bayi,satis,CmbStokSatisKdv.SelectedIndex==1,stokKdvOranlari[Math.Clamp(CmbStokKdvOrani.SelectedIndex,0,3)],para)]);
  }catch(Exception ex){MessageBox.Show("Stok kartı kaydedildi ancak fiyat kaydedilemedi:\n\n"+ex.Message,"MiapaxERP",MessageBoxButton.OK,MessageBoxImage.Warning);}
 }
}
