using System.Net;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public static class MobilApi220
{
 public static WebApplication Olustur(string connection,int port=5188,Action<WebApplicationBuilder>? configure=null,Action<KestrelServerOptions>? listen=null,Func<bool>? active=null){
  var b=WebApplication.CreateSlimBuilder(new WebApplicationOptions{Args=[]});b.Logging.ClearProviders();
  b.WebHost.UseKestrel(o=>{if(listen is null)o.Listen(IPAddress.Loopback,port);else listen(o);o.Limits.MaxRequestBodySize=64L*1024*1024;o.Limits.MaxConcurrentConnections=32;o.AddServerHeader=false;});
  configure?.Invoke(b);var app=b.Build();var accounts=new MobilHesapServisi(connection);var limit=new SemaphoreSlim(4);
  app.Use(async(ctx,next)=>{
   ctx.Response.Headers.CacheControl="no-store, private";ctx.Response.Headers["X-Content-Type-Options"]="nosniff";
   if(ctx.Request.Path==HttpsApi.Kok+"/events"){if(active?.Invoke()==false){ctx.Response.StatusCode=503;return;}await next(ctx);return;}
   if(!await limit.WaitAsync(0,ctx.RequestAborted)){ctx.Response.StatusCode=429;ctx.Response.Headers.RetryAfter="5";return;}
   try{if(ctx.Request.Path.StartsWithSegments("/api/mobile/v2")){var body=ctx.Features.Get<Microsoft.AspNetCore.Http.Features.IHttpMaxRequestBodySizeFeature>();if(body is not null&&!body.IsReadOnly)body.MaxRequestBodySize=32768;}if(active?.Invoke()==false){ctx.Response.StatusCode=503;return;}
    if(ctx.Request.Path.StartsWithSegments("/api/mobile/v2")&&!(HttpMethods.IsGet(ctx.Request.Method)&&ctx.Request.Path=="/api/mobile/v2/health"))LisansOturumu.Gerekli("MOBIL");await next(ctx);}
   catch(UnauthorizedAccessException e){ctx.Response.StatusCode=403;string m=e.Message;await ctx.Response.WriteAsJsonAsync(new{mesaj=string.IsNullOrWhiteSpace(m)||m.StartsWith("Attempted to perform",StringComparison.Ordinal)?"Hesap, cihaz, lisans veya modül erişimi kapalı.":m});}
   catch(ArgumentException){ctx.Response.StatusCode=400;await ctx.Response.WriteAsJsonAsync(new{mesaj="Bilgileri kontrol edin."});}
   catch(JsonException){ctx.Response.StatusCode=400;}
   catch(KeyNotFoundException){ctx.Response.StatusCode=400;}
   catch(InvalidOperationException e){ctx.Response.StatusCode=409;await ctx.Response.WriteAsJsonAsync(new{mesaj=e.Message});}
   catch(SqlException e)when(e.Number is 2601 or 2627){ctx.Response.StatusCode=409;await ctx.Response.WriteAsJsonAsync(new{mesaj="Kayıt zaten var. Yenileyerek kontrol edin."});}
   catch(SqlException){ctx.Response.StatusCode=503;await ctx.Response.WriteAsJsonAsync(new{mesaj="Fabrika veritabanına ulaşılamadı veya modül kurulmamış."});}
   finally{limit.Release();}
  });
  HttpsApi.Kur(app,connection);
  // Yalnız yerel kurulum aracı kullanır; HTTPS vekili bu yolu yayımlamaz.
  app.MapGet("/internal/ready",(HttpContext ctx)=>{
   if(ctx.Connection.RemoteIpAddress is null||!IPAddress.IsLoopback(ctx.Connection.RemoteIpAddress))return Results.NotFound();
   if(LisansOturumu.Zorunlu&&LisansOturumu.Gecerli is null)return Results.StatusCode(503);
   using var con=new SqlConnection(connection);con.Open();using var q=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.Kullanicilar','U') IS NOT NULL AND OBJECT_ID('dbo.KullaniciRolAtamalari','U') IS NOT NULL AND OBJECT_ID('dbo.KullaniciRolleri','U') IS NOT NULL THEN 1 ELSE 0 END",con);
   return Convert.ToInt32(q.ExecuteScalar())==1?Results.Json(new{ready=true}):Results.StatusCode(503);
  });
  MobilKimlik Auth(HttpContext c){string header=c.Request.Headers.Authorization.ToString();if(!header.StartsWith("Bearer ",StringComparison.Ordinal))throw new UnauthorizedAccessException();var k=accounts.Dogrula(header[7..]);using(var db=new SqlConnection(connection)){db.Open();IsbirligiSemasi.Hazirla(db);}if(!new MenuYetkiServisi(connection,k.Kullanici).Yetkiler().Contains("MOBILE.ACCESS"))throw new UnauthorizedAccessException();return k;}
  app.MapGet("/api/mobile/v2/health",()=>Results.Json(new{service="MiapaxERP.MobileServer",api=2}));
  app.MapPost("/api/mobile/v2/login",async(HttpContext c)=>{var d=await c.Request.ReadFromJsonAsync<JsonElement>();string k=d.GetProperty("user").GetString()??"",p=d.GetProperty("password").GetString()??"",n=d.GetProperty("name").GetString()??"Telefon";if(k.Length>60||p.Length>512||n.Length>80)throw new UnauthorizedAccessException("Kullanıcı adı veya şifre hatalı.");return Results.Json(accounts.GirisIleBagla(k,p,n));});
  app.MapPost("/api/mobile/v2/pair",async(HttpContext c)=>{var d=await c.Request.ReadFromJsonAsync<JsonElement>();return Results.Json(accounts.Bagla(d.GetProperty("code").GetString()!,d.GetProperty("name").GetString()!));});
  app.MapGet("/api/mobile/v2/profile",(HttpContext c)=>{var k=Auth(c);return Results.Json(new MobilDepartmanServisi(connection,k).Profil());});
  app.MapPost("/api/mobile/v2/rpc",async(HttpContext c)=>{
   var k=Auth(c);var d=await c.Request.ReadFromJsonAsync<JsonElement>();var s=new SahaServisi(connection,k.Kullanici,k);string? action=d.GetProperty("action").GetString();object result;var dept=new MobilDepartmanServisi(connection,k);
   if(action is "list" or "counts" or "province" or "load" or "save")dept.Gerekli("saha");
   if(action=="list")result=s.Liste(d.GetProperty("il").GetString()!,d.GetProperty("ilce").GetString()!,d.GetProperty("koy").GetString()!);
   else if(action=="counts")result=s.IlSayilari();
   else if(action=="province")result=s.IlGorusmeleri(d.GetProperty("il").GetString()!,d.GetProperty("ilce").GetString(),d.GetProperty("search").GetString(),d.GetProperty("offset").GetInt32());
   else if(action=="load")result=s.Oku(d.GetProperty("id").GetGuid());
   else if(action=="save")result=new{version=s.Kaydet(d.GetProperty("data").Deserialize<SahaMusterisi>(SahaServisi.Json)!,d.GetProperty("version").ValueKind==JsonValueKind.Null?null:d.GetProperty("version").GetString(),d.GetProperty("visitId").GetGuid(),d.GetProperty("visitDate").GetDateTimeOffset(),d.GetProperty("visit").GetString()!,d.GetProperty("operation").GetGuid())};
   else if(action=="report"){dept.Gerekli(d.GetProperty("section").GetString()!);result=MobilRaporOku.Oku(connection,k.Kullanici,d.GetProperty("section").GetString()!,c.RequestAborted);}
   else if(action=="barcode")result=dept.Barkod(d.GetProperty("barcode").GetString()!);
   else if(action=="stockTypes")result=dept.StokTipleri();
   else if(action=="stockFields")result=dept.StokAlanlari(d.GetProperty("type").GetInt32());
   else if(action=="createStock")result=dept.YeniStok(d.GetProperty("barcode").GetString()!,d.GetProperty("name").GetString()!,d.GetProperty("type").GetInt32(),d.GetProperty("unit").GetString()!,d.GetProperty("description").GetString()!,d.TryGetProperty("fields",out var fields)?fields.Deserialize<Dictionary<int,string>>()??[]:[]);
   else if(action=="notices")result=new IsbirligiServisi(connection,k.Kullanici).Bildirimler();
   else if(action=="noticesRead"){new IsbirligiServisi(connection,k.Kullanici).Okundu(d.GetProperty("ids").EnumerateArray().Select(x=>x.GetInt64()).Take(100).ToArray());result=new{ok=true};}
   else if(action=="calendar")result=new YardimciEkranServisi(connection,k.Kullanici).TakvimMobil();
   else if(action=="calendarAdd"){new YardimciEkranServisi(connection,k.Kullanici).TakvimEkle(d.GetProperty("title").GetString()!,d.GetProperty("note").GetString()??"","Mobil",d.GetProperty("date").GetDateTime());result=new{ok=true};}
   else if(action=="calendarDone"){new YardimciEkranServisi(connection,k.Kullanici).TakvimDurum(d.GetProperty("id").GetInt32(),"Tamamlandı");result=new{ok=true};}
   else if(action=="chatTargets"){dept.Gerekli("mesaj");result=new IsbirligiServisi(connection,k.Kullanici).Secimler();}
   else if(action=="messages"){dept.Gerekli("mesaj");result=new IsbirligiServisi(connection,k.Kullanici).Mesajlar(d.TryGetProperty("user",out var to)&&to.ValueKind==JsonValueKind.Number?to.GetInt32():null,d.TryGetProperty("department",out var dep)&&dep.ValueKind==JsonValueKind.Number?dep.GetInt32():null,0);}
   else if(action=="sendMessage"){dept.Gerekli("mesaj");result=new IsbirligiServisi(connection,k.Kullanici).MesajGonder(new(d.GetProperty("id").GetGuid(),d.TryGetProperty("user",out var to)&&to.ValueKind==JsonValueKind.Number?to.GetInt32():null,d.TryGetProperty("department",out var dep)&&dep.ValueKind==JsonValueKind.Number?dep.GetInt32():null,d.GetProperty("text").GetString()!));}
   else throw new ArgumentException();return Results.Json(result,SahaServisi.Json);
  });return app;
 }
}
