using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.IO;
using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class IsbirligiNextSqlTestleri
{
 sealed class Accounts:IHttpsHesapDeposu{public bool Active=true;public HttpsDogrulanmisHesap Giris(HttpsGiris input)=>input.Kullanici=="test"&&input.Parola=="TEST-ONLY"?new(new(3,"test","Test Stok","Çalışan"),"stamp"):throw new UnauthorizedAccessException();public bool Gecerli(int id,string stamp)=>Active&&id==3&&stamp=="stamp";}
 static void Sql(SqlConnection c,string sql){using var q=new SqlCommand(sql,c);q.ExecuteNonQuery();}
 [Fact]public async Task DuyuruVeMesajSadeceYetkiliAliciyaGiderBarkodlarTekUrunIcindedir(){
  string name="MiapaxNext_"+Guid.NewGuid().ToString("N");using var master=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=5");master.Open();Sql(master,"CREATE DATABASE ["+name+"]");
  try{string cs=new SqlConnectionStringBuilder(master.ConnectionString){InitialCatalog=name}.ConnectionString;using var c=new SqlConnection(cs);c.Open();Sql(c,"""
   CREATE TABLE dbo.Kullanicilar(Id int PRIMARY KEY,Aktif bit,AdSoyad nvarchar(100),KullaniciAdi nvarchar(50));INSERT dbo.Kullanicilar VALUES(1,1,'Admin','admin'),(2,1,'Muhasebe','muhasebe'),(3,1,'Stok','stok'),(4,1,'Uretim','uretim'),(5,0,'Pasif','pasif');
   CREATE TABLE dbo.KullaniciRolleri(Id int PRIMARY KEY,RolAdi nvarchar(80),Aktif bit);INSERT dbo.KullaniciRolleri VALUES(1,N'Yönetici',1);
   CREATE TABLE dbo.KullaniciRolAtamalari(KullaniciId int,RolId int);INSERT dbo.KullaniciRolAtamalari VALUES(1,1);
   CREATE TABLE dbo.Yetkiler(YetkiKodu varchar(80),Modul nvarchar(100),Islem nvarchar(100),Aciklama nvarchar(200),Aktif bit);INSERT dbo.Yetkiler VALUES('USERS.MANAGE','','','',1),('STOCK.VIEW','','','',1),('STOCK.EDIT','','','',1),('SALES.VIEW','','','',1);
   CREATE TABLE dbo.TestYetki(KullaniciId int,YetkiKodu varchar(80),Yetkili bit);INSERT dbo.TestYetki VALUES(2,'NOTIFICATION.PUBLISH',1),(2,'CHAT.VIEW',1),(2,'CHAT.SEND',1),(3,'CHAT.VIEW',1),(3,'CHAT.SEND',1),(4,'CHAT.VIEW',1),(4,'CHAT.SEND',1),(3,'STOCK.VIEW',1),(3,'STOCK.EDIT',1),(3,'QUICKSALE.VIEW',1),(3,'SALES.VIEW',1);
   CREATE TABLE dbo.StokKartlari(Id int PRIMARY KEY,StokKodu nvarchar(50),StokAdi nvarchar(200),Birim nvarchar(20),Aktif bit);INSERT dbo.StokKartlari VALUES(1,'PIPE',N'Boru','Adet',1),(2,'CAP',N'Kör tapa','Adet',1);
   CREATE TABLE dbo.StokFiyatlari(StokKartId int,PerakendeSatisFiyati decimal(18,2),ParaBirimi varchar(3));INSERT dbo.StokFiyatlari VALUES(1,100,'TRY'),(2,10,'TRY');
   """);Sql(c,"CREATE VIEW dbo.vw_KullaniciEtkinYetkileri AS SELECT * FROM dbo.TestYetki");
   Assert.Throws<UnauthorizedAccessException>(()=>new IsbirligiServisi(cs,5).Secimler());Assert.Equal(0,Convert.ToInt32(new SqlCommand("SELECT COUNT(*) FROM sys.tables WHERE name LIKE 'MPXNext_%'",c).ExecuteScalar()));
   var initialChoices=await Task.WhenAll(Task.Run(()=>new IsbirligiServisi(cs,3).Secimler()),Task.Run(()=>new IsbirligiServisi(cs,4).Secimler()));Assert.All(initialChoices,x=>Assert.True(x.Mesaj));Assert.Empty(new IsbirligiServisi(cs,3).Bildirimler());Assert.DoesNotContain("USERS.MANAGE",new MenuYetkiServisi(cs,3).Yetkiler());
   var admin=new IsbirligiServisi(cs,1);admin.Hazirla();admin.Hazirla();admin.DepartmanKaydet("Üretim",[3,4]);var pub=new IsbirligiServisi(cs,2);int dep=Assert.Single(pub.Secimler().Departmanlar).Id;Assert.False(Assert.Single(pub.Secimler().Departmanlar).Uye);Assert.True(Assert.Single(new IsbirligiServisi(cs,3).Secimler().Departmanlar).Uye);
   var g=new DuyuruGirdisi(Guid.NewGuid(),"TEST duyuru","TEST yalnız üretim",dep,null);long id=pub.Yayinla(g);Assert.Equal(id,pub.Yayinla(g));Assert.Single(new IsbirligiServisi(cs,3).Bildirimler());Assert.Single(new IsbirligiServisi(cs,4).Bildirimler());Assert.Empty(pub.Bildirimler());Assert.Throws<UnauthorizedAccessException>(()=>new IsbirligiServisi(cs,3).Yayinla(g with{Anahtar=Guid.NewGuid()}));Assert.Throws<InvalidOperationException>(()=>pub.Yayinla(g with{Metin="Başka içerik"}));
   new IsbirligiServisi(cs,4).Okundu([id]);Assert.False(Assert.Single(new IsbirligiServisi(cs,3).Bildirimler()).Okundu);Assert.True(Assert.Single(new IsbirligiServisi(cs,4).Bildirimler()).Okundu);
   var dm=new MesajGirdisi(Guid.NewGuid(),4,null,"TEST özel mesaj");long message=new IsbirligiServisi(cs,3).MesajGonder(dm);Assert.Equal(message,new IsbirligiServisi(cs,3).MesajGonder(dm));Assert.Single(new IsbirligiServisi(cs,4).Mesajlar(3,null,0));Assert.Empty(pub.Mesajlar(4,null,0));Assert.Throws<InvalidOperationException>(()=>new IsbirligiServisi(cs,3).MesajGonder(dm with{Metin="Başka mesaj"}));
   new IsbirligiServisi(cs,3).MesajGonder(new(Guid.NewGuid(),null,dep,"TEST departman mesajı"));Assert.Single(new IsbirligiServisi(cs,4).Mesajlar(null,dep,0));Assert.Throws<UnauthorizedAccessException>(()=>pub.Mesajlar(null,dep,0));
   Sql(c,"DELETE dbo.MPXNext_DepartmanUye WHERE Kullanici=4");Assert.Throws<UnauthorizedAccessException>(()=>new IsbirligiServisi(cs,4).Mesajlar(null,dep,0));Sql(c,"UPDATE dbo.Kullanicilar SET Aktif=0 WHERE Id=3");Assert.Throws<UnauthorizedAccessException>(()=>new IsbirligiServisi(cs,3).Mesajlar(4,null,0));Sql(c,"UPDATE dbo.Kullanicilar SET Aktif=1 WHERE Id=3");
   void Permission(SqlConnection _,SqlTransaction? __,string code){if(!new MenuYetkiServisi(cs,3).Yetkiler().Contains(code))throw new UnauthorizedAccessException();}
   var stock=new HizliSatisServisi(cs,3,Permission);stock.BarkodKaydet(1,"0000123",1);stock.BarkodKaydet(1,"0000456",5);Assert.Equal(2,stock.Barkodlar(1).Length);Assert.Throws<InvalidOperationException>(()=>stock.BarkodKaydet(2,"0000123",1));Assert.Equal(5,Assert.Single(stock.UrunAra("0000456",true)).Carpan);Assert.Equal(1,Assert.Single(stock.UrunAra("0000123",true)).Id);stock.BarkodSil(1,"0000123");Assert.Empty(stock.UrunAra("0000123",true));
   // Exercise the real authenticated HTTP long-poll and RPC, with identities provided by the server.
   var builder=WebApplication.CreateSlimBuilder();builder.Logging.ClearProviders();builder.WebHost.UseKestrel(o=>o.Listen(IPAddress.Loopback,0));await using var app=builder.Build();var accounts=new Accounts();HttpsApi.Kur(app,cs,accounts,()=>true);await app.StartAsync();try{
    var address=app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.Single();using var http=new HttpClient{BaseAddress=new Uri(address),Timeout=TimeSpan.FromSeconds(25)};
    Assert.Equal(System.Net.HttpStatusCode.Unauthorized,(await http.GetAsync(HttpsApi.Kok+"/events")).StatusCode);
    var login=await http.PostAsJsonAsync(HttpsApi.Kok+"/login",new HttpsGiris("test","TEST-ONLY"),HttpsJson.Ayarlar);var session=await login.Content.ReadFromJsonAsync<HttpsGirisYaniti>(HttpsJson.Ayarlar);http.DefaultRequestHeaders.Authorization=new("Bearer",session!.Token);
    var initial=JsonDocument.Parse(await http.GetStringAsync(HttpsApi.Kok+"/events"));string cursor=initial.RootElement.GetProperty("cursor").GetString()!;var waiting=http.GetStringAsync(HttpsApi.Kok+"/events?cursor="+Uri.EscapeDataString(cursor));
    var payload=new MesajGirdisi(Guid.NewGuid(),4,null,"TEST anlık HTTP mesaj");var call=new HttpsCagri("IsbirligiServisi.MesajGonder","",[JsonSerializer.SerializeToElement(payload,HttpsJson.Ayarlar)]);var sent=await http.PostAsJsonAsync(HttpsApi.Kok+"/rpc",call,HttpsJson.Ayarlar);Assert.True(sent.IsSuccessStatusCode);
    string changed=await waiting.WaitAsync(TimeSpan.FromSeconds(5));Assert.NotEqual(cursor,JsonDocument.Parse(changed).RootElement.GetProperty("cursor").GetString());Assert.DoesNotContain("TEST anlık HTTP mesaj",changed);Assert.Contains(new IsbirligiServisi(cs,4).Mesajlar(3,null,0),x=>x.Metin==payload.Metin&&x.Gonderen==3);
    var forbidden=new HttpsCagri("IsbirligiServisi.Yayinla","",[JsonSerializer.SerializeToElement(g with{Anahtar=Guid.NewGuid()},HttpsJson.Ayarlar)]);Assert.Equal(HttpStatusCode.Unauthorized,(await http.PostAsJsonAsync(HttpsApi.Kok+"/rpc",forbidden,HttpsJson.Ayarlar)).StatusCode);accounts.Active=false;Assert.Equal(HttpStatusCode.Unauthorized,(await http.GetAsync(HttpsApi.Kok+"/events")).StatusCode);
   }finally{await app.StopAsync();}
   Sql(c,"CREATE TABLE dbo.UretimEmirleri(Id int PRIMARY KEY,MamulStokId int,UretimEmriNo nvarchar(80),Durum nvarchar(30));INSERT dbo.UretimEmirleri VALUES(1,1,'TEST-UE-1',N'Tamamlandı');CREATE TABLE dbo.UretimPaketlemeKayitlari(Id int PRIMARY KEY,UretimEmriId int,PaketIciAdet int,PaketSayisi int);INSERT dbo.UretimPaketlemeKayitlari VALUES(123,1,10,30);INSERT dbo.TestYetki VALUES(3,'PRODUCTION.VIEW',1)");
   Sql(c,"INSERT dbo.Yetkiler VALUES('PRODUCTION.VIEW','','','',1)");var labels=new UrunEtiketServisi(cs,3,Permission);var batch=Assert.Single(labels.Bilgiler(1,true));Assert.Equal(10,batch.PaketIciAdet);Assert.Equal(30,batch.PaketSayisi);Assert.Equal(123,batch.PaketId);Assert.Equal(10,Assert.Single(stock.UrunAra(UrunEtiketServisi.PaketBarkodu(123,2),true)).Carpan);Assert.Empty(stock.UrunAra(UrunEtiketServisi.PaketBarkodu(123,31),true));
   Sql(c,"UPDATE dbo.UretimEmirleri SET Durum=N'İptal'");Assert.Empty(labels.Bilgiler(1,true));Assert.Empty(stock.UrunAra(UrunEtiketServisi.PaketBarkodu(123,1),true));Sql(c,"UPDATE dbo.TestYetki SET Yetkili=0 WHERE KullaniciId=3 AND YetkiKodu='PRODUCTION.VIEW'");Assert.Throws<UnauthorizedAccessException>(()=>labels.Bilgiler(1,true));
   Sql(c,"UPDATE dbo.TestYetki SET Yetkili=0 WHERE KullaniciId=3 AND YetkiKodu='STOCK.EDIT'");Assert.Throws<UnauthorizedAccessException>(()=>stock.BarkodKaydet(1,"999",1));

   Sql(c,"CREATE TABLE dbo.StokBakiyeleri(StokKartId int PRIMARY KEY,Miktar decimal(18,3));INSERT dbo.StokBakiyeleri VALUES(1,25),(2,10);INSERT dbo.TestYetki VALUES(3,'MOBILE.ACCESS',1),(3,'MOBILE.STOCK',1)");
   var mobile=new MobilDepartmanServisi(cs,new(Guid.NewGuid(),3,"TEST Stok","SAHA","TEST"),()=>new MenuYetkiServisi(cs,3).Yetkiler(),Permission);Assert.Equal("stok",Assert.Single(mobile.Bolumler()).Kod);
   using(var found=JsonDocument.Parse(JsonSerializer.Serialize(mobile.Barkod("0000456")))){Assert.True(found.RootElement.GetProperty("found").GetBoolean());Assert.Equal(25,found.RootElement.GetProperty("balance").GetDecimal());}
   using(var absent=JsonDocument.Parse(JsonSerializer.Serialize(mobile.Barkod("NOT-REGISTERED")))){Assert.False(absent.RootElement.GetProperty("found").GetBoolean());Assert.False(absent.RootElement.GetProperty("canCreate").GetBoolean());}
   Sql(c,"UPDATE dbo.TestYetki SET Yetkili=0 WHERE KullaniciId=3 AND YetkiKodu='MOBILE.STOCK'");Assert.Empty(mobile.Bolumler());Assert.Throws<UnauthorizedAccessException>(()=>mobile.Barkod("0000456"));
   // License-provider announcements are verified before import; each user gets an independent read receipt.
   var now=DateTimeOffset.UtcNow;var portalNotice=new MiapaxERP.Lisans.Core.PortalDuyuru(42,Guid.NewGuid().ToString(),"TEST lisans paneli duyurusu","TEST şirket bildirimi",now.AddMinutes(-1));
   var receipt=new MiapaxERP.Lisans.Core.LisansIcerigi(1,Guid.NewGuid().ToString(),Guid.NewGuid().ToString(),"TEST","BORU",["STOK"],new string('A',64),new string('B',64),now,now.AddDays(-1),null,now.AddDays(7),1){PortalNotices=[portalNotice]};
   using var rsa=System.Security.Cryptography.RSA.Create(3072);var envelope=MiapaxERP.Lisans.Core.LisansKripto.Imzala(receipt,rsa);var verified=MiapaxERP.Lisans.Core.LisansKripto.Dogrula(envelope,rsa.ExportSubjectPublicKeyInfoPem(),receipt.DeviceId,receipt.DatabaseId,now);
   Assert.Equal(42,PortalDuyuruAktar.Kaydet(cs,"https://license.test",verified));Assert.Equal(42,PortalDuyuruAktar.Kaydet(cs,"https://license.test",verified));var own=Assert.Single(new IsbirligiServisi(cs,3).Bildirimler(),x=>x.Baslik.StartsWith("MiaPaxERP · TEST"));Assert.False(own.Okundu);new IsbirligiServisi(cs,4).Okundu([own.Id]);Assert.False(Assert.Single(new IsbirligiServisi(cs,3).Bildirimler(),x=>x.Id==own.Id).Okundu);Assert.True(Assert.Single(new IsbirligiServisi(cs,4).Bildirimler(),x=>x.Id==own.Id).Okundu);
   Assert.Throws<System.Security.Cryptography.CryptographicException>(()=>MiapaxERP.Lisans.Core.LisansKripto.Dogrula(envelope with{Payload=Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("{}"))},rsa.ExportSubjectPublicKeyInfoPem(),receipt.DeviceId,receipt.DatabaseId,now));
  }finally{if(!System.Text.RegularExpressions.Regex.IsMatch(name,"^MiapaxNext_[a-f0-9]{32}$"))throw new InvalidOperationException();Sql(master,"ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]");}
 }
}
