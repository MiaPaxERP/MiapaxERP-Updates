using System.Buffers.Binary;
using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
namespace MiapaxERP.Desktop;

public sealed record MakineOkumaSonucu(bool Basarili,IReadOnlyDictionary<string,double?> Degerler,string? Hata,DateTimeOffset Zaman)
{
 public static MakineOkumaSonucu HataIle(string hata)=>new(false,new Dictionary<string,double?>(),hata,DateTimeOffset.Now);
}
public enum ModbusTablo{HR,IR,COIL,DI}
public enum ModbusTip{U16,S16,U32,S32,F32}
public readonly record struct ModbusAdresi(ModbusTablo Tablo,ushort Adres,ModbusTip Tip,bool KelimeTers);

/// <summary>
/// Bir makineye bağlanıp tanımlı alanları okur. Bağlantı açık tutulur; panel kapanınca <see cref="DisposeAsync"/> ile kapatılır.
/// Okuma yalnız bu bilgisayardan, makinelerle aynı ağ üzerinden yapılır; değerler veritabanına yazılmaz.
/// </summary>
public sealed class MakineOkuyucu(MakineTanimi makine):IAsyncDisposable
{
 static readonly HttpClient http=new(new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(6)};
 TcpClient? modbus;ushort islemNo;MqttDinleyici? mqtt;OpcUaBaglanti? opc;
 readonly SemaphoreSlim kilit=new(1,1);
 public MakineTanimi Makine{get;}=makine;

 public static async Task<MakineOkumaSonucu> TekSeferAsync(MakineTanimi m,CancellationToken ct){
  await using var r=new MakineOkuyucu(MakineServisi.Dogrula(m));
  if(r.Makine.Protokol=="MQTT"){var first=await r.OkuAsync(ct);if(first.Basarili&&first.Degerler.Values.Any(v=>v is not null))return first;await Task.Delay(TimeSpan.FromSeconds(3),ct);}
  return await r.OkuAsync(ct);
 }

 public async Task<MakineOkumaSonucu> OkuAsync(CancellationToken ct){
  await kilit.WaitAsync(ct);
  try{
   var degerler=Makine.Protokol switch{
    "HTTP"=>await Http(ct),"MODBUS"=>await Modbus(ct),"MQTT"=>await Mqtt(ct),"OPCUA"=>await Opc(ct),_=>throw new InvalidOperationException("Bağlantı türü desteklenmiyor.")};
   return new(true,degerler,null,DateTimeOffset.Now);
  }
  catch(OperationCanceledException)when(ct.IsCancellationRequested){throw;}
  catch(Exception e){Kapat();return MakineOkumaSonucu.HataIle(Aciklama(e));}
  finally{kilit.Release();}
 }

 static string Aciklama(Exception e)=>e switch{
  SocketException s=>"Makineye bağlanılamadı ("+s.SocketErrorCode+"). IP, port ve aynı ağda olduğunuzu kontrol edin.",
  TimeoutException or TaskCanceledException=>"Makine zamanında yanıt vermedi.",
  HttpRequestException h=>"HTTP isteği başarısız: "+h.Message,
  IOException=>"Bağlantı koptu; yeniden denenecek.",
  _=>e.Message};

 Dictionary<string,double?> Bos()=>Makine.Alanlar.ToDictionary(a=>a.Ad,_=>(double?)null);
 static double? Olcekle(double? v,MakineAlani a)=>v is { } x?x*a.Carpan:null;

 // ---------- HTTP / JSON ----------
 async Task<Dictionary<string,double?>> Http(CancellationToken ct){
  using var res=await http.GetAsync(Makine.Adres,HttpCompletionOption.ResponseHeadersRead,ct);res.EnsureSuccessStatusCode();
  if(res.Content.Headers.ContentLength>2_000_000)throw new InvalidDataException("Makine yanıtı çok büyük.");
  using var doc=JsonDocument.Parse(await res.Content.ReadAsStringAsync(ct));
  var d=Bos();foreach(var a in Makine.Alanlar)d[a.Ad]=Olcekle(JsonDeger(doc.RootElement,a.Kaynak),a);return d;
 }
 /// <summary>"veri.hatlar.0.hiz" biçimindeki yolu izler; sayı, true/false veya sayı içeren metni döndürür.</summary>
 public static double? JsonDeger(JsonElement root,string yol){
  var e=root;
  foreach(var part in yol.Split('.',StringSplitOptions.RemoveEmptyEntries)){
   if(e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(part,out var c))e=c;
   else if(e.ValueKind==JsonValueKind.Array&&int.TryParse(part,NumberStyles.None,CultureInfo.InvariantCulture,out int i)&&i<e.GetArrayLength())e=e[i];
   else return null;
  }
  return e.ValueKind switch{JsonValueKind.Number=>e.GetDouble(),JsonValueKind.True=>1,JsonValueKind.False=>0,JsonValueKind.String when double.TryParse(e.GetString(),NumberStyles.Float,CultureInfo.InvariantCulture,out double v)=>v,_=>null};
 }

 // ---------- Modbus TCP ----------
 /// <summary>"HR:40001", "IR:30005:F32", "HR:100:U32:SW", "COIL:1", "DI:3" biçimini çözer. 40001/30001/1 tabanlı adresler sıfır tabanlıya çevrilir.</summary>
 public static ModbusAdresi ModbusAdres(string kaynak){
  var p=(kaynak??"").Trim().ToUpperInvariant().Split(':');
  if(p.Length<2||!char.IsLetter(p[0].FirstOrDefault())||!Enum.TryParse<ModbusTablo>(p[0],out var tablo)||!int.TryParse(p[1],NumberStyles.None,CultureInfo.InvariantCulture,out int n))throw new ArgumentException("Modbus adresi HR:40001, IR:30001, COIL:1 veya DI:1 biçiminde olmalı (isteğe bağlı :F32/:U32/:S16 ve :SW).");
  int adres=tablo switch{ModbusTablo.HR when n>=40001&&n<=49999=>n-40001,ModbusTablo.IR when n>=30001&&n<=39999=>n-30001,ModbusTablo.COIL or ModbusTablo.DI when n>=1=>n-1,_=>n};
  if(adres<0||adres>65535)throw new ArgumentException("Modbus adresi 0–65535 aralığında olmalı.");
  var tip=ModbusTip.U16;bool sw=false;
  foreach(var x in p.Skip(2)){if(x=="SW")sw=true;else if(!char.IsLetter(x.FirstOrDefault())||!Enum.TryParse(x,out tip))throw new ArgumentException("Modbus veri tipi U16, S16, U32, S32 veya F32 olmalı.");}
  if(tablo is ModbusTablo.COIL or ModbusTablo.DI&&tip!=ModbusTip.U16)throw new ArgumentException("Bobin ve dijital giriş yalnız 0/1 okunur.");
  return new(tablo,(ushort)adres,tip,sw);
 }
 async Task<Dictionary<string,double?>> Modbus(CancellationToken ct){
  if(modbus is not {Connected:true}){modbus?.Dispose();modbus=new TcpClient{NoDelay=true,ReceiveTimeout=4000,SendTimeout=4000};using var cc=CancellationTokenSource.CreateLinkedTokenSource(ct);cc.CancelAfter(4000);await modbus.ConnectAsync(Makine.Adres,Makine.Port??502,cc.Token);}
  var s=modbus.GetStream();var d=Bos();
  foreach(var a in Makine.Alanlar){
   var adr=ModbusAdres(a.Kaynak);int adet=adr.Tip is ModbusTip.U32 or ModbusTip.S32 or ModbusTip.F32?2:1;
   byte fn=adr.Tablo switch{ModbusTablo.HR=>3,ModbusTablo.IR=>4,ModbusTablo.COIL=>1,_=>2};
   byte[] veri=await ModbusIstek(s,(byte)Makine.BirimNo,fn,adr.Adres,(ushort)adet,ct);
   d[a.Ad]=Olcekle(ModbusCoz(veri,adr),a);
  }
  return d;
 }
 async Task<byte[]> ModbusIstek(NetworkStream s,byte birim,byte fn,ushort adres,ushort adet,CancellationToken ct){
  ushort id=++islemNo;var req=new byte[12];BinaryPrimitives.WriteUInt16BigEndian(req,id);BinaryPrimitives.WriteUInt16BigEndian(req.AsSpan(4),6);req[6]=birim;req[7]=fn;BinaryPrimitives.WriteUInt16BigEndian(req.AsSpan(8),adres);BinaryPrimitives.WriteUInt16BigEndian(req.AsSpan(10),adet);
  using var cc=CancellationTokenSource.CreateLinkedTokenSource(ct);cc.CancelAfter(4000);
  await s.WriteAsync(req,cc.Token);
  var head=new byte[7];await s.ReadExactlyAsync(head,cc.Token);int len=BinaryPrimitives.ReadUInt16BigEndian(head.AsSpan(4));
  if(BinaryPrimitives.ReadUInt16BigEndian(head)!=id||len is <2 or >260)throw new InvalidDataException("Modbus yanıtı geçersiz.");
  var body=new byte[len-1];await s.ReadExactlyAsync(body,cc.Token);
  if((body[0]&0x80)!=0)throw new InvalidDataException("Modbus hata kodu "+body[1]+" (adres veya birim numarasını kontrol edin).");
  if(body[0]!=fn||body.Length<2||body[1]!=body.Length-2)throw new InvalidDataException("Modbus yanıtı beklenen biçimde değil.");
  return body[2..];
 }
 public static double ModbusCoz(byte[] v,ModbusAdresi a){
  if(a.Tablo is ModbusTablo.COIL or ModbusTablo.DI)return (v[0]&1)==1?1:0;
  if(a.Tip is ModbusTip.U16)return BinaryPrimitives.ReadUInt16BigEndian(v);
  if(a.Tip is ModbusTip.S16)return BinaryPrimitives.ReadInt16BigEndian(v);
  var b=a.KelimeTers?new[]{v[2],v[3],v[0],v[1]}:v[..4];
  return a.Tip switch{ModbusTip.U32=>BinaryPrimitives.ReadUInt32BigEndian(b),ModbusTip.S32=>BinaryPrimitives.ReadInt32BigEndian(b),_=>BinaryPrimitives.ReadSingleBigEndian(b)};
 }

 // ---------- MQTT ----------
 async Task<Dictionary<string,double?>> Mqtt(CancellationToken ct){
  if(mqtt is not {Bagli:true}){mqtt?.Dispose();mqtt=new MqttDinleyici(Makine.Adres,Makine.Port??1883,Makine.Alanlar.Select(a=>a.Kaynak.Split('#')[0]).Distinct().ToArray());await mqtt.BaslatAsync(ct);}
  if(mqtt.Hata is { } h)throw new IOException(h);
  var d=Bos();
  foreach(var a in Makine.Alanlar){var parts=a.Kaynak.Split('#',2);if(!mqtt.Son.TryGetValue(parts[0],out var payload))continue;d[a.Ad]=Olcekle(MqttDeger(payload,parts.Length>1?parts[1]:null),a);}
  return d;
 }
 public static double? MqttDeger(string payload,string? yol){
  payload=payload.Trim();
  if(yol is null&&double.TryParse(payload,NumberStyles.Float,CultureInfo.InvariantCulture,out double v))return v;
  if(payload is "true" or "ON" or "on")return 1;if(payload is "false" or "OFF" or "off")return 0;
  try{using var doc=JsonDocument.Parse(payload);return JsonDeger(doc.RootElement,yol??"");}catch(JsonException){return null;}
 }

 // ---------- OPC UA ----------
 async Task<Dictionary<string,double?>> Opc(CancellationToken ct){
  opc??=new OpcUaBaglanti(Makine.Adres);
  var values=await opc.OkuAsync(Makine.Alanlar.Select(a=>a.Kaynak).ToArray(),ct);
  var d=Bos();for(int i=0;i<Makine.Alanlar.Length;i++)d[Makine.Alanlar[i].Ad]=Olcekle(values[i],Makine.Alanlar[i]);return d;
 }

 void Kapat(){modbus?.Dispose();modbus=null;mqtt?.Dispose();mqtt=null;opc?.Dispose();opc=null;}
 public ValueTask DisposeAsync(){Kapat();kilit.Dispose();return ValueTask.CompletedTask;}
}

/// <summary>Yalnız abone olan, QoS 0 kullanan küçük MQTT 3.1.1 istemcisi. Her konunun son mesajını tutar.</summary>
public sealed class MqttDinleyici(string host,int port,string[] konular):IDisposable
{
 TcpClient? tcp;CancellationTokenSource? stop;
 public System.Collections.Concurrent.ConcurrentDictionary<string,string> Son{get;}=new(StringComparer.Ordinal);
 public bool Bagli=>tcp?.Connected==true&&Hata is null;
 public string? Hata{get;private set;}
 public async Task BaslatAsync(CancellationToken ct){
  if(konular.Length is 0 or >40||konular.Any(k=>k.Length is 0 or >200||k.Contains('\0')))throw new ArgumentException("MQTT konuları geçersiz.");
  tcp=new TcpClient{NoDelay=true};using(var cc=CancellationTokenSource.CreateLinkedTokenSource(ct)){cc.CancelAfter(5000);await tcp.ConnectAsync(host,port,cc.Token);}
  var s=tcp.GetStream();
  string client="miapax-"+Guid.NewGuid().ToString("N")[..12];
  var connect=new List<byte>();Str(connect,"MQTT");connect.Add(4);connect.Add(0x02);connect.Add(0);connect.Add(60);Str(connect,client);
  await Yaz(s,0x10,connect.ToArray(),ct);
  var (type,body)=await Oku(s,ct);if(type!=2||body.Length<2||body[1]!=0)throw new IOException("MQTT sunucusu bağlantıyı reddetti (kod "+(body.Length>1?body[1]:-1)+").");
  var sub=new List<byte>{0,1};foreach(var k in konular){Str(sub,k);sub.Add(0);}
  await Yaz(s,0x82,sub.ToArray(),ct);
  stop=new CancellationTokenSource();_=Task.Run(()=>Dongu(s,stop.Token));
 }
 async Task Dongu(NetworkStream s,CancellationToken ct){
  var ping=DateTime.UtcNow;
  try{
   while(!ct.IsCancellationRequested){
    if(DateTime.UtcNow-ping>TimeSpan.FromSeconds(30)){await Yaz(s,0xC0,[],ct);ping=DateTime.UtcNow;}
    if(!s.DataAvailable){await Task.Delay(100,ct);continue;}
    var (type,body)=await Oku(s,ct);
    if(type==3&&body.Length>=2){int tl=(body[0]<<8)|body[1];if(2+tl>body.Length)continue;string topic=Encoding.UTF8.GetString(body,2,tl);int qos=0;int off=2+tl+(qos>0?2:0);Son[topic]=Encoding.UTF8.GetString(body,off,body.Length-off);}
   }
  }catch(OperationCanceledException){}catch(Exception e){Hata="MQTT bağlantısı koptu: "+e.Message;}
 }
 static void Str(List<byte> b,string s){var x=Encoding.UTF8.GetBytes(s);b.Add((byte)(x.Length>>8));b.Add((byte)x.Length);b.AddRange(x);}
 static async Task Yaz(NetworkStream s,byte header,byte[] body,CancellationToken ct){
  var p=new List<byte>{header};int len=body.Length;do{byte d=(byte)(len%128);len/=128;if(len>0)d|=0x80;p.Add(d);}while(len>0);p.AddRange(body);
  await s.WriteAsync(p.ToArray(),ct);
 }
 static async Task<(int Type,byte[] Body)> Oku(NetworkStream s,CancellationToken ct){
  var one=new byte[1];await s.ReadExactlyAsync(one,ct);int type=one[0]>>4;
  int len=0,mul=1;for(int i=0;i<4;i++){await s.ReadExactlyAsync(one,ct);len+=(one[0]&127)*mul;if((one[0]&128)==0)break;mul*=128;}
  if(len>1_000_000)throw new InvalidDataException("MQTT mesajı çok büyük.");
  var body=new byte[len];if(len>0)await s.ReadExactlyAsync(body,ct);return (type,body);
 }
 public void Dispose(){stop?.Cancel();tcp?.Dispose();tcp=null;}
}
