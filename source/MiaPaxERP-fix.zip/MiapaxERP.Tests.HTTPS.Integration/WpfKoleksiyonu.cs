using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
/// <summary>WPF pencereleri aynı anda birden çok STA iş parçacığında XAML yüklerse paket akışı yarışa girer; bu testler sırayla çalışır.</summary>
[CollectionDefinition("WpfArayuz",DisableParallelization=true)]
public sealed class WpfKoleksiyonu{}
