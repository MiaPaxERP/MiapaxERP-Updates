using Orientation = System.Windows.Controls.Orientation;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
namespace MiapaxERP.Desktop.Muhasebe280;

/// <summary>
/// Otomatik bordro: tüm çalışanlar listelenir, ücret tanımı olan herkes için bugüne kadarki hak ediş (brüt, net, işveren maliyeti)
/// her gün kendiliğinden hesaplanır; ay sonunda tek tuşla tüm çalışanların taslak bordrosu hazırlanır (onay ve ödeme yine elle yapılır).
/// </summary>
public sealed partial class BordroPaneli
{
 readonly PersonelUcretDeposu? ucret;
 bool gunlukGorunum;DateTime sonHesapGunu;
 static readonly CultureInfo tr=CultureInfo.GetCultureInfo("tr-TR");

 sealed class UcretSatiri{
  public int PersonelId{get;set;}public string Sicil{get;set;}="";public string AdSoyad{get;set;}="";public string Departman{get;set;}="";public string Durum{get;set;}="";
  public string Esas{get;set;}="Brüt";public string Ucret{get;set;}="";public string Sigorta{get;set;}="Normal 4/a";public int? CariId{get;set;}public bool AsgariIstisna{get;set;}=true;
 }

 void OtomatikBagla(){
  if(ucret is null)return;
  // Panel açılınca çalışanlar ve bugünkü hak ediş kendiliğinden gelir; gün değişince yeniden hesaplanır.
  Loaded+=(_,_)=>{try{GunlukGoster();}catch(Exception e){status.Text=e.Message;}};
  var t=new DispatcherTimer{Interval=TimeSpan.FromMinutes(10)};
  t.Tick+=(_,_)=>{if(gunlukGorunum&&DateTime.Today!=sonHesapGunu){try{GunlukGoster();}catch(Exception e){status.Text=e.Message;}}};
  Loaded+=(_,_)=>t.Start();Unloaded+=(_,_)=>t.Stop();
 }

 void GunlukGoster(){
  if(ucret is null)throw new InvalidOperationException("Ücret tanımları bu ekranda kullanılamıyor.");
  var bugun=DateTime.Today;var list=ucret.GunlukHesap(bugun);var tum=ucret.Liste();
  var tanimsiz=tum.Where(p=>p.Ucret is null&&p.IstenCikis is null).Select(p=>new GunlukHakedis(p.PersonelId,p.Sicil,p.AdSoyad,p.Departman,bugun.Year,bugun.Month,0,0,0,"",0,0,0,0,"Ücret tanımlı değil · 'Çalışan ücretleri'nden girin"));
  var rows=list.Concat(tanimsiz).OrderBy(x=>x.AdSoyad,StringComparer.Create(tr,true)).ToArray();
  grid.ItemsSource=rows;gunlukGorunum=true;sonHesapGunu=bugun;
  decimal net=list.Sum(x=>x.Net),maliyet=list.Sum(x=>x.IsverenMaliyeti);
  status.Text=$"{bugun:dd.MM.yyyy} itibarıyla {list.Length} çalışanın bu ayki hak edişi otomatik hesaplandı: toplam net {net.ToString("N2",tr)} TRY, işveren maliyeti {maliyet.ToString("N2",tr)} TRY. "+
   (tanimsiz.Any()?tanimsiz.Count()+" çalışanın ücreti tanımlı değil. ":"")+"Ücretsiz izin ve rapor günleri İK kayıtlarından düşülür. Bordro listesine dönmek için 'Yenile'.";
 }

 void UcretTanimlari(){
  if(ucret is null)throw new InvalidOperationException("Ücret tanımları bu ekranda kullanılamıyor.");
  var data=new ObservableCollection<UcretSatiri>(ucret.Liste().Select(p=>new UcretSatiri{PersonelId=p.PersonelId,Sicil=p.Sicil,AdSoyad=p.AdSoyad,Departman=p.Departman,Durum=p.IstenCikis is null?"Çalışıyor":"Ayrıldı "+p.IstenCikis.Value.ToString("dd.MM.yyyy"),
   Esas=p.Esas==UcretEsasi.Net?"Net":"Brüt",Ucret=p.Ucret is decimal u?u.ToString("#,0.##",tr):"",Sigorta=p.Sigorta==SigortaTuru.EmekliSGDP?"Emekli (SGDP)":"Normal 4/a",CariId=p.CariId,AsgariIstisna=p.AsgariIstisna}));
  var cariler=db.Secimler(false);
  var p=new DockPanel{Margin=new Thickness(16)};var w=new Window{Title="Miapax ERP · Çalışan ücretleri",Owner=Window.GetWindow(this),Width=1100,Height=700,WindowStartupLocation=WindowStartupLocation.CenterOwner,Content=p};
  var info=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,10),Text="Tüm çalışanlar listelenir. Aylık ücreti (net veya brüt), sigorta türünü ve ücretin işleneceği cari kartı girin; ücret boş bırakılan çalışan için otomatik bordro hesaplanmaz. Ücret 30 gün üzerinden oranlanır."};
  DockPanel.SetDock(info,Dock.Top);p.Children.Add(info);
  var bar=new StackPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(0,10,0,0)};DockPanel.SetDock(bar,Dock.Bottom);p.Children.Add(bar);
  var g=new DataGrid{ItemsSource=data,AutoGenerateColumns=false,CanUserAddRows=false};
  g.Columns.Add(new DataGridTextColumn{Header="Sicil",Binding=new System.Windows.Data.Binding("Sicil"),IsReadOnly=true,Width=90});
  g.Columns.Add(new DataGridTextColumn{Header="Ad soyad",Binding=new System.Windows.Data.Binding("AdSoyad"),IsReadOnly=true,Width=180});
  g.Columns.Add(new DataGridTextColumn{Header="Departman",Binding=new System.Windows.Data.Binding("Departman"),IsReadOnly=true,Width=120});
  g.Columns.Add(new DataGridTextColumn{Header="Durum",Binding=new System.Windows.Data.Binding("Durum"),IsReadOnly=true,Width=120});
  g.Columns.Add(new DataGridComboBoxColumn{Header="Esas",ItemsSource=new[]{"Brüt","Net"},SelectedItemBinding=new System.Windows.Data.Binding("Esas"),Width=70});
  g.Columns.Add(new DataGridTextColumn{Header="Aylık ücret (TRY)",Binding=new System.Windows.Data.Binding("Ucret"),Width=120});
  g.Columns.Add(new DataGridComboBoxColumn{Header="Sigorta",ItemsSource=new[]{"Normal 4/a","Emekli (SGDP)"},SelectedItemBinding=new System.Windows.Data.Binding("Sigorta"),Width=120});
  g.Columns.Add(new DataGridComboBoxColumn{Header="Ücret cari kartı",ItemsSource=cariler.DefaultView,DisplayMemberPath="Ad",SelectedValuePath="Id",SelectedValueBinding=new System.Windows.Data.Binding("CariId"),Width=new DataGridLength(1,DataGridLengthUnitType.Star)});
  g.Columns.Add(new DataGridCheckBoxColumn{Header="Asgari ücret istisnası",Binding=new System.Windows.Data.Binding("AsgariIstisna"),Width=130});
  p.Children.Add(g);
  var save=new Button{Content="Kaydet",Padding=new Thickness(16,8,16,8),IsDefault=true};var close=new Button{Content="Kapat",Padding=new Thickness(16,8,16,8),Margin=new Thickness(8,0,0,0),IsCancel=true};
  var msg=new TextBlock{Margin=new Thickness(12,0,0,0),VerticalAlignment=VerticalAlignment.Center,TextWrapping=TextWrapping.Wrap};bar.Children.Add(save);bar.Children.Add(close);bar.Children.Add(msg);
  save.Click+=(_,_)=>{
   try{
    g.CommitEdit(DataGridEditingUnit.Row,true);var girdi=new List<PersonelUcretGirdisi>();
    foreach(var r in data){
     if(string.IsNullOrWhiteSpace(r.Ucret))continue;
     if(!SayiKutusu.Oku(r.Ucret,out var u)||u<=0)throw new ArgumentException(r.AdSoyad+": ücret geçerli bir tutar olmalı (örn. 35.000 veya 35000,50).");
     girdi.Add(new(r.PersonelId,r.Esas=="Net"?UcretEsasi.Net:UcretEsasi.Brut,decimal.Round(u,2),r.Sigorta.StartsWith("Emekli")?SigortaTuru.EmekliSGDP:SigortaTuru.Normal4A,r.CariId,r.AsgariIstisna));
    }
    if(girdi.Count==0)throw new ArgumentException("En az bir çalışana ücret girin.");
    int n=ucret.Kaydet(girdi.ToArray());msg.Text=n+" çalışanın ücreti kaydedildi.";GunlukGoster();
   }catch(Exception e){msg.Text=e.Message;}
  };
  w.ShowDialog();
 }

 void AySonu(){
  if(ucret is null)throw new InvalidOperationException("Ücret tanımları bu ekranda kullanılamıyor.");
  var bugun=DateTime.Today;var donem=bugun.Day>=25?bugun:bugun.AddMonths(-1);
  if(MessageBox.Show(Window.GetWindow(this),$"{donem:MMMM yyyy} için ücreti ve cari kartı tanımlı tüm çalışanların taslak bordrosu hazırlansın mı?\n\nPrim günü ücretsiz izin/rapor günleri düşülerek hesaplanır; önceki aylardan kümülatif vergi matrahı alınır. Taslaklar onaylanmadan muhasebeye işlenmez.","Ay sonu bordroları",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
  var r=ucret.AySonuTaslaklari(donem.Year,donem.Month);
  Load();status.Text=r.Hazirlanan+" taslak bordro hazırlandı."+(r.Atlanan.Length>0?" Atlanan: "+string.Join(" · ",r.Atlanan.Take(12))+(r.Atlanan.Length>12?" …":""):"");
 }
}
