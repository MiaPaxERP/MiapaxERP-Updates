using System.IO;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
public sealed partial class KolayBaglantiPaneli
{
 void AkilliKurulumuEkle(Panel actions){
  AsyncButton(actions,"İşyerindeki ana sunucuyu bul",async()=>{
   status.Text="İşyerinizin ağında MiaPaxERP ana sunucusu aranıyor…";var found=await HttpsAgKesfi.Bul(stop.Token);
   var ready=found.Where(x=>x.SqlHazir).ToArray();if(ready.Length==0){status.Text=found.Length==0?"Ana sunucu bulunamadı. Ana bilgisayarı ve MiaPaxERP'yi açın. Farklı şehirdeyseniz yöneticinizin verdiği bağlantı kodunu aşağıya yapıştırın.":"Ana bilgisayar bulundu fakat veritabanı hazır değil. Ana bilgisayarda programın açıldığını kontrol edin.";return;}
   if(ready.Length>1){status.Text="Birden fazla ana sunucu bulundu: "+string.Join(" · ",ready.Select(x=>x.Bilgisayar))+". Doğru işyerinin bağlantı kodunu kullanın; mevcut ayar değiştirilmedi.";return;}
   var server=ready[0];if(string.IsNullOrWhiteSpace(server.Adres)){status.Text=server.Bilgisayar+" ana bilgisayarı bulundu. Önce o bilgisayarda Ana sunucu → HTTPS sunucusunu hazırla adımını bir kez tamamlayın.";return;}
   status.Text=server.Bilgisayar+" bulundu. Güvenli bağlantısı doğrulanıyor…";var check=await KolayBaglantiKontrolu.Https(server.Adres,true,stop.Token);if(!check.Basarili){status.Text="Sunucu bulundu; adres kaydedilmedi. "+check.Mesaj;return;}
   address.Text=server.Adres;rol.SelectedIndex=1;var old=KolayBaglantiProfili.Oku();if(old.Rol=="Yan"&&string.Equals(old.MasaustuHttps,server.Adres,StringComparison.OrdinalIgnoreCase)){Profil().Kaydet();status.Text="Daha önce kullanılan ana sunucu doğrulandı; yan cihaz ayarları yenilendi. Programa bağlan düğmesine basın.";}
   else status.Text=server.Bilgisayar+" ana sunucusu ve HTTPS bağlantısı doğrulandı. Adres otomatik dolduruldu: "+server.Adres+". Bu işyerinin sunucusuysa Programa bağlan düğmesine basın ve kendi hesabınızla giriş yapın.";
  });
  string file=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","Baglanti","asistan.json");
  Button(actions,"Yapay zekâ bağlantısı",()=>new YapayZekaBaglantiPenceresi(file){Owner=owner}.ShowDialog());
  AsyncButton(actions,"Bağlantı sonucunu yapay zekâya sor",async()=>{var setting=AsistanAyari.Oku(file);if(setting.Tur=="Yerleşik rehber"){status.Text+="\nYapay zekâ sunucusu bağlı değil. Ağ taraması ve güvenli bağlantı kontrolleri modelsiz çalışır.";return;}string diagnostic=status.Text;if(MessageBox.Show(owner,"Bağlantı kontrol sonucu ve sunucu adresi şu yapay zekâ sunucusuna gönderilecek:\n"+setting.Adres+"\nSQL parolası veya lisans anahtarı gönderilmez. Gönderilsin mi?","Bağlantı analizi",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;var reply=await new AsistanIstemcisi().SorAsync(setting,"Bu HTTPS bağlantı kontrolünü normal bir kullanıcıya açıklayıp en fazla üç sonraki adımı öner. Sertifika doğrulamasını kapatmayı veya SQL portunu internete açmayı önerme. Modem/DNS değişikliğini yapılmış gibi gösterme. Sonuç: "+diagnostic,"Ağ kurulum asistanı",[],stop.Token);status.Text=reply.Metin??reply.Durum;});
 }
}
