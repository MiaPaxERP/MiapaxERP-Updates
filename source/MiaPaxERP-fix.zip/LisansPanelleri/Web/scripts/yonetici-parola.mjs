// İnternet lisans paneli için geçici yönetici parolası üretir (kendi Cloudflare hesabınızda).
// Kullanım: node scripts/yonetici-parola.mjs <kullanici-adi> [--yeni]
//   Çıktıdaki wrangler komutunu çalıştırın; ilk girişte panel parola değişikliği ister.
//   --yeni: kullanıcı yoksa oluşturur (ör. ikinci yönetici veya parola kaybı).
import {hashPassword} from '../worker/auth.js';
const [user,flag]=process.argv.slice(2);
if(!user||!/^[a-z0-9._-]{3,40}$/.test(user)){console.error('Kullanım: node scripts/yonetici-parola.mjs <kullanici-adi> [--yeni]');process.exit(2);}
const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
const pick=()=>{const b=crypto.getRandomValues(new Uint8Array(20));return Array.from(b,x=>alphabet[x%alphabet.length]).join('');};
let temp;do temp=pick().replace(/(.{5})(?=.)/g,'$1-');while(!/[0-9]/.test(temp)||!/[a-z]/i.test(temp));
const hash=await hashPassword(temp),now=new Date().toISOString();
const sql=flag==='--yeni'
 ?`INSERT INTO admin_users(username,password_hash,must_change,active,created_at,updated_at) VALUES('${user}','${hash}',1,1,'${now}','${now}') ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash,must_change=1,active=1,updated_at=excluded.updated_at; DELETE FROM admin_sessions WHERE username='${user}';`
 :`UPDATE admin_users SET password_hash='${hash}',must_change=1,active=1,updated_at='${now}' WHERE username='${user}'; DELETE FROM admin_sessions WHERE username='${user}';`;
console.log('\nKullanıcı adı : '+user);
console.log('Geçici parola : '+temp);
console.log('\nŞu komutu InternetPaneli klasöründe çalıştırın:\n');
console.log(`npx wrangler d1 execute miapax-lisans --remote --command "${sql}"`);
console.log('\nSonra panele bu bilgilerle girin; sistem yeni parola belirlemenizi isteyecek.\n');
