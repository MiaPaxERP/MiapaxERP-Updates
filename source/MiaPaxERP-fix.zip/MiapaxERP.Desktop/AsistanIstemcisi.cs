using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
namespace MiapaxERP.Desktop;
public sealed record AsistanMesaji(string role,string content);
public sealed record AsistanYaniti(string? Metin,string Durum);
public sealed class AsistanAyari
{
    public string Tur {get;set;}="Yerleşik rehber";
    public string Adres {get;set;}="http://127.0.0.1:5189/api/yardim";
    public string Model {get;set;}="";
    /// <summary>API anahtarı; Windows kullanıcı hesabına bağlı DPAPI ile şifreli saklanır (başka bilgisayarda çözülemez).</summary>
    public string AnahtarKorumali {get;set;}="";
    public static bool AnahtarliTur(string tur)=>tur is "OpenAI uyumlu" or "Anthropic Claude";
    public void AnahtarAyarla(string? anahtar){AnahtarKorumali=string.IsNullOrWhiteSpace(anahtar)?"":Convert.ToBase64String(System.Security.Cryptography.ProtectedData.Protect(Encoding.UTF8.GetBytes(anahtar.Trim()),null,System.Security.Cryptography.DataProtectionScope.CurrentUser));}
    public string Anahtar(){
        if(AnahtarKorumali.Length==0)return "";
        try{return Encoding.UTF8.GetString(System.Security.Cryptography.ProtectedData.Unprotect(Convert.FromBase64String(AnahtarKorumali),null,System.Security.Cryptography.DataProtectionScope.CurrentUser));}
        catch(Exception e) when(e is FormatException or System.Security.Cryptography.CryptographicException){return "";}
    }
    public static string VarsayilanAdres(string tur)=>tur switch{"OpenAI uyumlu"=>"https://api.openai.com/v1/chat/completions","Anthropic Claude"=>"https://api.anthropic.com/v1/messages","Ollama"=>"http://127.0.0.1:11434/api/chat",_=>"http://127.0.0.1:5189/api/yardim"};
    public static string VarsayilanModel(string tur)=>tur switch{"OpenAI uyumlu"=>"gpt-4o-mini","Anthropic Claude"=>"claude-sonnet-4-5",_=>""};
    public static AsistanAyari Oku(string dosya) {
        try { if(File.Exists(dosya))return JsonSerializer.Deserialize<AsistanAyari>(File.ReadAllText(dosya))??new(); }
        catch(Exception e) when(e is IOException or UnauthorizedAccessException or JsonException) { }
        var url=Environment.GetEnvironmentVariable("MiapaxERP_YARDIM_URL");
        return string.IsNullOrWhiteSpace(url)?new():new(){Tur="MiapaxERP sunucusu",Adres=url};
    }
    public void Kaydet(string dosya) {
        Directory.CreateDirectory(Path.GetDirectoryName(dosya)!);
        string temp=dosya+".tmp";File.WriteAllText(temp,JsonSerializer.Serialize(this));File.Move(temp,dosya,true);
    }
}
public sealed class AsistanIstemcisi
{
    private static readonly HttpClient Ortak=new(new HttpClientHandler{AllowAutoRedirect=false}) {Timeout=TimeSpan.FromSeconds(60)};
    private readonly HttpClient http;
    public AsistanIstemcisi(HttpClient? client=null) {http=client??Ortak;}
    public static Uri AdresiDogrula(AsistanAyari ayar) {
        if(ayar.Tur!="MiapaxERP sunucusu" && ayar.Tur!="Ollama" && !AsistanAyari.AnahtarliTur(ayar.Tur))throw new ArgumentException("Bağlantı türünü seç.");
        if(AsistanAyari.AnahtarliTur(ayar.Tur)){
            if(string.IsNullOrWhiteSpace(ayar.Adres))ayar.Adres=AsistanAyari.VarsayilanAdres(ayar.Tur);
            if(string.IsNullOrWhiteSpace(ayar.Model))ayar.Model=AsistanAyari.VarsayilanModel(ayar.Tur);
            if(ayar.Anahtar().Length==0)throw new ArgumentException("API anahtarını girin. Anahtar bu bilgisayarda şifreli saklanır.");
        }
        if(!Uri.TryCreate(ayar.Adres?.Trim(),UriKind.Absolute,out var uri) ||
            !(uri.Scheme=="https" || (uri.Scheme=="http" && uri.IsLoopback)) || !string.IsNullOrEmpty(uri.UserInfo) || !string.IsNullOrEmpty(uri.Fragment))
            throw new ArgumentException("HTTPS adresi veya bu bilgisayara ait http://127.0.0.1 adresi kullan. Adrese kullanıcı adı/parola ekleme.");
        if(ayar.Tur=="Ollama" && string.IsNullOrWhiteSpace(ayar.Model))throw new ArgumentException("Ollama'da kurulu modelin adını gir.");
        return uri;
    }
    public async Task<AsistanYaniti> SorAsync(AsistanAyari ayar,string soru,string modul,IReadOnlyList<AsistanMesaji> gecmis,CancellationToken token) {
        if(ayar.Tur=="Yerleşik rehber")return new(null,"Yerleşik rehber • Yapay zekâ sunucusu bağlı değil");
        try {
            Uri uri=AdresiDogrula(ayar);
            var messages=new List<AsistanMesaji>{new("system",AsistanBilgisi.Baglam+"\nAçık ekran: "+modul)};
            messages.AddRange(gecmis.TakeLast(12).Where(m=>m.role is "user" or "assistant").Select(m=>new AsistanMesaji(m.role,m.content[..Math.Min(m.content.Length,6000)])));
            messages.Add(new("user",soru));
            object payload=ayar.Tur switch{
                "Ollama"=>new {model=ayar.Model,messages,stream=false},
                "OpenAI uyumlu"=>new {model=ayar.Model,messages},
                "Anthropic Claude"=>new {model=ayar.Model,max_tokens=2000,system=messages[0].content,messages=messages.Skip(1).SkipWhile(m=>m.role!="user").ToArray()},
                _=>(object)new {soru,modul,messages,rehber=AsistanBilgisi.Baglam}};
            using var request=new HttpRequestMessage(HttpMethod.Post,uri){Content=new StringContent(JsonSerializer.Serialize(payload),Encoding.UTF8,"application/json")};
            if(ayar.Tur=="OpenAI uyumlu")request.Headers.Authorization=new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer",ayar.Anahtar());
            if(ayar.Tur=="Anthropic Claude"){request.Headers.Add("x-api-key",ayar.Anahtar());request.Headers.Add("anthropic-version","2023-06-01");}
            using var response=await http.SendAsync(request,HttpCompletionOption.ResponseHeadersRead,token);
            if(!response.IsSuccessStatusCode)return new(null,(int)response.StatusCode switch{401 or 403=>"API anahtarı reddedildi (HTTP "+(int)response.StatusCode+"). Anahtarı ve hesabın kredisini kontrol edin.",404=>"Adres veya model bulunamadı (HTTP 404). Model adını kontrol edin.",429=>"Sağlayıcı istek sınırına ulaşıldı veya kredi bitti (HTTP 429).",_=>$"Sunucu yanıt vermedi (HTTP {(int)response.StatusCode}). Yerleşik rehber kullanılabilir."});
            using var stream=await response.Content.ReadAsStreamAsync(token);
            using var buffer=new MemoryStream();byte[] bytes=new byte[8192];int count;
            while((count=await stream.ReadAsync(bytes,token))>0){if(buffer.Length+count>256000)return new(null,"Sunucu yanıtı çok uzun. Soruyu daraltarak tekrar dene.");buffer.Write(bytes,0,count);}
            using var json=JsonDocument.Parse(buffer.ToArray());string? answer=null;
            if(ayar.Tur=="Ollama") {if(json.RootElement.TryGetProperty("message",out var msg)&&msg.ValueKind==JsonValueKind.Object&&msg.TryGetProperty("content",out var val)&&val.ValueKind==JsonValueKind.String)answer=val.GetString();}
            else if(ayar.Tur=="OpenAI uyumlu"){if(json.RootElement.TryGetProperty("choices",out var ch)&&ch.ValueKind==JsonValueKind.Array&&ch.GetArrayLength()>0&&ch[0].TryGetProperty("message",out var m)&&m.TryGetProperty("content",out var c)&&c.ValueKind==JsonValueKind.String)answer=c.GetString();}
            else if(ayar.Tur=="Anthropic Claude"){if(json.RootElement.TryGetProperty("content",out var parts)&&parts.ValueKind==JsonValueKind.Array)answer=string.Concat(parts.EnumerateArray().Where(x=>x.TryGetProperty("type",out var t)&&t.GetString()=="text"&&x.TryGetProperty("text",out _)).Select(x=>x.GetProperty("text").GetString()));}
            else if(json.RootElement.TryGetProperty("yanit",out var val)&&val.ValueKind==JsonValueKind.String)answer=val.GetString();
            return string.IsNullOrWhiteSpace(answer)?new(null,"Sunucu boş veya beklenmeyen yanıt verdi. Yerleşik rehber kullanılabilir."):new(answer[..Math.Min(answer.Length,20000)],"Yapay zekâ yanıtı • "+ayar.Tur);
        }
        catch(OperationCanceledException) when(token.IsCancellationRequested){throw;}
        catch(OperationCanceledException){return new(null,"Sunucu zaman aşımına uğradı. Yerleşik rehber kullanılabilir.");}
        catch(Exception ex) when(ex is HttpRequestException or JsonException or ArgumentException or IOException or InvalidOperationException) {return new(null,"Yapay zekâ bağlantısı kurulamadı. Adres, model ve sunucuyu kontrol et; yerleşik rehber kullanılabilir.");}
    }
}
