const enc=new TextEncoder(),un64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const fail=(m,status=403)=>{throw Object.assign(new Error(m),{status});};
const hash=async s=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(s))),x=>x.toString(16).padStart(2,'0')).join('');
const canonical=(b,digest)=>enc.encode(['MiaPaxERP.LicenseSync.1',b.at,b.nonce,digest].join('\n')+'\n');
export async function signLicenseSync(env,snapshot){
 const b={at:Date.now(),nonce:crypto.randomUUID(),snapshot};
 const key=await crypto.subtle.importKey('pkcs8',un64(env.LICENSE_PRIVATE_PKCS8),{name:'RSA-PSS',hash:'SHA-256'},false,['sign']);
 const signature=await crypto.subtle.sign({name:'RSA-PSS',saltLength:32},key,canonical(b,await hash(JSON.stringify(snapshot))));
 b.signature=btoa(String.fromCharCode(...new Uint8Array(signature)));return b;
}
export async function verifyLicenseSync(env,b){
 if(!b||!Number.isSafeInteger(b.at)||Math.abs(Date.now()-b.at)>60000||!/^[-a-f0-9]{36}$/i.test(b.nonce||'')||typeof b.signature!=='string'||b.signature.length>2048||!b.snapshot)fail('Lisans eşitleme isteği geçersiz.');
 const digest=await hash(JSON.stringify(b.snapshot));
 try{const k=await crypto.subtle.importKey('pkcs8',un64(env.LICENSE_PRIVATE_PKCS8),{name:'RSA-PSS',hash:'SHA-256'},true,['sign']);const j=await crypto.subtle.exportKey('jwk',k);const pub=await crypto.subtle.importKey('jwk',{kty:'RSA',n:j.n,e:j.e,alg:'PS256',ext:true},{name:'RSA-PSS',hash:'SHA-256'},false,['verify']);if(!await crypto.subtle.verify({name:'RSA-PSS',saltLength:32},pub,un64(b.signature),canonical(b,digest)))fail('Lisans eşitleme imzası geçersiz.');}catch{fail('Lisans eşitleme imzası geçersiz.');}
 return {snapshot:b.snapshot,digest};
}
export async function applyLicenseSync(env,b,validModules,moduleDates){
 const {snapshot:s,digest}=await verifyLicenseSync(env,b),c=s.customer,l=s.license;
 const guid=x=>typeof x==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(x);
 if(s.v!==1||!c||!l||!guid(c.id)||!guid(l.id)||l.customerId!==c.id||typeof c.name!=='string'||!c.name.trim()||c.name.length>160||!['BORU','YEDEK','RESTORAN','SUNGER','GENEL'].includes(c.sector)||!Number.isSafeInteger(c.revision)||c.revision<1||!Number.isSafeInteger(l.revision)||l.revision<1||typeof l.label!=='string'||!l.label.trim()||l.label.length>160||!/^[a-f0-9]{64}$/i.test(l.keyHash)||![0,1].includes(c.active)||![0,1].includes(l.active)||!Number.isInteger(l.maxDevices)||l.maxDevices<1||l.maxDevices>1000||!Number.isFinite(Date.parse(l.startsAt))||l.expiresAt!==null&&(!Number.isFinite(Date.parse(l.expiresAt))||Date.parse(l.expiresAt)<=Date.parse(l.startsAt)))fail('Lisans eşitleme bilgileri geçersiz.',400);
 const modules=validModules(l.modules),dates=moduleDates(l.moduleExpiresAt,modules,l.startsAt,l.expiresAt);
 const old=await env.DB.prepare('SELECT * FROM licenses WHERE id=?').bind(l.id).first(),mark=await env.DB.prepare('SELECT * FROM license_panel_sync WHERE license_id=?').bind(l.id).first();
 if(old&&old.customer_id!==c.id)fail('Lisans başka müşteriye bağlı.',409);
 if(mark){if(l.revision<mark.source_revision||c.revision<mark.source_customer_revision)fail('Eski panel kaydı gönderildi.',409);if(old?.revision!==mark.cloud_revision)fail('İnternet panelinde lisans değişmiş; iki panelin değişikliklerini karşılaştırın.',409);if(digest===mark.payload_hash)return {ok:true,alreadySynced:true,id:l.id};}
 else if(old&&old.key_hash!==l.keyHash)fail('Aynı kimlikte farklı anahtar var; lisans üzerine yazılmadı.',409);
 const duplicate=await env.DB.prepare('SELECT id FROM licenses WHERE key_hash=? AND id<>?').bind(l.keyHash,l.id).first();if(duplicate)fail('Anahtar başka bir lisansa bağlı.',409);
 const now=new Date().toISOString(),revision=old?old.revision+1:1;
 const items=[env.DB.prepare('INSERT INTO customers(id,name,sector,active,revision,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,sector=excluded.sector,active=excluded.active,revision=MAX(customers.revision,excluded.revision)').bind(c.id,c.name,c.sector,c.active,c.revision,now)];
 if(old)items.push(env.DB.prepare('UPDATE licenses SET key_hash=?,key_cipher=CASE WHEN key_hash=? THEN key_cipher ELSE NULL END,label=?,modules=?,module_expires=?,max_devices=?,starts_at=?,expires_at=?,active=?,revision=? WHERE id=? AND revision=? RETURNING id').bind(l.keyHash,l.keyHash,l.label,JSON.stringify(modules),JSON.stringify(dates),l.maxDevices,l.startsAt,l.expiresAt,l.active,revision,l.id,old.revision));
 else items.push(env.DB.prepare('INSERT INTO licenses(id,customer_id,key_hash,label,modules,module_expires,max_devices,starts_at,expires_at,active,revision,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) RETURNING id').bind(l.id,c.id,l.keyHash,l.label,JSON.stringify(modules),JSON.stringify(dates),l.maxDevices,l.startsAt,l.expiresAt,l.active,revision,now));
 items.push(env.DB.prepare('INSERT INTO license_panel_sync(license_id,source_revision,source_customer_revision,payload_hash,cloud_revision,updated_at) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM licenses WHERE id=? AND revision=? AND key_hash=? AND modules=? AND module_expires=?) ON CONFLICT(license_id) DO UPDATE SET source_revision=excluded.source_revision,source_customer_revision=excluded.source_customer_revision,payload_hash=excluded.payload_hash,cloud_revision=excluded.cloud_revision,updated_at=excluded.updated_at').bind(l.id,l.revision,c.revision,digest,revision,now,l.id,revision,l.keyHash,JSON.stringify(modules),JSON.stringify(dates)));
 const results=await env.DB.batch(items);if(!results[1].results?.length)fail('Lisans eşzamanlı değişti; yenileyin.',409);return {ok:true,id:l.id,revision};
}
