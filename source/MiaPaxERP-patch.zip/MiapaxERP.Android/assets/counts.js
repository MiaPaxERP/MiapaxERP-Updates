'use strict';
const cityCounts={values:null,busy:false};
function cityCount(id){return cityCounts.values===null?'…':String(cityCounts.values.get(id)||0);}
async function refreshCityCounts(){if(cityCounts.busy)return;cityCounts.busy=true;try{const rows=await rpc('counts'),next=new Map();for(const r of rows){if(typeof r.ilId!=='string'||!Number.isSafeInteger(r.kisiSayisi)||r.kisiSayisi<0)throw Error('Şehir kişi sayıları okunamadı.');next.set(r.ilId,r.kisiSayisi);}cityCounts.values=next;if(provinces)draw();$('countStatus').textContent='Şehirlerdeki sayılar kayıtlı ayrı kişi / müşteri kartıdır. Tekrarlanan görüşmeler tekrar sayılmaz.';}catch(e){$('countStatus').textContent=cityCounts.values?'Şehir sayıları yenilenemedi; son alınan sayılar gösteriliyor.':'Şehir sayıları alınamadı. '+(e.message||e);}finally{cityCounts.busy=false;}}
window.addEventListener('mobile-sync',refreshCityCounts);
setInterval(()=>{if(!document.hidden)refreshCityCounts();},30000);
