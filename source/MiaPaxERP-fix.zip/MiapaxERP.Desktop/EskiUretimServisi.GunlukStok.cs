using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>
/// Üretim emrinde gün içinde kaydedilen sağlam ürün miktarı, emir tamamlanmayı beklemeden üretilen ürün stoğuna girer.
/// Stoğa işlenen toplam <c>MPXNext_UretimGunlukStok</c> tablosunda tutulur; miktar düzeltilirse fark kadar giriş veya çıkış yapılır,
/// emir tamamlanınca yalnız kalan fark işlenir. Hammadde tüketimi ve parti kaydı tamamlamada yapılır.
/// </summary>
public sealed partial class EskiUretimServisi
{
 internal const string GunlukStokDdl="""
IF OBJECT_ID('dbo.MPXNext_UretimGunlukStok','U') IS NULL
 CREATE TABLE dbo.MPXNext_UretimGunlukStok(
  UretimEmriId int NOT NULL CONSTRAINT PK_MPXNext_UretimGunlukStok PRIMARY KEY,
  IslenenMiktar decimal(18,3) NOT NULL CONSTRAINT CK_MPXNext_UretimGunlukStok_Miktar CHECK(IslenenMiktar>=0),
  Guncelleme datetime2(3) NOT NULL CONSTRAINT DF_MPXNext_UretimGunlukStok_Tarih DEFAULT SYSDATETIME());
IF OBJECT_ID('dbo.UretimEmirleri','U') IS NOT NULL AND OBJECT_ID('dbo.FK_MPXNext_UretimGunlukStok_Emir','F') IS NULL
 ALTER TABLE dbo.MPXNext_UretimGunlukStok ADD CONSTRAINT FK_MPXNext_UretimGunlukStok_Emir FOREIGN KEY(UretimEmriId) REFERENCES dbo.UretimEmirleri(Id);
""";
 static readonly System.Collections.Concurrent.ConcurrentDictionary<string,bool> gunlukStokHazir=new(StringComparer.OrdinalIgnoreCase);

 static void GunlukStokHazirla(SqlConnection c,SqlTransaction t){
  string key=c.DataSource+"|"+c.Database;if(gunlukStokHazir.ContainsKey(key))return;
  using(var l=new SqlCommand("EXEC sp_getapplock @Resource='MiaPaxNextSchema',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;",c,t))l.ExecuteNonQuery();
  using(var k=new SqlCommand(GunlukStokDdl,c,t))k.ExecuteNonQuery();
  gunlukStokHazir[key]=true;
 }

 static decimal GunlukStokIslenen(SqlConnection c,SqlTransaction t,int emirId){
  GunlukStokHazirla(c,t);
  using var k=new SqlCommand("SELECT IslenenMiktar FROM dbo.MPXNext_UretimGunlukStok WITH(UPDLOCK,HOLDLOCK) WHERE UretimEmriId=@e",c,t);
  k.Parameters.Add("@e",SqlDbType.Int).Value=emirId;return k.ExecuteScalar() is decimal d?d:0m;
 }

 static void GunlukStokKaydet(SqlConnection c,SqlTransaction t,int emirId,decimal miktar){
  using var k=new SqlCommand("UPDATE dbo.MPXNext_UretimGunlukStok SET IslenenMiktar=@m,Guncelleme=SYSDATETIME() WHERE UretimEmriId=@e;IF @@ROWCOUNT=0 INSERT dbo.MPXNext_UretimGunlukStok(UretimEmriId,IslenenMiktar)VALUES(@e,@m);",c,t);
  k.Parameters.Add("@e",SqlDbType.Int).Value=emirId;UretimDecimalParametreEkle(k,"@m",miktar);k.ExecuteNonQuery();
 }

 /// <summary>Mamul stoğuna <paramref name="fark"/> kadar giriş (+) veya çıkış (−) yazar; bakiye ve hareket aynı işlemde güncellenir.</summary>
 static void MamulStokFarkiIsle(SqlConnection c,SqlTransaction t,int emirId,int mamulId,string mamulBirim,decimal fark,string aciklama){
  if(fark==0m)return;
  decimal miktar=Math.Abs(fark);
  if(fark>0){
   using var u=new SqlCommand("UPDATE dbo.StokBakiyeleri WITH(UPDLOCK,HOLDLOCK) SET Miktar=Miktar+@m,SonGuncelleme=SYSDATETIME() WHERE StokKartId=@s AND Birim=@b;IF @@ROWCOUNT=0 INSERT dbo.StokBakiyeleri(StokKartId,Birim,Miktar)VALUES(@s,@b,@m);",c,t);
   u.Parameters.Add("@s",SqlDbType.Int).Value=mamulId;u.Parameters.Add("@b",SqlDbType.NVarChar,20).Value=mamulBirim;UretimDecimalParametreEkle(u,"@m",miktar);u.ExecuteNonQuery();
  }else{
   using var u=new SqlCommand("UPDATE dbo.StokBakiyeleri WITH(UPDLOCK,HOLDLOCK) SET Miktar=Miktar-@m,SonGuncelleme=SYSDATETIME() WHERE StokKartId=@s AND Birim=@b AND Miktar>=@m;",c,t);
   u.Parameters.Add("@s",SqlDbType.Int).Value=mamulId;u.Parameters.Add("@b",SqlDbType.NVarChar,20).Value=mamulBirim;UretimDecimalParametreEkle(u,"@m",miktar);
   if(u.ExecuteNonQuery()!=1)throw new InvalidOperationException("Üretilen miktar azaltılamadı: mamul stoğunda "+miktar.ToString("0.###",CultureInfo.GetCultureInfo("tr-TR"))+" "+mamulBirim+" bulunmuyor (satılmış veya sevk edilmiş olabilir).");
  }
  using var h=new SqlCommand("INSERT dbo.StokHareketleri(StokKartId,HareketTipi,Yon,Miktar,Birim,Aciklama)VALUES(@s,@tip,@yon,@m,@b,@a);",c,t);
  h.Parameters.Add("@s",SqlDbType.Int).Value=mamulId;h.Parameters.Add("@tip",SqlDbType.NVarChar,40).Value=fark>0?"MANUEL_GIRIS":"MANUEL_CIKIS";h.Parameters.Add("@yon",SqlDbType.NChar,1).Value=fark>0?"G":"C";
  UretimDecimalParametreEkle(h,"@m",miktar);h.Parameters.Add("@b",SqlDbType.NVarChar,20).Value=mamulBirim;h.Parameters.Add("@a",SqlDbType.NVarChar,500).Value="Üretim emri #"+emirId+" · "+aciklama;h.ExecuteNonQuery();
 }

 static (int MamulId,string Birim) EmirMamulu(SqlConnection c,SqlTransaction t,int emirId){
  using var k=new SqlCommand("SELECT e.MamulStokId,s.Birim FROM dbo.UretimEmirleri e JOIN dbo.StokKartlari s ON s.Id=e.MamulStokId WHERE e.Id=@e",c,t);
  k.Parameters.Add("@e",SqlDbType.Int).Value=emirId;using var r=k.ExecuteReader();
  if(!r.Read()||r.IsDBNull(0))throw new InvalidOperationException("Üretim emrinin mamul stok kartı bulunamadı.");
  return (r.GetInt32(0),r.IsDBNull(1)?"":r.GetString(1));
 }

 /// <summary>Günlük kayıtta sağlam ürünü stoğa işler: önceden işlenen ile yeni toplam arasındaki fark kadar.</summary>
 static void GunlukUretimiStogaIsle(SqlConnection c,SqlTransaction t,int emirId,decimal uretilenToplam){
  decimal islenen=GunlukStokIslenen(c,t,emirId);decimal fark=uretilenToplam-islenen;if(fark==0m)return;
  var (mamul,birim)=EmirMamulu(c,t,emirId);
  if(string.IsNullOrWhiteSpace(birim))throw new InvalidOperationException("Mamul stok kartında birim tanımlı değil.");
  MamulStokFarkiIsle(c,t,emirId,mamul,birim,fark,fark>0?"günlük sağlam ürün girişi":"günlük üretim düzeltmesi");
  GunlukStokKaydet(c,t,emirId,uretilenToplam);
 }
}
