using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi
{
 public long AlisEvrakiIleDepoyaAl(SatinAlmaGirdisi g){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.AlisEvrakiIleDepoyaAl","",[g]);
  Text(g.No,1,80,"Evrak no");Text(g.Aciklama,1,400,"İrsaliye / açıklama");Currency(g.Para,g.Kur);
  if(g.Id.HasValue||g.Anahtar==Guid.Empty||g.Tarih.Date>DateTime.Today||g.Tarih.Year<2000||g.Kalemler is null||g.Kalemler.Length is <1 or >200)throw new ArgumentException("Alış evrakının tarih ve kalemlerini kontrol edin.");
  foreach(var k in g.Kalemler)PurchaseLine(k);
  using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"WAREHOUSE.VIEW");Yetki(c,t,"STOCK.RECEIVE");
  using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Kayit WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k OR(Tur='SatinAlma' AND JSON_VALUE(Veri,'$.no')=@n AND TRY_CONVERT(int,JSON_VALUE(Veri,'$.cari'))=@c)",("@k",g.Anahtar),("@n",g.No.Trim()),("@c",g.Cari)))if(Convert.ToInt32(q.ExecuteScalar())>0)throw new InvalidOperationException("Bu alış evrakı zaten kayıtlı; stok ikinci kez artırılmadı.");
  using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(HOLDLOCK) WHERE Id=@c AND Aktif=1",("@c",g.Cari)))if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Aktif tedarikçi seçin.");
  var order=g with{No=g.No.Trim(),Termin=g.Tarih,Aciklama="Depoya doğrudan alış · "+g.Aciklama};if(order.Aciklama.Length>400)order=order with{Aciklama=order.Aciklama[..400]};
  long id=Create(c,t,"SatinAlma",g.Anahtar,order);
  var receipt=new MalKabulGirdisi(Guid.NewGuid(),id,g.Tarih,g.Kalemler.Select((k,i)=>new MalKabulKalemi(i,k.Miktar,string.IsNullOrWhiteSpace(k.Parti)?"ALIS-"+id+"-"+(i+1):k.Parti.Trim(),false)).ToArray(),g.Aciklama);
  long received=Create(c,t,"MalKabul",receipt.Anahtar,receipt,"Tamamlandı",id);
  for(int i=0;i<g.Kalemler.Length;i++){
   var k=g.Kalemler[i];using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.StokKartlari WHERE Id=@s AND Aktif=1",("@s",k.Stok)))if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Aktif ürün seçin.");
   long lot;using(var q=Q(c,t,"INSERT dbo.MPX310_Lot(StokId,Kod,Kaynak,KaynakId,Kalite,BirimMaliyet) OUTPUT INSERTED.Id VALUES(@s,@p,'MalKabul',@i,N'Serbest',@m)",("@s",k.Stok),("@p",receipt.Kalemler[i].Parti),("@i",received),("@m",k.Fiyat*g.Kur)))lot=Convert.ToInt64(q.ExecuteScalar());
   LocationChange(c,t,lot,k.Raf,k.Miktar,"Mal kabul","MalKabul",received,g.No);AggregateChange(c,t,k.Stok,k.Miktar,"MAL_KABUL",g.No+" · "+receipt.Kalemler[i].Parti);
  }
  Event(c,t,id,"Alış evrakı depoya alındı",g.No);t.Commit();return id;
 }
}
