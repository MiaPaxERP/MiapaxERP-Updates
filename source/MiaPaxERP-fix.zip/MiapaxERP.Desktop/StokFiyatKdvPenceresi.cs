using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
namespace MiapaxERP.Desktop;

/// <summary>Mevcut ve üretilen stoklar için toplu birim fiyat, alış fiyatı ve KDV (dahil/hariç) girişi.</summary>
public sealed class StokFiyatKdvPenceresi:Window
{
 public sealed class Satir:INotifyPropertyChanged
 {
  public int Id{get;init;}public string Kod{get;init;}="";public string Ad{get;init;}="";public string Birim{get;init;}="";public bool Uretilen{get;init;}
  public string SonAlis{get;init;}="";
  decimal? alis,bayi,perakende;decimal kdv;bool alisDahil,satisDahil;string para="TRY";
  public decimal? Alis{get=>alis;set{alis=value;Degisti();}}
  public decimal? Bayi{get=>bayi;set{bayi=value;Degisti();}}
  public decimal? Perakende{get=>perakende;set{perakende=value;Degisti();}}
  public decimal Kdv{get=>kdv;set{kdv=value;Degisti();}}
  public string AlisKdv{get=>alisDahil?"Dahil":"Hariç";set{alisDahil=value=="Dahil";Degisti();}}
  public string SatisKdv{get=>satisDahil?"Dahil":"Hariç";set{satisDahil=value=="Dahil";Degisti();}}
  public string Para{get=>para;set{para=value;Degisti();}}
  public bool Degistirildi{get;private set;}
  public string AlisKdvHaric=>Alis is { } a?StokFiyatKdvServisi.KdvHaric(a,alisDahil,kdv).ToString("N2",tr):"";
  public string AlisKdvDahilTutar=>Alis is { } a?StokFiyatKdvServisi.KdvDahil(a,alisDahil,kdv).ToString("N2",tr):"";
  public string SatisKdvHaric=>Perakende is { } p?StokFiyatKdvServisi.KdvHaric(p,satisDahil,kdv).ToString("N2",tr):"";
  public string SatisKdvDahilTutar=>Perakende is { } p?StokFiyatKdvServisi.KdvDahil(p,satisDahil,kdv).ToString("N2",tr):"";
  public string Kar=>Perakende is { } p&&Alis is { } a&&a>0?"%"+((StokFiyatKdvServisi.KdvHaric(p,satisDahil,kdv)/StokFiyatKdvServisi.KdvHaric(a,alisDahil,kdv)-1)*100).ToString("N1",tr):"";
  internal void Yukle(StokFiyatSatiri s){alis=s.Alis;bayi=s.Bayi;perakende=s.Perakende;kdv=s.KdvOrani;alisDahil=s.AlisKdvDahil;satisDahil=s.SatisKdvDahil;para=s.ParaBirimi;Degistirildi=false;}
  internal StokFiyatGirdisi Girdi()=>new(Id,Alis,alisDahil,Bayi,Perakende,satisDahil,Kdv,Para);
  void Degisti(){Degistirildi=true;PropertyChanged?.Invoke(this,new(null));}
  public event PropertyChangedEventHandler? PropertyChanged;
 }
 static readonly CultureInfo tr=CultureInfo.GetCultureInfo("tr-TR");
 readonly StokFiyatKdvServisi service;readonly DataGrid grid=new(){AutoGenerateColumns=false,CanUserAddRows=false,CanUserDeleteRows=false,FrozenColumnCount=2};
 readonly TextBox find=new(){MinWidth=240,MaxLength=100};readonly System.Windows.Controls.CheckBox onlyProduced=new(){Content="Yalnız üretilen ürünler",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,8,0)};
 readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,0)};
 List<Satir> rows=[];

 public StokFiyatKdvPenceresi(string connection,int user,bool uretilen)
 {
  service=new(connection,user);Title="MiaPaxERP • Birim fiyat ve KDV";Width=1280;Height=760;WindowStartupLocation=WindowStartupLocation.CenterOwner;
  var root=new DockPanel{Margin=new Thickness(18)};Content=root;
  var top=new StackPanel();DockPanel.SetDock(top,Dock.Top);root.Children.Add(top);
  top.Children.Add(new TextBlock{Text=uretilen?"Üretilen ürünler · birim fiyat ve KDV":"Stoklar · birim fiyat ve KDV",FontSize=22,FontWeight=FontWeights.SemiBold});
  top.Children.Add(new TextBlock{Text="Alış ve satış fiyatını girdiğiniz gibi yazın; yanındaki sütundan KDV'nin dahil mi hariç mi olduğunu seçin. Program KDV hariç/dahil karşılıklarını ve brüt kârı hesaplar. Satış, teklif ve diğer modüller aynı fiyatları kullanır.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,10)});
  var bar=new WrapPanel();top.Children.Add(bar);bar.Children.Add(find);onlyProduced.IsChecked=uretilen;bar.Children.Add(onlyProduced);
  var load=Btn(bar,"Listele");var save=Btn(bar,"Değişiklikleri kaydet");
  var bulk=new ComboBox{ItemsSource=StokFiyatKdvServisi.KdvOranlari.Select(x=>"%"+x.ToString("0",tr)).ToList(),SelectedIndex=3,Width=80,Margin=new Thickness(16,0,6,6)};bar.Children.Add(new TextBlock{Text="Seçililere KDV:",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(16,0,0,6)});bar.Children.Add(bulk);
  var applyBulk=Btn(bar,"Uygula");
  var foot=new StackPanel();DockPanel.SetDock(foot,Dock.Bottom);root.Children.Add(foot);foot.Children.Add(status);
  root.Children.Add(grid);
  grid.SelectionMode=DataGridSelectionMode.Extended;
  Kolon("Kod","Kod",110,true);Kolon("Ürün","Ad",230,true);Kolon("Birim","Birim",55,true);
  Sayi("Alış fiyatı","Alis");Secim("Alış KDV","AlisKdv",["Hariç","Dahil"]);
  Sayi("Satış fiyatı","Perakende");Sayi("Bayi fiyatı","Bayi");Secim("Satış KDV","SatisKdv",["Dahil","Hariç"]);
  var kdvCol=new DataGridComboBoxColumn{Header="KDV %",ItemsSource=StokFiyatKdvServisi.KdvOranlari,SelectedItemBinding=new System.Windows.Data.Binding("Kdv"){UpdateSourceTrigger=UpdateSourceTrigger.PropertyChanged},Width=70};grid.Columns.Add(kdvCol);
  Secim("Döviz","Para",["TRY","USD","EUR","GBP"]);
  Kolon("Alış KDV hariç","AlisKdvHaric",100,true);Kolon("Alış KDV dahil","AlisKdvDahilTutar",100,true);Kolon("Satış KDV hariç","SatisKdvHaric",100,true);Kolon("Satış KDV dahil","SatisKdvDahilTutar",100,true);Kolon("Brüt kâr","Kar",70,true);Kolon("Son alış","SonAlis",120,true);
  load.Click+=async(_,_)=>await Yukle();find.KeyDown+=async(_,e)=>{if(e.Key==System.Windows.Input.Key.Enter)await Yukle();};
  onlyProduced.Click+=async(_,_)=>await Yukle();
  applyBulk.Click+=(_,_)=>{decimal oran=StokFiyatKdvServisi.KdvOranlari[Math.Max(0,bulk.SelectedIndex)];int n=0;foreach(var r in grid.SelectedItems.OfType<Satir>()){r.Kdv=oran;n++;}status.Text=n==0?"Önce satır seçin (Ctrl/Shift ile çoklu seçim).":n+" satıra %"+oran.ToString("0",tr)+" KDV uygulandı. Kaydetmeyi unutmayın.";};
  save.Click+=async(_,_)=>{
   grid.CommitEdit(DataGridEditingUnit.Row,true);var changed=rows.Where(x=>x.Degistirildi).ToList();
   if(changed.Count==0){status.Text="Değişiklik yok.";return;}
   save.IsEnabled=false;try{int n=await Task.Run(()=>service.Kaydet(changed.Select(x=>x.Girdi()).ToArray()));status.Text=n+" ürünün fiyat ve KDV bilgisi kaydedildi.";await Yukle();}
   catch(Exception e){DestekIzleme.Bildir(e,"STOK");status.Text="Kaydedilmedi: "+e.Message;}finally{save.IsEnabled=true;}
  };
  Closing+=(_,e)=>{if(rows.Any(x=>x.Degistirildi)&&MessageBox.Show(this,"Kaydedilmemiş fiyat değişiklikleri var. Kapatılsın mı?","Birim fiyat ve KDV",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)e.Cancel=true;};
  Loaded+=async(_,_)=>await Yukle();
 }

 async Task Yukle(){
  try{
   string q=find.Text;bool p=onlyProduced.IsChecked==true;var data=await Task.Run(()=>service.Liste(q,p));
   rows=data.Select(x=>{var r=new Satir{Id=x.Id,Kod=x.Kod,Ad=x.Ad+(x.Uretilen?" ⚙":""),Birim=x.Birim,Uretilen=x.Uretilen,SonAlis=x.SonAlis is { } s?s.ToString("N2",tr)+(x.SonAlisTarihi is { } d?" · "+d.ToString("dd.MM.yy",tr):""):""};r.Yukle(x);return r;}).ToList();
   grid.ItemsSource=rows;int fiyatsiz=rows.Count(x=>x.Perakende is null);
   status.Text=rows.Count+" ürün listelendi"+(fiyatsiz>0?" · "+fiyatsiz+" ürünün satış fiyatı yok.":".")+" ⚙ = üretilen ürün.";
  }catch(Exception e){DestekIzleme.Bildir(e,"STOK");status.Text=e.Message;}
 }
 Button Btn(Panel p,string t){var b=new Button{Content=t,Padding=new Thickness(12,6,12,6),Margin=new Thickness(0,0,8,6)};p.Children.Add(b);return b;}
 void Kolon(string h,string path,double w,bool ro)=>grid.Columns.Add(new DataGridTextColumn{Header=h,Binding=new System.Windows.Data.Binding(path),Width=w,IsReadOnly=ro});
 void Sayi(string h,string path)=>grid.Columns.Add(new DataGridTextColumn{Header=h,Binding=new System.Windows.Data.Binding(path){ConverterCulture=tr,StringFormat="0.####",TargetNullValue="",UpdateSourceTrigger=UpdateSourceTrigger.LostFocus},Width=95});
 void Secim(string h,string path,string[] items)=>grid.Columns.Add(new DataGridComboBoxColumn{Header=h,ItemsSource=items,SelectedItemBinding=new System.Windows.Data.Binding(path){UpdateSourceTrigger=UpdateSourceTrigger.PropertyChanged},Width=75});
}
