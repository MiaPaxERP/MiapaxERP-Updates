using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
 DispatcherTimer? nextTimer;bool nextBusy;int nextUser;DateTime nextDaily=DateTime.MinValue;CancellationTokenSource? nextStreamStop;HttpsIstemci? nextStream;
 void NextOlay()=>Dispatcher.BeginInvoke(new Action(async()=>await OzellikNextYenile()));
 void OzellikleriNextBagla(){
  HaberBandiniKur();var factory=new FrameworkElementFactory(typeof(Button));factory.SetValue(ContentControl.ContentProperty,"Barkodlar");factory.SetValue(FrameworkElement.MarginProperty,new Thickness(4));factory.AddHandler(Button.ClickEvent,new RoutedEventHandler((sender,e)=>{if(sender is FrameworkElement{DataContext:DataRowView row})StokBarkodlariniAc(Convert.ToInt32(row["Id"]));}));StokTablosu.Columns.Add(new DataGridTemplateColumn{Header="Çoklu barkod",CellTemplate=new DataTemplate{VisualTree=factory},Width=100});
  var parcaFactory=new FrameworkElementFactory(typeof(Button));parcaFactory.SetValue(ContentControl.ContentProperty,"Parçalar");parcaFactory.SetValue(FrameworkElement.MarginProperty,new Thickness(4));parcaFactory.AddHandler(Button.ClickEvent,new RoutedEventHandler((sender,e)=>{if(sender is FrameworkElement{DataContext:DataRowView row})StokParcalariniAc(Convert.ToInt32(row["Id"]),row.Row.Table.Columns.Contains("StokAdi")?Convert.ToString(row["StokAdi"])??"":"");}));StokTablosu.Columns.Add(new DataGridTemplateColumn{Header="Stok içinde stok",CellTemplate=new DataTemplate{VisualTree=parcaFactory},Width=100});
  nextTimer=new(){Interval=TimeSpan.FromSeconds(5)};nextTimer.Tick+=async(_,_)=>await OzellikNextYenile();Loaded+=(_,_)=>nextTimer.Start();Closed+=(_,_)=>{nextTimer.Stop();nextUser=0;nextStreamStop?.Cancel();if(nextStream is not null)nextStream.IsbirligiDegisti-=NextOlay;};
 }
 async Task OzellikNextYenile(){if(nextBusy||aktifKullanici is null)return;nextBusy=true;int user=aktifKullanici.KullaniciId;try{
  BtnBildirimler.Visibility=Visibility.Visible;BtnMesajlasma.Visibility=menuYetkileri.Contains("CHAT.VIEW")?Visibility.Visible:Visibility.Collapsed;
  if(nextUser!=user){nextStreamStop?.Cancel();if(nextStream is not null)nextStream.IsbirligiDegisti-=NextOlay;nextStream=HttpsOturumu.Istemci;if(nextStream is not null){nextStreamStop=new();nextStream.IsbirligiDegisti+=NextOlay;_ = nextStream.OlaylariIzle(nextStreamStop.Token);}var service=new IsbirligiServisi(baglantiAdresi,user);await Task.Run(service.Secimler);nextUser=user;await MenuYetkileriniYenileAsync();}
  await Task.Run(()=>new IsbirligiServisi(baglantiAdresi,user).LisansUyarilari());var rows=await Task.Run(()=>new IsbirligiServisi(baglantiAdresi,user).Bildirimler());if(aktifKullanici?.KullaniciId!=user)return;BtnBildirimler.ToolTip=null;BtnBildirimler.Content="🔔 Bildirim ("+rows.Count(x=>!x.Okundu)+")";SonDakikaDenetle(rows);
  if(DateTime.UtcNow-nextDaily>TimeSpan.FromMinutes(15)&&menuYetkileri.Contains("COST.PUBLISH")){nextDaily=DateTime.UtcNow;await Task.Run(()=>new DetayliMaliyetServisi(baglantiAdresi,user).Gunluk());}
 }catch(Exception e){BtnBildirimler.ToolTip="Bildirim bağlantısı: "+e.Message;}finally{nextBusy=false;}}
 void Mesajlasma_Click(object s,RoutedEventArgs e)=>IletisimiAc(true);
 void IletisimiAc(bool chat){if(aktifKullanici is null)return;try{new IletisimPenceresi(baglantiAdresi,aktifKullanici.KullaniciId,chat){Owner=this}.Show();}catch(Exception e){MessageBox.Show(e.Message,"İletişim");}}
 void HizliSatis_Click(object s,RoutedEventArgs e){if(aktifKullanici is null)return;try{new HizliSatisPenceresi(baglantiAdresi,aktifKullanici.KullaniciId){Owner=this}.Show();}catch(Exception ex){MessageBox.Show(ex.Message,"Hızlı satış");}}
 void DetayliMaliyet_Click(object s,RoutedEventArgs e){if(aktifKullanici is null)return;try{new DetayliMaliyetPenceresi(baglantiAdresi,aktifKullanici.KullaniciId){Owner=this}.Show();}catch(Exception ex){MessageBox.Show(ex.Message,"MRP ve maliyet");}}
 void StokParcalariniAc(int stock,string ad){if(aktifKullanici is null)return;try{new StokBilesenPenceresi(baglantiAdresi,aktifKullanici.KullaniciId,stock,ad.Length>0?ad:"Stok #"+stock){Owner=this}.ShowDialog();}catch(Exception e){MessageBox.Show(e.Message,"Parçalar");}}
 void StokBarkodlariniAc(int stock){if(aktifKullanici is null)return;try{new StokBarkodPenceresi(baglantiAdresi,aktifKullanici.KullaniciId,stock){Owner=this}.ShowDialog();}catch(Exception e){MessageBox.Show(e.Message,"Barkodlar");}}
 async void UretimEmriPdf_Click(object s,RoutedEventArgs e)=>await UretimPdf(false);
 async void UretimPaketPdf_Click(object s,RoutedEventArgs e)=>await UretimPdf(true);
 void UretimPaketEtiket_Click(object s,RoutedEventArgs e){if(aktifKullanici is null||UretimEmirleriTablosu.SelectedItem is not DataRowView row){MessageBox.Show("Önce paketlenmiş üretim emrini seçin.");return;}new UrunEtiketPenceresi(baglantiAdresi,aktifKullanici.KullaniciId,Convert.ToInt32(row["Id"]),true){Owner=this}.ShowDialog();}
 async Task UretimPdf(bool packages){if(aktifKullanici is null||UretimEmirleriTablosu.SelectedItem is not DataRowView row){MessageBox.Show("Önce üretim emri seçin.");return;}try{int order=Convert.ToInt32(row["Id"]);var service=new UretimPdfServisi(baglantiAdresi,aktifKullanici.KullaniciId);var data=await Task.Run(()=>service.Rapor(order,packages));await PdfTabloRaporu.Kaydet(this,packages?"Paketleme kayıtları":"Üretim emri",data);}catch(Exception e){MessageBox.Show(e.Message,"Üretim PDF");}}
}
