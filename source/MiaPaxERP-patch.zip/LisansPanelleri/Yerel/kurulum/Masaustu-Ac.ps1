param([switch]$TarayiciAcma)
$ErrorActionPreference='Stop'
$panelRoot=Split-Path $PSScriptRoot -Parent
$privateFolder=Join-Path $env:USERPROFILE 'BoruERP_GizliAnahtarlar\BayiPaneli30'
$url='http://127.0.0.1:5290'
function PanelHazir {
    try { $health=Invoke-RestMethod ($url+'/api/health') -TimeoutSec 2; return ($health.ok -eq $true -and $health.version -like '3.0.*' -and $health.support -eq $true -and $health.moduleDates -eq $true -and $health.announcements -eq $true) } catch { return $false }
}
$mutex=New-Object Threading.Mutex($false,'Local\BoruERPPanelBaslat30')
$locked=$false
try {
    $locked=$mutex.WaitOne(20000)
    if(-not $locked) { throw 'Panel başlatma işlemi sürüyor. Birkaç saniye sonra yeniden deneyin.' }
    if(-not (PanelHazir)) {
        if(-not (Test-Path -LiteralPath (Join-Path $privateFolder 'portal.sqlite'))) { throw 'Panel veritabanı bulunamadı.' }
        $nodeCommand=Get-Command node -ErrorAction SilentlyContinue
        $nodePath=if($nodeCommand) {$nodeCommand.Source} else {Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'}
        if(-not (Test-Path -LiteralPath $nodePath)) { throw 'Node.js 24 bulunamadı. https://nodejs.org/en/download adresinden kurulmalıdır.' }
        $env:DB_PATH=Join-Path $privateFolder 'portal.sqlite'
        $env:PORTAL_SECRET_FILE=Join-Path $privateFolder 'secrets.dpapi'
        $env:PUBLIC_ORIGIN=$url
        $env:HOST='127.0.0.1'
        $env:PORT='5290'
        $env:PAYMENTS_ENABLED='false'
        $serverScript=Join-Path $panelRoot 'src\server.js'
        # Preflight under the interactive Windows account before replacing an older process.
        Push-Location $panelRoot
        try {
            & $nodePath --input-type=module -e "import {loadConfig,validateConfig} from './src/config.js';validateConfig(loadConfig());"
            if($LASTEXITCODE -ne 0){throw 'Panel ayarları doğrulanamadı; çalışan eski panel korunuyor.'}
        } finally { Pop-Location }
        $listener=Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 5290 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
        if($listener){
            $running=Get-CimInstance Win32_Process -Filter ("ProcessId="+$listener.OwningProcess)
            if($running.Name -ne 'node.exe' -or !$running.CommandLine.Contains($serverScript)){throw '5290 portunu farklı bir program kullanıyor; kapatılmadı.'}
            $env:MIAPAX_SUPPORT_BACKUP=Join-Path $privateFolder ('portal-destek-oncesi-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.sqlite')
            & $nodePath --input-type=module -e "import {DatabaseSync} from 'node:sqlite';const db=new DatabaseSync(process.env.DB_PATH);db.exec('PRAGMA busy_timeout=5000');db.exec('VACUUM INTO '+String.fromCharCode(39)+process.env.MIAPAX_SUPPORT_BACKUP.replaceAll(String.fromCharCode(39),String.fromCharCode(39).repeat(2))+String.fromCharCode(39));db.close();"
            if($LASTEXITCODE -ne 0){throw 'Panel yedeği alınamadı; çalışan eski panel korunuyor.'}
            Stop-Process -Id $listener.OwningProcess -ErrorAction Stop
            Start-Sleep -Milliseconds 600
        }
        $child=Start-Process -FilePath $nodePath -ArgumentList ('"'+$serverScript+'"') -WorkingDirectory $panelRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $privateFolder 'sunucu.log') -RedirectStandardError (Join-Path $privateFolder 'sunucu-hata.log')
        for($attempt=0;$attempt -lt 40;$attempt++) {
            if(PanelHazir) { break }
            if($child.HasExited) { throw 'Panel sunucusu açılamadı. Özel panel klasöründeki sunucu-hata.log dosyasını kontrol edin.' }
            Start-Sleep -Milliseconds 250
        }
        if(-not (PanelHazir)) { throw 'Panel zamanında açılamadı. sunucu-hata.log dosyasını kontrol edin.' }
    }
    if(-not $TarayiciAcma) { Start-Process $url }
    Write-Output 'MiaPax Yönetim Paneli hazır: http://127.0.0.1:5290'
} catch {
    $message=$_.Exception.Message
    if(-not $TarayiciAcma) { Add-Type -AssemblyName PresentationFramework; [Windows.MessageBox]::Show($message,'MiaPax Yönetim Paneli') | Out-Null }
    throw
} finally {
    if($locked) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
