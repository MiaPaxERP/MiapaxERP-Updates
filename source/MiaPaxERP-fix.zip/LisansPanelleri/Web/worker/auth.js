// Bağımsız barındırma için yönetici kimlik doğrulaması.
// AUTH_MODE=password (önerilen): kullanıcı adı + parola, D1'de tutulan HttpOnly oturum çerezi.
// AUTH_MODE=sites: yalnız ChatGPT Sites içinde; oai-authenticated-user-id başlığına yalnız orada güvenilir.
// AUTH_MODE ayarlı değilse geriye uyumluluk için ADMIN_USER_ID varsa sites, yoksa password kullanılır.
const enc=new TextEncoder();
export const COOKIE='__Host-lisans_oturum';
const SESSION_SECONDS=12*3600;
const ITERATIONS=100000; // Cloudflare Workers PBKDF2 üst sınırı
const USER_RE=/^[a-z0-9._-]{3,40}$/;
const fail=(message,status=400)=>{throw Object.assign(new Error(message),{status});};
const hex=b=>Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('');
const b64=v=>btoa(String.fromCharCode(...new Uint8Array(v)));
const from64=v=>Uint8Array.from(atob(v),x=>x.charCodeAt(0));
const sha=async v=>hex(await crypto.subtle.digest('SHA-256',enc.encode(v)));

export function authMode(env){
 if(env.AUTH_MODE==='password'||env.AUTH_MODE==='sites')return env.AUTH_MODE;
 if(env.AUTH_MODE)fail('AUTH_MODE yalnız password veya sites olabilir.',503);
 return env.ADMIN_USER_ID?'sites':'password';
}

async function derive(password,salt,iterations){
 const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
 return new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt,iterations},key,256));
}
export async function hashPassword(password){
 const salt=crypto.getRandomValues(new Uint8Array(16));
 return `pbkdf2-sha256$${ITERATIONS}$${b64(salt)}$${b64(await derive(password,salt,ITERATIONS))}`;
}
const DUMMY='pbkdf2-sha256$100000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=';
export async function verifyPassword(password,stored){
 const p=String(stored||DUMMY).split('$');if(p.length!==4||p[0]!=='pbkdf2-sha256')return false;
 const iterations=Number(p[1]);if(!Number.isInteger(iterations)||iterations<10000||iterations>ITERATIONS)return false;
 const expected=from64(p[3]),actual=await derive(password,from64(p[2]),iterations);
 if(expected.length!==actual.length)return false;let d=0;for(let i=0;i<actual.length;i++)d|=actual[i]^expected[i];return d===0&&!!stored;
}
export function validPassword(p){
 if(typeof p!=='string'||p.length<12||p.length>128||/[\x00-\x1f]/.test(p))fail('Parola 12–128 karakter olmalı.');
 if(!/[a-zçğıöşü]/i.test(p)||!/[0-9]/.test(p))fail('Parola en az bir harf ve bir rakam içermeli.');
 return p;
}
const validUser=u=>{u=typeof u==='string'?u.trim().toLowerCase():'';if(!USER_RE.test(u))fail('Kullanıcı adı 3–40 karakter; küçük harf, rakam, nokta, tire veya alt çizgi olmalı.');return u;};

function cookieToken(req){
 for(const part of (req.headers.get('cookie')||'').split(';')){const i=part.indexOf('=');if(i>0&&part.slice(0,i).trim()===COOKIE){const v=part.slice(i+1).trim();return /^[a-f0-9]{64}$/.test(v)?v:null;}}
 return null;
}
const setCookie=token=>`${COOKIE}=${token}; Path=/; Max-Age=${SESSION_SECONDS}; HttpOnly; Secure; SameSite=Lax`;
const clearCookie=`${COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax`;

/** Parola modunda oturumdaki kullanıcıyı döndürür; yoksa null. */
export async function sessionUser(req,env){
 const token=cookieToken(req);if(!token)return null;
 const row=await env.DB.prepare('SELECT u.username,u.must_change FROM admin_sessions s JOIN admin_users u ON u.username=s.username WHERE s.token_hash=? AND s.expires_at>? AND u.active=1').bind(await sha(token),Math.floor(Date.now()/1000)).first();
 return row?{username:row.username,mustChange:!!row.must_change}:null;
}

/** Yönetim API'leri için kimlik. Parola modunda oai başlığı hiç okunmaz. */
export async function adminActor(req,env){
 if(authMode(env)==='sites'){
  const id=req.headers.get('oai-authenticated-user-id');if(!id)fail('Oturum açın.',401);if(!env.ADMIN_USER_ID)fail('Yönetici hesabı henüz bağlanmadı.',503);if(id!==env.ADMIN_USER_ID)fail('Bu panel hesabınıza açık değil.',403);return id;
 }
 const user=await sessionUser(req,env);if(!user)fail('Oturum açın.',401);if(user.mustChange)fail('Önce geçici parolanızı değiştirin.',403);return 'admin:'+user.username;
}

export const hasAdmins=async env=>!!(await env.DB.prepare('SELECT 1 AS x FROM admin_users LIMIT 1').first());
const log=(env,actor,action,detail='')=>env.DB.prepare('INSERT INTO audit(at,actor,action,record_id,detail) VALUES(?,?,?,?,?)').bind(new Date().toISOString(),actor,action,'',detail).run();

async function newSession(env,username){
 const token=hex(crypto.getRandomValues(new Uint8Array(32))),now=Math.floor(Date.now()/1000);
 await env.DB.batch([env.DB.prepare('DELETE FROM admin_sessions WHERE expires_at<=?').bind(now),env.DB.prepare('INSERT INTO admin_sessions(token_hash,username,expires_at,created_at) VALUES(?,?,?,?)').bind(await sha(token),username,now+SESSION_SECONDS,new Date().toISOString())]);
 return token;
}

/** /api/auth/* uçları. h: {body,limited,json} index.js yardımcıları. */
export async function authRoute(req,env,url,h){
 const mode=authMode(env),ip=req.headers.get('cf-connecting-ip')||'unknown';
 if(req.method!=='POST')fail('Yöntem geçersiz.',405);
 if(req.headers.get('origin')!==url.origin)fail('İstek kaynağı geçersiz.',403);
 if(url.pathname==='/api/auth/logout'){
  if(mode==='sites')return new Response(null,{status:303,headers:{location:'/signout-with-chatgpt?return_to=%2F'}});
  const token=cookieToken(req);if(token)await env.DB.prepare('DELETE FROM admin_sessions WHERE token_hash=?').bind(await sha(token)).run();
  return new Response(null,{status:303,headers:{location:'/','set-cookie':clearCookie,'cache-control':'no-store'}});
 }
 if(mode!=='password')fail('Bu kurulum ChatGPT Sites oturumu kullanıyor.',404);
 const withCookie=(data,token)=>{const r=h.json(data);r.headers.append('set-cookie',token?setCookie(token):clearCookie);return r;};
 if(url.pathname==='/api/auth/setup'){
  await h.limited(env.DB,'setup:'+ip,5);
  const b=await h.body(req);
  if(!env.ADMIN_SETUP_TOKEN||env.ADMIN_SETUP_TOKEN.length<24)fail('Kurulum anahtarı (ADMIN_SETUP_TOKEN) sunucuda tanımlı değil.',503);
  const given=typeof b.setupToken==='string'?b.setupToken:'';
  if(await sha(given)!==await sha(env.ADMIN_SETUP_TOKEN))fail('Kurulum anahtarı yanlış.',403);
  const username=validUser(b.username),password=validPassword(b.password),now=new Date().toISOString();
  const r=await env.DB.prepare('INSERT INTO admin_users(username,password_hash,must_change,active,created_at,updated_at) SELECT ?,?,0,1,?,? WHERE NOT EXISTS(SELECT 1 FROM admin_users) RETURNING username').bind(username,await hashPassword(password),now,now).first();
  if(!r)fail('Yönetici hesabı zaten oluşturulmuş. Giriş yapın.',409);
  await log(env,'admin:'+username,'İlk yönetici hesabı oluşturuldu');
  return withCookie({ok:true},await newSession(env,username));
 }
 if(url.pathname==='/api/auth/login'){
  await h.limited(env.DB,'login-ip:'+ip,10);
  const b=await h.body(req);const username=typeof b.username==='string'?b.username.trim().toLowerCase().slice(0,40):'';
  await h.limited(env.DB,'login-user:'+username,8);
  const row=USER_RE.test(username)?await env.DB.prepare('SELECT username,password_hash FROM admin_users WHERE username=? AND active=1').bind(username).first():null;
  const ok=await verifyPassword(typeof b.password==='string'?b.password.slice(0,128):'',row?.password_hash);
  if(!row||!ok){await log(env,'ip:'+ip,'Başarısız yönetici girişi',username);fail('Kullanıcı adı veya parola hatalı.',401);}
  await log(env,'admin:'+username,'Yönetici girişi');
  return withCookie({ok:true},await newSession(env,username));
 }
 if(url.pathname==='/api/auth/password'){
  const user=await sessionUser(req,env);if(!user)fail('Oturum açın.',401);
  await h.limited(env.DB,'password:'+user.username,5);
  const b=await h.body(req);const row=await env.DB.prepare('SELECT password_hash FROM admin_users WHERE username=?').bind(user.username).first();
  if(!await verifyPassword(typeof b.current==='string'?b.current.slice(0,128):'',row?.password_hash))fail('Mevcut parola hatalı.',403);
  const next=validPassword(b.password);if(next===b.current)fail('Yeni parola eskisiyle aynı olamaz.');
  await env.DB.batch([env.DB.prepare('UPDATE admin_users SET password_hash=?,must_change=0,updated_at=? WHERE username=?').bind(await hashPassword(next),new Date().toISOString(),user.username),env.DB.prepare('DELETE FROM admin_sessions WHERE username=?').bind(user.username)]);
  await log(env,'admin:'+user.username,'Yönetici parolası değiştirildi');
  return withCookie({ok:true},await newSession(env,user.username));
 }
 fail('İşlem bulunamadı.',404);
}
