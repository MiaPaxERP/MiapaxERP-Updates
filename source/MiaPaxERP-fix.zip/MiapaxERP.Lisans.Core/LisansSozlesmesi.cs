using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MiapaxERP.Lisans.Core;

public sealed record Sektor(string Kod,string Ad,string UretimAdi,string StokAdi,string Aciklama,string[] OnerilenModuller)
{
    /// <summary>URETIM, TICARET, YEMEICME veya HIZMET.</summary>
    public string Grup{get;init;}="HIZMET";
    /// <summary>Ekran davranışı: BORU, RESTORAN, URETIM, TICARET, HIZMET veya GENEL.</summary>
    public string Davranis{get;init;}="GENEL";
    /// <summary>2.8.x ve önceki istemcilere imzalanan eski sektör kodu.</summary>
    public string EskiKod{get;init;}="GENEL";
    public string[] AltDallar{get;init;}=[];
    public string[] Birimler{get;init;}=[];
    public string CariAdi{get;init;}="Cari";
    public string GrupAdi=>UrunKatalogu.Gruplar.FirstOrDefault(g=>g.Kod==Grup)?.Ad??Grup;
    public string GrupluAd=>GrupAdi+" › "+Ad;
}
public sealed record SektorGrubu(string Kod,string Ad);
public sealed record Modul(string Kod,string Ad);
public static class UrunKatalogu
{
    /// <summary>İstemcinin tanıdığı sektör kataloğu sürümü; etkinleştirme isteğinde sunucuya gönderilir.</summary>
    public const int SektorKataloguSurumu=2;
    public static readonly string[] EskiSektorler=["BORU","YEDEK","RESTORAN","SUNGER","GENEL"];
    public static readonly Modul[] Moduller=[new("STOK","Stok ve hareketler"),new("URETIM","Reçete ve üretim"),new("SATIS","Cari ve satış"),new("FINANS","Muhasebe ve finans"),new("SATINALMA","Satın alma"),new("IK","İnsan kaynakları"),new("CRM","CRM"),new("ETICARET","E-ticaret"),new("DISTICARET","Dış ticaret"),new("KROKI","Sulama ve kroki"),new("RESTORAN","Masa, adisyon ve mutfak"),new("MOBIL","Mobil saha ve yönetim"),new("LABORATUVAR","Laboratuvar ve kalite kontrol"),new("RAPOR","Raporlar"),new("MAKINA","Makine yönetimi ve canlı üretim izleme"),new("DEPO","Depo, raf ve sevkiyat"),new("MALIYET","Detaylı maliyet ve MRP"),new("SAHA","Saha ziyaret ve harita"),new("CEKSENET","Çek ve senet"),new("BASINC","Basınç testi"),new("TAKVIM","İş takvimi ve hatırlatmalar"),new("ILETISIM","Mesajlaşma ve duyurular"),new("ASISTAN","Yapay zekâ asistanı ve akıllı öneriler"),new("PIYASA","Haber ve piyasa takibi")];
    /// <summary>Modül kataloğu sürümü: 3 ile alt modüller ayrı satılır. Daha eski lisanslarda alt modül, üst modülle birlikte açık sayılır.</summary>
    public const int ModulKataloguSurumu=3;
    /// <summary>Katalog 3 ile ayrılan modüller ve eski lisanslarda kendilerini açan üst modül ("*" = eski lisanslarda her zaman açık).</summary>
    public static readonly IReadOnlyDictionary<string,string> AltModuller=new Dictionary<string,string>(StringComparer.Ordinal){["DEPO"]="STOK",["MALIYET"]="URETIM",["SAHA"]="CRM",["CEKSENET"]="FINANS",["BASINC"]="LABORATUVAR",["TAKVIM"]="*",["ILETISIM"]="*",["ASISTAN"]="*",["PIYASA"]="*"};
    /// <summary>Katalog 3'ten önceki (2.9.1 ve eski) istemcilerin tanıdığı modüller.</summary>
    public static readonly string[] EskiModuller=["STOK","URETIM","SATIS","FINANS","SATINALMA","IK","CRM","ETICARET","DISTICARET","KROKI","RESTORAN","MOBIL","LABORATUVAR","RAPOR"];
    public static readonly SektorGrubu[] Gruplar=[new("URETIM","Üretim"),new("TICARET","Ticaret"),new("YEMEICME","Yeme-içme"),new("HIZMET","Hizmet ve diğer")];
    static Sektor S(string kod,string ad,string grup,string davranis,string eski,string uretim,string stok,string cari,string aciklama,string[] moduller,string[] dallar,string[] birimler)=>new(kod,ad,uretim,stok,aciklama,moduller){Grup=grup,Davranis=davranis,EskiKod=eski,AltDallar=dallar,Birimler=birimler,CariAdi=cari};
    public static readonly Sektor[] Sektorler=[
        S("BORU","Boru ve plastik profil üretimi","URETIM","BORU","BORU","Üretim ve paketleme","Hammadde / mamul","Müşteri / bayi","Metre, adet ve KG kendi stok birimleriyle izlenir; paketleme ve sulama projeleri.",["STOK","URETIM","SATIS","FINANS","KROKI","RAPOR"],["PE / PPRC boru","Damla sulama","Profil ve hortum"],["Metre","KG","Adet","Top"]),
        S("SUNGER","Sünger ve köpük üretimi","URETIM","URETIM","SUNGER","Üretim / kesim reçeteleri","Hammadde / sünger","Müşteri","KG, M3, M2 ve adet dönüşümleri yalnız açık reçete verisiyle yapılır.",["STOK","URETIM","SATIS","FINANS","RAPOR"],["Yatak / döşeme süngeri","Kesim ve levha","Ambalaj köpüğü"],["KG","M3","M2","Adet"]),
        S("PLASTIK","Plastik ve ambalaj üretimi","URETIM","URETIM","GENEL","Enjeksiyon / ekstrüzyon emirleri","Granül / mamul","Müşteri","Granül tüketimi, kalıp / makine bazlı üretim emirleri ve kalite kontrol.",["STOK","URETIM","SATIS","FINANS","SATINALMA","LABORATUVAR","RAPOR"],["Enjeksiyon","Şişirme","Film ve poşet","Ambalaj"],["KG","Adet","Koli","Rulo"]),
        S("GIDA","Gıda üretimi","URETIM","URETIM","GENEL","Gıda reçeteleri / partiler","Hammadde / mamul","Müşteri / bayi","Parti ve son kullanma takibi, reçeteli tüketim ve kalite kayıtları.",["STOK","URETIM","SATIS","FINANS","SATINALMA","LABORATUVAR","RAPOR"],["Unlu mamul","Süt ürünleri","Et ürünleri","Konserve / kuru gıda","İçecek"],["KG","Litre","Adet","Koli"]),
        S("TEKSTIL","Tekstil ve konfeksiyon","URETIM","URETIM","GENEL","Kesim / dikim emirleri","Kumaş / ürün","Müşteri","Kumaş metre, beden-renk varyantı, kesim-dikim emirleri ve fason işçilik.",["STOK","URETIM","SATIS","FINANS","SATINALMA","IK","RAPOR"],["Hazır giyim","Ev tekstili","Kumaş / iplik","Fason üretim"],["Metre","Adet","KG","Top"]),
        S("METAL","Metal işleme ve makine imalatı","URETIM","URETIM","GENEL","İş emirleri","Malzeme / parça","Müşteri","Sac, profil ve parça tüketimi; iş emri ve makine süresi takibi.",["STOK","URETIM","SATIS","FINANS","SATINALMA","RAPOR"],["Talaşlı imalat","Sac işleme","Kaynaklı imalat","Makine imalatı"],["KG","Adet","Metre","Ton"]),
        S("MOBILYA","Mobilya ve ahşap","URETIM","URETIM","GENEL","Üretim reçeteleri","Levha / ürün","Müşteri","Levha, kenar bandı ve aksesuar tüketimiyle ürün reçetesi.",["STOK","URETIM","SATIS","FINANS","SATINALMA","RAPOR"],["Ev mobilyası","Ofis mobilyası","Mutfak / dolap","Ahşap doğrama"],["Adet","M2","Metre","Takım"]),
        S("KIMYA","Kimya, boya ve temizlik ürünleri","URETIM","URETIM","GENEL","Formül / parti üretimi","Hammadde / ürün","Müşteri / bayi","Formül bazlı parti üretimi, ambalajlama ve kalite kontrol.",["STOK","URETIM","SATIS","FINANS","SATINALMA","LABORATUVAR","RAPOR"],["Boya / vernik","Temizlik ürünleri","Kozmetik","Gübre / tarım kimyasalı"],["KG","Litre","Adet","Koli"]),
        S("YAPIURETIM","Yapı malzemesi üretimi","URETIM","URETIM","GENEL","Üretim partileri","Hammadde / ürün","Müşteri / şantiye","Parti üretimi, numune / dayanım kayıtları ve sevkiyat.",["STOK","URETIM","SATIS","FINANS","LABORATUVAR","RAPOR"],["Hazır beton","Briket / parke taşı","Prefabrik","Çatı / yalıtım"],["M3","Ton","Adet","M2"]),
        S("YEDEK","Yedek parça ticareti","TICARET","TICARET","YEDEK","Montaj / kit hazırlama","Parça ve ürün","Müşteri","Parça kodu, muadil ve birim bazında stok, alış ve satış.",["STOK","SATIS","FINANS","SATINALMA","RAPOR"],["Otomotiv","İş makinesi","Tarım makinesi","Beyaz eşya"],["Adet","Takım","Litre"]),
        S("TOPTAN","Toptan ticaret ve dağıtım","TICARET","TICARET","GENEL","Paketleme / set hazırlama","Ürün","Müşteri / bayi","Çok depolu stok, müşteri fiyat listeleri, saha satışı ve sevkiyat.",["STOK","SATIS","FINANS","SATINALMA","CRM","MOBIL","RAPOR"],["Gıda toptan","Kırtasiye / ambalaj","Elektrik / elektronik","Hırdavat"],["Adet","Koli","KG","Paket"]),
        S("PERAKENDE","Perakende ve market","TICARET","TICARET","GENEL","Paketleme","Ürün","Müşteri","Barkodlu hızlı satış, kasa, raf ve stok sayımı.",["STOK","SATIS","FINANS","SATINALMA","RAPOR"],["Market / bakkal","Giyim mağazası","Elektronik","Kırtasiye / kitap"],["Adet","KG","Paket"]),
        S("YAPIMARKET","Yapı ve inşaat malzemesi ticareti","TICARET","TICARET","GENEL","Paketleme","Malzeme","Müşteri / usta","Ton, M2 ve torba gibi farklı birimlerle stok; şantiye teslimatı.",["STOK","SATIS","FINANS","SATINALMA","RAPOR"],["Nalbur / hırdavat","Seramik / vitrifiye","Demir / çimento","Boya / yalıtım"],["Adet","KG","Ton","M2","Torba"]),
        S("ONLINE","E-ticaret satıcısı","TICARET","TICARET","GENEL","Paketleme / kargo hazırlama","Ürün","Müşteri","Web sitesi ve pazaryeri siparişleri, stok eşitleme ve kargo.",["STOK","SATIS","FINANS","ETICARET","RAPOR"],["Pazaryeri satıcısı","Kendi web mağazası","Sosyal medya satışı"],["Adet","Paket"]),
        S("RESTORAN","Restoran ve lokanta","YEMEICME","RESTORAN","RESTORAN","Mutfak reçeteleri","Malzeme / menü","Müşteri","Masa, adisyon, mutfak, ödeme ve reçeteli tüketim.",["STOK","URETIM","SATIS","FINANS","RESTORAN","RAPOR"],["Restoran","Esnaf lokantası","Fast food"],["Porsiyon","Adet","KG","Litre"]),
        S("KAFE","Kafe ve kahve dükkânı","YEMEICME","RESTORAN","RESTORAN","Menü reçeteleri","Malzeme / menü","Müşteri","Masa / paket sipariş, adisyon ve menü reçeteleriyle malzeme tüketimi.",["STOK","URETIM","SATIS","FINANS","RESTORAN","RAPOR"],["Kafe","Kahve dükkânı","Pastane-kafe","Bar"],["Adet","Porsiyon","Litre","KG"]),
        S("FIRIN","Fırın ve pastane","YEMEICME","URETIM","GENEL","Günlük üretim reçeteleri","Hammadde / ürün","Müşteri","Günlük üretim planı, reçeteli un-malzeme tüketimi ve tezgâh satışı.",["STOK","URETIM","SATIS","FINANS","SATINALMA","RAPOR"],["Ekmek fırını","Pastane","Unlu mamul imalathanesi"],["Adet","KG","Tepsi"]),
        S("CATERING","Catering ve toplu yemek","YEMEICME","URETIM","GENEL","Menü / porsiyon üretimi","Malzeme / menü","Kurum / müşteri","Kurum sözleşmeleri, günlük porsiyon planı ve porsiyon maliyeti.",["STOK","URETIM","SATIS","FINANS","SATINALMA","RAPOR"],["Kurumsal yemek","Okul / hastane mutfağı","Organizasyon"],["Porsiyon","KG","Litre"]),
        S("SERVIS","Teknik servis ve tamir","HIZMET","HIZMET","GENEL","Servis / iş emirleri","Yedek parça / sarf","Müşteri","Servis kaydı, parça kullanımı, işçilik ve tahsilat.",["STOK","SATIS","FINANS","CRM","MOBIL","RAPOR"],["Beyaz eşya / elektronik","Oto servis","Klima / ısıtma","Bilgisayar / telefon"],["Adet","Saat"]),
        S("TARIM","Tarım ve sulama","HIZMET","HIZMET","GENEL","Proje / uygulama","Malzeme / ürün","Çiftçi / müşteri","Sulama projeleri, kroki, saha ziyaretleri ve malzeme teklifleri.",["STOK","SATIS","FINANS","KROKI","CRM","MOBIL","RAPOR"],["Sulama sistemleri","Tarım girdileri","Sera","Peyzaj"],["Adet","Metre","KG","Dekar"]),
        S("INSAAT","İnşaat ve taahhüt","HIZMET","HIZMET","GENEL","Proje / hakediş","Malzeme","İşveren / taşeron","Şantiye bazlı malzeme, taşeron ve hakediş takibi.",["STOK","SATIS","FINANS","SATINALMA","IK","RAPOR"],["Konut","Altyapı","Tadilat / dekorasyon","Elektrik / mekanik taahhüt"],["M2","M3","Ton","Adet"]),
        S("LOJISTIK","Lojistik ve nakliye","HIZMET","HIZMET","GENEL","Sefer / sevkiyat","Depo stoğu","Müşteri","Sefer, araç, sürücü ve depo hareketleri.",["STOK","SATIS","FINANS","IK","MOBIL","RAPOR"],["Yurt içi nakliye","Depolama","Kurye","Uluslararası taşımacılık"],["Sefer","KG","Palet","Adet"]),
        S("GENEL","Genel KOBİ / işletme","HIZMET","GENEL","GENEL","Reçeteli üretim","Stok kartları","Cari","Sektör bağımsız stok, cari, satış ve muhasebe.",["STOK","SATIS","FINANS","RAPOR"],["Hizmet işletmesi","Danışmanlık","Diğer"],["Adet","KG","Saat"])
    ];
    public static IEnumerable<Sektor> GrubunSektorleri(string grup)=>Sektorler.Where(x=>x.Grup==grup);
    public static string Davranis(string? code)=>Sektorler.SingleOrDefault(x=>x.Kod==code)?.Davranis??"GENEL";
    /// <summary>Sektörün üretim / reçete ekranları kullanması beklenir mi?</summary>
    public static bool UretimOdakli(string? code)=>Davranis(code) is "BORU" or "URETIM" or "RESTORAN";
    /// <summary>Katalog sürümü bildirmeyen eski (2.8.x) istemciye gönderilecek sektör kodu.</summary>
    public static string EskiIstemciKodu(string? code){var s=Sektorler.SingleOrDefault(x=>x.Kod==code);return s is null?"GENEL":EskiSektorler.Contains(s.Kod)?s.Kod:s.EskiKod;}
    public static Sektor SektorBul(string code)=>Sektorler.SingleOrDefault(x=>x.Kod==code)??throw new ArgumentException("Sektör bulunamadı.");
    public static void ModulDogrula(IEnumerable<string> modules)
    {
        var m=modules.ToHashSet(StringComparer.Ordinal);
        if(m.Count==0||m.Any(x=>!Moduller.Any(a=>a.Kod==x)))throw new ArgumentException("Geçersiz modül seçimi.");
        foreach(var (parent,required) in new[]{("LABORATUVAR","STOK"),("URETIM","STOK"),("RESTORAN","STOK"),("RESTORAN","SATIS"),("RESTORAN","FINANS"),("RESTORAN","URETIM")}.Concat(AltModuller.Where(x=>x.Value!="*").Select(x=>(x.Key,x.Value))))
            if(m.Contains(parent)&&!m.Contains(required))throw new ArgumentException(parent+" için "+required+" modülü gerekli.");
    }
    public static string? YetkiModulu(string permission)=>permission.Split('.')[0] switch
    {"MOBILE"=>"MOBIL","COST"=>"MALIYET","QUICKSALE"=>"SATIS","KROKI"=>"KROKI","STOCK"=>"STOK","WAREHOUSE" or "SHIPMENT"=>"DEPO","PRODUCTION"=>"URETIM","CUSTOMER" or "SALES"=>"SATIS","FINANCE" or "ACCOUNTING"=>"FINANS","CHECKNOTE"=>"CEKSENET","PURCHASE"=>"SATINALMA","HR"=>"IK","CRM"=>"CRM","FIELD"=>"SAHA","ECOM"=>"ETICARET","LAB"=>"LABORATUVAR","PRESSURE"=>"BASINC","MACHINE"=>"MAKINA","CALENDAR"=>"TAKVIM","CHAT"=>"ILETISIM","ASSISTANT"=>"ASISTAN","MARKET"=>"PIYASA","TRADE"=>"DISTICARET","REPORT"=>"RAPOR","RESTAURANT"=>"RESTORAN",_=>null};
}
public sealed record ImzaliLisans(int Version,string Payload,string Signature);
public sealed record PortalDuyuru(long Sequence,string Id,string Title,string Body,DateTimeOffset CreatedAt);
public sealed record LisansIcerigi(int Schema,string LicenseId,string CustomerId,string Company,string Sector,string[] Modules,string DeviceId,string DatabaseId,DateTimeOffset IssuedAt,DateTimeOffset NotBefore,DateTimeOffset? ExpiresAt,DateTimeOffset ValidUntil,int Revision){/* Lisans panelinde tanımlanan mobil cihaz (telefon) sayısı; null = sınır yok. */ public int? MobileDevices {get;init;} public Dictionary<string,DateTimeOffset>? ModuleExpiresAt {get;init;} public PortalDuyuru[]? PortalNotices {get;init;} /// <summary>Panelin imzaladığı modül kataloğu sürümü; 3 ve üstünde modül listesi kesindir.</summary>
 public int? Catalog {get;init;}};
public static class LisansKripto
{
    public static readonly JsonSerializerOptions Json=new(JsonSerializerDefaults.Web);
    public static string Ozet(string text)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)));
    public static LisansIcerigi Dogrula(ImzaliLisans envelope,string publicKey,string device,string database,DateTimeOffset now)
    {
        if(envelope.Version!=1 || envelope.Payload.Length>24000 || envelope.Signature.Length>2048)throw new InvalidDataException("Lisans biçimi geçersiz.");
        byte[] body,signature;try{body=Convert.FromBase64String(envelope.Payload);signature=Convert.FromBase64String(envelope.Signature);}catch(FormatException){throw new InvalidDataException("Lisans kodlaması geçersiz.");}
        using var rsa=RSA.Create();rsa.ImportFromPem(publicKey);
        if(rsa.KeySize<3072||!rsa.VerifyData(body,signature,HashAlgorithmName.SHA256,RSASignaturePadding.Pss))throw new CryptographicException("Lisans imzası doğrulanamadı.");
        var p=JsonSerializer.Deserialize<LisansIcerigi>(body,Json)??throw new InvalidDataException("Lisans boş.");
        if(p.Schema!=1||!Guid.TryParse(p.LicenseId,out _)||!Guid.TryParse(p.CustomerId,out _)||string.IsNullOrWhiteSpace(p.Company)||p.Company.Length>160||p.Revision<1)throw new InvalidDataException("Lisans bilgileri geçersiz.");
        UrunKatalogu.SektorBul(p.Sector);UrunKatalogu.ModulDogrula(p.Modules);ModulSureleri.Dogrula(p);
        long last=0;if(p.PortalNotices is {} notices){if(notices.Length>10)throw new InvalidDataException("Duyuru sınırı aşıldı.");foreach(var n in notices){if(n is null||n.Sequence<=last||!Guid.TryParse(n.Id,out _)||string.IsNullOrWhiteSpace(n.Title)||n.Title.Length>120||string.IsNullOrWhiteSpace(n.Body)||n.Body.Length>2000||n.Title.Any(char.IsControl)||n.Body.Any(c=>char.IsControl(c)&&c!='\n'&&c!='\r'&&c!='\t')||n.CreatedAt>p.IssuedAt.AddMinutes(1))throw new InvalidDataException("İmzalı duyuru geçersiz.");last=n.Sequence;}}
        if(p.DeviceId!=device||p.DatabaseId!=database)throw new UnauthorizedAccessException("Lisans bu cihaz veya veritabanına ait değil.");
        if(p.IssuedAt>now.AddMinutes(5)||p.NotBefore>now||p.ValidUntil<=now||p.ExpiresAt<=now||p.ValidUntil<=p.IssuedAt||p.ValidUntil>p.IssuedAt.AddDays(7).AddMinutes(1)||p.ExpiresAt.HasValue&&p.ValidUntil>p.ExpiresAt.Value)
            throw new UnauthorizedAccessException("Lisansın süresi veya doğrulama süresi geçersiz. İnternetten yenileyin.");
        return p;
    }
    public static ImzaliLisans Imzala(LisansIcerigi payload,RSA privateKey)
    {
        byte[] data=JsonSerializer.SerializeToUtf8Bytes(payload,Json);
        return new(1,Convert.ToBase64String(data),Convert.ToBase64String(privateKey.SignData(data,HashAlgorithmName.SHA256,RSASignaturePadding.Pss)));
    }
}
