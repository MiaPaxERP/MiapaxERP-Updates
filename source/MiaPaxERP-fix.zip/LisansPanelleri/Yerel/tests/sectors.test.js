import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {sectorCatalog,sectorGroups,LEGACY_SECTORS,sectorForClient,SECTOR_CATALOG_VERSION} from '../src/legacy/sectors.js';
import {modules} from '../src/legacy/index.js';

test('sector catalog codes, groups, legacy codes and modules are valid',()=>{
 const codes=sectorCatalog.map(s=>s.code);assert.equal(new Set(codes).size,codes.length);
 for(const legacy of LEGACY_SECTORS)assert.ok(codes.includes(legacy),'eski kod korunur: '+legacy);
 for(const s of sectorCatalog){
  assert.match(s.code,/^[A-Z]{3,20}$/);assert.ok(sectorGroups.some(g=>g[0]===s.group),s.code);
  assert.ok(LEGACY_SECTORS.includes(s.legacy),s.code);assert.ok(s.modules.length&&s.modules.every(m=>modules.some(x=>x[0]===m)),s.code);
  assert.ok(s.branches.length>=2&&s.description.length>10,s.code);
 }
 for(const g of sectorGroups)assert.ok(sectorCatalog.some(s=>s.group===g[0]),g[0]);
});
test('old clients receive a legacy sector, catalog 2 clients the detailed one',()=>{
 assert.equal(sectorForClient('KAFE'),'RESTORAN');assert.equal(sectorForClient('GIDA',1),'GENEL');assert.equal(sectorForClient('YEDEK'),'YEDEK');
 assert.equal(sectorForClient('GIDA',SECTOR_CATALOG_VERSION),'GIDA');assert.equal(sectorForClient('YOK',2),'GENEL');
});
const core=process.env.MIAPAX_CORE_CS||fileURLToPath(new URL('../../../MiapaxERP.Lisans.Core/LisansSozlesmesi.cs',import.meta.url));
test('desktop C# catalog matches the panel catalog',{skip:!existsSync(core)&&'ERP kaynağı bu kopyada yok'},()=>{
 const cs=readFileSync(core,'utf8');
 const rows=[...cs.matchAll(/S\("([A-Z]+)","([^"]+)","([A-Z]+)","([A-Z]+)","([A-Z]+)","[^"]*","[^"]*","[^"]*","[^"]*",\[([^\]]*)\]/g)].map(m=>({code:m[1],name:m[2],group:m[3],legacy:m[5],modules:[...m[6].matchAll(/"([A-Z]+)"/g)].map(x=>x[1])}));
 assert.equal(rows.length,sectorCatalog.length);
 for(const s of sectorCatalog){const r=rows.find(x=>x.code===s.code);assert.ok(r,'C# kataloğunda yok: '+s.code);assert.deepEqual({name:r.name,group:r.group,legacy:r.legacy,modules:r.modules},{name:s.name,group:s.group,legacy:s.legacy,modules:s.modules},s.code);}
 assert.match(cs,new RegExp('SektorKataloguSurumu='+SECTOR_CATALOG_VERSION+';'));
});
