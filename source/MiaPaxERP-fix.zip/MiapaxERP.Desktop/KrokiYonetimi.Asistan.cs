using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
public partial class KrokiYonetimi
{
 internal string? ServisBaglantisi {get;set;}
 internal int ServisKullanici {get;set;}
 string KrokiAsistanDosyasi=>Path.Combine(GorunumDeposu.Klasor(ServisBaglantisi??"kroki",ServisKullanici),"kroki-asistan.json");
 void KrokiYetkiKontrol(){
  if(ServisBaglantisi is null||ServisKullanici<1)throw new UnauthorizedAccessException("Aktif kullanıcı oturumu gerekli.");
  LisansOturumu.Gerekli("KROKI");var p=new HashSet<string>(new MenuYetkiServisi(ServisBaglantisi,ServisKullanici).Yetkiler(),StringComparer.OrdinalIgnoreCase);
  if(!p.Contains("KROKI.VIEW")&&!p.Contains("USERS.MANAGE"))throw new UnauthorizedAccessException("Kroki yetkisi gerekli.");
 }
 void KrokiAsistanAyarlari(){
  KrokiYetkiKontrol();var old=AsistanAyari.Oku(KrokiAsistanDosyasi);var w=new Window{Title="Kroki yapay zekâ bağlantısı",Owner=Window.GetWindow(this),Width=590,Height=470,WindowStartupLocation=WindowStartupLocation.CenterOwner};var panel=new StackPanel{Margin=new Thickness(24)};w.Content=panel;
  panel.Children.Add(new TextBlock{Text="Otomatik sulama ve malzeme hesabı bağlantısız çalışır. Serbest metinden tasarım oluşturmak için kurulu bir Ollama modeli veya MiaPaxERP yapay zekâ sunucusu bağlayın. Tasarım isteği ve tarla ölçüleri seçtiğiniz sunucuya gönderilir; stok fiyatları gönderilmez.",TextWrapping=TextWrapping.Wrap});
  var type=new ComboBox{ItemsSource=new[]{"Yerleşik rehber","Ollama","MiapaxERP sunucusu"},SelectedItem=old.Tur,Margin=new Thickness(0,16,0,8)};panel.Children.Add(type);
  panel.Children.Add(new TextBlock{Text="Sunucu adresi (Ollama örneği: http://127.0.0.1:11434/api/chat)"});var url=new TextBox{Text=old.Adres,Margin=new Thickness(0,6,0,12)};panel.Children.Add(url);
  panel.Children.Add(new TextBlock{Text="Kurulu model adı"});var model=new TextBox{Text=old.Model,Margin=new Thickness(0,6,0,12)};panel.Children.Add(model);var status=new TextBlock{TextWrapping=TextWrapping.Wrap};panel.Children.Add(status);
  var save=new Button{Content="Bağlantıyı kaydet",Margin=new Thickness(0,12,0,0)};panel.Children.Add(save);save.Click+=(_,_)=>{try{var a=new AsistanAyari{Tur=type.SelectedItem as string??"Yerleşik rehber",Adres=url.Text.Trim(),Model=model.Text.Trim()};if(a.Tur!="Yerleşik rehber")AsistanIstemcisi.AdresiDogrula(a);a.Kaydet(KrokiAsistanDosyasi);w.DialogResult=true;}catch(Exception e){status.Text=e.Message;}};w.ShowDialog();
 }
 async Task KrokiAsistanSor(Microsoft.Web.WebView2.Wpf.WebView2 web,JsonElement root){
  var id=root.GetProperty("id").GetString();try{
   KrokiYetkiKontrol();var prompt=root.GetProperty("prompt").GetString()??"";if(prompt.Length is <1 or >1000)throw new ArgumentException("İstek 1–1000 karakter olmalı.");
   var context=root.GetProperty("context").GetString()??"";if(context.Length>1500)throw new ArgumentException("Tarla özeti çok uzun.");
   var ayar=AsistanAyari.Oku(KrokiAsistanDosyasi);if(ayar.Tur=="Yerleşik rehber")throw new InvalidOperationException("Yapay zekâ sunucusu bağlı değil. Bağlantı ayarlarından kurulu modelinizi seçin. Otomatik çizim düğmesi sunucu olmadan çalışır.");
   using var cts=new CancellationTokenSource(TimeSpan.FromSeconds(60));
   var instruction="Sulama tasarım isteğini yalnız JSON nesnesi olarak döndür. İzinli alanlar: method(sprinkler/drip), side(left/right), rowGap(0.3..50 metre), headGap(1..50 metre), mainDiameter(10..1000 mm), lateralDiameter(10..1000 mm), pieceLength(0.5..1000 metre), piecesPerHead(1..100). Belirtilmeyen değerleri ekleme. Boru boyu ile başlık aralığını karıştırma; iki adet 5m boruda bir başlık headGap=10 demektir. Fiyat, ürün kimliği veya hidrolik onay üretme.\nTarla: "+context+"\nİstek: "+prompt;
   var result=await new AsistanIstemcisi().SorAsync(ayar,instruction,"Kroki sulama tasarımı",[],cts.Token);
   web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="designResult",id,text=result.Metin,error=result.Metin is null?result.Durum:null}));
  }catch(Exception e){web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="designResult",id,error=e.Message}));}
 }

 /// <summary>AI proje sihirbazı: serbest anlatımı ölçü/boru/kaynak parametrelerine çevirir. Yanıt yalnız izinli alanlarla JSON'dur;
 /// sayfa her değeri yeniden doğrular, hesap ve malzeme listesi bağlantısız hesap motorunda yapılır.</summary>
 async Task KrokiProjeSor(Microsoft.Web.WebView2.Wpf.WebView2 web,JsonElement root){
  var id=root.TryGetProperty("id",out var idv)?idv.GetString():null;try{
   KrokiYetkiKontrol();var prompt=root.GetProperty("prompt").GetString()??"";if(prompt.Length is <1 or >1500)throw new ArgumentException("Anlatım 1–1500 karakter olmalı.");
   var context=root.TryGetProperty("context",out var cv)?cv.GetString()??"":"";if(context.Length>2000)throw new ArgumentException("Proje özeti çok uzun.");
   var ayar=AsistanAyari.Oku(KrokiAsistanDosyasi);if(ayar.Tur=="Yerleşik rehber")throw new InvalidOperationException("Yapay zekâ sunucusu bağlı değil; anlatım yerleşik çözümleyiciyle okundu. Daha iyi anlama için Kroki → Yapay zekâ bağlantısı ayarından modelinizi seçin.");
   using var cts=new CancellationTokenSource(TimeSpan.FromSeconds(60));
   var instruction="Tarla sulama projesi anlatımını yalnız tek bir JSON nesnesine çevir, açıklama yazma. İzinli alanlar: width(tarla eni m), length(tarla boyu m), method(drip/sprinkler/minisprinkler), crop(metin), rowGap(sıra/hat arası m), emitterGap(damlatıcı veya başlık arası m), emitterFlow(damlatıcı l/sa veya başlık m3/sa), material(PE100/PVC/LDPE), mainDiameter(mm, dış çap), lateralDiameter(mm), pieceLength(boru boyu m), sourceType(well/tank/canal/network), sourceSide(north/south/east/west), sourceDistance(su kaynağının tarla kenarına uzaklığı m), sourceOffset(kaynağın kenar boyunca konumu, 0..1), wellDepth(dinamik su seviyesi m), elevation(kaynak ile tarla en yüksek noktası farkı m), hoursPerDay(1..24), accessories(dizi: filter, fertilizer, airValve, pressureRegulator, flushValve, manometer, pump, waterMeter, timer). Belirtilmeyen alanı ekleme, tahmin etme. Fiyat, ürün kodu veya mühendislik onayı üretme.\nMevcut proje: "+context+"\nAnlatım: "+prompt;
   var result=await new AsistanIstemcisi().SorAsync(ayar,instruction,"Kroki AI proje sihirbazı",[],cts.Token);
   web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="projectResult",id,text=result.Metin,error=result.Metin is null?result.Durum:null}));
  }catch(Exception e){web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="projectResult",id,error=e.Message}));}
 }
}
