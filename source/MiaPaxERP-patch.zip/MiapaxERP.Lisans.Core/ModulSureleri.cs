namespace MiapaxERP.Lisans.Core;
public static class ModulSureleri
{
 public static bool Acik(LisansIcerigi p,string module,DateTimeOffset now){
  return Acik(p.Modules,p.ModuleExpiresAt,module,now);
 }
 public static bool Acik(string[] modules,Dictionary<string,DateTimeOffset>? dates,string module,DateTimeOffset now){
  if(!modules.Contains(module)||dates?.TryGetValue(module,out var end)==true&&end<=now)return false;
  return module switch{"URETIM" or "LABORATUVAR"=>Acik(modules,dates,"STOK",now),"RESTORAN"=>new[]{"STOK","URETIM","SATIS","FINANS"}.All(m=>Acik(modules,dates,m,now)),_=>true};
 }
 public static string[] Etkin(LisansIcerigi p,DateTimeOffset now)=>p.Modules.Where(m=>Acik(p,m,now)).ToArray();
 public static (string Modul,DateTimeOffset Bitis)[] Yaklasan(LisansIcerigi p,DateTimeOffset now)=>p.ModuleExpiresAt?.Where(x=>p.Modules.Contains(x.Key)&&x.Value>now&&x.Value<=now.AddDays(7)).Select(x=>(x.Key,x.Value)).ToArray()??[];
 public static void Dogrula(LisansIcerigi p){if(p.ModuleExpiresAt is null)return;if(p.ModuleExpiresAt.Count>UrunKatalogu.Moduller.Length||p.ModuleExpiresAt.Any(x=>!p.Modules.Contains(x.Key)||x.Value<p.NotBefore||p.ExpiresAt.HasValue&&x.Value>p.ExpiresAt.Value))throw new InvalidDataException("Modül süreleri geçersiz.");}
}
