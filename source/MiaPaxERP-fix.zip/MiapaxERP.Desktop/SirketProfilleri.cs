using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace MiapaxERP.Desktop;

/// <summary>Tek kurulumda birden çok şirket: her şirket ayrı SQL veritabanıdır ve kendi lisansını kullanır.</summary>
public sealed record SirketProfili(string Id,string Ad,MiapaxERPBaglantiAyarlari Ayarlar)
{
    public string Ozet=>Ad+"  •  "+Ayarlar.Sunucu+" / "+Ayarlar.Veritabani;
}

public static class SirketProfilleri
{
    static readonly JsonSerializerOptions json=new(){WriteIndented=true};
    static string Klasor=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","Sirketler");
    static string Dosya(string id)=>Path.Combine(Klasor,id+".json");
    public const int EnFazla=50;

    public static List<SirketProfili> Listele()
    {
        var list=new List<SirketProfili>();
        if(!Directory.Exists(Klasor))return list;
        foreach(var file in Directory.GetFiles(Klasor,"*.json").Take(EnFazla*2))
            try{var p=JsonSerializer.Deserialize<SirketProfili>(File.ReadAllText(file));if(p is not null&&Guid.TryParse(p.Id,out _)&&Path.GetFileNameWithoutExtension(file)==p.Id&&p.Ayarlar is not null)list.Add(p);}
            catch(JsonException){}catch(IOException){}
        return list.OrderBy(x=>x.Ad,StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    static bool Ayni(MiapaxERPBaglantiAyarlari a,MiapaxERPBaglantiAyarlari b)=>
        string.Equals(a.Sunucu.Trim(),b.Sunucu.Trim(),StringComparison.OrdinalIgnoreCase)&&string.Equals(a.Veritabani.Trim(),b.Veritabani.Trim(),StringComparison.OrdinalIgnoreCase);

    public static SirketProfili? Etkin()
    {
        var current=MiapaxERPBaglantiAyarlari.Oku();
        return Listele().FirstOrDefault(p=>Ayni(p.Ayarlar,current));
    }

    public static string EtkinAdi()
    {
        var current=MiapaxERPBaglantiAyarlari.Oku();
        return Etkin()?.Ad??current.Veritabani;
    }

    static string AdDogrula(string ad)
    {
        ad=(ad??"").Trim();
        if(ad.Length is 0 or >80||ad.Any(char.IsControl))throw new ArgumentException("Şirket adı 1–80 karakter olmalı.");
        return ad;
    }

    /// <summary>Etkin bağlantıyı (parola Windows DPAPI ile şifreli kalarak) şirket profili olarak kaydeder.</summary>
    public static SirketProfili EtkiniKaydet(string ad)
    {
        ad=AdDogrula(ad);
        var current=MiapaxERPBaglantiAyarlari.Oku();
        _=current.BaglantiDizesi();
        var list=Listele();
        var existing=list.FirstOrDefault(p=>Ayni(p.Ayarlar,current));
        if(existing is null&&list.Count>=EnFazla)throw new InvalidOperationException("En fazla "+EnFazla+" şirket kaydedilebilir.");
        if(list.Any(p=>p.Id!=existing?.Id&&string.Equals(p.Ad,ad,StringComparison.CurrentCultureIgnoreCase)))throw new ArgumentException("Bu adla kayıtlı başka bir şirket var.");
        var profile=new SirketProfili(existing?.Id??Guid.NewGuid().ToString(),ad,current);
        Directory.CreateDirectory(Klasor);
        string tmp=Dosya(profile.Id)+".tmp";File.WriteAllText(tmp,JsonSerializer.Serialize(profile,json));File.Move(tmp,Dosya(profile.Id),true);
        return profile;
    }

    /// <summary>Seçilen şirketi etkin bağlantı yapar. Program yeniden açılınca bu şirketin veritabanı ve lisansı kullanılır.</summary>
    public static void Sec(string id)
    {
        var profile=Listele().FirstOrDefault(p=>p.Id==id)??throw new ArgumentException("Şirket bulunamadı.");
        profile.Ayarlar.Kaydet();
    }

    public static void Sil(string id)
    {
        if(!Guid.TryParse(id,out _))throw new ArgumentException("Şirket bulunamadı.");
        if(Etkin()?.Id==id)throw new InvalidOperationException("Etkin şirket silinemez. Önce başka bir şirkete geçin.");
        if(File.Exists(Dosya(id)))File.Delete(Dosya(id));
    }
}

/// <summary>Giriş ekranından açılan şirket seçimi. Geçiş, oturum açılmadan önce yapılır; program yeniden başlatılır.</summary>
public sealed class SirketSecimPenceresi:Window
{
    readonly System.Windows.Controls.ListBox list=new(){Height=230,DisplayMemberPath="Ozet",Margin=new Thickness(0,8,0,12)};
    readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,0)};
    public bool YenidenBaslat{get;private set;}

    public SirketSecimPenceresi()
    {
        Title="MiapaxERP | Şirket seçimi";Width=640;Height=560;WindowStartupLocation=WindowStartupLocation.CenterOwner;ResizeMode=ResizeMode.NoResize;
        var p=new StackPanel{Margin=new Thickness(24)};Content=p;
        p.Children.Add(new TextBlock{Text="Şirketler",FontSize=24,FontWeight=FontWeights.SemiBold});
        p.Children.Add(new TextBlock{Text="Her şirket ayrı bir veritabanıdır ve kendi lisansıyla çalışır. Şirketler arasında geçiş yaptığınızda program yeniden açılır; seçilen şirketin kullanıcı hesabıyla giriş yaparsınız.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,0)});
        p.Children.Add(list);
        var bar=new WrapPanel();p.Children.Add(bar);
        Button B(string text,Action work){var b=new Button{Content=text,Padding=new Thickness(12,7,12,7),Margin=new Thickness(0,0,8,8)};b.Click+=(_,_)=>{try{work();}catch(Exception ex){status.Text=ex.Message;}};bar.Children.Add(b);return b;}
        B("Seçili şirkete geç",Gec);
        B("Mevcut bağlantıyı şirket olarak kaydet",()=>{var ad=AdSor("Mevcut bağlantı için şirket adı",SirketProfilleri.Etkin()?.Ad??MiapaxERPBaglantiAyarlari.Oku().Veritabani);if(ad is null)return;SirketProfilleri.EtkiniKaydet(ad);Yenile();status.Text="Kaydedildi.";});
        B("Yeni şirket ekle",YeniSirket);
        B("Listeden kaldır",()=>{if(list.SelectedItem is not SirketProfili s)throw new InvalidOperationException("Önce bir şirket seçin.");if(MessageBox.Show(this,s.Ad+" listeden kaldırılsın mı? Veritabanı ve veriler silinmez.","Şirket",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;SirketProfilleri.Sil(s.Id);Yenile();});
        var close=new Button{Content="Kapat",Padding=new Thickness(12,7,12,7),HorizontalAlignment=System.Windows.HorizontalAlignment.Right,Margin=new Thickness(0,8,0,0)};close.Click+=(_,_)=>Close();
        p.Children.Add(status);p.Children.Add(close);
        Loaded+=(_,_)=>Yenile();
    }

    void Yenile()
    {
        var items=SirketProfilleri.Listele();var active=SirketProfilleri.Etkin();
        list.ItemsSource=items;list.SelectedItem=items.FirstOrDefault(x=>x.Id==active?.Id);
        status.Text=items.Count==0?"Henüz kayıtlı şirket yok. Önce mevcut bağlantıyı şirket olarak kaydedin, sonra yeni şirket ekleyin.":"Etkin şirket: "+(active?.Ad??"kaydedilmemiş bağlantı ("+MiapaxERPBaglantiAyarlari.Oku().Veritabani+")");
    }

    void Gec()
    {
        if(list.SelectedItem is not SirketProfili s)throw new InvalidOperationException("Önce bir şirket seçin.");
        if(SirketProfilleri.Etkin()?.Id==s.Id){status.Text=s.Ad+" zaten etkin.";return;}
        if(SirketProfilleri.Etkin() is null&&MessageBox.Show(this,"Mevcut bağlantı şirket listesinde kayıtlı değil. Geçmeden önce kaydetmek ister misiniz?","Şirket",MessageBoxButton.YesNo,MessageBoxImage.Question)==MessageBoxResult.Yes)
        {var ad=AdSor("Mevcut bağlantı için şirket adı",MiapaxERPBaglantiAyarlari.Oku().Veritabani);if(ad is null)return;SirketProfilleri.EtkiniKaydet(ad);}
        SirketProfilleri.Sec(s.Id);YenidenBaslat=true;Close();
    }

    void YeniSirket()
    {
        if(SirketProfilleri.Etkin() is null)
        {var mevcut=AdSor("Önce mevcut bağlantıyı kaydedelim. Şirket adı",MiapaxERPBaglantiAyarlari.Oku().Veritabani);if(mevcut is null)return;SirketProfilleri.EtkiniKaydet(mevcut);}
        var ad=AdSor("Yeni şirketin adı","");if(ad is null)return;
        var once=MiapaxERPBaglantiAyarlari.Oku();
        MessageBox.Show(this,"Açılacak pencerede yeni şirketin SQL sunucusunu ve veritabanı adını girin. Veritabanı yoksa program yeniden açıldığında ilk kurulum sihirbazı oluşturur.","Yeni şirket",MessageBoxButton.OK,MessageBoxImage.Information);
        new BaglantiAyarlariPenceresi{Owner=this}.ShowDialog();
        var sonra=MiapaxERPBaglantiAyarlari.Oku();
        if(string.Equals(once.Sunucu,sonra.Sunucu,StringComparison.OrdinalIgnoreCase)&&string.Equals(once.Veritabani,sonra.Veritabani,StringComparison.OrdinalIgnoreCase)){status.Text="Sunucu veya veritabanı değişmedi; yeni şirket eklenmedi.";return;}
        SirketProfilleri.EtkiniKaydet(ad);YenidenBaslat=true;Close();
    }

    string? AdSor(string soru,string varsayilan)
    {
        var w=new Window{Title="Şirket adı",Owner=this,Width=440,Height=200,WindowStartupLocation=WindowStartupLocation.CenterOwner,ResizeMode=ResizeMode.NoResize};
        var p=new StackPanel{Margin=new Thickness(18)};w.Content=p;
        p.Children.Add(new TextBlock{Text=soru,TextWrapping=TextWrapping.Wrap});
        var box=new TextBox{Text=varsayilan,MaxLength=80,Margin=new Thickness(0,8,0,12)};p.Children.Add(box);
        var ok=new Button{Content="Tamam",IsDefault=true,Padding=new Thickness(12,6,12,6),HorizontalAlignment=System.Windows.HorizontalAlignment.Right};p.Children.Add(ok);
        string? result=null;ok.Click+=(_,_)=>{result=box.Text.Trim();w.DialogResult=true;};
        box.Focus();
        return w.ShowDialog()==true&&result is {Length:>0}?result:null;
    }

    /// <summary>Programı aynı komut satırıyla yeniden başlatır.</summary>
    public static void ProgramiYenidenAc()
    {
        var path=Environment.ProcessPath??throw new InvalidOperationException("Program yolu bulunamadı.");
        var args=Environment.GetCommandLineArgs().Skip(1).Select(a=>a.Contains(' ')?"\""+a+"\"":a);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(path,string.Join(" ",args)){UseShellExecute=false});
        Application.Current.Shutdown();
    }
}
