using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public class IlkKurulumSqlTestleri
{
 [Fact]public void BosSunucudaKendiSemaVeAdmininiOlustururMevcutSifreyiDegistirmez(){
  string name="MiapaxFresh_"+Guid.NewGuid().ToString("N");using var master=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=10");master.Open();string cs=new SqlConnectionStringBuilder(master.ConnectionString){InitialCatalog=name}.ConnectionString;
  try{Assert.Contains("Admin",IlkKurulumServisi.Hazirla(cs,true));Assert.True(IlkKurulumServisi.HazirMi(cs));using var c=new SqlConnection(cs);c.Open();using var q=new SqlCommand("SELECT Id,SifreOzeti,SifreDegistirmeli FROM dbo.Kullanicilar WHERE KullaniciAdi=N'Admin'",c);using var rd=q.ExecuteReader();Assert.True(rd.Read());int id=rd.GetInt32(0);Assert.True(GirisPenceresi.SifreDogrula("1234",rd.GetString(1)));Assert.True(rd.GetBoolean(2));rd.Close();Assert.Contains("DASHBOARD.VIEW",new MenuYetkiServisi(cs,id).Yetkiler());Assert.Contains("SALES.VIEW",new MenuYetkiServisi(cs,id).Yetkiler());
   using(var check=new SqlCommand("SELECT COUNT(*) FROM dbo.StokKartlari",c))Assert.Equal(0,Convert.ToInt32(check.ExecuteScalar()));
   string changed=GirisPenceresi.SifreOzetiOlustur("TEST-CHANGED-PASSWORD-2026");using(var change=new SqlCommand("UPDATE dbo.Kullanicilar SET SifreOzeti=@s WHERE Id=@i",c)){change.Parameters.AddWithValue("@s",changed);change.Parameters.AddWithValue("@i",id);change.ExecuteNonQuery();}
   IlkKurulumServisi.Hazirla(cs,true);using var again=new SqlCommand("SELECT SifreOzeti FROM dbo.Kullanicilar WHERE Id=@i",c);again.Parameters.AddWithValue("@i",id);Assert.Equal(changed,again.ExecuteScalar());
  }finally{SqlConnection.ClearAllPools();using var drop=new SqlCommand("IF DB_ID(@n) IS NOT NULL BEGIN ALTER DATABASE "+IlkKurulumServisi.Tanim(name)+" SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE "+IlkKurulumServisi.Tanim(name)+";END",master);drop.Parameters.AddWithValue("@n",name);drop.ExecuteNonQuery();}
 }
 [Theory][InlineData("master")][InlineData("tempdb")][InlineData("")][InlineData("msdb")]
 public void SistemVeritabaniKurulumunaIzinVermez(string name)=>Assert.Throws<ArgumentException>(()=>IlkKurulumServisi.Veritabani(name));
}
