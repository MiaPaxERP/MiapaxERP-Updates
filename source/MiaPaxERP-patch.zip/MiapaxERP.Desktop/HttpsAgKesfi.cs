using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed record HttpsAgAdayi(string Bilgisayar,string Adres,string YerelIp,bool SqlHazir);
public static class HttpsAgKesfi
{
 public const int Port=38766;const string Request="MIAPAX-HTTPS-FIND-v1|";static UdpClient? listener;static CancellationTokenSource? stop;static readonly object gate=new();
 public static void Baslat(string connection,Func<string> address){lock(gate){if(listener is not null)return;try{listener=new UdpClient(new IPEndPoint(IPAddress.Any,Port));stop=new();_ = Listen(listener,connection,address,stop.Token);}catch(SocketException){listener?.Dispose();listener=null;}}}
 public static void Durdur(){lock(gate){stop?.Cancel();listener?.Dispose();listener=null;stop?.Dispose();stop=null;}}
 internal static HttpsAgAdayi? Coz(byte[] data,string nonce,IPAddress remote){
  if(data.Length>2048||remote.AddressFamily!=AddressFamily.InterNetwork||!MobilYerelSunucu.OzelIp(remote.ToString())&&!IPAddress.IsLoopback(remote))return null;
  try{using var doc=JsonDocument.Parse(data);var r=doc.RootElement;if(r.GetProperty("protocol").GetString()!="MiaPaxERP.HTTPS.v1"||r.GetProperty("nonce").GetString()!=nonce)return null;string url=r.GetProperty("https").GetString()??"",name=r.GetProperty("name").GetString()??"";if(name.Length is <1 or >80||url.Length>300)return null;if(url.Length>0)url=KolayBaglantiProfili.KisaAdres(KolayBaglantiProfili.Https(url));return new(name,url,remote.ToString(),r.GetProperty("sqlReady").GetBoolean());}catch(Exception e)when(e is JsonException or ArgumentException or InvalidOperationException or KeyNotFoundException){return null;}
 }
 static async Task Listen(UdpClient socket,string connection,Func<string> address,CancellationToken ct){DateTime checkedAt=DateTime.MinValue;bool ready=false;while(!ct.IsCancellationRequested)try{var request=await socket.ReceiveAsync(ct);if(request.Buffer.Length>120||!MobilYerelSunucu.OzelIp(request.RemoteEndPoint.Address.ToString()))continue;string text=Encoding.UTF8.GetString(request.Buffer);if(!text.StartsWith(Request,StringComparison.Ordinal))continue;string nonce=text[Request.Length..];if(nonce.Length!=32||!nonce.All(Uri.IsHexDigit))continue;if(LisansOturumu.Gecerli is null)continue;
   if(DateTime.UtcNow-checkedAt>TimeSpan.FromMinutes(1)){ready=false;try{using var c=new SqlConnection(connection);await c.OpenAsync(ct);using var q=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.Kullanicilar','U') IS NULL THEN 0 ELSE 1 END",c);ready=Convert.ToInt32(await q.ExecuteScalarAsync(ct))==1;}catch{}checkedAt=DateTime.UtcNow;}
   string url=address();if(url.Length>0)url=KolayBaglantiProfili.KisaAdres(KolayBaglantiProfili.Https(url));var reply=JsonSerializer.SerializeToUtf8Bytes(new{protocol="MiaPaxERP.HTTPS.v1",nonce,name=Environment.MachineName,https=url,sqlReady=ready});await socket.SendAsync(reply,request.RemoteEndPoint,ct);
  }catch(OperationCanceledException){break;}catch(ObjectDisposedException){break;}catch(Exception e)when(e is SocketException or ArgumentException){}}
 public static async Task<HttpsAgAdayi[]> Bul(CancellationToken ct=default){
  using var socket=new UdpClient(new IPEndPoint(IPAddress.Any,0)){EnableBroadcast=true};string nonce=Guid.NewGuid().ToString("N");var payload=Encoding.UTF8.GetBytes(Request+nonce);var targets=new HashSet<IPAddress>{IPAddress.Broadcast,IPAddress.Loopback};foreach(var nic in NetworkInterface.GetAllNetworkInterfaces().Where(x=>x.OperationalStatus==OperationalStatus.Up))foreach(var ip in nic.GetIPProperties().UnicastAddresses.Where(x=>x.Address.AddressFamily==AddressFamily.InterNetwork&&x.IPv4Mask is not null)){var a=ip.Address.GetAddressBytes();var mask=ip.IPv4Mask.GetAddressBytes();targets.Add(new IPAddress(a.Select((v,i)=>(byte)(v|~mask[i])).ToArray()));}
  foreach(var ip in targets)try{await socket.SendAsync(payload,new IPEndPoint(ip,Port),ct);}catch(SocketException){}using var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct);timeout.CancelAfter(TimeSpan.FromSeconds(4));var found=new Dictionary<string,HttpsAgAdayi>(StringComparer.OrdinalIgnoreCase);while(!timeout.IsCancellationRequested)try{var response=await socket.ReceiveAsync(timeout.Token);var candidate=Coz(response.Buffer,nonce,response.RemoteEndPoint.Address);if(candidate is not null)found[candidate.Adres.Length>0?candidate.Adres:candidate.Bilgisayar+"|"+candidate.YerelIp]=candidate;}catch(OperationCanceledException){break;}return found.Values.ToArray();
 }
}
