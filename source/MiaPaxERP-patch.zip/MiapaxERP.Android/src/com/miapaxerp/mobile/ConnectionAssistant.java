package com.miapaxerp.mobile;
import java.net.*;
import javax.net.ssl.*;

/** Deterministic connection diagnostics; no credentials are sent to an AI service. */
public final class ConnectionAssistant {
 private ConnectionAssistant(){}
 public static String address(String raw)throws Exception{
  String s=raw.trim();if(!s.contains("://"))s="https://"+s;
  LanTls.validate(s,"");URL u=new URL(s);
  return "https://"+u.getHost().toLowerCase(java.util.Locale.ROOT)+(u.getPort()==8443?":8443":"");
 }
 public static String diagnosis(Throwable error){
  for(Throwable e=error;e!=null;e=e.getCause()){
   if(e instanceof UnknownHostException)return "Alan adı bulunamadı. Telefonun internetini ve alan adının ana sunucunun sabit dış IP adresine yönlendiğini kontrol edin.";
   if(e instanceof SSLException)return "HTTPS sertifikası doğrulanamadı. Ana sunucuda HTTPS kurulumunu ve alan adını kontrol edin. Güvenlik doğrulaması kapatılmadı.";
   if(e instanceof SocketTimeoutException||e instanceof ConnectException)return "Ana sunucuya ulaşılamadı. Sunucu açık, MiaPaxERP HTTPS servisi çalışır durumda olmalı; modem HTTPS portunu ana sunucuya yönlendirmeli. CGNAT varsa internet sağlayıcısından gerçek sabit dış IP isteyin.";
  }
  return "MiaPaxERP mobil servisi doğrulanamadı. Ana sunucuyu 2.8.8 sürümüne güncelleyin ve bağlantı panelinden yeni mobil bağlantı kodu alın.";
 }
}
