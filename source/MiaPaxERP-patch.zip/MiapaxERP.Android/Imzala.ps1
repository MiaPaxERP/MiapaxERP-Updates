param([string]$BuildTools='', [string]$JavaHome='')
$ErrorActionPreference='Stop'
if(!$BuildTools){$BuildTools=Join-Path $env:USERPROFILE 'Documents\ChatGPT\Program yazma\BoruERP-1.8.1-Gelistirme\AndroidAraclari\build-tools';$BuildTools=(Get-ChildItem -LiteralPath $BuildTools -Directory | Select-Object -First 1).FullName}
if($JavaHome){$env:JAVA_HOME=$JavaHome}
if(!$env:JAVA_HOME){$jdkRoot=Join-Path $env:USERPROFILE 'Documents\ChatGPT\Program yazma\BoruERP-1.8.1-Gelistirme\AndroidAraclari\jdk';$env:JAVA_HOME=(Get-ChildItem -LiteralPath $jdkRoot -Directory | Select-Object -First 1).FullName}
$private=Join-Path $env:USERPROFILE 'BoruERP_GizliAnahtarlar'
$key=Join-Path $private 'boruerp-android.jks';$passwordFile=Join-Path $private 'android-signing-password.dpapi'
$inputApk=Join-Path $PSScriptRoot 'MiaPaxERP-Mobil-v2.8.8-imzasiz.apk';$outputApk=Join-Path $PSScriptRoot 'MiaPaxERP-Mobil-v2.8.8.apk'
foreach($file in @($key,$passwordFile,$inputApk,(Join-Path $BuildTools 'apksigner.bat'))){if(!(Test-Path -LiteralPath $file)){throw "Gerekli dosya yok: $file"}}
$secret=[Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($passwordFile),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
try{
 $env:MIAPAX_ANDROID_PASS=[Text.Encoding]::UTF8.GetString($secret)
 & (Join-Path $BuildTools 'apksigner.bat') sign --ks $key --ks-key-alias boruerp --ks-pass env:MIAPAX_ANDROID_PASS --key-pass env:MIAPAX_ANDROID_PASS --out $outputApk $inputApk
 if($LASTEXITCODE -ne 0){throw 'Mevcut anahtarla imzalanamadı'}
 & (Join-Path $BuildTools 'apksigner.bat') verify --verbose --print-certs $outputApk
 if($LASTEXITCODE -ne 0){throw 'APK imzası doğrulanamadı'}
 Get-FileHash -LiteralPath $outputApk -Algorithm SHA256
 Write-Output 'Mevcut anahtarla imzalı APK hazır. Telefonunuzdaki eski uygulamayı kaldırmadan üzerine kurun.'
}finally{Remove-Item Env:MIAPAX_ANDROID_PASS -ErrorAction SilentlyContinue;[Array]::Clear($secret)}
