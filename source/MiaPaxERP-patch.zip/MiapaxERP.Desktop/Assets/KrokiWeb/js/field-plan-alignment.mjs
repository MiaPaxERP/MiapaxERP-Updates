import {inside,simple,area,length,PARTS} from './field-plan-core.mjs?v=2.8.5';
const finite=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
export function rotate(p,origin,degrees){const a=degrees*Math.PI/180,c=Math.cos(a),s=Math.sin(a),x=p.x-origin.x,y=p.y-origin.y;return {x:origin.x+x*c-y*s,y:origin.y+x*s+y*c};}
export function contains(p,poly){if(inside(p,poly))return true;return poly.some((a,i)=>{const b=poly[(i+1)%poly.length],d=length(a,b);return Math.abs(length(a,p)+length(p,b)-d)<1e-7;});}
// Check every interval delimited by an edge crossing, including very narrow concave notches.
export function segmentInside(a,b,poly){if(!contains(a,poly)||!contains(b,poly))return false;const ts=[0,1],dx=b.x-a.x,dy=b.y-a.y;
 for(let i=0;i<poly.length;i++){const p=poly[i],q=poly[(i+1)%poly.length],ex=q.x-p.x,ey=q.y-p.y,den=dx*ey-dy*ex;if(Math.abs(den)<1e-10)continue;const t=((p.x-a.x)*ey-(p.y-a.y)*ex)/den,u=((p.x-a.x)*dy-(p.y-a.y)*dx)/den;if(t>0&&t<1&&u>=0&&u<=1)ts.push(t);}
 ts.sort((x,y)=>x-y);return ts.every((t,i)=>!i||contains({x:a.x+dx*(t+ts[i-1])/2,y:a.y+dy*(t+ts[i-1])/2},poly));}
export function cleanDesign(value){const n=(x,lo,hi,def)=>Number.isFinite(x)&&x>=lo&&x<=hi?x:def;return {enabled:value?.enabled!==false,angle:n(value?.angle,-360,360,0),rowGap:n(value?.rowGap,.3,50,12),headGap:n(value?.headGap,1,50,12),origin:finite(value?.origin)?{x:n(value.origin.x,-100000,100000,0),y:n(value.origin.y,-100000,100000,0)}:null};}
export function cleanBackground(b){if(!b)return null;if(typeof b.image!=='string'||b.image.length>4000000||!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(b.image)||!finite(b)||![b.width,b.height].every(x=>Number.isFinite(x)&&x>.01&&x<=100000))throw Error('PDF zemin görüntüsü veya ölçeği geçersiz.');return {image:b.image,x:b.x,y:b.y,width:b.width,height:b.height,name:String(b.name||'Parsel PDF').slice(0,120),page:Number.isInteger(b.page)&&b.page>0?b.page:1,calibrated:b.calibrated===true,visible:b.visible!==false};}
function origin(plan,d){return d.origin||plan.items.find(i=>i.kind==='source')?.p||plan.boundary[0];}
export function alignItems(plan,ids=null){const next=structuredClone(plan),d=cleanDesign(plan.design),o=origin(plan,d);let moved=0,rejected=0;
 const local=p=>rotate(p,o,-d.angle),world=p=>rotate(p,o,d.angle),snap=(v,g,base)=>base+Math.round((v-base)/g)*g;
 for(const i of next.items){if(ids&&!ids.includes(i.id)||!['pipe','drip','sprinkler'].includes(i.kind))continue;const old=structuredClone(i);
  if(PARTS[i.kind].line){let a=local(i.a),b=local(i.b);if(Math.abs(b.x-a.x)>=Math.abs(b.y-a.y)){const y=snap((a.y+b.y)/2,d.rowGap,o.y);a.y=b.y=y;}else{const x=snap((a.x+b.x)/2,d.headGap,o.x);a.x=b.x=x;}i.a=world(a);i.b=world(b);if(length(i.a,i.b)<.1||!segmentInside(i.a,i.b,plan.boundary)){Object.assign(i,old);rejected++;continue;}}
  else{let p=local(i.p);p={x:snap(p.x,d.headGap,o.x),y:snap(p.y,d.rowGap,o.y)};i.p=world(p);if(!contains(i.p,plan.boundary)){Object.assign(i,old);rejected++;continue;}}
  if(JSON.stringify(i)!==JSON.stringify(old))moved++;
 }return {plan:next,moved,rejected};}
export function scalePlan(plan,a,b,meters){if(!finite(a)||!finite(b)||length(a,b)<.01||!Number.isFinite(meters)||meters<=0||meters>10000)throw Error('İki farklı nokta ve 0–10000 m arasında gerçek mesafe seçin.');const k=meters/length(a,b),next=structuredClone(plan),scale=p=>({x:a.x+(p.x-a.x)*k,y:a.y+(p.y-a.y)*k});
 next.boundary=next.boundary.map(scale);if(!simple(next.boundary)||area(next.boundary)<1||next.boundary.some(p=>Math.abs(p.x)>100000||Math.abs(p.y)>100000))throw Error('Bu ölçek çizim sınırını aşıyor.');
 next.items=next.items.map(i=>PARTS[i.kind].line?{...i,a:scale(i.a),b:scale(i.b)}:{...i,p:scale(i.p),...(i.kind==='sprinkler'?{range:Math.min(100,Math.max(1,(i.range||8)*k))}:{})});
 if(next.background){const p=scale(next.background);next.background={...next.background,...p,width:next.background.width*k,height:next.background.height*k,calibrated:true};}
 if(next.design?.origin)next.design.origin=scale(next.design.origin);next.geo=null;return next;}
export function toGeo(p,g){if(!g)throw Error('Önce harita konumunu belirleyin.');const origin={x:g.originX||0,y:g.originY||0},v=rotate(p,origin,g.heading||0),cos=Math.cos((g.scaleLat??g.lat)*Math.PI/180);if(Math.abs(cos)<.01)throw Error('Bu enlem desteklenmiyor.');return {lat:g.lat-(v.y-origin.y)/111320,lng:g.lng+(v.x-origin.x)/(111320*cos),altitude:0};}
