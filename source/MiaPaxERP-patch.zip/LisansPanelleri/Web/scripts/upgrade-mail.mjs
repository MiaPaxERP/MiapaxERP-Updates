import fs from 'node:fs';
let p='worker/index.js',s=fs.readFileSync(p,'utf8');
s=s.replace("import {gmailRoute}","import {gmailRoute,seal,unseal,sendLicenseMail}");
s=s.replace("const contact=String(b.contact", "const email=text(b.email,254,'E-posta');if(!/^[^\\s@<>]+@[^\\s@<>]+\\.[^\\s@<>]+$/.test(email))fail('E-posta geçersiz.');\n  const contact=String(b.contact");
s=s.replace('tax_info=?,active=?','tax_info=?,email=?,active=?').replace('JSON.stringify(tax),b.active?','JSON.stringify(tax),email,b.active?');
s=s.replace('tax_info,created_at) VALUES(?,?,?,?,?,?,?)','tax_info,email,created_at) VALUES(?,?,?,?,?,?,?,?)').replace('JSON.stringify(tax),now)','JSON.stringify(tax),email,now)');
s=s.replaceAll('key_hash,label,modules,max_devices,starts_at,expires_at,created_at) VALUES(?,?,?,?,?,?,?,?,?)','key_hash,key_cipher,label,modules,max_devices,starts_at,expires_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
s=s.replaceAll('await hash(key),','await hash(key),await seal(env,key),');
s=s.replace('SET key_hash=?,revision=revision+1','SET key_hash=?,key_cipher=?,mail_status=\'not_sent\',mail_sent_at=NULL,revision=revision+1');
s=s.replace('active,revision,created_at FROM licenses','active,revision,created_at,mail_status,mail_sent_at FROM licenses');
s=s.replace('return json({ok:true,id,licenseId:lid,key});',"return json({ok:true,id,licenseId:lid,key,mail:await deliverLicense(env,lid)});");
s=s.replace('return json({ok:true,key,id});','return json({ok:true,key,id,...(key?{mail:await deliverLicense(env,id)}:{})});');
s=s.replace('return json({key});','return json({key,mail:await deliverLicense(env,b.id)});');
s=s.replace(" if(url.pathname==='/api/admin/device'){",` if(url.pathname==='/api/admin/key'){
  const l=await env.DB.prepare('SELECT key_cipher FROM licenses WHERE id=?').bind(b.id).first();if(!l?.key_cipher)fail('Eski lisansın anahtarı geri okunamaz. Anahtar yenile işlemini kullanın.',409);
  await audit(env.DB,actor,'Lisans anahtarı görüntülendi',b.id).run();return json({key:await unseal(env,l.key_cipher)});
 }
 if(url.pathname==='/api/admin/send-mail')return json({mail:await deliverLicense(env,b.id)});
 if(url.pathname==='/api/admin/device'){
`);
s=s.replace('async function handleAdmin',`async function deliverLicense(env,id){
 const l=await env.DB.prepare('SELECT l.key_cipher,l.key_hash,l.mail_status,c.email,c.name FROM licenses l JOIN customers c ON c.id=l.customer_id WHERE l.id=?').bind(id).first();
 if(!l?.key_cipher||!l.email)return 'E-posta veya saklanan anahtar eksik; müşteri bilgilerini güncelleyin.';
 if(l.mail_status==='sent')return 'Google gönderimi daha önce kabul etti.';
 const claim=await env.DB.prepare("UPDATE licenses SET mail_status='sending' WHERE id=? AND key_hash=? AND mail_status IN ('not_sent','failed') RETURNING id").bind(id,l.key_hash).first();if(!claim)return 'Gönderim sürüyor veya sonuç belirsiz; yinelenen gönderim yapılmadı.';
 try{await sendLicenseMail(env,l.email,await unseal(env,l.key_cipher),l.name);await env.DB.prepare("UPDATE licenses SET mail_status='sent',mail_sent_at=? WHERE id=? AND key_hash=?").bind(new Date().toISOString(),id,l.key_hash).run();return 'Google e-postayı göndermek üzere kabul etti. Teslim durumu alıcı posta kutusundan kontrol edilmelidir.';}
 catch{await env.DB.prepare("UPDATE licenses SET mail_status='failed' WHERE id=? AND key_hash=?").bind(id,l.key_hash).run();return 'E-posta gönderimi doğrulanamadı. Gmail bağlantısını kontrol edin; tekrar denemek yinelenen e-postaya yol açabilir.';}
}
async function handleAdmin`);
s=s.replace("new Date(tax.startDate).toISOString().slice(0,10)!==tax.startDate", "(!Number.isFinite(Date.parse(tax.startDate))||new Date(tax.startDate).toISOString().slice(0,10)!==tax.startDate)");
fs.writeFileSync(p,s);
p='scripts/build.mjs';s=fs.readFileSync(p,'utf8').replaceAll("import {gmailRoute} from './mail.js';","import {gmailRoute,seal,unseal,sendLicenseMail} from './mail.js';");fs.writeFileSync(p,s);
p='worker/ui.js';s=fs.readFileSync(p,'utf8');
s=s.replace('<label>İletişim<input', '<label>E-posta (zorunlu)<input type="email" id="email" maxlength="254" required value="\'+esc(editing?.email||\'\')+\'"></label><label>İletişim<input');
s=s.replace("contact:$('contact').value,", "email:$('email').value,contact:$('contact').value,");
s=s.replace('Bu anahtar yalnızca şimdi gösterilir. Müşterinin Lisans / Etkinleştirme ekranına girin. Kaybolursa anahtarı yenileyebilirsiniz.','Anahtarı müşterinin Lisans / Etkinleştirme ekranına girin. Anahtarı saklayın ve başkalarıyla paylaşmayın. Yönetici bu anahtarı panelden yeniden görüntüleyebilir.');
s=s.replace('<button data-rotate="', '<button data-key="\'+l.id+\'">Anahtarı göster</button> <button data-mail="\'+l.id+\'">E-posta: \'+esc(l.mail_status||\'not_sent\')+\'</button> <button data-rotate="');
s=s.replace("if(b.dataset.rotate){", "if(b.dataset.key){showKey((await api('key',{id:b.dataset.key})).key);return;}if(b.dataset.mail){if(!confirm('Kayıtlı müşteri adresine lisans e-postası gönderilsin mi? Önceki denemenin sonucu belirsizse yinelenen mesaj oluşabilir.'))return;$('message').textContent=(await api('send-mail',{id:b.dataset.mail})).mail;}if(b.dataset.rotate){");
s=s.replace('if(r.key)showKey(r.key);',"if(r.key)showKey(r.key);if(r.mail)$('message').textContent=r.mail;");
fs.writeFileSync(p,s);
p='drizzle/meta/_journal.json';let j=JSON.parse(fs.readFileSync(p,'utf8'));j.entries.push({idx:3,version:'6',when:1794171000000,tag:'0003_customer_mail',breakpoints:true});fs.writeFileSync(p,JSON.stringify(j));
p='scripts/test.mjs';s=fs.readFileSync(p,'utf8').replace("this.db.exec(readFileSync('drizzle/0001_customer_tax.sql','utf8'));", "this.db.exec(readFileSync('drizzle/0001_customer_tax.sql','utf8'));this.db.exec(readFileSync('drizzle/0002_mail.sql','utf8'));this.db.exec(readFileSync('drizzle/0003_customer_mail.sql','utf8'));");s=s.replaceAll("sector:'GENEL',", "sector:'GENEL',email:'test@example.com',");fs.writeFileSync(p,s);
