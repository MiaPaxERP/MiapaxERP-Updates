# İnternet lisans panelini ChatGPT Sites'tan kendi Cloudflare hesabınıza taşıma

Bu panel artık ChatGPT hesabına bağlı değildir. `AUTH_MODE=password` ile kendi kullanıcı adı / parola girişini,
HttpOnly + Secure oturum çerezini ve D1'de tutulan oturumları kullanır. Bu modda `oai-authenticated-user-id`
başlığı hiç okunmaz. Ücretsiz Cloudflare planı bu iş yükü için yeterlidir.

İmza anahtarı **aynı kalır**. Bu sayede sahadaki 2.8.x ve yeni sürüm ERP'ler mevcut lisanslarını doğrulamaya devam eder.

## 1. Hazırlık (bir kez)

1. https://dash.cloudflare.com adresinden ücretsiz hesap açın.
2. Bu klasörde (`InternetPaneli`) bir komut satırı açın. Node.js 24 kurulu olmalı.
3. `npx wrangler login` komutunu çalıştırın. Tarayıcıda Cloudflare hesabınıza izin verin.

## 2. Veritabanı

```
npx wrangler d1 create miapax-lisans
```

Çıktıdaki `database_id` değerini `wrangler.toml` içindeki `BURAYA_...` yerine yazın. Ardından tabloları oluşturun:

```
npx wrangler d1 migrations apply miapax-lisans --remote
```

## 3. Gizli değerler (dosyaya yazılmaz)

```
powershell -ExecutionPolicy Bypass -File scripts\imza-anahtarini-yukle.ps1 -YerelPanel "C:\Users\EXE\Documents\ChatGPT\Program yazma\BoruERP-BayiPaneli-3.0"
npx wrangler secret put ADMIN_SETUP_TOKEN
```

- İlk komut, yerel paneldeki mevcut imza anahtarını diske yazmadan Cloudflare'e yükler.
- `ADMIN_SETUP_TOKEN` için en az 24 karakterlik rastgele bir değer girin. Bu değer yalnız ilk yönetici hesabını oluştururken bir kez kullanılır.
- Gmail ile lisans e-postası gönderiyorsanız `GMAIL_CLIENT_ID` ve `GMAIL_CLIENT_SECRET` değerlerini de `wrangler secret put` ile girin. Google Cloud Console'daki yönlendirme adresine yeni alan adınızı ekleyin.

## 4. Yayınlama

```
npx wrangler deploy
```

Çıktıdaki adresi (`https://miapax-lisans.<hesabınız>.workers.dev`) açın. **İlk yönetici hesabı** ekranında şunları girin:

- kurulum anahtarı,
- kullanıcı adı (ör. `yonetici`),
- en az 12 karakterlik, harf ve rakam içeren bir parola.

Kendi alan adınızı kullanmak isterseniz `wrangler.toml` içindeki `routes` satırını açın ve tekrar `npx wrangler deploy` çalıştırın.

## 5. Mevcut müşteri ve lisansları aktarma

Yerel yönetim paneli ana kayıt kaynağıdır.

1. `BoruERP-BayiPaneli-3.0\kurulum\Internete-Esitle.cmd` dosyasını çalıştırın.
2. Açılan kutuya yeni adresi yazın.

Tüm lisanslar imzalı olarak yeni panele gönderilir. Lisans anahtarlarının kendisi gönderilmez; mevcut müşteri anahtarları aynen çalışmaya devam eder.

Kalıcı yapmak için yerel panelin gizli ayarlarına `LICENSE_CLOUD_ORIGIN=https://yeni-adresiniz` ekleyin (ortam değişkeni olarak da verilebilir). Böylece yeni lisanslar otomatik olarak yeni panele eşitlenir.

## 6. ERP'leri yeni adrese yönlendirme

Aşağıdaki yollardan birini kullanın:

- **Müşteriye özel yeni kurulum:** Program klasörüne `lisans-sunucusu.txt` koyun ve içine tek satır olarak `https://yeni-adresiniz` yazın. Bu dosya yeni kurulumların varsayılan lisans adresi olur.
- **Mevcut kurulum:** Programda **Mağaza → Panel bağlantı ayarları → Lisans adresi** alanına yeni adresi yazın.

Taşıma tamamlanana kadar eski Sites paneli açık kalabilir. Her iki panel aynı anahtarla imzaladığı için iki adres de geçerli lisans üretir.

## Parolayı unutursanız

```
node scripts/yonetici-parola.mjs yonetici
```

Bu komut geçici bir parola üretir ve çalıştırmanız gereken `wrangler d1 execute` komutunu yazdırır. Geçici parolayla girdikten sonra yeni parola belirlemeniz istenir. O kullanıcının eski oturumları kapanır. Yeni bir yönetici eklemek için komutun sonuna `--yeni` ekleyin.

## Güvenlik notları

- SQL veritabanınız internete açılmaz. Panel yalnız lisans kayıtlarını tutar.
- Giriş denemeleri IP ve kullanıcı başına dakikada sınırlanır. Başarısız girişler işlem geçmişine yazılır.
- Oturum süresi 12 saattir. Parola değişince o kullanıcının tüm oturumları kapanır.
- `AUTH_MODE` değerini `sites` yapmayın. Bu mod yalnız ChatGPT Sites içinde güvenlidir.
