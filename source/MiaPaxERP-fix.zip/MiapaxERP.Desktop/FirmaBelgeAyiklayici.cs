using System.Globalization;
using System.Text.RegularExpressions;
namespace MiapaxERP.Desktop;

/// <summary>
/// Vergi levhası, ticaret sicil gazetesi, imza sirküleri, faaliyet / oda kayıt belgesi gibi resmî PDF'lerin metninden
/// firma alanlarını çıkarır. Yalnız güvenilir kalıplar alınır; IBAN ve vergi numarası doğrulanır. Sonuç alan adı → değer sözlüğüdür
/// (anahtarlar FirmaBilgileri penceresindeki F_* alan adlarıdır).
/// </summary>
public static class FirmaBelgeAyiklayici
{
 static readonly CultureInfo tr=CultureInfo.GetCultureInfo("tr-TR");
 const RegexOptions O=RegexOptions.IgnoreCase|RegexOptions.CultureInvariant|RegexOptions.Multiline;
 static readonly string[] Iller=["ADANA","ADIYAMAN","AFYONKARAHİSAR","AĞRI","AKSARAY","AMASYA","ANKARA","ANTALYA","ARDAHAN","ARTVİN","AYDIN","BALIKESİR","BARTIN","BATMAN","BAYBURT","BİLECİK","BİNGÖL","BİTLİS","BOLU","BURDUR","BURSA","ÇANAKKALE","ÇANKIRI","ÇORUM","DENİZLİ","DİYARBAKIR","DÜZCE","EDİRNE","ELAZIĞ","ERZİNCAN","ERZURUM","ESKİŞEHİR","GAZİANTEP","GİRESUN","GÜMÜŞHANE","HAKKARİ","HATAY","IĞDIR","ISPARTA","İSTANBUL","İZMİR","KAHRAMANMARAŞ","KARABÜK","KARAMAN","KARS","KASTAMONU","KAYSERİ","KİLİS","KIRIKKALE","KIRKLARELİ","KIRŞEHİR","KOCAELİ","KONYA","KÜTAHYA","MALATYA","MANİSA","MARDİN","MERSİN","MUĞLA","MUŞ","NEVŞEHİR","NİĞDE","ORDU","OSMANİYE","RİZE","SAKARYA","SAMSUN","ŞANLIURFA","SİİRT","SİNOP","ŞIRNAK","SİVAS","TEKİRDAĞ","TOKAT","TRABZON","TUNCELİ","UŞAK","VAN","YALOVA","YOZGAT","ZONGULDAK"];

 public static Dictionary<string,string> Ayikla(string metin){
  var d=new Dictionary<string,string>(StringComparer.Ordinal);
  if(string.IsNullOrWhiteSpace(metin))return d;
  string t=Regex.Replace(metin.Replace(' ',' '),"[ \t]+"," ");
  void Al(string alan,string? deger,int max=200){deger=Temizle(deger);if(deger is {Length:>0}&&!d.ContainsKey(alan))d[alan]=deger.Length>max?deger[..max]:deger;}
  string? Esle(string desen,int grup=1){var m=Regex.Match(t,desen,O);return m.Success?m.Groups[grup].Value:null;}

  // Unvan
  Al("F_FirmaAdi",Esle(@"(?:TİCARET\s+)?(?:ÜNVANI|UNVANI|ÜNVAN|UNVAN)\s*[:\-]?\s*(.{5,150}?)(?:\n|$)"),150);
  Al("F_FirmaAdi",Esle(@"^(.{3,120}?\b(?:ANONİM ŞİRKETİ|LİMİTED ŞİRKETİ|A\.\s?Ş\.|LTD\.?\s?ŞTİ\.?|KOOPERATİFİ|KOLLEKTİF ŞİRKETİ))\s*$"),150);
  // Vergi
  if(Esle(@"VERG[İIıi]\s*K[İIıi]ML[İIıi]K\s*(?:NO|NUMARASI)\s*[:\-]?\s*(\d{10})")is string vkn&&VknGecerli(vkn))Al("F_VergiNo",vkn);
  else if(Esle(@"T\.?\s?C\.?\s*K[İIıi]ML[İIıi]K\s*(?:NO|NUMARASI)\s*[:\-]?\s*(\d{11})")is string tckn&&TcknGecerli(tckn))Al("F_VergiNo",tckn);
  else if(Esle(@"VERG[İIıi]\s*(?:NO|NUMARASI)\s*[:\-]?\s*(\d{10,11})")is string vn&&(vn.Length==10?VknGecerli(vn):TcknGecerli(vn)))Al("F_VergiNo",vn);
  Al("F_VergiDairesi",Esle(@"VERG[İIıi]\s*DA[İIıi]RES[İIıi](?:\s*(?:ADI|MÜDÜRLÜĞÜ))?\s*[:\-]?\s*([A-ZÇĞİÖŞÜa-zçğıöşü .]{3,60}?)(?:\s+VERG|\s+\d|\n|$)"),60);
  // Sicil
  Al("F_MersisNo",Esle(@"MERS[İIıi]S\s*(?:NO|NUMARASI)\s*[:\-]?\s*(\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4})")?.Replace(" ","").Replace("-",""));
  Al("F_TicaretSicilNo",Esle(@"(?:T[İIıi]CARET\s+)?S[İIıi]C[İIıi]L\s*(?:NO|NUMARASI)\s*[:\-]?\s*([0-9][0-9\-/ ]{1,20}[0-9])"),40);
  Al("F_TicaretSicilMudurlugu",Esle(@"([A-ZÇĞİÖŞÜ][A-Za-zÇĞİÖŞÜçğıöşü ]{2,40}T[İIıi]CARET\s+S[İIıi]C[İIıi]L[İIıi]?\s+MÜDÜRLÜĞÜ)"),80);
  Al("F_OdaKayitNo",Esle(@"(?:ODA\s+(?:S[İIıi]C[İIıi]L|KAYIT)|ÜYE\s+S[İIıi]C[İIıi]L)\s*(?:NO|NUMARASI)\s*[:\-]?\s*([0-9][0-9\-/]{0,15})"),30);
  Al("F_NaceKodu",Esle(@"NACE\s*(?:KODU|KOD)?\s*[:\-]?\s*(\d{2}[.\s]?\d{2}(?:[.\s]?\d{2})?)")?.Replace(" ","."),20);
  if(Esle(@"(?:KURULU[ŞS]|TESC[İIıi]L|İŞE\s+BAŞLAMA)\s*TAR[İIıi]H[İIıi]\s*[:\-]?\s*(\d{1,2}[./]\d{1,2}[./]\d{4})")is string kt&&DateTime.TryParseExact(kt.Replace('/','.'),["d.M.yyyy","dd.MM.yyyy"],tr,DateTimeStyles.None,out var kd))Al("F_KurulusTarihi",kd.ToString("dd.MM.yyyy",tr));
  Al("F_FaaliyetKonusu",Esle(@"(?:ANA\s+)?FAAL[İIıi]YET\s*(?:KONUSU|KODU VE ADI|ADI)?\s*[:\-]\s*(.{5,300}?)(?:\n|$)"),500);
  if(!d.ContainsKey("F_NaceKodu")&&d.TryGetValue("F_FaaliyetKonusu",out var fk)&&Regex.Match(fk,@"^(\d{2}\.\d{2}(?:\.\d{2})?)\b") is {Success:true} nm)Al("F_NaceKodu",nm.Groups[1].Value,20);
  Al("F_FirmaTuru",Esle(@"\b(ANON[İIıi]M ŞİRKETİ|L[İIıi]M[İIıi]TED ŞİRKETİ|ŞAHIS ŞİRKETİ|KOLLEKT[İIıi]F ŞİRKETİ|KOOPERAT[İIıi]F|KOMAND[İIıi]T ŞİRKET[İIıi])\b"),40);
  // İletişim
  if(Regex.Match(t,@"\bTR\s?\d{2}(?:\s?\d{4}){5}\s?\d{2}\b",O) is {Success:true} iban){string ib=iban.Value.Replace(" ","").ToUpperInvariant();if(IbanGecerli(ib))Al("F_Iban",Regex.Replace(ib,".{4}","$0 ").Trim());}
  var ep=Regex.Match(t,@"(?:E-?POSTA|E-?MA[İIıi]L)\s*[:\-]?\s*([A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,})",O);if(!ep.Success)ep=Regex.Match(t,@"\b([A-Za-z0-9._%+\-]+@(?![A-Za-z0-9.\-]*kep\.tr)[A-Za-z0-9.\-]+\.[A-Za-z]{2,})\b",O);if(ep.Success)Al("F_Eposta",ep.Groups[1].Value.ToLowerInvariant(),120);
  Al("F_KepAdresi",Esle(@"\b([A-Za-z0-9._%+\-]+@hs\d{2}\.kep\.tr)\b")?.ToLowerInvariant(),120);
  Al("F_WebSitesi",Esle(@"\b((?:https?://)?www\.[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)+)\b")?.ToLowerInvariant(),120);
  var telefonlar=Regex.Matches(t,@"(?:TEL(?:EFON)?|GSM|CEP)\s*(?:NO)?\s*[:\-]?\s*((?:\+?90\s?)?\(?0?\d{3}\)?[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2})",O).Select(m=>Telefon(m.Groups[1].Value)).Where(x=>x is not null).Distinct().ToList();
  if(telefonlar.Count>0)Al("F_Telefon",telefonlar[0]);if(telefonlar.Count>1)Al("F_Telefon2",telefonlar[1]);
  // Adres ve il/ilçe
  var adres=Esle(@"(?:İŞ\s*YER[İIıi]\s*ADRES[İIıi]|MERKEZ\s*ADRES[İIıi]|ADRES[İIıi]?)\s*[:\-]\s*(.{10,260}?)(?:\n(?:[A-ZÇĞİÖŞÜ ]{3,30}:)|\n\n|$)",1);
  if(adres is not null){adres=Regex.Replace(adres,@"\s*\n\s*"," ");Al("F_Adres",adres,500);
   var il=Regex.Match(adres,@"([A-Za-zÇĞİÖŞÜçğıöşü]{3,25})\s*/\s*([A-Za-zÇĞİÖŞÜçğıöşü]{3,20})\s*$",O);
   if(il.Success&&IlBul(il.Groups[2].Value) is string ilAdi){Al("F_Il",ilAdi);Al("F_Ilce",Baslik(il.Groups[1].Value));}
   else if(Iller.FirstOrDefault(x=>Regex.IsMatch(adres.ToUpper(tr),@"\b"+Regex.Escape(x)+@"\b")) is string bulunan)Al("F_Il",Baslik(bulunan));
   if(Regex.Match(adres,@"\b(\d{5})\b") is {Success:true} pk&&int.Parse(pk.Value)>=1000&&int.Parse(pk.Value)<=81999)Al("F_PostaKodu",pk.Value);}
  // Yetkili (imza sirküleri)
  Al("F_YetkiliAdSoyad",Esle(@"(?:YETK[İIıi]L[İIıi]|MÜDÜR|TEMS[İIıi]LE\s+YETK[İIıi]L[İIıi])\s*(?:AD[Iİ]?\s*SOYAD[Iİ]?|K[İIıi]Ş[İIıi])?\s*[:\-]\s*([A-ZÇĞİÖŞÜ][A-Za-zÇĞİÖŞÜçğıöşü]+(?:\s+[A-ZÇĞİÖŞÜ][A-Za-zÇĞİÖŞÜçğıöşü]+){1,3})"),80);
  Al("F_BankaAdi",Esle(@"\b([A-ZÇĞİÖŞÜ][A-Za-zÇĞİÖŞÜçğıöşü]+(?:\s+[A-ZÇĞİÖŞÜ][A-Za-zÇĞİÖŞÜçğıöşü]+){0,3}\s+BANKASI(?:\s+A\.?\s?Ş\.?)?)"),80);
  Al("F_SubeAdi",Esle(@"ŞUBE(?:\s*ADI)?\s*[:\-]\s*([A-Za-zÇĞİÖŞÜçğıöşü0-9 .\-]{2,60}?)(?:\s+(?:ŞUBE\s*KODU|HESAP)|\n|$)"),60);
  Al("F_HesapNo",Esle(@"HESAP\s*(?:NO|NUMARASI)\s*[:\-]?\s*([0-9\-]{5,30})"),30);
  Al("F_Ulke",d.ContainsKey("F_Il")||d.ContainsKey("F_VergiNo")?"Türkiye":null);
  return d;
 }

 static string? Temizle(string? s){if(s is null)return null;s=Regex.Replace(s,@"\s+"," ").Trim(' ',':','-','.',',',';');return s.Length==0?null:s;}
 static string Baslik(string s)=>tr.TextInfo.ToTitleCase(s.ToLower(tr));
 static string? IlBul(string s){var u=s.ToUpper(tr);return Iller.Contains(u)?Baslik(u):null;}
 static string? Telefon(string s){var dg=new string(s.Where(char.IsDigit).ToArray());if(dg.StartsWith("90"))dg=dg[2..];if(dg.StartsWith('0'))dg=dg[1..];if(dg.Length!=10||dg[0] is '0' or '1')return null;return "0"+dg[..3]+" "+dg[3..6]+" "+dg[6..8]+" "+dg[8..];}
 /// <summary>Vergi kimlik numarası (10 hane) kontrol algoritması.</summary>
 public static bool VknGecerli(string v){
  if(v.Length!=10||!v.All(char.IsAsciiDigit))return false;int sum=0;
  for(int i=0;i<9;i++){int d=(v[i]-'0'+9-i)%10;int p=d==0?0:(d*(int)Math.Pow(2,9-i))%9;if(d!=0&&p==0)p=9;sum+=p;}
  return (10-sum%10)%10==v[9]-'0';
 }
 public static bool TcknGecerli(string t){
  if(t.Length!=11||!t.All(char.IsAsciiDigit)||t[0]=='0')return false;int[] n=t.Select(c=>c-'0').ToArray();
  int d10=((n[0]+n[2]+n[4]+n[6]+n[8])*7-(n[1]+n[3]+n[5]+n[7]))%10;if(d10<0)d10+=10;
  return d10==n[9]&&(n.Take(10).Sum()%10)==n[10];
 }
 public static bool IbanGecerli(string iban){
  iban=iban.Replace(" ","").ToUpperInvariant();if(!Regex.IsMatch(iban,@"^TR\d{24}$"))return false;
  string r=iban[4..]+iban[..4];var sb=new System.Text.StringBuilder();foreach(char c in r)sb.Append(char.IsLetter(c)?(c-'A'+10).ToString():c.ToString());
  int mod=0;foreach(char c in sb.ToString())mod=(mod*10+(c-'0'))%97;return mod==1;
 }
}
