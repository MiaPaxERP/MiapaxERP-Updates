using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>Akıllı denetimin bulduğu bir eksik, fazla, yanlış veya iyileştirilebilir durum.</summary>
/// <param name="Anahtar">Aynı bulgunun tekrar gösterilmemesi için kalıcı kimlik.</param>
/// <param name="Onem">Kritik, Uyarı veya Öneri.</param>
public sealed record AkilliOneri(string Anahtar,string Alan,string Onem,string Baslik,string Aciklama,string Oneri);

/// <summary>
/// Üretim, stok, masraf, muhasebe, finans ve cari kayıtlarını salt okunur inceler; yalnız kullanıcının
/// görme yetkisi ve lisansı olan alanlarda bulgu üretir. Hiçbir kaydı değiştirmez, dış servise veri göndermez.
/// </summary>
public sealed class AkilliDenetimServisi(string connection,int user)
{
 const int EnFazlaBulgu=60;
 readonly ErpModulServisi access=new(connection,user);
 static readonly CultureInfo tr=CultureInfo.GetCultureInfo("tr-TR");
 static string N(decimal v)=>v.ToString("#,##0.###",tr);

 public AkilliOneri[] Incele(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<AkilliOneri[]>(connection,"AkilliDenetimServisi.Incele","",[]);
  var list=new List<AkilliOneri>();
  using var c=access.Ac();
  void Kural(string izin,Action<SqlConnection,List<AkilliOneri>> kural){
   if(list.Count>=EnFazlaBulgu||!Var(c,izin))return;
   try{kural(c,list);}catch(SqlException){/* tablo bu kurulumda yok veya geçici hata: diğer kurallar sürer */}
  }
  Kural("STOCK.VIEW",EksiStok);Kural("STOCK.VIEW",MinimumAlti);Kural("STOCK.VIEW",OluStok);Kural("STOCK.VIEW",BenzerStokAdlari);Kural("STOCK.VIEW",BarkodsuzParcalar);
  Kural("PRODUCTION.VIEW",GecikenUretim);Kural("PRODUCTION.VIEW",YuksekFire);Kural("PRODUCTION.VIEW",ReceteOrani);Kural("PRODUCTION.VIEW",HammaddeYetmezligi);
  Kural("FINANCE.VIEW",MukerrerMasraf);Kural("FINANCE.VIEW",KategorisizMasraf);Kural("FINANCE.VIEW",GecikenOdeme);Kural("FINANCE.VIEW",YaklasanCekSenet);
  Kural("ACCOUNTING.VIEW",DengesizFis);Kural("ACCOUNTING.VIEW",AcikDonem);
  Kural("CUSTOMER.VIEW",VergiNoEksikCari);
  var sira=new Dictionary<string,int>{["Kritik"]=0,["Uyarı"]=1,["Öneri"]=2};
  return list.Take(EnFazlaBulgu).OrderBy(x=>sira.GetValueOrDefault(x.Onem,3)).ThenBy(x=>x.Alan,StringComparer.Ordinal).ToArray();
 }

 /// <summary>Lisans ve rol yetkisini, destek kaydı üretmeden sessizce denetler.</summary>
 bool Var(SqlConnection c,string izin){
  var modul=MiapaxERP.Lisans.Core.UrunKatalogu.YetkiModulu(izin);
  if(modul is not null&&(LisansOturumu.Zorunlu||HttpsOturumu.Istemci?.Oturum is not null)&&!LisansOturumu.ModulVar(modul))return false;
  try{access.Yetki(c,null,izin);return true;}catch(UnauthorizedAccessException){return false;}
 }
 static SqlCommand Q(SqlConnection c,string sql,params(string,object?)[] ps){var q=ErpModulServisi.Komut(c,null,sql,ps);q.CommandTimeout=20;return q;}
 static void Oku(SqlConnection c,string sql,Action<SqlDataReader> satir,params(string,object?)[] ps){using var q=Q(c,sql,ps);using var r=q.ExecuteReader();while(r.Read())satir(r);}
 static string Liste(IEnumerable<string> items,int max=5){var a=items.ToList();return string.Join(", ",a.Take(max))+(a.Count>max?" ve "+(a.Count-max)+" kayıt daha":"");}

 // ---- STOK ----
 static void EksiStok(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(20) s.StokKodu,s.StokAdi,b.Miktar,b.Birim FROM dbo.StokBakiyeleri b JOIN dbo.StokKartlari s ON s.Id=b.StokKartId WHERE b.Miktar<0 AND s.Aktif=1 ORDER BY b.Miktar",r=>rows.Add(r.GetString(1)+" ("+N(r.GetDecimal(2))+" "+r.GetString(3)+")"));
  if(rows.Count>0)o.Add(new("stok-eksi-"+rows.Count,"Stok","Kritik",rows.Count+" stokta eksi bakiye var","Eksi bakiye; giriş kaydı unutulmuş, çıkış iki kez yapılmış veya birim yanlış seçilmiş olabilir: "+Liste(rows),"Son hareketleri inceleyip eksik giriş/sayım kaydını yapın; mükerrer çıkışı ters kayıtla düzeltin."));
 }
 static void MinimumAlti(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(30) s.StokAdi,ISNULL(b.Miktar,0),s.MinimumStokMiktari,s.Birim FROM dbo.StokKartlari s LEFT JOIN dbo.StokBakiyeleri b ON b.StokKartId=s.Id WHERE s.Aktif=1 AND s.MinimumStokMiktari>0 AND ISNULL(b.Miktar,0)<s.MinimumStokMiktari ORDER BY ISNULL(b.Miktar,0)/NULLIF(s.MinimumStokMiktari,0)",r=>rows.Add(r.GetString(0)+" "+N(r.GetDecimal(1))+"/"+N(r.GetDecimal(2))+" "+r.GetString(3)));
  if(rows.Count>0)o.Add(new("stok-min-"+rows.Count,"Stok","Uyarı",rows.Count+" stok minimum seviyenin altında","Üretim veya satış aksayabilir: "+Liste(rows),"Satın alma talebi oluşturun veya minimum seviyeleri güncel tüketime göre gözden geçirin."));
 }
 static void OluStok(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(30) s.StokAdi,b.Miktar,b.Birim FROM dbo.StokBakiyeleri b JOIN dbo.StokKartlari s ON s.Id=b.StokKartId WHERE s.Aktif=1 AND b.Miktar>0 AND NOT EXISTS(SELECT 1 FROM dbo.StokHareketleri h WHERE h.StokKartId=s.Id AND h.KayitTarihi>=DATEADD(day,-180,SYSUTCDATETIME())) ORDER BY b.Miktar DESC",r=>rows.Add(r.GetString(0)+" ("+N(r.GetDecimal(1))+" "+r.GetString(2)+")"));
  if(rows.Count>=3)o.Add(new("stok-olu-"+rows.Count,"Stok","Öneri",rows.Count+" stok 6 aydır hareketsiz","Depoda bekleyen ve sermaye bağlayan ürünler: "+Liste(rows),"Kampanya, iade veya üretimde kullanım planlayın; gereksizse kartı pasife alın."));
 }
 static void BenzerStokAdlari(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(10) MIN(StokAdi),COUNT(*) FROM dbo.StokKartlari WHERE Aktif=1 GROUP BY UPPER(LTRIM(RTRIM(REPLACE(StokAdi,N'  ',N' ')))) HAVING COUNT(*)>1",r=>rows.Add(r.GetString(0)+" ×"+r.GetInt32(1)));
  if(rows.Count>0)o.Add(new("stok-benzer-"+rows.Count,"Stok","Öneri",rows.Count+" stok adı birden fazla kartta","Aynı ürün farklı kodlarla açılmış olabilir; bakiye ve maliyet bölünür: "+Liste(rows),"Kartları karşılaştırın; gerçekten aynıysa birini pasife alıp tek kod kullanın."));
 }
 static void BarkodsuzParcalar(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"IF OBJECT_ID('dbo.MPXNext_StokBilesen','U') IS NOT NULL SELECT DISTINCT TOP(30) s.StokAdi FROM dbo.MPXNext_StokBilesen x JOIN dbo.StokKartlari s ON s.Id=x.Bilesen WHERE s.Aktif=1 AND NOT EXISTS(SELECT 1 FROM dbo.MPXNext_Barkod b WHERE b.Stok=s.Id)",r=>rows.Add(r.GetString(0)));
  if(rows.Count>0)o.Add(new("parca-barkod-"+rows.Count,"Stok","Öneri",rows.Count+" parçanın barkodu yok","Barkodsuz parçalar depoda okutulamaz ve sayımda karışır: "+Liste(rows),"Stok → Stok içinde stok ekranında 'Seçili parçaya barkod ver' ile barkod üretip etiket yazdırın."));
 }

 // ---- ÜRETİM ----
 static void GecikenUretim(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(20) UretimEmriNo,DATEDIFF(day,PlanlananBitis,SYSDATETIME()) FROM dbo.UretimEmirleri WHERE Durum IN(N'Planlandı',N'Üretimde') AND PlanlananBitis IS NOT NULL AND PlanlananBitis<CAST(SYSDATETIME() AS date) ORDER BY PlanlananBitis",r=>rows.Add(r.GetString(0)+" ("+r.GetInt32(1)+" gün)"));
  if(rows.Count>0)o.Add(new("uretim-gecikme-"+rows.Count,"Üretim","Uyarı",rows.Count+" üretim emri planlanan bitişi geçti","Teslim tarihleri tehlikede olabilir: "+Liste(rows),"Emirlerin durumunu güncelleyin; bitenleri tamamlayın, ertelenenlerin tarihini yeniden planlayın."));
 }
 static void YuksekFire(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(15) UretimEmriNo,CAST(100*FireMiktari/NULLIF(UretilenMiktar+FireMiktari,0) AS decimal(9,1)) FROM dbo.UretimEmirleri WHERE Durum=N'Tamamlandı' AND KayitTarihi>=DATEADD(day,-60,SYSUTCDATETIME()) AND FireMiktari>0 AND FireMiktari>0.1*(UretilenMiktar+FireMiktari) ORDER BY FireMiktari/NULLIF(UretilenMiktar+FireMiktari,0) DESC",r=>rows.Add(r.GetString(0)+" %"+N(r.GetDecimal(1))));
  if(rows.Count>0)o.Add(new("uretim-fire-"+rows.Count,"Üretim","Uyarı","Son 60 günde "+rows.Count+" emirde fire %10'un üstünde","Yüksek fire maliyeti doğrudan artırır: "+Liste(rows),"Makine ayarı, hammadde partisi ve vardiya bazında fireyi karşılaştırın; reçete oranlarını gözden geçirin."));
 }
 static void ReceteOrani(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(20) r.ReceteKodu,SUM(k.YuzdeOrani) FROM dbo.UretimReceteleri r JOIN dbo.UretimReceteKalemleri k ON k.ReceteId=r.Id WHERE r.Aktif=1 GROUP BY r.ReceteKodu HAVING ABS(SUM(k.YuzdeOrani)-100)>0.5",r=>rows.Add(r.GetString(0)+" toplam %"+N(r.GetDecimal(1))));
  if(rows.Count>0)o.Add(new("recete-oran-"+rows.Count,"Üretim","Kritik",rows.Count+" etkin reçetenin oran toplamı %100 değil","Hammadde tüketimi ve maliyet yanlış hesaplanır: "+Liste(rows),"Reçete kalemlerinin yüzde oranlarını toplam %100 olacak şekilde düzeltin."));
 }
 static void HammaddeYetmezligi(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"""
SELECT TOP(15) s.StokAdi,SUM((e.PlanlananMiktar-e.UretilenMiktar)*k.YuzdeOrani/100.0),MAX(ISNULL(b.Miktar,0)),s.Birim
FROM dbo.UretimEmirleri e JOIN dbo.UretimReceteKalemleri k ON k.ReceteId=e.ReceteId JOIN dbo.StokKartlari s ON s.Id=k.HammaddeStokId LEFT JOIN dbo.StokBakiyeleri b ON b.StokKartId=s.Id
WHERE e.Durum IN(N'Planlandı',N'Üretimde') AND e.PlanlananMiktar>e.UretilenMiktar AND (e.MiktarBirimi IS NULL OR e.MiktarBirimi=s.Birim)
GROUP BY s.StokAdi,s.Birim HAVING SUM((e.PlanlananMiktar-e.UretilenMiktar)*k.YuzdeOrani/100.0)>MAX(ISNULL(b.Miktar,0))
""",r=>rows.Add(r.GetString(0)+" gereken "+N(r.GetDecimal(1))+", stok "+N(r.GetDecimal(2))+" "+r.GetString(3)));
  if(rows.Count>0)o.Add(new("uretim-hammadde-"+rows.Count,"Üretim","Uyarı","Açık emirler için "+rows.Count+" hammadde yetmeyebilir","Aynı birimdeki reçete oranlarına göre tahmindir: "+Liste(rows),"Satın almayı öne çekin veya emirleri hammadde durumuna göre sıralayın."));
 }

 // ---- MASRAF / FİNANS ----
 static void MukerrerMasraf(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(15) CONVERT(varchar(10),Tarih,104),Kategori,Tutar,COUNT(*) FROM dbo.BoruERP_YeniMasraflar WHERE Tarih>=DATEADD(day,-90,CAST(SYSDATETIME() AS date)) GROUP BY Tarih,Kategori,Tutar,ISNULL(Aciklama,N'') HAVING COUNT(*)>1 ORDER BY Tarih DESC",r=>rows.Add(r.GetString(0)+" "+r.GetString(1)+" "+N(r.GetDecimal(2))+" ×"+r.GetInt32(3)));
  if(rows.Count>0)o.Add(new("masraf-mukerrer-"+rows.Count,"Masraf","Uyarı",rows.Count+" masraf aynı gün, tutar ve açıklamayla tekrarlanmış","Mükerrer giriş gideri şişirir: "+Liste(rows),"Belgeleri kontrol edin; çift girilen masrafı iptal edin."));
 }
 static void KategorisizMasraf(SqlConnection c,List<AkilliOneri> o){
  decimal oran=0,toplam=0;Oku(c,"SELECT COUNT(*),SUM(CASE WHEN Kategori IN(N'Diğer',N'Genel',N'') THEN 1 ELSE 0 END) FROM dbo.BoruERP_YeniMasraflar WHERE Tarih>=DATEADD(day,-90,CAST(SYSDATETIME() AS date))",r=>{toplam=r.GetInt32(0);oran=toplam==0||r.IsDBNull(1)?0:r.GetInt32(1)/toplam;});
  if(toplam>=10&&oran>0.3m)o.Add(new("masraf-kategori","Masraf","Öneri","Son 90 gün masraflarının %"+N(decimal.Round(oran*100,0))+"'ü 'Diğer/Genel'","Kategorisiz gider raporlarda maliyetin nereden geldiğini gizler.","Sık geçen giderler için ayrı kategori açın (yakıt, bakım, nakliye vb.)."));
 }
 static void GecikenOdeme(SqlConnection c,List<AkilliOneri> o){
  var gecik=new List<string>();var yakin=new List<string>();
  Oku(c,"SELECT TOP(40) Baslik,VadeTarihi,Tutar,ParaBirimi FROM dbo.PlanliOdemeler WHERE Durum=N'Bekliyor' AND VadeTarihi<=DATEADD(day,7,CAST(SYSDATETIME() AS date)) ORDER BY VadeTarihi",r=>{string s=r.GetString(0)+" "+r.GetDateTime(1).ToString("dd.MM",tr)+" "+N(r.GetDecimal(2))+" "+r.GetString(3);(r.GetDateTime(1).Date<DateTime.Today?gecik:yakin).Add(s);});
  if(gecik.Count>0)o.Add(new("odeme-gecik-"+gecik.Count,"Finans","Kritik",gecik.Count+" planlı ödemenin vadesi geçti","Gecikme faizi ve tedarikçi ilişkisi riski: "+Liste(gecik),"Ödendiyse durumunu 'Ödendi' yapın; ödenmediyse bugün planlayın."));
  if(yakin.Count>0)o.Add(new("odeme-yakin-"+yakin.Count,"Finans","Öneri",yakin.Count+" ödeme 7 gün içinde","Nakit planı için hatırlatma: "+Liste(yakin),"Hesap bakiyesini kontrol edin."));
 }
 static void YaklasanCekSenet(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(20) EvrakNo,Yon,VadeTarihi,Tutar,ParaBirimi FROM dbo.CekSenetler WHERE Durum IN(N'Portföyde',N'Bekliyor',N'Açık',N'Verildi') AND VadeTarihi<=DATEADD(day,7,CAST(SYSDATETIME() AS date)) ORDER BY VadeTarihi",r=>rows.Add(r.GetString(0)+" ("+r.GetString(1)+") "+r.GetDateTime(2).ToString("dd.MM",tr)+" "+N(r.GetDecimal(3))+" "+r.GetString(4)));
  if(rows.Count>0)o.Add(new("cek-vade-"+rows.Count,"Finans","Uyarı",rows.Count+" çek/senedin vadesi 7 gün içinde veya geçmiş","Tahsil/ödeme takibi: "+Liste(rows),"Tahsil edilen veya ödenenlerin durumunu güncelleyin."));
 }

 // ---- MUHASEBE ----
 static void DengesizFis(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(15) CAST(f.Yil AS varchar(4))+'/'+CAST(f.Sira AS varchar(10)),SUM(k.Borc)-SUM(k.Alacak) FROM dbo.MPX310_Fis f JOIN dbo.MPX310_FisKalem k ON k.FisId=f.Id WHERE f.Durum<>N'İptal' GROUP BY f.Yil,f.Sira HAVING ABS(SUM(k.Borc)-SUM(k.Alacak))>0.009",r=>rows.Add(r.GetString(0)+" fark "+N(r.GetDecimal(1))));
  if(rows.Count>0)o.Add(new("fis-denge-"+rows.Count,"Muhasebe","Kritik",rows.Count+" yevmiye fişinde borç ve alacak eşit değil","Mizan ve bilanço tutmaz: "+Liste(rows),"Fişleri açıp eksik/yanlış kalemi düzeltin veya ters kayıtla iptal edin."));
 }
 static void AcikDonem(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(6) CAST(Yil AS varchar(4))+'/'+RIGHT('0'+CAST(Ay AS varchar(2)),2) FROM dbo.MPX310_Donem WHERE Kapali=0 AND DATEFROMPARTS(Yil,Ay,1)<DATEADD(month,-2,DATEFROMPARTS(YEAR(SYSDATETIME()),MONTH(SYSDATETIME()),1)) ORDER BY Yil,Ay",r=>rows.Add(r.GetString(0)));
  if(rows.Count>0)o.Add(new("donem-acik-"+string.Join("",rows),"Muhasebe","Öneri",rows.Count+" eski ay dönemi hâlâ açık","Kapatılmamış geçmiş aylara sonradan kayıt girilebilir: "+Liste(rows),"Beyannamesi verilmiş ayları muhasebe ekranından kapatın."));
 }

 // ---- CARİ ----
 static void VergiNoEksikCari(SqlConnection c,List<AkilliOneri> o){
  var rows=new List<string>();Oku(c,"SELECT TOP(30) c.Unvan FROM dbo.CariKartlari c WHERE c.Aktif=1 AND NULLIF(LTRIM(RTRIM(c.VergiNo)),N'') IS NULL AND EXISTS(SELECT 1 FROM dbo.TicariBelgeler t WHERE t.CariId=c.Id AND t.Durum<>N'İptal')",r=>rows.Add(r.GetString(0)));
  if(rows.Count>0)o.Add(new("cari-vkn-"+rows.Count,"Cari","Öneri",rows.Count+" faturalı carinin vergi numarası boş","e-Fatura/e-Arşiv ve mutabakat için VKN/TCKN gerekir: "+Liste(rows),"Cari kartlarına vergi numarası ve vergi dairesini girin."));
 }
}
