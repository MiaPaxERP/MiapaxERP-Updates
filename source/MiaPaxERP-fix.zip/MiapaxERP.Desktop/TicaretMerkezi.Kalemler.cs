using System.Data;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using ClosedXML.Excel;
namespace MiapaxERP.Desktop;

/// <summary>
/// Dış ticaret / ticari dosya kalemleri: stoktan ürün ekleme (fiyat ve KDV oranıyla), seçili kalemlere KDV uygulama,
/// GTİP ve net ağırlık, canlı ara toplam / KDV / genel toplam ve proforma fatura (Excel).
/// </summary>
public sealed partial class TicaretMerkezi
{
 readonly string baglanti="";readonly int kullanici;
 readonly TextBlock kalemOzeti=new(){FontSize=14,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,6,0,8),TextWrapping=TextWrapping.Wrap};
 readonly ComboBox kdvSecimi=new(){IsEditable=true,Width=80,Margin=new Thickness(0,0,6,5),ToolTip="KDV / vergi oranı %"};
 static readonly CultureInfo tr=CultureInfo.GetCultureInfo("tr-TR");
 static readonly string[] Birimler=["ADET","KG","TON","METRE","M2","M3","LİTRE","PAKET","KOLİ","PALET","TAKIM"];

 void KalemSutunlariniKur(){
  System.Windows.Data.Binding B(string ad,string? format=null)=>new($"[{ad}]"){StringFormat=format,ConverterCulture=tr,UpdateSourceTrigger=System.Windows.Data.UpdateSourceTrigger.LostFocus};
  kalemGrid.Columns.Add(new DataGridTextColumn{Header="Kod",Binding=B("Kod"),Width=80});
  kalemGrid.Columns.Add(new DataGridTextColumn{Header="Ürün / hizmet",Binding=B("Ürün"),Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=160});
  kalemGrid.Columns.Add(new DataGridTextColumn{Header="Miktar",Binding=B("Miktar","#,0.###"),Width=75});
  kalemGrid.Columns.Add(new DataGridComboBoxColumn{Header="Birim",ItemsSource=Birimler,SelectedItemBinding=new System.Windows.Data.Binding("[Birim]"),Width=80});
  kalemGrid.Columns.Add(new DataGridTextColumn{Header="Birim fiyat",Binding=B("Birim fiyat","#,0.00##"),Width=95});
  kalemGrid.Columns.Add(new DataGridTextColumn{Header="İndirim %",Binding=B("İndirim %","0.##"),Width=70});
  kalemGrid.Columns.Add(new DataGridTextColumn{Header="KDV %",Binding=B("Vergi %","0.##"),Width=60});
  kalemGrid.Columns.Add(new DataGridTextColumn{Header="GTİP",Binding=B("GTİP"),Width=95});
  kalemGrid.Columns.Add(new DataGridTextColumn{Header="Net kg",Binding=B("Net kg","#,0.###"),Width=75});
  kalemGrid.CellEditEnding+=(_,_)=>Dispatcher.BeginInvoke(KalemOzetiniYenile,System.Windows.Threading.DispatcherPriority.Background);
  kalemler.RowChanged+=(_,_)=>Dispatcher.BeginInvoke(KalemOzetiniYenile,System.Windows.Threading.DispatcherPriority.Background);
  kalemler.RowDeleted+=(_,_)=>Dispatcher.BeginInvoke(KalemOzetiniYenile,System.Windows.Threading.DispatcherPriority.Background);
 }

 void KalemAraclari(Panel form){
  var bar=new WrapPanel{Margin=new Thickness(0,4,0,4)};form.Children.Add(bar);
  Dugme(bar,"+ Stoktan ürün ekle",StoktanEkle);
  kdvSecimi.ItemsSource=new[]{"0","1","10","20"};kdvSecimi.Text="20";bar.Children.Add(new TextBlock{Text="KDV %",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(10,0,6,5)});bar.Children.Add(kdvSecimi);
  Dugme(bar,"Seçili kalemlere KDV uygula",()=>KdvUygula(true));
  Dugme(bar,"Tüm kalemlere KDV uygula",()=>KdvUygula(false));
  Dugme(bar,"Seçili kalemi sil",()=>{foreach(var r in kalemGrid.SelectedItems.OfType<DataRowView>().ToList())r.Row.Delete();kalemler.AcceptChanges();KalemOzetiniYenile();});
 }

 void KdvUygula(bool yalnizSecili){
  if(!SayiKutusu.Oku(kdvSecimi.Text,out var oran)||oran<0||oran>100)throw new ArgumentException("KDV oranı 0 ile 100 arasında olmalı.");
  kalemGrid.CommitEdit(DataGridEditingUnit.Row,true);
  var satirlar=yalnizSecili?kalemGrid.SelectedItems.OfType<DataRowView>().Select(v=>v.Row).ToList():kalemler.AsEnumerable().Where(r=>r.RowState!=DataRowState.Deleted).ToList();
  if(satirlar.Count==0)throw new ArgumentException(yalnizSecili?"Önce tabloda bir veya daha fazla kalem seçin (Ctrl ile çoklu seçim).":"Önce kalem ekleyin.");
  foreach(var r in satirlar)r["Vergi %"]=oran;
  KalemOzetiniYenile();
 }

 void KalemOzetiniYenile(){
  try{
   static decimal D(object v)=>v is DBNull or null?0m:Convert.ToDecimal(v);
   decimal brut=0,indirim=0,net=0,kdv=0,kg=0;int n=0;var kdvKirilim=new SortedDictionary<decimal,decimal>();
   foreach(DataRow r in kalemler.Rows){
    if(r.RowState==DataRowState.Deleted)continue;decimal adet=D(r["Miktar"]),fiyat=D(r["Birim fiyat"]),ind=D(r["İndirim %"]),oran=D(r["Vergi %"]);if(adet<=0)continue;
    decimal b=decimal.Round(adet*fiyat,2),nt=decimal.Round(b*(1-ind/100),2),v=decimal.Round(nt*oran/100,2);
    brut+=b;indirim+=b-nt;net+=nt;kdv+=v;kg+=D(r["Net kg"]);n++;kdvKirilim[oran]=kdvKirilim.GetValueOrDefault(oran)+v;
   }
   string doviz=para.SelectedItem as string??"";
   kalemOzeti.Text=n==0?"Kalem yok.":$"{n} kalem · Brüt {brut.ToString("N2",tr)} · İndirim {indirim.ToString("N2",tr)} · Ara toplam {net.ToString("N2",tr)} · KDV {kdv.ToString("N2",tr)}"+(kdvKirilim.Count>1?" ("+string.Join(", ",kdvKirilim.Select(k=>"%"+k.Key.ToString("0.##",tr)+": "+k.Value.ToString("N2",tr)))+")":"")+$" · Genel toplam {(net+kdv).ToString("N2",tr)} {doviz}"+(kg>0?$" · Net ağırlık {kg.ToString("#,0.###",tr)} kg":"");
  }catch(Exception e){kalemOzeti.Text="Kalemlerde geçersiz değer: "+e.Message;}
 }

 void TutariHesapla(){var k=KalemOku();if(k.Length==0)throw new ArgumentException("Önce kalem ekleyin.");metin["Tutar"].Text=k.Sum(x=>x.Toplam()).ToString("#,0.00",tr);KalemOzetiniYenile();}

 void StoktanEkle(){
  DataTable kaynak;bool fiyatli=true;
  try{
   var list=new StokFiyatKdvServisi(baglanti,kullanici).Liste("",false);
   kaynak=new DataTable();foreach(var (c,t) in new[]{("Id",typeof(int)),("Kod",typeof(string)),("Ürün",typeof(string)),("Birim",typeof(string)),("Fiyat",typeof(decimal)),("KDV %",typeof(decimal)),("Fiyat KDV",typeof(string))})kaynak.Columns.Add(c,t);
   foreach(var s in list)kaynak.Rows.Add(s.Id,s.Kod,s.Ad,s.Birim,(object?)(s.Perakende??s.Bayi)??DBNull.Value,s.KdvOrani,s.SatisKdvDahil?"dahil":"hariç");
  }catch(Exception e)when(e is UnauthorizedAccessException||e.GetBaseException() is UnauthorizedAccessException){
   fiyatli=false;var s=new IsletmeServisi(baglanti,kullanici).Secimler("stok");kaynak=new DataTable();kaynak.Columns.Add("Id",typeof(int));kaynak.Columns.Add("Ürün");kaynak.Columns.Add("Birim");foreach(DataRow r in s.Rows)kaynak.Rows.Add(r["Id"],r["Ad"],r["Birim"]);
  }
  var w=new Window{Title="Stoktan ürün ekle",Owner=this,Width=900,Height=600,WindowStartupLocation=WindowStartupLocation.CenterOwner};
  var root=new DockPanel{Margin=new Thickness(14)};w.Content=root;var top=new WrapPanel();DockPanel.SetDock(top,Dock.Top);root.Children.Add(top);
  var ara2=new TextBox{Width=280,Margin=new Thickness(0,0,8,8),ToolTip="Kod veya ad ile ara"};top.Children.Add(ara2);
  var bilgi=new TextBlock{Text=fiyatli?"Fiyat ve KDV, stok 'Birim fiyat ve KDV' listesinden gelir; KDV dahil fiyatlar KDV hariçe çevrilir.":"Fiyat görme yetkiniz olmadığı için fiyat boş gelir; elle girin.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,8)};top.Children.Add(bilgi);
  var grid=new DataGrid{ItemsSource=kaynak.DefaultView,IsReadOnly=true,AutoGenerateColumns=true,SelectionMode=DataGridSelectionMode.Extended};grid.AutoGeneratingColumn+=(_,e)=>{if(e.PropertyName=="Id")e.Cancel=true;};
  var ekle=new Button{Content="Seçilenleri ekle",Padding=new Thickness(14,7,14,7),Margin=new Thickness(0,8,0,0),HorizontalAlignment=HorizontalAlignment.Left,IsDefault=true};DockPanel.SetDock(ekle,Dock.Bottom);root.Children.Add(ekle);root.Children.Add(grid);
  ara2.TextChanged+=(_,_)=>{string q=ara2.Text.Replace("'","''").Replace("[","[[]").Replace("%","[%]").Replace("*","[*]");kaynak.DefaultView.RowFilter=q.Length==0?"":string.Join(" OR ",kaynak.Columns.Cast<DataColumn>().Where(c=>c.DataType==typeof(string)).Select(c=>$"[{c.ColumnName}] LIKE '%{q}%'"));};
  void Ekle(){
   foreach(var v in grid.SelectedItems.OfType<DataRowView>()){
    decimal oran=fiyatli?Convert.ToDecimal(v["KDV %"]):(SayiKutusu.Oku(kdvSecimi.Text,out var k)?k:20);
    decimal fiyat=fiyatli&&v["Fiyat"] is decimal f?(Convert.ToString(v["Fiyat KDV"])=="dahil"&&oran>0?decimal.Round(f/(1+oran/100),4):f):0;
    string kod=fiyatli?Convert.ToString(v["Kod"])??"":"",ad=Convert.ToString(v["Ürün"])??"";if(!fiyatli&&ad.Contains(" · ")){kod=ad[..ad.IndexOf(" · ")];ad=ad[(ad.IndexOf(" · ")+3)..];}
    kalemler.Rows.Add(kod,ad,1m,fiyat,0m,oran,(Convert.ToString(v["Birim"])??"ADET").ToUpper(tr),"",0m);
   }
   KalemOzetiniYenile();w.Close();
  }
  ekle.Click+=(_,_)=>Ekle();grid.MouseDoubleClick+=(_,_)=>Ekle();ara2.Focus();w.ShowDialog();
 }

 /// <summary>Kayıt kartındaki bilgilerle proforma fatura (Excel). Resmî fatura değildir.</summary>
 void Proforma(){
  var k=KalemOku();if(k.Length==0)throw new ArgumentException("Proforma için kalem ekleyin.");
  string doviz=para.SelectedItem as string??"";string S(string a)=>metin.TryGetValue(a,out var t)?t.Text.Trim():"";
  var dlg=new Microsoft.Win32.SaveFileDialog{Filter="Excel|*.xlsx",FileName="Proforma-"+(S("Referans").Length>0?S("Referans"):DateTime.Today.ToString("yyyyMMdd"))+".xlsx"};if(dlg.ShowDialog(this)!=true)return;
  using var wb=new XLWorkbook();var ws=wb.Worksheets.Add("Proforma");
  ws.Cell(1,1).Value="PROFORMA FATURA / PROFORMA INVOICE";ws.Range(1,1,1,10).Merge().Style.Font.SetBold().Font.SetFontSize(16);
  int row=3;void Satir(string a,string b){ws.Cell(row,1).Value=a;ws.Cell(row,1).Style.Font.SetBold();ws.Cell(row,3).Value=b;row++;}
  Satir("Referans",S("Referans"));Satir("Alıcı / Buyer",S("Firma"));Satir("Konu",S("Konu"));Satir("Tarih",(tarih.SelectedDate??DateTime.Today).ToString("dd.MM.yyyy"));Satir("Geçerlilik / Valid until",(vade.SelectedDate??DateTime.Today).ToString("dd.MM.yyyy"));Satir("Para birimi",doviz);
  foreach(string a in db.Akis.Alanlar)if(S(a).Length>0)Satir(a,S(a));
  row++;string[] h=["Kod","Ürün / Description","GTİP / HS code","Miktar","Birim","Birim fiyat","İndirim %","Ara toplam","KDV %","KDV","Toplam","Net kg"];
  for(int i=0;i<h.Length;i++){ws.Cell(row,i+1).Value=h[i];ws.Cell(row,i+1).Style.Font.SetBold().Fill.SetBackgroundColor(XLColor.LightGray);}
  int ilk=++row;
  foreach(var x in k){object[] v=[x.Kod,x.Urun,x.Gtip,x.Adet,x.Birim,x.Fiyat,x.Indirim,x.Net(),x.VergiOrani,x.Vergi(),x.Toplam(),x.NetKg];for(int i=0;i<v.Length;i++)ws.Cell(row,i+1).Value=XLCellValue.FromObject(v[i]);row++;}
  foreach(int c in new[]{6,8,10,11})ws.Range(ilk,c,row-1,c).Style.NumberFormat.Format="#,##0.00";
  row++;Satir("Ara toplam",k.Sum(x=>x.Net()).ToString("N2",tr)+" "+doviz);Satir("KDV",k.Sum(x=>x.Vergi()).ToString("N2",tr)+" "+doviz);Satir("GENEL TOPLAM",k.Sum(x=>x.Toplam()).ToString("N2",tr)+" "+doviz);
  if(k.Sum(x=>x.NetKg)>0)Satir("Toplam net ağırlık",k.Sum(x=>x.NetKg).ToString("#,0.###",tr)+" kg");
  row++;ws.Cell(row,1).Value="Bu belge proforma niteliğindedir; resmî fatura veya e-fatura yerine geçmez.";ws.Cell(row,1).Style.Font.SetItalic();
  ws.Columns().AdjustToContents();wb.SaveAs(dlg.FileName);
 }
}
