using Point = System.Windows.Point;
using Cursors = System.Windows.Input.Cursors;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
namespace MiapaxERP.Desktop;

/// <summary>Yeni gelen bildirim ve duyuruları (lisans paneli duyuruları dahil) ekranın üstünde yanıp sönen "son dakika" bandıyla kısa süre gösterir.</summary>
public partial class MainWindow
{
 HashSet<long>? gorulenBildirimler;Window? sonDakikaPenceresi;
 void SonDakikaDenetle(DuyuruSatiri[] rows){
  if(gorulenBildirimler is null){
   // İlk okumada yalnız son 2 saatteki okunmamışlar gösterilir; eskiler sayaçta kalır.
   gorulenBildirimler=new(rows.Where(r=>r.Okundu||r.Tarih<DateTime.UtcNow.AddHours(-2)).Select(r=>r.Id));
  }
  var yeni=rows.Where(r=>!r.Okundu&&gorulenBildirimler.Add(r.Id)).OrderBy(r=>r.Tarih).ToArray();
  if(yeni.Length>0)SonDakikaGoster(yeni);
 }
 void SonDakikaGoster(DuyuruSatiri[] yeni){
  try{
   sonDakikaPenceresi?.Close();
   var son=yeni[^1];string baslik=yeni.Length>1?$"{yeni.Length} yeni bildirim · {son.Baslik}":son.Baslik;
   string metin=son.Metin.Length>220?son.Metin[..220]+"…":son.Metin;
   var etiket=new Border{Background=new SolidColorBrush(Color.FromRgb(200,30,45)),CornerRadius=new CornerRadius(6),Padding=new Thickness(10,4,10,4),Margin=new Thickness(0,0,12,0),VerticalAlignment=VerticalAlignment.Center,
    Child=new TextBlock{Text="SON DAKİKA",Foreground=Brushes.White,FontWeight=FontWeights.Bold}};
   var yazi=new StackPanel{VerticalAlignment=VerticalAlignment.Center};
   yazi.Children.Add(new TextBlock{Text=baslik,Foreground=Brushes.White,FontWeight=FontWeights.SemiBold,FontSize=15,TextTrimming=TextTrimming.CharacterEllipsis});
   yazi.Children.Add(new TextBlock{Text=metin,Foreground=new SolidColorBrush(Color.FromRgb(230,236,242)),TextWrapping=TextWrapping.Wrap,MaxHeight=40,TextTrimming=TextTrimming.CharacterEllipsis});
   var kapat=new Button{Content="✕",Width=32,Height=32,Margin=new Thickness(12,0,0,0),VerticalAlignment=VerticalAlignment.Center,Background=Brushes.Transparent,Foreground=Brushes.White,BorderThickness=new Thickness(0)};
   var dp=new DockPanel();DockPanel.SetDock(etiket,Dock.Left);DockPanel.SetDock(kapat,Dock.Right);dp.Children.Add(etiket);dp.Children.Add(kapat);dp.Children.Add(yazi);
   var kutu=new Border{Background=new SolidColorBrush(Color.FromRgb(185,22,38)),BorderBrush=new SolidColorBrush(Color.FromRgb(200,30,45)),BorderThickness=new Thickness(2),CornerRadius=new CornerRadius(10),Padding=new Thickness(14,10,10,10),Child=dp,Cursor=Cursors.Hand,ToolTip="Bildirimleri açmak için tıklayın"};
   double w=Math.Min(760,Math.Max(420,ActualWidth-120));
   var p=new Window{Owner=this,WindowStyle=WindowStyle.None,AllowsTransparency=true,Background=Brushes.Transparent,ShowInTaskbar=false,ShowActivated=false,Topmost=false,ResizeMode=ResizeMode.NoResize,
    Width=w,SizeToContent=SizeToContent.Height,Content=kutu};
   var tl=WindowState==WindowState.Maximized?new Point(0,0):new Point(Left,Top);
   p.Left=tl.X+(ActualWidth-w)/2;p.Top=tl.Y+12;
   kapat.Click+=(_,e)=>{e.Handled=true;p.Close();};
   kutu.MouseLeftButtonUp+=(_,_)=>{p.Close();IletisimiAc(false);};
   // Yanıp sönme: kırmızı etiket ve çerçeve 8 kez yanıp söner; band 25 sn sonra kendiliğinden kapanır.
   var yanip=new DoubleAnimation(1,0.25,TimeSpan.FromMilliseconds(450)){AutoReverse=true,RepeatBehavior=new RepeatBehavior(8)};
   etiket.BeginAnimation(OpacityProperty,yanip);
   var cerceve=new ColorAnimation(Color.FromRgb(200,30,45),Color.FromRgb(255,190,60),TimeSpan.FromMilliseconds(450)){AutoReverse=true,RepeatBehavior=new RepeatBehavior(8)};
   kutu.BorderBrush.BeginAnimation(SolidColorBrush.ColorProperty,cerceve);
   var zemin=new ColorAnimation(Color.FromRgb(185,22,38),Color.FromRgb(110,10,20),TimeSpan.FromMilliseconds(450)){AutoReverse=true,RepeatBehavior=new RepeatBehavior(8)};
   kutu.Background.BeginAnimation(SolidColorBrush.ColorProperty,zemin);
   if(!IsActive||WindowState==WindowState.Minimized)WindowsBildirimi(baslik,metin);
   var sure=new System.Windows.Threading.DispatcherTimer{Interval=TimeSpan.FromSeconds(25)};sure.Tick+=(_,_)=>{sure.Stop();if(p.IsVisible)p.Close();};sure.Start();
   p.Closed+=(_,_)=>{if(ReferenceEquals(sonDakikaPenceresi,p))sonDakikaPenceresi=null;};
   sonDakikaPenceresi=p;p.Show();
   System.Media.SystemSounds.Asterisk.Play();
  }catch(Exception e) when(e is InvalidOperationException or ArgumentException){DestekIzleme.Bildir(e,"SonDakika");}
 }
 static System.Windows.Forms.NotifyIcon? bildirimSimgesi;
 /// <summary>Program arka plandayken Windows bildirimi (ekranın köşesinde kayan bildirim) gösterir.</summary>
 void WindowsBildirimi(string baslik,string metin){
  try{
   bildirimSimgesi??=new System.Windows.Forms.NotifyIcon{Icon=System.Drawing.Icon.ExtractAssociatedIcon(Environment.ProcessPath??"")??System.Drawing.SystemIcons.Information,Text="MiaPaxERP",Visible=true};Application.Current.Exit+=(_,_)=>{bildirimSimgesi?.Dispose();bildirimSimgesi=null;};
   bildirimSimgesi.BalloonTipClicked-=BildirimTiklandi;bildirimSimgesi.BalloonTipClicked+=BildirimTiklandi;
   bildirimSimgesi.ShowBalloonTip(10000,baslik.Length>60?baslik[..60]:baslik,string.IsNullOrWhiteSpace(metin)?" ":(metin.Length>200?metin[..200]:metin),System.Windows.Forms.ToolTipIcon.Info);
  }catch(Exception e) when(e is InvalidOperationException or ArgumentException or System.ComponentModel.Win32Exception){DestekIzleme.Bildir(e,"WindowsBildirimi");}
 }
 void BildirimTiklandi(object? s,EventArgs e)=>Dispatcher.Invoke(()=>{if(WindowState==WindowState.Minimized)WindowState=WindowState.Normal;Activate();IletisimiAc(false);});
}
