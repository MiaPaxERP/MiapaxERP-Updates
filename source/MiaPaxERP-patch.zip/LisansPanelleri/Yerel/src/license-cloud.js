import {signLicenseSync} from './legacy/license-sync.js';
const url='https://boruerp-lisans-yonetimi.ali-can-0001.chatgpt.site/api/license-sync';
export function licenseSnapshot(db,id){
 const l=db.prepare('SELECT * FROM licenses WHERE id=?').get(id);if(!l)throw Error('Lisans bulunamadı.');
 const c=db.prepare('SELECT * FROM customers WHERE id=?').get(l.customer_id);
 return {v:1,customer:{id:c.id,name:c.name,sector:c.sector,active:c.active,revision:c.revision},license:{id:l.id,customerId:c.id,keyHash:l.key_hash,label:l.label,modules:JSON.parse(l.modules),moduleExpiresAt:JSON.parse(l.module_expires||'{}'),maxDevices:l.max_devices,startsAt:l.starts_at,expiresAt:l.expires_at,active:l.active,revision:l.revision}};
}
export async function syncLicense(db,env,id,send=fetch){
 if(env.SUPPORT_CLOUD_ENABLED!=='true')return {ok:true,disabled:true};
 db.prepare('INSERT INTO cloud_license_outbox(license_id,status) VALUES(?,\'pending\') ON CONFLICT(license_id) DO UPDATE SET status=\'pending\'').run(id);
 try{const body=await signLicenseSync(env,licenseSnapshot(db,id));const r=await send(url,{method:'POST',redirect:'error',signal:AbortSignal.timeout(10000),headers:{'content-type':'application/json'},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw Error(data.message||'İnternet lisans sunucusuna aktarım başarısız.');db.prepare('UPDATE cloud_license_outbox SET status=\'synced\',error=\'\',synced_at=? WHERE license_id=?').run(new Date().toISOString(),id);return {ok:true};}
 catch(e){const message=String(e.message||'Eşitleme başarısız.').slice(0,500);db.prepare('UPDATE cloud_license_outbox SET status=\'pending\',error=? WHERE license_id=?').run(message,id);return {ok:false,message:'Lisans yerelde kaydedildi, internet etkinleştirmesi bekliyor. '+message};}
}
