namespace MiapaxERP.Lisans.Core;
public static class ModulSureleri
{
 public static bool Acik(LisansIcerigi p,string module,DateTimeOffset now){
  return Acik(p.Modules,p.ModuleExpiresAt,module,now,p.Catalog>=UrunKatalogu.ModulKataloguSurumu);
 }
 /// <param name="kesinKatalog">true: modül listesi katalog 3 ile imzalandı, alt modüller yalnız açıkça satılmışsa açılır.
 /// false (eski lisans/sunucu): alt modül, üst modülü açıksa (veya "*" ise her zaman) açık sayılır.</param>
 public static bool Acik(string[] modules,Dictionary<string,DateTimeOffset>? dates,string module,DateTimeOffset now,bool kesinKatalog=false){
  if(!kesinKatalog&&UrunKatalogu.AltModuller.TryGetValue(module,out var ust)&&!modules.Contains(module))return ust=="*"||Acik(modules,dates,ust,now,false);
  if(!modules.Contains(module)||dates?.TryGetValue(module,out var end)==true&&end<=now)return false;
  if(UrunKatalogu.AltModuller.TryGetValue(module,out var parent)&&parent!="*"&&!Acik(modules,dates,parent,now,kesinKatalog))return false;
  return module switch{"URETIM" or "LABORATUVAR"=>Acik(modules,dates,"STOK",now,kesinKatalog),"RESTORAN"=>new[]{"STOK","URETIM","SATIS","FINANS"}.All(m=>Acik(modules,dates,m,now,kesinKatalog)),_=>true};
 }
 /// <summary>Lisansta fiilen açık olan tüm modüller (eski lisanslarda üst modülden gelen alt modüller dahil).</summary>
 public static string[] Etkin(LisansIcerigi p,DateTimeOffset now)=>UrunKatalogu.Moduller.Select(m=>m.Kod).Where(m=>Acik(p,m,now)).ToArray();
 public static (string Modul,DateTimeOffset Bitis)[] Yaklasan(LisansIcerigi p,DateTimeOffset now)=>p.ModuleExpiresAt?.Where(x=>p.Modules.Contains(x.Key)&&x.Value>now&&x.Value<=now.AddDays(7)).Select(x=>(x.Key,x.Value)).ToArray()??[];
 public static void Dogrula(LisansIcerigi p){if(p.ModuleExpiresAt is null)return;if(p.ModuleExpiresAt.Count>UrunKatalogu.Moduller.Length||p.ModuleExpiresAt.Any(x=>!p.Modules.Contains(x.Key)||x.Value<p.NotBefore||p.ExpiresAt.HasValue&&x.Value>p.ExpiresAt.Value))throw new InvalidDataException("Modül süreleri geçersiz.");}
}
