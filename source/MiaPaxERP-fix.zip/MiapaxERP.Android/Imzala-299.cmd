@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Imzala-299.ps1" > "%~dp0imzala-sonuc.txt" 2>&1
echo BITTI >> "%~dp0imzala-sonuc.txt"
