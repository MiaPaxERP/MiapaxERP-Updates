using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record ExcelStokTipi(int Id, string Ad, bool Zorunlu);
public sealed record ExcelStokKategorisi(int Id, int TipId, int? UstId, string Ad);
public sealed record ExcelStokOnBilgisi(List<ExcelStokTipi> Tipler, List<ExcelStokKategorisi> Kategoriler, List<string> Kodlar, bool AcilisIzni);

public sealed partial class IsletmeServisi
{
 /// <summary>Excel toplu stok önizlemesi için stok tipleri, kategoriler, mevcut kodlar ve açılış izni (SQL veya HTTPS).</summary>
 public ExcelStokOnBilgisi ExcelOnBilgi()
 {
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<ExcelStokOnBilgisi>(connection,"IsletmeServisi.ExcelOnBilgi","",[]);
  using var con=access.Ac();
  Yetki(con,null,"STOCK.CREATE");
  bool acilis;try{Yetki(con,null,"STOCK.OPENING");acilis=true;}catch(Exception){acilis=false;}
  var zorunlu=new HashSet<int>();
  using(var q=Q(con,null,"IF OBJECT_ID(N'dbo.StokOzellikTanimlari',N'U') IS NOT NULL AND COL_LENGTH(N'dbo.StokOzellikTanimlari',N'Zorunlu') IS NOT NULL EXEC(N'SELECT DISTINCT StokTipId FROM dbo.StokOzellikTanimlari WHERE Aktif=1 AND Zorunlu=1 AND StokTipId IS NOT NULL') ELSE SELECT CAST(NULL AS int) WHERE 1=0"))
  using(var r=q.ExecuteReader())while(r.Read())if(!r.IsDBNull(0))zorunlu.Add(r.GetInt32(0));
  var tipler=new List<ExcelStokTipi>();
  using(var q=Q(con,null,"SELECT Id,Ad FROM dbo.StokTipleri WHERE Aktif=1 ORDER BY Id"))
  using(var r=q.ExecuteReader())while(r.Read())tipler.Add(new(r.GetInt32(0),r.GetString(1),zorunlu.Contains(r.GetInt32(0))));
  var kategoriler=new List<ExcelStokKategorisi>();
  using(var q=Q(con,null,"IF OBJECT_ID(N'dbo.StokKategorileri',N'U') IS NOT NULL EXEC(N'SELECT Id,StokTipId,UstKategoriId,Ad FROM dbo.StokKategorileri WHERE Aktif=1') ELSE SELECT 0,0,CAST(NULL AS int),N'' WHERE 1=0"))
  using(var r=q.ExecuteReader())while(r.Read())kategoriler.Add(new(r.GetInt32(0),r.GetInt32(1),r.IsDBNull(2)?null:r.GetInt32(2),r.GetString(3)));
  var kodlar=new List<string>();
  using(var q=Q(con,null,"SELECT StokKodu FROM dbo.StokKartlari"))
  using(var r=q.ExecuteReader())while(r.Read())kodlar.Add(r.GetString(0));
  return new(tipler,kategoriler,kodlar,acilis);
 }
}
