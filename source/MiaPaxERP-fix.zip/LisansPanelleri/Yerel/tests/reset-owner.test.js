import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,existsSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {openDatabase} from '../src/database.js';
import {createAccount,createPortal} from '../src/portal.js';
import {sahipParolasiniSifirla,geciciParola} from '../src/reset-owner.js';

const origin='http://127.0.0.1:5290';
test('owner password reset keeps data, forces change and allows login',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'parola-')),dbPath=join(dir,'portal.sqlite');
 try{
  let db=openDatabase(dbPath);const id=await createAccount(db,{username:'yonetici',name:'Yönetici',role:'OWNER',password:'eski-parola-uzun-123'});
  db.prepare('UPDATE accounts SET must_change=0 WHERE id=?').run(id);db.prepare("INSERT INTO auth_limits VALUES('x',99,?)").run(Math.floor(Date.now()/1000)+600);
  const before=db.prepare('SELECT COUNT(*) n FROM customers').get().n;db.close();
  const r=await sahipParolasiniSifirla(dbPath,{backupDir:dir});
  assert.equal(r.username,'yonetici');assert.ok(r.password.length>=14);assert.ok(existsSync(r.backup));
  const bdb=new DatabaseSync(r.backup,{readOnly:true});assert.equal(bdb.prepare('SELECT COUNT(*) n FROM accounts').get().n,1);bdb.close();
  db=openDatabase(dbPath);
  assert.equal(db.prepare('SELECT must_change FROM accounts WHERE id=?').get(id).must_change,1);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM auth_limits').get().n,0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM customers').get().n,before);
  const handle=createPortal(db,{PUBLIC_ORIGIN:origin,PAYMENTS_ENABLED:'false'},{});
  const login=async(password)=>handle(new Request(origin+'/api/login',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({username:'yonetici',password})}));
  assert.equal((await login('eski-parola-uzun-123')).status,401);
  const ok=await login(r.password);assert.equal(ok.status,200);
  const cookie=ok.headers.get('set-cookie').split(';')[0];
  const state=await handle(new Request(origin+'/api/state',{headers:{origin,cookie}}));assert.equal(state.status,428);
  const ch=await handle(new Request(origin+'/api/password',{method:'POST',headers:{origin,cookie,'content-type':'application/json'},body:JSON.stringify({current:r.password,next:'yepyeni-guclu-parola-2026'})}));assert.equal(ch.status,200);
  assert.equal((await login('yepyeni-guclu-parola-2026')).status,200);
  db.close();
 }finally{rmSync(dir,{recursive:true,force:true});}
});
test('temporary password format is readable and strong',()=>{const p=geciciParola();assert.match(p,/^[A-Za-z2-9]{5}(-[A-Za-z2-9]{5}){3}$/);assert.notEqual(p,geciciParola());});
