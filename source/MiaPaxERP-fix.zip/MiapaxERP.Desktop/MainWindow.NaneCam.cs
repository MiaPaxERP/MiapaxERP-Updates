using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using HorizontalAlignment = System.Windows.HorizontalAlignment;
using VerticalAlignment = System.Windows.VerticalAlignment;
using Orientation = System.Windows.Controls.Orientation;
using MouseEventArgs = System.Windows.Input.MouseEventArgs;
using Cursors = System.Windows.Input.Cursors;

namespace MiapaxERP.Desktop;

/// <summary>
/// "Cam" tema ailesi (Nane, Okyanus, Lavanta, Gün Batımı, Gece) gösterge paneli kabuğu:
/// degrade zemin; solda yüzen, yuvarlak, yalnız ikonlu ince menü (üzerine gelince açılır);
/// üstte karşılama kartı, sağ sütunda iş takvimi; buzlu cam kartlar.
/// Diğer temalara geçildiğinde özgün kabuk aynen geri yüklenir.
/// </summary>
public partial class MainWindow
{
    const double RayDar = 76, RayGenis = 286;
    bool camUygulandi, rayAcik;
    Grid? camPano; StackPanel? camSol, camSag; Border? camKarsilama; Panel? panoAsil; int panoSira;
    readonly List<UIElement> panoCocuklari = new();
    readonly Dictionary<Button, string> menuIkonlari = new();
    static ControlTemplate? menuSablonu;
    bool menuSecimiBagli;

    /// <summary>Menü düğmeleri için şeffaf, yuvarlak şablon: gri kutu görünmez; üzerine gelince hafif aydınlanır, seçili olan vurgulanır.</summary>
    static ControlTemplate MenuSablonu() => menuSablonu ??= (ControlTemplate)XamlReader.Parse("""
<ControlTemplate xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" TargetType="Button">
  <Border x:Name="Yuzey" CornerRadius="14" Background="{TemplateBinding Background}" Padding="{TemplateBinding Padding}" SnapsToDevicePixels="True">
    <ContentPresenter HorizontalAlignment="{TemplateBinding HorizontalContentAlignment}" VerticalAlignment="Center" RecognizesAccessKey="True"/>
  </Border>
  <ControlTemplate.Triggers>
    <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Yuzey" Property="Background" Value="#2EFFFFFF"/></Trigger>
    <Trigger Property="IsPressed" Value="True"><Setter TargetName="Yuzey" Property="Background" Value="#45FFFFFF"/></Trigger>
    <Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.5"/></Trigger>
  </ControlTemplate.Triggers>
</ControlTemplate>
""");

    /// <summary>Menü yazısına göre sade çizgi ikon (Segoe UI Symbol / Emoji tek renk çizer).</summary>
    static string MenuIkonu(string metin)
    {
        string t = metin.ToLower(new System.Globalization.CultureInfo("tr-TR"));
        (string anahtar, string ikon)[] harita = [
            ("whatsapp","💬"),("saha müşteri","💬"),("saha","📍"),("hızlı satış","⚡"),("teklif","📄"),("tahsilat","💰"),("satış","🛒"),
            ("satın alma eşleştirme","🔗"),("satın alma","🧾"),("dış ticaret","🌍"),("insan","👤"),("e-ticaret","🛍"),("mobil","📱"),
            ("lisans","🔑"),("sektör","🏭"),("masa","🍽"),("ana sayfa","🏠"),("firma","🏢"),("üretilen","📦"),("stok hareket","🔁"),
            ("stok","📦"),("reçete","🧪"),("mrp","📈"),("maliyet","📈"),("üretim","🏭"),("cari","👥"),("genel muhasebe","📒"),("muhasebe","📒"),
            ("kroki","🗺"),("makine","🔧"),("rapor","📊"),("excel","🖨"),("kullanıcı","🛡"),("laboratuvar","🔬"),("web","🌐"),
            ("uzaktan","🔗"),("mağaza","🏬"),("ayarlar","⚙"),("sevkiyat","🚚"),("basınç","🧯"),("depo","🏷")];
        foreach (var (a, i) in harita) if (t.Contains(a)) return i;
        return "▪";
    }

    void CamKabugu(GorunumTercihleri a)
    {
        // Tüm temalarda menü düğmeleri şeffaf şablonla çizilir (gri kutu görünümü yok).
        foreach (Button b in TemaMenuOgeleri.Children.OfType<Button>()) b.Template = MenuSablonu();
        TemaOkunurlugu.Haric(TemaMenu);
        if (!menuSecimiBagli)
        {
            menuSecimiBagli = true;
            // Seçili modül menüde vurgu rengiyle işaretli kalır.
            TemaMenuOgeleri.AddHandler(Button.ClickEvent, new RoutedEventHandler((_, e) =>
            {
                if (e.OriginalSource is not Button secilen || !TemaMenuOgeleri.Children.Contains(secilen)) return;
                foreach (Button b in TemaMenuOgeleri.Children.OfType<Button>()) b.ClearValue(BackgroundProperty);
                secilen.SetResourceReference(BackgroundProperty, "ErpVurgu");
            }), true);
        }
        Dispatcher.InvokeAsync(TakvimYerlesiminiUygula, System.Windows.Threading.DispatcherPriority.Loaded);
        bool cam = Tema170.CamMi(a.Tema);
        string yer = Tema170.Yerlesim(a);
        var baslik = TemaIcerik.Children.OfType<Border>().FirstOrDefault(b => Grid.GetRow(b) == 0);
        if (!cam) { NaneTemizle(baslik); return; }

        var golge = Color.FromRgb(0x0B, 0x2A, 0x22);
        TemaKabuk.SetResourceReference(Panel.BackgroundProperty, "ErpZemin");
        TemaMenu.CornerRadius = new CornerRadius(30);
        TemaMenu.Effect = new DropShadowEffect { BlurRadius = 30, ShadowDepth = 6, Direction = 270, Opacity = .2, Color = golge };
        TemaMenu.ClipToBounds = true;
        if (baslik != null)
        {
            baslik.CornerRadius = new CornerRadius(26);
            baslik.BorderThickness = new Thickness(0);
            baslik.Margin = new Thickness(0, 0, 0, 14);
            baslik.Effect = new DropShadowEffect { BlurRadius = 24, ShadowDepth = 4, Direction = 270, Opacity = .16, Color = golge };
        }
        if (yer == "Üst menü")
        {
            TemaMenu.Margin = new Thickness(14, 14, 14, 0);
            TemaIcerik.Margin = new Thickness(14);
        }
        else RayKur(yer == "Sağ menü");
        PanoyuCamYap(a);
        camUygulandi = true;
    }

    /// <summary>İnce ikon menü: menü üstte katman olarak durur, fareyle üzerine gelince yazılarla birlikte genişler.</summary>
    void RayKur(bool sag)
    {
        int menuSutun = sag ? 1 : 0, icerikSutun = sag ? 0 : 1;
        TemaKabuk.ColumnDefinitions[menuSutun].Width = new GridLength(RayDar + 28);
        TemaKabuk.ColumnDefinitions[icerikSutun].Width = new GridLength(1, GridUnitType.Star);
        Grid.SetColumn(TemaMenu, 0); Grid.SetColumnSpan(TemaMenu, 2);
        TemaMenu.HorizontalAlignment = sag ? HorizontalAlignment.Right : HorizontalAlignment.Left;
        TemaMenu.Width = RayDar; TemaMenu.Margin = new Thickness(14);
        Panel.SetZIndex(TemaMenu, 50);
        Grid.SetColumn(TemaIcerik, icerikSutun);
        TemaIcerik.Margin = sag ? new Thickness(14, 14, 0, 14) : new Thickness(0, 14, 14, 14);
        foreach (Button b in TemaMenuOgeleri.Children.OfType<Button>())
        {
            if (!menuIkonlari.ContainsKey(b) && b.Content is string c) menuIkonlari[b] = c[..Math.Min(c.Length, c.TakeWhile(ch => !char.IsLetterOrDigit(ch)).Count())];
            DilUygulayici.IkonDegistir(b, MenuIkonu(DilUygulayici.TurkceAsil(b)));
            b.HorizontalContentAlignment = HorizontalAlignment.Left;
            b.Padding = new Thickness(17, 0, 10, 0);
            b.Margin = new Thickness(9, 3, 9, 3);
            b.FontSize = 15;
            b.Width = RayGenis - 18;
            if (b.ToolTip is null) b.ToolTip = DilUygulayici.TurkceAsil(b).TrimStart(' ', '▪').Trim();
        }
        TemaMarka.Margin = new Thickness(12, 20, 12, 18);
        ImgFirmaLogosu.Width = ImgFirmaLogosu.Height = 46;
        TxtFirmaBasligi.FontSize = 21; TxtFirmaBasligi.MaxWidth = 170;
        RayDurumu(false, false);
        TemaMenu.MouseEnter -= RayAc; TemaMenu.MouseLeave -= RayKapat;
        TemaMenu.MouseEnter += RayAc; TemaMenu.MouseLeave += RayKapat;
    }
    void RayAc(object? s, MouseEventArgs e) => RayDurumu(true, true);
    void RayKapat(object? s, MouseEventArgs e) => RayDurumu(false, true);
    void RayDurumu(bool acik, bool animasyon)
    {
        if (!camUygulandi && animasyon) return;
        rayAcik = acik;
        double hedef = acik ? RayGenis : RayDar;
        if (animasyon) TemaMenu.BeginAnimation(WidthProperty, new DoubleAnimation(hedef, TimeSpan.FromMilliseconds(170)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
        else { TemaMenu.BeginAnimation(WidthProperty, null); TemaMenu.Width = hedef; }
        // Dar hâlde firma yazıları ve menü arama satırı gizlenir; yalnız logo ve ikonlar kalır.
        var gorunum = acik ? Visibility.Visible : Visibility.Collapsed;
        if (TxtFirmaBasligi.Parent is FrameworkElement yazilar) yazilar.Visibility = gorunum;
        if (TemaMarka.Parent is DockPanel dock && dock.Children.Count > 1 && dock.Children[1] is DockPanel araclar) araclar.Visibility = gorunum;
        TemaMenuKaydir.VerticalScrollBarVisibility = acik ? ScrollBarVisibility.Auto : ScrollBarVisibility.Hidden;
    }

    /// <summary>Ana sayfa iki sütun: solda karşılama kartı ve özet kartları, sağda iş takvimi.</summary>
    void PanoyuCamYap(GorunumTercihleri a)
    {
        if (BrdIsTakvimi.Parent is not StackPanel pano) return;
        panoAsil = pano; panoCocuklari.Clear(); panoCocuklari.AddRange(pano.Children.OfType<UIElement>());
        camSol = new StackPanel(); camSag = new StackPanel();
        camPano = new Grid { Margin = pano.Margin };
        camPano.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        camPano.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(16) });
        camPano.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(380) });
        Grid.SetColumn(camSag, 2); camPano.Children.Add(camSol); camPano.Children.Add(camSag);
        pano.Children.Clear();
        camKarsilama = KarsilamaKarti();
        camSol.Children.Add(camKarsilama);
        foreach (var c in panoCocuklari) (ReferenceEquals(c, BrdIsTakvimi) ? camSag : camSol).Children.Add(c);
        // Takvim dar sütunda alt alta yerleşir.
        TemaTakvimAlani.ColumnDefinitions[0].Width = new GridLength(1, GridUnitType.Star);
        pano.Children.Add(camPano);
    }

    Border KarsilamaKarti()
    {
        string ad = aktifKullanici?.AdSoyad is { Length: > 0 } n ? n : aktifKullanici?.KullaniciAdi ?? "";
        int saat = DateTime.Now.Hour;
        string selam = saat < 6 ? "İyi geceler" : saat < 12 ? "Günaydın" : saat < 18 ? "İyi günler" : "İyi akşamlar";
        var yigin = new StackPanel();
        var ust = new TextBlock { Text = selam + (ad.Length > 0 ? ", " + ad : ""), FontSize = 30, FontWeight = FontWeights.SemiBold, Foreground = Brushes.White };
        var alt = new TextBlock { Text = "İşinizin her adımı tek bir merkezde. Bugünkü işler, takvim ve kısayollar aşağıda.", FontSize = 14, Opacity = .82, Foreground = Brushes.White, Margin = new Thickness(0, 6, 0, 16), TextWrapping = TextWrapping.Wrap };
        yigin.Children.Add(ust); yigin.Children.Add(alt);
        var dugmeler = new WrapPanel();
        foreach (var (yazi, hedef) in new[] { ("🛒  Satış", "BtnMenuSatis"), ("📦  Stok", "BtnMenuStok"), ("📊  Raporlar", "BtnMenuRaporlar"), ("👥  Cari", "BtnMenuCari") })
        {
            if (FindName(hedef) is not Button menu || menu.Visibility != Visibility.Visible) continue;
            var b = new Button { Content = yazi, Padding = new Thickness(16, 8, 16, 8), Margin = new Thickness(0, 0, 10, 6), Foreground = Brushes.White, BorderThickness = new Thickness(0), FontWeight = FontWeights.SemiBold, Cursor = Cursors.Hand };
            b.SetResourceReference(BackgroundProperty, "ErpVurgu");
            b.Click += (_, _) => menu.RaiseEvent(new RoutedEventArgs(Button.ClickEvent, menu));
            dugmeler.Children.Add(b);
        }
        yigin.Children.Add(dugmeler);
        var kart = new Border { Child = yigin, Padding = new Thickness(28, 24, 28, 22), Margin = new Thickness(0, 0, 0, 16), CornerRadius = new CornerRadius(26), Effect = new DropShadowEffect { BlurRadius = 26, ShadowDepth = 5, Direction = 270, Opacity = .18, Color = Color.FromRgb(0x0B, 0x2A, 0x22) } };
        kart.SetResourceReference(Border.BackgroundProperty, "ErpMenu");
        TemaOkunurlugu.Haric(kart);
        return kart;
    }

    /// <summary>Cam düzenini geri alır: pano, menü ve marka alanı özgün hâline döner.</summary>
    void CamGeriAl()
    {
        if (!camUygulandi) return;
        camUygulandi = false;
        if (panoAsil != null && camPano != null)
        {
            camSol?.Children.Clear(); camSag?.Children.Clear();
            panoAsil.Children.Clear();
            foreach (var c in panoCocuklari) panoAsil.Children.Add(c);
            panoCocuklari.Clear(); camPano = null; camKarsilama = null;
        }
        TemaMenu.MouseEnter -= RayAc; TemaMenu.MouseLeave -= RayKapat;
        TemaMenu.BeginAnimation(WidthProperty, null);
        TemaMenu.ClearValue(WidthProperty); TemaMenu.ClearValue(HorizontalAlignmentProperty);
        Grid.SetColumnSpan(TemaMenu, 1); Panel.SetZIndex(TemaMenu, 0);
        TemaMenu.ClipToBounds = false;
        foreach (var (b, ikon) in menuIkonlari) { DilUygulayici.IkonDegistir(b, ikon); b.ClearValue(WidthProperty); }
        menuIkonlari.Clear();
        if (TxtFirmaBasligi.Parent is FrameworkElement yazilar) yazilar.Visibility = Visibility.Visible;
        if (TemaMarka.Parent is DockPanel dock && dock.Children.Count > 1 && dock.Children[1] is DockPanel araclar) araclar.Visibility = Visibility.Visible;
        TemaMenuKaydir.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
    }

    void NaneTemizle(Border? baslik)
    {
        TemaKabuk.ClearValue(Panel.BackgroundProperty);
        TemaMenu.ClearValue(FrameworkElement.MarginProperty);
        TemaMenu.ClearValue(Border.CornerRadiusProperty);
        TemaMenu.Effect = null;
        TemaIcerik.ClearValue(FrameworkElement.MarginProperty);
        TemaMarka.Margin = new Thickness(20, 25, 20, 30);
        TxtFirmaBasligi.FontSize = 27; TxtFirmaBasligi.MaxWidth = 220;
        if (baslik != null)
        {
            baslik.ClearValue(Border.CornerRadiusProperty);
            baslik.BorderThickness = new Thickness(0, 0, 0, 1);
            baslik.ClearValue(FrameworkElement.MarginProperty);
            baslik.Effect = null;
        }
    }
}
