// Yerel panel sahibi (OWNER) için geçici parola üretir.
// Önce SQLite yedeği alınır; müşteri, lisans ve cihaz kayıtlarına dokunulmaz.
// Parola konsola yalnız bu aracı çalıştıran Windows kullanıcısına JSON olarak yazılır.
import {resolve,dirname,join} from 'node:path';
import {existsSync} from 'node:fs';
import {randomInt} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {passwordHash,audit} from './security.js';

const ALFABE='ABCDEFGHJKLMNPRSTUVYZabcdefghjkmnprstuvyz23456789';
export function geciciParola(){const parca=()=>Array.from({length:5},()=>ALFABE[randomInt(ALFABE.length)]).join('');return [parca(),parca(),parca(),parca()].join('-');}

export async function sahipParolasiniSifirla(dbPath,{username='',backupDir=dirname(dbPath),now=new Date()}={}){
 if(!existsSync(dbPath))throw Error('Panel veritabanı bulunamadı: '+dbPath);
 const db=new DatabaseSync(dbPath);
 try{
  db.exec('PRAGMA busy_timeout=8000');
  const a=username?db.prepare("SELECT * FROM accounts WHERE username=? COLLATE NOCASE AND role='OWNER'").get(username):db.prepare("SELECT * FROM accounts WHERE role='OWNER' ORDER BY created_at LIMIT 1").get();
  if(!a)throw Error('Yönetici (OWNER) hesabı bulunamadı. İlk kurulum için npm run kur kullanılır.');
  const stamp=now.toISOString().replace(/[-:]/g,'').replace('T','-').slice(0,15);
  const backup=join(backupDir,'portal-parola-oncesi-'+stamp+'.sqlite');
  db.exec("VACUUM INTO '"+backup.replaceAll("'","''")+"'");
  const parola=geciciParola(),hash=await passwordHash(parola);
  db.exec('BEGIN IMMEDIATE');
  try{
   const r=db.prepare('UPDATE accounts SET password_hash=?,must_change=1,active=1 WHERE id=? AND password_hash=?').run(hash,a.id,a.password_hash);
   if(!r.changes)throw Error('Hesap aynı anda değişti; işlem yapılmadı. Yeniden deneyin.');
   db.prepare('DELETE FROM sessions WHERE account_id=?').run(a.id);
   db.prepare('DELETE FROM auth_limits').run();
   audit(db,a.id,'Parola yerel sıfırlama aracıyla yenilendi',a.id,'Bilgisayardaki araçla; ilk girişte değişim zorunlu');
   db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}
  return {username:a.username,password:parola,backup};
 }finally{db.close();}
}

if(import.meta.url===`file:///${process.argv[1]?.replaceAll('\\','/').replace(/^\//,'')}`||process.argv[1]?.endsWith('reset-owner.js')){
 const dbPath=resolve(process.env.DB_PATH||'data/portal.sqlite');
 try{const r=await sahipParolasiniSifirla(dbPath,{username:process.env.PANEL_USER||''});process.stdout.write(JSON.stringify({ok:true,...r}));}
 catch(e){process.stdout.write(JSON.stringify({ok:false,error:e.message}));process.exitCode=1;}
}
