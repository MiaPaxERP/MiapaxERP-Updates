﻿using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using HorizontalAlignment = System.Windows.HorizontalAlignment;
using VerticalAlignment = System.Windows.VerticalAlignment;
using Orientation = System.Windows.Controls.Orientation;
using System.Windows.Controls.Primitives;
using Point = System.Windows.Point;
using Size = System.Windows.Size;
using Path = System.Windows.Shapes.Path;

namespace MiapaxERP.Desktop;

/// <summary>
/// Temaya göre tamamen farklı gösterge paneli: her tema kendi widget setini ve yerleşimini kullanır
/// (ör. Nane Cam ekip + istatistik, Okyanus Cam finans akışı, Lavanta Cam görev panosu, Gün Batımı Cam satış vitrini,
/// Gece Cam üretim kontrol odası, VIP yönetici özeti, Eskitme/Klasik defter görünümü).
/// Veriler <see cref="PanoOzetiServisi"/> ile yetkiye göre okunur; yetkisi olmayan widget gösterilmez.
/// </summary>
public partial class MainWindow
{
    Border? temaPanosu; PanoOzeti? panoOzeti; bool panoYukleniyor;
    static readonly CultureInfo trP = CultureInfo.GetCultureInfo("tr-TR");

    /// <summary>Tema panosunun adı ve kısa tanımı (Görünüm ayarlarında ve pano başlığında gösterilir).</summary>
    internal static (string Ad, string Tanim) PanoKimligi(string tema) => tema switch
    {
        "Nane Cam" => ("Ekip ve istatistik", "Ekip, bugünkü veriler ve haftalık satış grafiği"),
        "Okyanus Cam" => ("Finans akışı", "Satış, alacak ve tahsilat göstergeleri ile 7 günlük akış"),
        "Lavanta Cam" => ("Görev panosu", "Gecikmiş, bugün ve yarın sütunlu iş panosu"),
        "Gün Batımı Cam" => ("Satış vitrini", "Günün satışı, en iyi müşteriler ve tahsilat oranı"),
        "Gece Cam" => ("Kontrol odası", "Üretim ilerlemesi ve stok alarmları"),
        "VIP" => ("Yönetici özeti", "Aylık performans, alacak ve risk göstergeleri"),
        "Modern" or "Yenilikçi" => ("Gösterge ızgarası", "İkonlu gösterge kutuları"),
        "Doğal" or "Kültürel" => ("Günün akışı", "Zaman çizelgesi ve kısa özet"),
        "Eskitme" or "Klasik" => ("Defter görünümü", "Sade, satır satır özet"),
        "Canlı" => ("Renkli kutular", "Canlı renkli gösterge kutuları"),
        _ => ("Özet kutuları", "Temel göstergeler")
    };

    void TemaPanosunuKur(GorunumTercihleri a)
    {
        if (BrdIsTakvimi.Parent is not Panel pano) return;
        if (temaPanosu is null)
        {
            temaPanosu = new Border { Margin = new Thickness(0, 0, 0, 14) };
            temaPanosu.IsVisibleChanged += (_, e) => { if (e.NewValue is true) _ = TemaPanosunuYenileAsync(); };
        }
        if (temaPanosu.Parent is Panel eski && !ReferenceEquals(eski, pano)) eski.Children.Remove(temaPanosu);
        pano.Children.Remove(temaPanosu);
        // Kullanıcının seçtiği ana sayfa düzeninin ilk bölümü (takvim / modül / haber) başta kalır; tema panosu hemen ardından gelir.
        pano.Children.Insert(Math.Min(1, pano.Children.Count), temaPanosu);
        TemaPanosunuCiz();
    }

    async Task TemaPanosunuYenileAsync()
    {
        if (panoYukleniyor || aktifKullanici is null || DemoModu || temaPanosu is null) return;
        int u = aktifKullanici.KullaniciId; panoYukleniyor = true;
        try
        {
            var ozet = await Task.Run(() => new PanoOzetiServisi(baglantiAdresi, u).Oku());
            if (aktifKullanici?.KullaniciId != u) return;
            panoOzeti = ozet; TemaPanosunuCiz();
        }
        catch (Exception e) { DestekIzleme.Bildir(e, "MainWindow.TemaPanosu"); }
        finally { panoYukleniyor = false; }
    }

    void TemaPanosunuCiz()
    {
        if (temaPanosu is null) return;
        var o = panoOzeti;
        if (o is null || aktifKullanici is null) { temaPanosu.Visibility = Visibility.Collapsed; return; }
        string tema = gorunum.Tema;
        UIElement icerik = tema switch
        {
            "Nane Cam" => NanePano(o),
            "Okyanus Cam" => OkyanusPano(o),
            "Lavanta Cam" => LavantaPano(o),
            "Gün Batımı Cam" => GunBatimiPano(o),
            "Gece Cam" => GecePano(o),
            "VIP" => VipPano(o),
            "Eskitme" or "Klasik" => DefterPano(o),
            "Doğal" or "Kültürel" => AkisPano(o),
            "Modern" or "Yenilikçi" or "Canlı" => IzgaraPano(o, tema == "Canlı"),
            _ => IzgaraPano(o, false)
        };
        temaPanosu.Child = icerik;
        temaPanosu.Visibility = Visibility.Visible;
        TemaOkunurlugu.Haric(temaPanosu);
    }

    // ---------- Ortak parçalar ----------
    static string Para(decimal v) => v >= 1_000_000 ? (v / 1_000_000m).ToString("0.#", trP) + " Mn ₺" : v >= 10_000 ? (v / 1000m).ToString("0.#", trP) + " B ₺" : v.ToString("#,##0", trP) + " ₺";
    static string Yuzde(decimal simdi, decimal once) => once <= 0 ? (simdi > 0 ? "yeni" : "—") : ((simdi - once) / once * 100m).ToString("+0;-0", trP) + "%";

    Border Kutu(UIElement child, double pad = 16, string? arka = null, double kose = 18)
    {
        var b = new Border { Child = child, Padding = new Thickness(pad), CornerRadius = new CornerRadius(kose), Margin = new Thickness(0, 0, 12, 12) };
        if (arka is null) b.SetResourceReference(Border.BackgroundProperty, "ErpKart"); else b.Background = Tema170.Firca(arka);
        if (gorunum.Golge) b.Effect = new DropShadowEffect { BlurRadius = 18, ShadowDepth = 2, Direction = 270, Opacity = .08, Color = Colors.Black };
        return b;
    }
    static TextBlock Yazi(string t, double boyut = 13, bool kalin = false, double opak = 1, string? renk = null)
    {
        var x = new TextBlock { Text = t, FontSize = boyut, FontWeight = kalin ? FontWeights.SemiBold : FontWeights.Normal, Opacity = opak, TextWrapping = TextWrapping.Wrap };
        if (renk is null) x.SetResourceReference(TextBlock.ForegroundProperty, "ErpMetin"); else x.Foreground = Tema170.Firca(renk);
        return x;
    }
    static UniformGrid Izgara(int sutun) => new() { Columns = sutun };
    Border Gosterge(string ikon, string baslik, string deger, string alt, string? arka = null, string? yaziRenk = null)
    {
        var s = new StackPanel();
        s.Children.Add(Yazi(ikon + "  " + baslik, 12, false, .75, yaziRenk));
        s.Children.Add(Yazi(deger, 26, true, 1, yaziRenk));
        if (alt.Length > 0) s.Children.Add(Yazi(alt, 11, false, .7, yaziRenk));
        return Kutu(s, 16, arka);
    }
    static FrameworkElement Cubuklar(decimal[] v, double yukseklik, Brush renk, string[]? etiket = null)
    {
        var g = new UniformGrid { Columns = v.Length, Height = yukseklik + 18 };
        decimal max = v.Length == 0 ? 0 : v.Max();
        for (int i = 0; i < v.Length; i++)
        {
            var hucre = new DockPanel { Margin = new Thickness(3, 0, 3, 0) };
            var e = new TextBlock { Text = etiket?[i] ?? "", FontSize = 10, Opacity = .7, HorizontalAlignment = HorizontalAlignment.Center };
            e.SetResourceReference(TextBlock.ForegroundProperty, "ErpMetin");
            DockPanel.SetDock(e, Dock.Bottom); hucre.Children.Add(e);
            double h = max <= 0 ? 3 : Math.Max(3, (double)(v[i] / max) * yukseklik);
            hucre.Children.Add(new Border { Height = h, VerticalAlignment = VerticalAlignment.Bottom, CornerRadius = new CornerRadius(6), Background = renk, ToolTip = v[i].ToString("#,##0.##", trP) + " ₺" });
            g.Children.Add(hucre);
        }
        return g;
    }
    static FrameworkElement Cizgi(decimal[] v, double w, double h, Brush renk)
    {
        var c = new Canvas { Width = w, Height = h };
        if (v.Length < 2) return c;
        decimal max = Math.Max(1, v.Max());
        var pts = new PointCollection();
        for (int i = 0; i < v.Length; i++) pts.Add(new Point(i * w / (v.Length - 1), h - 4 - (double)(v[i] / max) * (h - 8)));
        var alan = new PointCollection(pts) { new Point(w, h), new Point(0, h) };
        var dolgu = renk.Clone(); dolgu.Opacity = .18;
        c.Children.Add(new Polygon { Points = alan, Fill = dolgu });
        c.Children.Add(new Polyline { Points = pts, Stroke = renk, StrokeThickness = 3, StrokeLineJoin = PenLineJoin.Round });
        foreach (var p in pts) { var d = new Ellipse { Width = 7, Height = 7, Fill = renk }; Canvas.SetLeft(d, p.X - 3.5); Canvas.SetTop(d, p.Y - 3.5); c.Children.Add(d); }
        return c;
    }
    static FrameworkElement Halka(double oran, double boyut, Brush renk, string ortaYazi)
    {
        oran = Math.Clamp(oran, 0, 1);
        var g = new Grid { Width = boyut, Height = boyut };
        double r = boyut / 2 - 7, cx = boyut / 2, cy = boyut / 2;
        var zemin = renk.Clone(); zemin.Opacity = .18;
        g.Children.Add(new Ellipse { Stroke = zemin, StrokeThickness = 12, Margin = new Thickness(1) });
        if (oran > 0)
        {
            double aci = oran * 359.99 * Math.PI / 180;
            var bas = new Point(cx, cy - r); var son = new Point(cx + r * Math.Sin(aci), cy - r * Math.Cos(aci));
            var fig = new PathFigure { StartPoint = bas, IsClosed = false };
            fig.Segments.Add(new ArcSegment(son, new Size(r, r), 0, oran > .5, SweepDirection.Clockwise, true));
            g.Children.Add(new Path { Data = new PathGeometry([fig]), Stroke = renk, StrokeThickness = 12, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round });
        }
        var t = Yazi(ortaYazi, 16, true); t.HorizontalAlignment = HorizontalAlignment.Center; t.VerticalAlignment = VerticalAlignment.Center; t.TextAlignment = TextAlignment.Center;
        g.Children.Add(t);
        return g;
    }
    static FrameworkElement Ilerleme(string ad, double yuzde, Brush renk)
    {
        var s = new StackPanel { Margin = new Thickness(0, 0, 0, 8) };
        var ust = new DockPanel();
        var y = Yazi("%" + yuzde.ToString("0", trP), 11, true); DockPanel.SetDock(y, Dock.Right); ust.Children.Add(y);
        ust.Children.Add(Yazi(ad, 12));
        s.Children.Add(ust);
        var zemin = renk.Clone(); zemin.Opacity = .18;
        var bar = new Grid { Height = 8, Margin = new Thickness(0, 4, 0, 0) };
        bar.Children.Add(new Border { Background = zemin, CornerRadius = new CornerRadius(4) });
        bar.Children.Add(new Border { Background = renk, CornerRadius = new CornerRadius(4), HorizontalAlignment = HorizontalAlignment.Left, Width = 0, Tag = yuzde });
        bar.SizeChanged += (_, e) => { if (bar.Children[1] is Border b && b.Tag is double p) b.Width = e.NewSize.Width * Math.Clamp(p, 0, 100) / 100; };
        s.Children.Add(bar);
        return s;
    }
    Brush Vurgu() => TryFindResource("ErpVurgu") as Brush ?? Brushes.SeaGreen;
    static string[] GunEtiketleri() => Enumerable.Range(0, 7).Select(i => DateTime.Today.AddDays(i - 6).ToString("ddd", trP)).ToArray();
    static string Dakika(decimal dk) => dk < 2 ? "şimdi" : dk < 60 ? dk.ToString("0") + " dk önce" : dk < 1440 ? (dk / 60).ToString("0") + " sa önce" : (dk / 1440).ToString("0") + " gün önce";
    StackPanel PanoBasligi(string tema)
    {
        var (ad, tanim) = PanoKimligi(tema);
        var s = new StackPanel { Margin = new Thickness(2, 0, 0, 10) };
        s.Children.Add(Yazi(ad, 17, true));
        s.Children.Add(Yazi(tanim + " · " + (panoOzeti?.Zaman.ToString("HH:mm", trP) ?? ""), 11, false, .65));
        return s;
    }

    // ---------- Tema panoları ----------
    UIElement NanePano(PanoOzeti o)
    {
        var kok = new StackPanel(); kok.Children.Add(PanoBasligi("Nane Cam"));
        var sira = new Grid();
        sira.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.2, GridUnitType.Star) });
        sira.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        // Ekip kartı: baş harfli yuvarlak avatarlar ve son giriş.
        var ekip = new StackPanel(); ekip.Children.Add(Yazi("👥  Ekip · " + o.Ekip.Length, 14, true));
        var av = new WrapPanel { Margin = new Thickness(0, 10, 0, 0) };
        string[] renkler = ["#1F9D73", "#2D7FF9", "#E0703A", "#7B5CD6", "#D64570", "#0E9F9F"];
        int k = 0;
        foreach (var u in o.Ekip)
        {
            var hucre = new StackPanel { Width = 78, Margin = new Thickness(0, 0, 6, 6) };
            string bas = string.Concat(u.Ad.Split(' ', StringSplitOptions.RemoveEmptyEntries).Take(2).Select(p => char.ToUpper(p[0], trP)));
            var daire = new Border { Width = 46, Height = 46, CornerRadius = new CornerRadius(23), Background = Tema170.Firca(renkler[k++ % renkler.Length]), HorizontalAlignment = HorizontalAlignment.Center, Child = new TextBlock { Text = bas, Foreground = Brushes.White, FontWeight = FontWeights.Bold, FontSize = 16, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center } };
            if (u.Deger < 30) daire.BorderBrush = Tema170.Firca("#34D399"); daire.BorderThickness = new Thickness(u.Deger < 30 ? 3 : 0);
            hucre.Children.Add(daire);
            var ad = Yazi(u.Ad, 11); ad.TextAlignment = TextAlignment.Center; ad.MaxHeight = 30; hucre.Children.Add(ad);
            var zm = Yazi(Dakika(u.Deger), 10, false, .6); zm.TextAlignment = TextAlignment.Center; hucre.Children.Add(zm);
            av.Children.Add(hucre);
        }
        ekip.Children.Add(av);
        sira.Children.Add(Kutu(ekip));
        var veri = new StackPanel();
        if (o.Satis)
        {
            veri.Children.Add(Yazi("📈  Bugünkü veriler", 14, true));
            veri.Children.Add(Yazi(Para(o.SatisBugun), 32, true));
            veri.Children.Add(Yazi("Bugünkü satış · bu ay " + Para(o.SatisAy) + " (" + Yuzde(o.SatisAy, o.SatisGecenAy) + ")", 11, false, .7));
        }
        var mini = Izgara(3); mini.Margin = new Thickness(0, 10, 0, 0);
        if (o.Uretim) mini.Children.Add(Yazi("🏭 " + o.AktifUretim + "\nüretimde", 12));
        if (o.Stok) mini.Children.Add(Yazi("⚠ " + o.KritikStok + "\nkritik stok", 12));
        if (o.Takvim) mini.Children.Add(Yazi("🗓 " + o.Bugun.Length + "\nbugünkü plan", 12));
        veri.Children.Add(mini);
        var vk = Kutu(veri); Grid.SetColumn(vk, 1); sira.Children.Add(vk);
        kok.Children.Add(sira);
        if (o.Satis)
        {
            var ist = new StackPanel(); ist.Children.Add(Yazi("📊  İstatistik · son 7 gün satış", 14, true));
            var c = Cubuklar(o.Son7Gun, 110, Vurgu(), GunEtiketleri()); c.Margin = new Thickness(0, 12, 0, 0); ist.Children.Add(c);
            kok.Children.Add(Kutu(ist));
        }
        return kok;
    }

    UIElement OkyanusPano(PanoOzeti o)
    {
        var kok = new StackPanel(); kok.Children.Add(PanoBasligi("Okyanus Cam"));
        var kutular = Izgara(4);
        if (o.Satis) { kutular.Children.Add(Gosterge("💧", "Bugün satış", Para(o.SatisBugun), "")); kutular.Children.Add(Gosterge("🌊", "Bu ay satış", Para(o.SatisAy), "Geçen aya göre " + Yuzde(o.SatisAy, o.SatisGecenAy))); }
        if (o.Cari) { kutular.Children.Add(Gosterge("🧾", "Açık alacak", Para(o.AcikAlacak), "")); kutular.Children.Add(Gosterge("💰", "Bu ay tahsilat", Para(o.TahsilatAy), "")); }
        if (kutular.Children.Count > 0) kok.Children.Add(kutular);
        if (o.Satis)
        {
            var akis = new StackPanel(); akis.Children.Add(Yazi("〰  7 günlük satış akışı", 14, true));
            var cz = new Grid { Height = 140, Margin = new Thickness(0, 12, 0, 0) };
            cz.SizeChanged += (_, e) => { cz.Children.Clear(); if (e.NewSize.Width > 20) cz.Children.Add(Cizgi(o.Son7Gun, e.NewSize.Width, 130, Vurgu())); };
            akis.Children.Add(cz);
            var et = Izgara(7); foreach (var g in GunEtiketleri()) et.Children.Add(Yazi(g, 10, false, .6)); akis.Children.Add(et);
            kok.Children.Add(Kutu(akis));
        }
        return kok;
    }

    UIElement LavantaPano(PanoOzeti o)
    {
        var kok = new StackPanel(); kok.Children.Add(PanoBasligi("Lavanta Cam"));
        if (o.Takvim)
        {
            var kb = Izgara(3);
            foreach (var (baslik, liste, renk) in new[] { ("⏰ Gecikmiş", o.Gecikmis, "#E11D48"), ("📍 Bugün", o.Bugun, "#7B5CD6"), ("🌙 Yarın", o.Yarin, "#0EA5E9") })
            {
                var s = new StackPanel();
                var ust = new DockPanel();
                var say = new Border { CornerRadius = new CornerRadius(10), Padding = new Thickness(8, 1, 8, 1), Background = Tema170.Firca(renk), Child = new TextBlock { Text = liste.Length.ToString(), Foreground = Brushes.White, FontWeight = FontWeights.Bold } };
                DockPanel.SetDock(say, Dock.Right); ust.Children.Add(say); ust.Children.Add(Yazi(baslik, 14, true)); s.Children.Add(ust);
                if (liste.Length == 0) s.Children.Add(Yazi("Boş", 12, false, .5));
                foreach (var x in liste)
                {
                    var kart = new Border { CornerRadius = new CornerRadius(10), Padding = new Thickness(10, 7, 10, 7), Margin = new Thickness(0, 8, 0, 0), BorderThickness = new Thickness(3, 0, 0, 0), BorderBrush = Tema170.Firca(renk) };
                    kart.SetResourceReference(Border.BackgroundProperty, "ErpZemin");
                    kart.Child = Yazi(x, 12); s.Children.Add(kart);
                }
                kb.Children.Add(Kutu(s));
            }
            kok.Children.Add(kb);
        }
        var alt = Izgara(3);
        if (o.Uretim) { int top = o.AktifUretim + o.PlanliUretim; alt.Children.Add(Kutu(new StackPanel { Children = { Yazi("Üretim zamanında", 13, true), Halka(top == 0 ? 1 : 1 - (double)o.GecikenUretim / top, 110, Vurgu(), top == 0 ? "—" : "%" + ((1 - (double)o.GecikenUretim / top) * 100).ToString("0")) } })); }
        if (o.Stok) alt.Children.Add(Kutu(new StackPanel { Children = { Yazi("Stok sağlığı", 13, true), Halka(o.ToplamStokKarti == 0 ? 1 : 1 - (double)o.KritikStok / o.ToplamStokKarti, 110, Tema170.Firca("#22C55E"), o.KritikStok + " kritik") } }));
        if (o.Cari && o.Satis) alt.Children.Add(Kutu(new StackPanel { Children = { Yazi("Tahsilat / satış", 13, true), Halka(o.SatisAy == 0 ? 0 : (double)(o.TahsilatAy / o.SatisAy), 110, Tema170.Firca("#0EA5E9"), o.SatisAy == 0 ? "—" : "%" + (o.TahsilatAy / o.SatisAy * 100).ToString("0", trP)) } }));
        if (alt.Children.Count > 0) kok.Children.Add(alt);
        return kok;
    }

    UIElement GunBatimiPano(PanoOzeti o)
    {
        var kok = new StackPanel(); kok.Children.Add(PanoBasligi("Gün Batımı Cam"));
        var g = new Grid(); g.ColumnDefinitions.Add(new ColumnDefinition()); g.ColumnDefinitions.Add(new ColumnDefinition());
        if (o.Satis)
        {
            var buyuk = new StackPanel();
            buyuk.Children.Add(Yazi("☀  Günün satışı", 14, true, .9, "#FFFFFF"));
            buyuk.Children.Add(Yazi(Para(o.SatisBugun), 40, true, 1, "#FFFFFF"));
            buyuk.Children.Add(Yazi("Bu ay " + Para(o.SatisAy) + " · geçen aya göre " + Yuzde(o.SatisAy, o.SatisGecenAy), 12, false, .9, "#FFFFFF"));
            var c = Cubuklar(o.Son7Gun, 70, new SolidColorBrush(Color.FromArgb(0xCC, 0xFF, 0xFF, 0xFF)), GunEtiketleri()); c.Margin = new Thickness(0, 14, 0, 0);
            foreach (var t in LogicalTreeHelper.GetChildren(c).OfType<DockPanel>().SelectMany(d => d.Children.OfType<TextBlock>())) t.Foreground = Brushes.White;
            buyuk.Children.Add(c);
            var kb = Kutu(buyuk, 22);
            kb.Background = new LinearGradientBrush(Color.FromRgb(0xF0, 0x7A, 0x3E), Color.FromRgb(0xD9, 0x46, 0x6F), 45);
            g.Children.Add(kb);
            var musteri = new StackPanel(); musteri.Children.Add(Yazi("🏆  Bu ayın en iyi müşterileri", 14, true));
            decimal max = o.EnIyiCariler.Length == 0 ? 1 : o.EnIyiCariler.Max(x => x.Deger);
            foreach (var m in o.EnIyiCariler) musteri.Children.Add(Ilerleme(m.Ad + " · " + Para(m.Deger), max <= 0 ? 0 : (double)(m.Deger / max * 100), Tema170.Firca("#E0703A")));
            if (o.EnIyiCariler.Length == 0) musteri.Children.Add(Yazi("Bu ay satış kaydı yok.", 12, false, .6));
            if (o.Cari) { musteri.Children.Add(new Separator { Margin = new Thickness(0, 6, 0, 8) }); musteri.Children.Add(Yazi("Açık alacak " + Para(o.AcikAlacak) + " · bu ay tahsilat " + Para(o.TahsilatAy), 12, false, .8)); }
            var mk = Kutu(musteri); Grid.SetColumn(mk, 1); g.Children.Add(mk);
            kok.Children.Add(g);
        }
        else kok.Children.Add(IzgaraPano(o, true));
        return kok;
    }

    UIElement GecePano(PanoOzeti o)
    {
        var kok = new StackPanel(); kok.Children.Add(PanoBasligi("Gece Cam"));
        var sayac = Izgara(5);
        void Sayac(string ad, int v, string renk) { var s = new StackPanel(); s.Children.Add(Yazi(v.ToString(trP), 30, true, 1, renk)); s.Children.Add(Yazi(ad, 11, false, .75)); var b = Kutu(s, 14); b.BorderBrush = Tema170.Firca(renk); b.BorderThickness = new Thickness(0, 0, 0, 3); sayac.Children.Add(b); }
        if (o.Uretim) { Sayac("Üretimde", o.AktifUretim, "#2CC69B"); Sayac("Planlı", o.PlanliUretim, "#38BDF8"); Sayac("Geciken", o.GecikenUretim, o.GecikenUretim > 0 ? "#F87171" : "#94A3B8"); }
        if (o.Stok) { Sayac("Kritik stok", o.KritikStok, o.KritikStok > 0 ? "#FBBF24" : "#94A3B8"); Sayac("Eksi bakiye", o.EksiStok, o.EksiStok > 0 ? "#F87171" : "#94A3B8"); }
        if (sayac.Children.Count > 0) kok.Children.Add(sayac);
        if (o.Uretim)
        {
            var hat = new StackPanel(); hat.Children.Add(Yazi("🛰  Üretim hattı canlı ilerleme", 14, true));
            if (o.UretimIlerleme.Length == 0) hat.Children.Add(Yazi("Şu anda üretimde emir yok.", 12, false, .6));
            foreach (var x in o.UretimIlerleme) hat.Children.Add(Ilerleme(x.Ad, (double)x.Deger, Tema170.Firca("#2CC69B")));
            kok.Children.Add(Kutu(hat));
        }
        return kok;
    }

    UIElement VipPano(PanoOzeti o)
    {
        var kok = new StackPanel(); kok.Children.Add(PanoBasligi("VIP"));
        var g = Izgara(3);
        TextBlock Serif(string t, double s) { var x = Yazi(t, s, true); x.FontFamily = new FontFamily("Cambria"); return x; }
        if (o.Satis)
        {
            var s = new StackPanel(); s.Children.Add(Yazi("AYLIK CİRO", 11, true, .6)); s.Children.Add(Serif(Para(o.SatisAy), 34));
            var fark = o.SatisGecenAy <= 0 ? 0 : (o.SatisAy - o.SatisGecenAy) / o.SatisGecenAy;
            s.Children.Add(Yazi((fark >= 0 ? "▲ " : "▼ ") + Yuzde(o.SatisAy, o.SatisGecenAy) + " geçen ayın aynı dönemine göre", 12, false, 1, fark >= 0 ? "#15803D" : "#B91C1C"));
            var b = Kutu(s, 22); b.BorderBrush = Tema170.Firca("#8B652C"); b.BorderThickness = new Thickness(0, 3, 0, 0); g.Children.Add(b);
        }
        if (o.Cari)
        {
            var s = new StackPanel(); s.Children.Add(Yazi("ALACAK POZİSYONU", 11, true, .6)); s.Children.Add(Serif(Para(o.AcikAlacak), 34)); s.Children.Add(Yazi("Bu ay tahsil edilen " + Para(o.TahsilatAy), 12, false, .75));
            var b = Kutu(s, 22); b.BorderBrush = Tema170.Firca("#8B652C"); b.BorderThickness = new Thickness(0, 3, 0, 0); g.Children.Add(b);
        }
        var risk = new StackPanel(); risk.Children.Add(Yazi("RİSK GÖSTERGELERİ", 11, true, .6));
        if (o.Uretim) risk.Children.Add(Yazi((o.GecikenUretim > 0 ? "● " : "○ ") + o.GecikenUretim + " geciken üretim emri", 13, false, 1, o.GecikenUretim > 0 ? "#B91C1C" : null));
        if (o.Stok) risk.Children.Add(Yazi((o.KritikStok > 0 ? "● " : "○ ") + o.KritikStok + " kritik stok", 13, false, 1, o.KritikStok > 0 ? "#B45309" : null));
        if (o.Takvim) risk.Children.Add(Yazi((o.Gecikmis.Length > 0 ? "● " : "○ ") + o.Gecikmis.Length + " gecikmiş iş planı", 13, false, 1, o.Gecikmis.Length > 0 ? "#B91C1C" : null));
        var rb = Kutu(risk, 22); rb.BorderBrush = Tema170.Firca("#8B652C"); rb.BorderThickness = new Thickness(0, 3, 0, 0); g.Children.Add(rb);
        kok.Children.Add(g);
        return kok;
    }

    UIElement DefterPano(PanoOzeti o)
    {
        var kok = new StackPanel(); kok.Children.Add(PanoBasligi(gorunum.Tema));
        var satirlar = new StackPanel();
        void Satir(string ad, string deger) { var d = new DockPanel { Margin = new Thickness(0, 0, 0, 2) }; var v = Yazi(deger, 13, true); DockPanel.SetDock(v, Dock.Right); d.Children.Add(v); var a = Yazi(ad, 13); d.Children.Add(a); satirlar.Children.Add(d); satirlar.Children.Add(new Border { Height = 1, Opacity = .25, Margin = new Thickness(0, 3, 0, 5), Background = Brushes.Gray }); }
        if (o.Satis) { Satir("Bugünkü satış", Para(o.SatisBugun)); Satir("Bu ay satış", Para(o.SatisAy) + "  (" + Yuzde(o.SatisAy, o.SatisGecenAy) + ")"); }
        if (o.Cari) { Satir("Açık alacak", Para(o.AcikAlacak)); Satir("Bu ay tahsilat", Para(o.TahsilatAy)); }
        if (o.Stok) { Satir("Kritik stok", o.KritikStok.ToString()); Satir("Eksi bakiyeli stok", o.EksiStok.ToString()); }
        if (o.Uretim) { Satir("Üretimde / planlı / geciken", o.AktifUretim + " / " + o.PlanliUretim + " / " + o.GecikenUretim); }
        if (o.Takvim) { Satir("Bugünkü / gecikmiş plan", o.Bugun.Length + " / " + o.Gecikmis.Length); }
        var b = Kutu(satirlar, 18, null, gorunum.Tema == "Eskitme" ? 2 : 4);
        if (gorunum.Tema == "Eskitme") { b.BorderBrush = Tema170.Firca("#875D3B"); b.BorderThickness = new Thickness(1); }
        kok.Children.Add(b);
        return kok;
    }

    UIElement AkisPano(PanoOzeti o)
    {
        var kok = new StackPanel(); kok.Children.Add(PanoBasligi(gorunum.Tema));
        var g = new Grid(); g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.4, GridUnitType.Star) }); g.ColumnDefinitions.Add(new ColumnDefinition());
        var akis = new StackPanel(); akis.Children.Add(Yazi("🌿  Günün akışı", 14, true));
        var olaylar = o.Gecikmis.Select(x => ("Gecikmiş", x, "#B91C1C")).Concat(o.Bugun.Select(x => ("Bugün", x, "#237250"))).Concat(o.Yarin.Select(x => ("Yarın", x, "#64748B"))).Take(10).ToList();
        if (olaylar.Count == 0) akis.Children.Add(Yazi("Bugün için planlanmış iş yok.", 12, false, .6));
        foreach (var (tur, metin, renk) in olaylar)
        {
            var d = new DockPanel { Margin = new Thickness(0, 8, 0, 0) };
            var nokta = new Ellipse { Width = 12, Height = 12, Fill = Tema170.Firca(renk), Margin = new Thickness(0, 3, 10, 0), VerticalAlignment = VerticalAlignment.Top };
            DockPanel.SetDock(nokta, Dock.Left); d.Children.Add(nokta);
            var s = new StackPanel(); s.Children.Add(Yazi(metin, 13)); s.Children.Add(Yazi(tur, 10, false, .6)); d.Children.Add(s);
            akis.Children.Add(d);
        }
        g.Children.Add(Kutu(akis));
        var ozet = new StackPanel();
        if (o.Satis) ozet.Children.Add(Gosterge("🛒", "Bugün satış", Para(o.SatisBugun), ""));
        if (o.Stok) ozet.Children.Add(Gosterge("📦", "Kritik stok", o.KritikStok.ToString(), ""));
        if (o.Uretim) ozet.Children.Add(Gosterge("🏭", "Üretimde", o.AktifUretim.ToString(), ""));
        Grid.SetColumn(ozet, 1); g.Children.Add(ozet);
        kok.Children.Add(g);
        return kok;
    }

    UIElement IzgaraPano(PanoOzeti o, bool canli)
    {
        var kok = new StackPanel(); kok.Children.Add(PanoBasligi(gorunum.Tema));
        var g = Izgara(3);
        string[] renk = canli ? ["#B03F54", "#E0703A", "#0E9F9F", "#6441BA", "#2563EB", "#15803D"] : [];
        int i = 0;
        string? R() => canli ? renk[i++ % renk.Length] : null;
        string? Y() => canli ? "#FFFFFF" : null;
        if (o.Satis) { g.Children.Add(Gosterge("🛒", "Bugün satış", Para(o.SatisBugun), "", R(), Y())); g.Children.Add(Gosterge("📅", "Bu ay satış", Para(o.SatisAy), Yuzde(o.SatisAy, o.SatisGecenAy) + " geçen aya göre", R(), Y())); }
        if (o.Cari) g.Children.Add(Gosterge("🧾", "Açık alacak", Para(o.AcikAlacak), "Bu ay tahsilat " + Para(o.TahsilatAy), R(), Y()));
        if (o.Stok) g.Children.Add(Gosterge("📦", "Kritik stok", o.KritikStok.ToString(), o.EksiStok + " eksi bakiye", R(), Y()));
        if (o.Uretim) g.Children.Add(Gosterge("🏭", "Üretim", o.AktifUretim + " aktif", o.PlanliUretim + " planlı · " + o.GecikenUretim + " geciken", R(), Y()));
        if (o.Takvim) g.Children.Add(Gosterge("🗓", "Bugünkü planlar", o.Bugun.Length.ToString(), o.Gecikmis.Length + " gecikmiş", R(), Y()));
        kok.Children.Add(g);
        return kok;
    }
}
