using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

/// <summary>
/// Mobilde kullanıcı adı ve şifreyle giriş: herkes programdaki kendi ERP kullanıcı adı/şifresiyle girer.
/// Doğrulama masaüstü HTTPS girişiyle aynı (kilitleme dahil). Kullanıcının mobil hesabı yoksa açılır,
/// tek kullanımlık eşleme kodu sunucu içinde üretilip mevcut cihaz bağlama akışı kullanılır.
/// </summary>
public sealed partial class MobilHesapServisi
{
 public object GirisIleBagla(string kullaniciAdi,string sifre,string cihazAdi)
 {
  if(HttpsOturumu.Uzak(Baglanti))throw new InvalidOperationException("Mobil giriş ana sunucuda yapılır.");
  HttpsDogrulanmisHesap hesap;
  try{hesap=new HttpsSqlHesapDeposu(Baglanti).Giris(new HttpsGiris(kullaniciAdi??"",sifre??""));}
  catch(InvalidOperationException e){throw new UnauthorizedAccessException(e.Message);}
  int u=hesap.Kullanici.Id;
  var yetki=new MenuYetkiServisi(Baglanti,u).Yetkiler().ToHashSet(StringComparer.Ordinal);
  if(!yetki.Contains("MOBILE.ACCESS"))throw new UnauthorizedAccessException("Kullanıcı adı ve şifre doğru, ancak bu kullanıcıya 'Mobil erişim' yetkisi verilmemiş. Yöneticiniz Kullanıcı ve Yetkiler'den veya Mobil bağlantı ekranındaki 'Mobil erişimi ver' düğmesinden açabilir.");
  string rol=hesap.Kullanici.Roller.Split(',',StringSplitOptions.TrimEntries).Contains("Yönetici")?"PATRON":"SAHA";
  string kod=MobilRaporSunucusu.YeniAnahtar();
  using(var c=new SqlConnection(Baglanti))
  {
   c.Open();using var tx=c.BeginTransaction(System.Data.IsolationLevel.Serializable);
   using var q=ErpModulServisi.Komut(c,tx,"""
DECLARE @id uniqueidentifier=(SELECT TOP(1) Id FROM dbo.BERP220_Hesap WITH(UPDLOCK,HOLDLOCK) WHERE KullaniciId=@u);
IF @id IS NULL BEGIN SET @id=NEWID();INSERT dbo.BERP220_Hesap(Id,KullaniciId,Ad,Rol,Aktif) VALUES(@id,@u,@ad,@rol,1);END
ELSE UPDATE dbo.BERP220_Hesap SET Aktif=1 WHERE Id=@id;
DELETE dbo.BERP220_Esleme WHERE HesapId=@id OR Bitis<SYSUTCDATETIME();
INSERT dbo.BERP220_Esleme(Ozet,HesapId,Bitis) VALUES(@h,@id,DATEADD(minute,2,SYSUTCDATETIME()));
""",("@u",u),("@ad",hesap.Kullanici.AdSoyad.Length>0?hesap.Kullanici.AdSoyad:hesap.Kullanici.KullaniciAdi),("@rol",rol),("@h",MobilRaporSunucusu.Ozet(kod)));
   q.ExecuteNonQuery();MobilDepartmaniEsitle(c,tx);tx.Commit();
  }
  return Bagla(kod,cihazAdi);
 }
}
