using System.Data;
namespace MiapaxERP.Desktop;

public sealed record SahaGorusulenKisi(Guid Id,string Ad,string Telefon,string IlceId,string Koy,DateTime? SonGorusme,string Sonuc);
public sealed record SahaIlSayfasi(SahaGorusulenKisi[] Rows,bool HasMore,int NextOffset,long TotalCount=0);
public sealed record SahaIlSayisi(string IlId,long KisiSayisi);
public sealed partial class SahaServisi
{
 public SahaIlSayfasi IlGorusmeleri(string il,string? ilce=null,string? search=null,int offset=0){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<SahaIlSayfasi>(connection,"SahaServisi.IlGorusmeleri","",new object?[]{il,ilce,search,offset});}

  if(fixtureCheck is null)LisansOturumu.Gerekli("SAHA");ilce??="";search=(search??"").Trim();
  if(string.IsNullOrWhiteSpace(il)||il.Length>30||ilce.Length>40||search.Length>160||offset<0||offset>int.MaxValue-101)throw new ArgumentException("İl, ilçe, arama veya sayfa bilgisi geçersiz.");
  using var c=access.Ac();GecmisHazirla(c);Yetki(c,null,"FIELD.VIEW");
  // Son işlem: en son görüşme veya kart güncellemesi (hangisi yeniyse).
  using var q=ErpModulServisi.Komut(c,null,"""
   SELECT m.Id,m.Ad,m.Telefon,m.IlceId,m.Koy,g.Tarih,ISNULL(LEFT(g.Sonuc,160),N'') AS Sonuc,COUNT_BIG(*) OVER() AS Toplam
    FROM dbo.BERP210_SahaMusteri m
    OUTER APPLY(SELECT TOP(1) Tarih,Sonuc FROM(
      SELECT a.Tarih,a.Sonuc,a.KayitZamani Sira FROM(SELECT TOP(1) Tarih,Sonuc,KayitZamani FROM dbo.BERP210_Gorusme WHERE MusteriId=m.Id ORDER BY Tarih DESC,KayitZamani DESC,Id DESC)a
      UNION ALL
      SELECT b.Tarih,N'✎ Kart güncellendi: '+b.Ozet,b.Tarih FROM(SELECT TOP(1) Tarih,Ozet FROM dbo.BERP299_SahaGecmis WHERE MusteriId=m.Id ORDER BY Tarih DESC)b) s ORDER BY Tarih DESC,Sira DESC)g
    WHERE m.IlId=@il AND (@district=N'' OR m.IlceId=@district)
     AND (@own=0 OR m.Olusturan=@user)
     AND (@search=N'' OR CHARINDEX(@search,m.Ad)>0 OR CHARINDEX(@search,m.Telefon)>0)
   ORDER BY g.Tarih DESC,m.Ad,m.Id
   OFFSET @offset ROWS FETCH NEXT 101 ROWS ONLY
   """,("@il",il),("@district",ilce),("@own",Own),("@user",user),("@search",search),("@offset",offset));
  using var reader=q.ExecuteReader();var rows=new List<SahaGorusulenKisi>();long total=0;
  while(reader.Read()){total=reader.GetInt64(7);rows.Add(new(reader.GetGuid(0),reader.GetString(1),reader.GetString(2),reader.GetString(3),reader.GetString(4),reader.IsDBNull(5)?null:DateTime.SpecifyKind(reader.GetDateTime(5),DateTimeKind.Utc),reader.GetString(6)));}
  bool more=rows.Count>100;if(more)rows.RemoveAt(100);return new(rows.ToArray(),more,offset+rows.Count,total);
 }
 public SahaIlSayisi[] IlSayilari(){
  if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<SahaIlSayisi[]>(connection,"SahaServisi.IlSayilari","",[]);
  if(fixtureCheck is null)LisansOturumu.Gerekli("SAHA");using var c=access.Ac();Yetki(c,null,"FIELD.VIEW");
  using var q=ErpModulServisi.Komut(c,null,"SELECT IlId,COUNT_BIG(*) FROM dbo.BERP210_SahaMusteri WHERE (@own=0 OR Olusturan=@user) GROUP BY IlId",("@own",Own),("@user",user));
  using var reader=q.ExecuteReader();var rows=new List<SahaIlSayisi>();while(reader.Read())rows.Add(new(reader.GetString(0),reader.GetInt64(1)));return rows.ToArray();
 }
}
