using System.Data;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public static class IlkKurulumServisi
{
 internal static string Kaynak(string name){using var stream=typeof(IlkKurulumServisi).Assembly.GetManifestResourceStream("MiapaxERP.Desktop.IlkKurulum."+name)??throw new InvalidOperationException("Kurulum kaynağı pakette bulunamadı: "+name);using var reader=new StreamReader(stream);return reader.ReadToEnd();}
 internal static string[] Betikler(string sql)=>Regex.Split(sql,@"^\s*GO\s*(?:--[^\r\n]*)?$",RegexOptions.Multiline|RegexOptions.IgnoreCase).Where(x=>!string.IsNullOrWhiteSpace(x)).ToArray();
 internal static string Veritabani(string name){name=name.Trim();if(name.Length is <1 or >128||name.Any(char.IsControl)||new[]{"master","model","msdb","tempdb"}.Contains(name,StringComparer.OrdinalIgnoreCase))throw new ArgumentException("Şirkete ait ayrı bir veritabanı adı girin; sistem veritabanı kullanılamaz.");return name;}
 internal static string Tanim(string value)=>"["+value.Replace("]","]]")+"]";
 public static bool HazirMi(string connection){using var c=new SqlConnection(connection);c.Open();using var q=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.Kullanicilar','U') IS NOT NULL AND OBJECT_ID('dbo.KullaniciRolleri','U') IS NOT NULL AND OBJECT_ID('dbo.BoruERP_IlkKurulum','U') IS NOT NULL THEN 1 ELSE 0 END",c);return Convert.ToInt32(q.ExecuteScalar())==1;}
 public static string Hazirla(string connection,bool olustur){
  var builder=new SqlConnectionStringBuilder(connection);string database=Veritabani(builder.InitialCatalog);builder.InitialCatalog="master";
  using(var master=new SqlConnection(builder.ConnectionString)){master.Open();using var exists=new SqlCommand("SELECT DB_ID(@name)",master);exists.Parameters.AddWithValue("@name",database);if(exists.ExecuteScalar() is DBNull){if(!olustur)throw new InvalidOperationException("Veritabanı bulunamadı. Oluşturma seçeneğini işaretleyin.");using var create=new SqlCommand("CREATE DATABASE "+Tanim(database)+" COLLATE Turkish_CI_AS",master){CommandTimeout=120};create.ExecuteNonQuery();}}
  using var c=new SqlConnection(connection);c.Open();
  using(var check=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.Kullanicilar','U') IS NOT NULL AND OBJECT_ID('dbo.BoruERP_IlkKurulum','U') IS NOT NULL AND OBJECT_ID('dbo.StokKartlari','U') IS NOT NULL AND OBJECT_ID('dbo.MPX310_Lot','U') IS NOT NULL THEN 1 ELSE 0 END",c))if(Convert.ToInt32(check.ExecuteScalar())==1){bool first=GirisPenceresi.IlkAdminHesabiniGerekirseOlustur(connection);return first?"İlk kullanıcı Admin, geçici şifre 1234. Girişte değiştirin.":"Mevcut ERP veritabanı doğrulandı; kullanıcılar ve şirket kayıtları korundu.";}
  using var tx=c.BeginTransaction(IsolationLevel.Serializable);
  try{
   using(var gate=new SqlCommand("DECLARE @r int;EXEC @r=sys.sp_getapplock @Resource='MiaPaxERP.FreshInstall',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;IF @r<0 THROW 51000,N'Kurulum kilidi alınamadı.',1;IF OBJECT_ID('dbo.Kullanicilar','U') IS NULL AND EXISTS(SELECT 1 FROM sys.tables WHERE is_ms_shipped=0) THROW 51000,N'Bu veritabanı boş değil ve ERP kullanıcı şeması yok. Farklı boş veritabanı adı seçin.',1;",c,tx))gate.ExecuteNonQuery();
   foreach(var batch in Betikler(Kaynak("Sema.sql"))){using var q=new SqlCommand(batch,c,tx){CommandTimeout=120};q.ExecuteNonQuery();}
   using(var seed=new SqlCommand(Kaynak("Tohum.sql"),c,tx){CommandTimeout=120})seed.ExecuteNonQuery();
   // Fixed migrations seed only product catalogs and required default accounts/warehouse.
   foreach(var file in new[]{"Isletme310.sql","ModullerNext.sql"}){
    string path=Path.Combine(AppContext.BaseDirectory,file);if(!File.Exists(path))throw new InvalidOperationException("Kurulum dosyası eksik: "+file);foreach(var batch in Betikler(File.ReadAllText(path))){using var q=new SqlCommand(batch,c,tx){CommandTimeout=120};q.ExecuteNonQuery();}
   }
   tx.Commit();
  }catch{tx.Rollback();throw;}
  bool created=GirisPenceresi.IlkAdminHesabiniGerekirseOlustur(connection);
  return created?"Veritabanı ve tüm tablolar hazır. İlk kullanıcı Admin, geçici şifre 1234. Girişte şifrenizi değiştirin.":"ERP şeması doğrulandı. Mevcut kullanıcılar ve şirket verileri korundu; kendi hesabınızla giriş yapın.";
 }
}
