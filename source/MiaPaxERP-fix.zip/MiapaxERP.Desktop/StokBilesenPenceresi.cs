using System.Globalization;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;

/// <summary>Stok içinde stok: ürünün parçalarını, parçaların barkodlarını ve tam parça ağacını yönetir.</summary>
public sealed class StokBilesenPenceresi:Window
{
 sealed record AgacGorunum(string Parca,string Kod,string Birim,string Miktar,string Toplam,string Barkodlar);
 readonly StokBilesenServisi service;readonly HizliSatisServisi barkodlar;readonly string connection;readonly int user,ana;
 readonly DataGrid parts=new(){AutoGenerateColumns=false,IsReadOnly=true,Height=220,SelectionMode=DataGridSelectionMode.Single};
 readonly DataGrid tree=new(){AutoGenerateColumns=false,IsReadOnly=true,Height=200};
 readonly TextBox search=new(){MinWidth=260,MaxLength=100},qty=new(){Width=90,Text="1"},note=new(){Width=220,MaxLength=200};
 readonly ComboBox found=new(){MinWidth=320,DisplayMemberPath="Ad"};
 readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,0)};
 static readonly CultureInfo tr=CultureInfo.GetCultureInfo("tr-TR");

 public StokBilesenPenceresi(string connection,int user,int ana,string anaAdi)
 {
  this.connection=connection;this.user=user;this.ana=ana;service=new(connection,user);barkodlar=new(connection,user);
  Title="MiaPaxERP • Parçalar · "+anaAdi;Width=980;Height=820;WindowStartupLocation=WindowStartupLocation.CenterOwner;
  var p=new StackPanel{Margin=new Thickness(20)};Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
  p.Children.Add(new TextBlock{Text="Stok içinde stok · "+anaAdi,FontSize=22,FontWeight=FontWeights.SemiBold});
  p.Children.Add(new TextBlock{Text="Bu ürünün içindeki parçaları tanımlayın. Her parça normal bir stok kartıdır; kendi barkodu, etiketi ve kendi parçaları olabilir. Barkodu okutulan parça doğrudan bulunur.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,6,0,12)});

  p.Children.Add(Baslik("Doğrudan parçalar"));
  parts.Columns.Add(new DataGridTextColumn{Header="Kod",Binding=new System.Windows.Data.Binding("Kod"),Width=140});
  parts.Columns.Add(new DataGridTextColumn{Header="Parça",Binding=new System.Windows.Data.Binding("Ad"),Width=new DataGridLength(1,DataGridLengthUnitType.Star)});
  parts.Columns.Add(new DataGridTextColumn{Header="Miktar",Binding=new System.Windows.Data.Binding("Miktar"){StringFormat="N3",ConverterCulture=tr},Width=80});
  parts.Columns.Add(new DataGridTextColumn{Header="Birim",Binding=new System.Windows.Data.Binding("Birim"),Width=60});
  parts.Columns.Add(new DataGridTextColumn{Header="Barkodlar",Binding=new System.Windows.Data.Binding("Barkodlar"),Width=170});
  parts.Columns.Add(new DataGridTextColumn{Header="Alt parça",Binding=new System.Windows.Data.Binding("AltParcaSayisi"),Width=70});
  p.Children.Add(parts);
  var rowBar=new WrapPanel{Margin=new Thickness(0,6,0,0)};p.Children.Add(rowBar);
  B(rowBar,"Seçili parçanın parçaları",()=>{if(parts.SelectedItem is not StokBileseni b)throw new ArgumentException("Önce bir parça seçin.");new StokBilesenPenceresi(connection,user,b.Bilesen,b.Ad){Owner=this}.ShowDialog();_=Yenile();});
  B(rowBar,"Seçili parçaya barkod ver",async()=>{if(parts.SelectedItem is not StokBileseni b)throw new ArgumentException("Önce bir parça seçin.");string kod=await Task.Run(service.YeniBarkod);await Task.Run(()=>barkodlar.BarkodKaydet(b.Bilesen,kod,1));status.Text=b.Ad+" için barkod oluşturuldu: "+kod;await Yenile();});
  B(rowBar,"Barkodları yönet",()=>{if(parts.SelectedItem is not StokBileseni b)throw new ArgumentException("Önce bir parça seçin.");new StokBarkodPenceresi(connection,user,b.Bilesen){Owner=this}.ShowDialog();_=Yenile();});
  B(rowBar,"Barkod etiketi yazdır",()=>{if(parts.SelectedItem is not StokBileseni b)throw new ArgumentException("Önce bir parça seçin.");new UrunEtiketPenceresi(connection,user,b.Bilesen,false){Owner=this}.ShowDialog();});
  B(rowBar,"Parçayı çıkar",async()=>{if(parts.SelectedItem is not StokBileseni b)throw new ArgumentException("Önce bir parça seçin.");if(MessageBox.Show(this,b.Ad+" bu üründen çıkarılsın mı? Parçanın stok kartı silinmez.","Parçalar",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;await Task.Run(()=>service.Sil(ana,b.Bilesen));await Yenile();status.Text="Parça çıkarıldı.";});

  p.Children.Add(Baslik("Var olan stoğu parça olarak ekle"));
  var addBar=new WrapPanel();p.Children.Add(addBar);
  addBar.Children.Add(Etiket("Kod / ad / barkod"));addBar.Children.Add(search);
  B(addBar,"Ara",async()=>{var list=await Task.Run(()=>service.Ara(search.Text));found.ItemsSource=list.Where(x=>x.Id!=ana).Select(x=>new{x.Id,Ad=x.Kod+" · "+x.Ad+" ("+x.Birim+")"}).ToList();found.SelectedIndex=found.Items.Count>0?0:-1;status.Text=found.Items.Count==0?"Eşleşen stok bulunamadı.":found.Items.Count+" stok bulundu.";});
  var addBar2=new WrapPanel{Margin=new Thickness(0,6,0,0)};p.Children.Add(addBar2);
  addBar2.Children.Add(found);addBar2.Children.Add(Etiket("Miktar"));addBar2.Children.Add(qty);addBar2.Children.Add(Etiket("Açıklama"));addBar2.Children.Add(note);
  B(addBar2,"Parça olarak ekle",async()=>{if(found.SelectedItem is null)throw new ArgumentException("Önce stok arayıp seçin.");int id=(int)found.SelectedItem.GetType().GetProperty("Id")!.GetValue(found.SelectedItem)!;decimal m=Miktar();string d=note.Text;await Task.Run(()=>service.Kaydet(ana,id,m,d));await Yenile();status.Text="Parça eklendi.";});

  p.Children.Add(Baslik("Yeni parça kartı aç (barkodlu)"));
  var newBar=new WrapPanel();p.Children.Add(newBar);
  var newName=new TextBox{MinWidth=260,MaxLength=200};var newUnit=new TextBox{Width=70,Text="Adet",MaxLength=20};var newQty=new TextBox{Width=80,Text="1"};var newBarcode=new TextBox{Width=160,MaxLength=100};
  newBar.Children.Add(Etiket("Parça adı"));newBar.Children.Add(newName);newBar.Children.Add(Etiket("Birim"));newBar.Children.Add(newUnit);newBar.Children.Add(Etiket("Miktar"));newBar.Children.Add(newQty);
  var newBar2=new WrapPanel{Margin=new Thickness(0,6,0,0)};p.Children.Add(newBar2);
  newBar2.Children.Add(Etiket("Barkod (boş bırakılırsa üretilir)"));newBar2.Children.Add(newBarcode);
  B(newBar2,"Parça kartını oluştur",async()=>{
   string ad=newName.Text.Trim(),birim=newUnit.Text.Trim(),barkod=newBarcode.Text.Trim();if(ad.Length==0)throw new ArgumentException("Parça adını girin.");if(birim.Length==0)throw new ArgumentException("Birimi girin.");
   if(!decimal.TryParse(newQty.Text,NumberStyles.Number,tr,out decimal m))throw new ArgumentException("Miktarı sayı olarak girin.");
   status.Text="Parça kartı oluşturuluyor…";
   int tip=await Task.Run(()=>service.AnaTipi(ana));string kod=await Task.Run(()=>service.SonrakiParcaKodu(ana));
   await Task.Run(()=>new EskiStokServisi(connection,user).Kaydet(new ErpStokGirdisi(null,kod,ad,tip,birim,"Parça · "+anaAdi,null,"",null,"",null,"",null,null,null,new Dictionary<int,string>())));
   int id=await Task.Run(()=>service.IdBul(kod));
   await Task.Run(()=>service.Kaydet(ana,id,m,""));
   if(barkod.Length==0)barkod=await Task.Run(service.YeniBarkod);
   await Task.Run(()=>barkodlar.BarkodKaydet(id,barkod,1));
   newName.Text="";newBarcode.Text="";await Yenile();status.Text="Parça kartı oluşturuldu: "+kod+" · barkod "+barkod;
  });

  p.Children.Add(Baslik("Tam parça ağacı (1 adet ana ürün için)"));
  tree.Columns.Add(new DataGridTextColumn{Header="Parça",Binding=new System.Windows.Data.Binding("Parca"),Width=new DataGridLength(1,DataGridLengthUnitType.Star)});
  tree.Columns.Add(new DataGridTextColumn{Header="Kod",Binding=new System.Windows.Data.Binding("Kod"),Width=140});
  tree.Columns.Add(new DataGridTextColumn{Header="Bir üstte",Binding=new System.Windows.Data.Binding("Miktar"),Width=80});
  tree.Columns.Add(new DataGridTextColumn{Header="Toplam",Binding=new System.Windows.Data.Binding("Toplam"),Width=80});
  tree.Columns.Add(new DataGridTextColumn{Header="Birim",Binding=new System.Windows.Data.Binding("Birim"),Width=60});
  tree.Columns.Add(new DataGridTextColumn{Header="Barkodlar",Binding=new System.Windows.Data.Binding("Barkodlar"),Width=170});
  p.Children.Add(tree);p.Children.Add(status);
  Loaded+=async(_,_)=>await Guvenli(Yenile);
 }

 decimal Miktar(){if(!decimal.TryParse(qty.Text,NumberStyles.Number,tr,out decimal m))throw new ArgumentException("Miktarı sayı olarak girin.");return m;}
 async Task Yenile(){
  var list=await Task.Run(()=>service.Bilesenler(ana));parts.ItemsSource=list;
  var agac=await Task.Run(()=>service.Agac(ana));
  tree.ItemsSource=agac.Select(x=>new AgacGorunum(new string(' ',(x.Seviye-1)*4)+(x.Seviye>1?"└ ":"")+x.Ad,x.Kod,x.Birim,x.Miktar.ToString("N3",tr),x.Toplam.ToString("N3",tr),x.Barkodlar)).ToList();
  int barkodsuz=agac.Count(x=>x.Barkodlar.Length==0);
  if(status.Text.Length==0||status.Text.StartsWith("Bilgi:"))status.Text="Bilgi: "+list.Length+" doğrudan parça, ağaçta "+agac.Length+" satır"+(barkodsuz>0?" · "+barkodsuz+" parçanın barkodu yok.":".");
 }
 async Task Guvenli(Func<Task> work){try{await work();}catch(Exception e){DestekIzleme.Bildir(e,"STOK");status.Text=e.Message;}}
 void B(Panel p,string text,Action a){var b=new Button{Content=text,Padding=new Thickness(10,6,10,6),Margin=new Thickness(0,0,8,6)};b.Click+=(_,_)=>{try{a();}catch(Exception e){DestekIzleme.Bildir(e,"STOK");status.Text=e.Message;}};p.Children.Add(b);}
 void B(Panel p,string text,Func<Task> a){var b=new Button{Content=text,Padding=new Thickness(10,6,10,6),Margin=new Thickness(0,0,8,6)};b.Click+=async(_,_)=>{b.IsEnabled=false;try{await Guvenli(a);}finally{b.IsEnabled=true;}};p.Children.Add(b);}
 static TextBlock Baslik(string t)=>new(){Text=t,FontSize=16,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,16,0,6)};
 static TextBlock Etiket(string t)=>new(){Text=t,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,6,6)};
}
