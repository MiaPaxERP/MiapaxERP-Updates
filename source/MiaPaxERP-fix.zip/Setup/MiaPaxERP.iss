#ifndef Payload
  #error Payload is required
#endif
#ifndef PackageVersion
  #define PackageVersion "2.9.1"
#endif
#ifndef Role
  #define Role "Ana"
#endif
#ifndef Preview
  #define Preview "1"
#endif
#if Preview == "1"
  #define Suffix "-ONIZLEME"
  #define Identity "MiaPaxERP-Unpublished-Preview"
  #define Folder "MiaPaxERP-Onizleme"
#else
  #define Suffix ""
  #define Identity "MiaPaxERP-Desktop"
  #define Folder "MiaPaxERP"
#endif
[Setup]
AppId={#Identity}
AppName=MiaPaxERP {#Role} PC{#Suffix}
AppVersion={#PackageVersion}
AppPublisher=MiaPaxERP
DefaultDirName={localappdata}\Programs\{#Folder}
DefaultGroupName=MiaPaxERP{#Suffix}
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir={#Output}
OutputBaseFilename=MiaPaxERP-{#Role}-Setup-{#PackageVersion}{#Suffix}
Compression=lzma2/fast
SolidCompression=yes
WizardStyle=modern
SetupIconFile=..\MiapaxERP.Desktop\Assets\MiapaxERP.ico
DisableProgramGroupPage=yes
CloseApplications=yes
RestartApplications=no
UninstallDisplayIcon={app}\MiapaxERP.Desktop.exe
InfoBeforeFile=KURULUM-OKU.txt
[Languages]
Name: "turkish"; MessagesFile: "compiler:Languages\Turkish.isl"
[Tasks]
Name: "desktopicon"; Description: "Masaüstü kısayolu oluştur"; Flags: unchecked
[Files]
Source: "{#Payload}\Masaustu\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "*.pdb,*.dpapi,*.pfx,*.pem,*.key,*.mdf,*.ldf,*.bak,*.db,*.sqlite,ag-baglantisi.json,MiapaxERP.guncelleme.json,BoruERP.guncelleme.json,MiaSoft.guncelleme.json"
Source: "{#Output}\guncelleme-{#Role}.json"; DestDir: "{app}"; DestName: "MiapaxERP.guncelleme.json"; Flags: onlyifdoesntexist; Check: InstallUpdateConfig
Source: "KURULUM-OKU.txt"; DestDir: "{app}"; Flags: ignoreversion
#if Role == "Ana"
Source: "{#Payload}\Sunucu\*"; DestDir: "{app}\Sunucu"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "*.pdb,*.dpapi,*.pfx,*.pem,*.key,*.mdf,*.ldf,*.bak,*.db,*.sqlite,appsettings.json,appsettings.Production.json"
Source: "{#Payload}\Sunucu\appsettings.json"; DestDir: "{app}\Sunucu"; Flags: onlyifdoesntexist skipifsourcedoesntexist
Source: "..\MobilKurulum\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
  #define Arguments ""
#else
  #define Arguments "--baglanti"
#endif
[Icons]
Name: "{group}\MiaPaxERP {#Role} PC"; Filename: "{app}\MiapaxERP.Desktop.exe"; Parameters: "{#Arguments}"; WorkingDir: "{app}"
Name: "{autodesktop}\MiaPaxERP {#Role} PC{#Suffix}"; Filename: "{app}\MiapaxERP.Desktop.exe"; Parameters: "{#Arguments}"; WorkingDir: "{app}"; Tasks: desktopicon
[Run]
Filename: "{app}\MiapaxERP.Desktop.exe"; Parameters: "{#Arguments}"; Description: "MiaPaxERP uygulamasını aç"; Flags: nowait postinstall skipifsilent

[Code]
function InstallUpdateConfig: Boolean;
begin
 Result := not FileExists(ExpandConstant('{app}\MiapaxERP.guncelleme.json'))
   and not FileExists(ExpandConstant('{app}\BoruERP.guncelleme.json'))
   and not FileExists(ExpandConstant('{app}\MiaSoft.guncelleme.json'));
end;