import test from 'node:test';import assert from 'node:assert/strict';
import {automaticPlan,billOfMaterials} from '../js/field-plan-estimate.mjs?v=kroki-next1';
import {initial,autoLayout,rectangle} from '../js/field-plan-core.mjs?v=kroki-next1';
import {hydraulicDefaults} from '../js/hydraulics.mjs?v=kroki-next1';

const base={project:'Test',crop:'',water:'Kuyu / pompa',method:'sprinkler',side:'left',areaMode:'dimensions',rowGap:12,headGap:12};
test('automatic plan keeps the pipe diameters the user selected',()=>{
 for(const [main,lat] of [[90,32],[110,50],[50,25]]){
  const plan=automaticPlan(initial(),{...base,mainDiameter:main,lateralDiameter:lat,hydraulics:{...hydraulicDefaults}},{width:120,height:200});
  const lines=plan.items.filter(i=>i.a);const mains=lines.filter(i=>i.a.x===i.b.x),laterals=lines.filter(i=>i.a.y===i.b.y);
  assert.ok(mains.length&&laterals.length);
  assert.ok(mains.every(i=>i.diameter===main),`ana hat ${main}`);assert.ok(laterals.every(i=>i.diameter===lat),`yan hat ${lat}`);
  const labels=billOfMaterials(plan).map(r=>r.label).join('|');assert.ok(labels.includes(`Ø${main} mm`)&&labels.includes(`Ø${lat} mm`),labels);
  assert.ok(!labels.includes('Ø63 mm')||main===63||lat===63);
 }
});
test('auto sizing only enlarges an undersized choice',()=>{
 const plan=automaticPlan(initial(),{...base,mainDiameter:200,lateralDiameter:50,hydraulics:{...hydraulicDefaults,autoDiameter:true}},{width:120,height:200});
 assert.ok(plan.items.filter(i=>i.a&&i.a.x===i.b.x).every(i=>i.diameter===200));
});
test('chat auto layout uses selected diameters',()=>{
 const r=autoLayout(rectangle(100,60),{spacing:12,mode:'drip',mainDiameter:75,lateralDiameter:20});
 assert.ok(r.items.filter(i=>i.kind==='pipe').every(i=>i.diameter===75));assert.ok(r.items.filter(i=>i.kind==='drip').every(i=>i.diameter===20));
});
